# Rsbuild project

## Setup

Install the dependencies:

```bash
npm install
```

## Get started

Start the dev server:

```bash
npm run dev
```

Build the app for production:

```bash
npm run build
```

Preview the production build locally:

```bash
npm run preview
```

Start Storybook:

```bash
npm run storybook
```

Build Storybook:

```bash
npm run build:storybook
```

Format the code:

```bash
npm run format
```

Check code formatting:

```bash
npm run format:check
```

Write code formatting:

```bash
npm run format:write
```

Lint the code:

```bash
npm run lint
```

Clean the dist folder:

```bash
npm run clean
```

Clean node_modules:

```bash
npm run clean:node-modules
```

Run tests:

```bash
npm run test
```
