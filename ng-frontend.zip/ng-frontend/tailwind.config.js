import { heroui } from '@aisera-ui/react';

// Paths to scan the content for classes
const contentPaths = [
  './src/**/*.{html,js,ts,jsx,tsx}',
  './node_modules/@aisera-ui/theme/dist/**/*.{js,ts,jsx,tsx}',
  './node_modules/@aisera-ui/sidebar/dist/**/*.{js,ts,jsx,tsx}',
  './node_modules/@aisera-ui/app-shell/dist/**/*.{js,ts,jsx,tsx}',
  './node_modules/@aisera-ui/general-filter/dist/**/*.{js,ts,jsx,tsx}',
  './node_modules/@aisera-ui/table-controller/dist/**/*.{js,ts,jsx,tsx}',
  './node_modules/@aisera-ui/advanced-data-table/dist/**/*.{js,ts,jsx,tsx}',
  './node_modules/@aisera-ui/data-table/dist/**/*.{js,ts,jsx,tsx}',
];

/** @type {import('tailwindcss').Config} */
export default {
  content: contentPaths,
  purge: contentPaths,
  theme: {
    extend: {},
  },
  plugins: [
    heroui({
      layout: {
        radius: {
          small: '5px', // rounded-small
          medium: '12px', // rounded-medium
          large: '12px', // rounded-large
        },
      },
    }),
  ],
};
