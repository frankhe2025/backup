#!/bin/bash

# Read the NG Frontend template file and substitute environment variables
envsubst '$ng_backend_uri' < /app/nginx.conf.template > /nginx/nginx.conf

# Start Nginx
nginx -c /nginx/nginx.conf -e /dev/stderr -g "daemon off;"
