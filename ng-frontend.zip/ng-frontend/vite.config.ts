import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { sentryVitePlugin } from '@sentry/vite-plugin';
const DEFAULT_PORT = 3001;

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const enableSentry = env.ENABLE_SENTRY === 'true' && env.SENTRY_AUTH_TOKEN;
  const plugins = [react()];

  if (enableSentry) plugins.push(sentryPlugin(env));

  return {
    base: env.PUBLIC_PATH || '',
    plugins,
    define: {
      'process.env.NODE_ENV': JSON.stringify(mode),
      'process.env.PUBLIC_NG_GA_MEASUREMENT_ID': JSON.stringify(env.PUBLIC_NG_GA_MEASUREMENT_ID),
      'process.env.ENABLE_SENTRY': JSON.stringify(enableSentry),
      'process.env.SENTRY_DSN': JSON.stringify(env.SENTRY_DSN_NG_FRONTEND),
      'process.env.CLUSTER': JSON.stringify(env.CLUSTER),
      'process.env.NAMESPACE': JSON.stringify(env.NAMESPACE),
      'process.env.IMAGE_TAG': JSON.stringify(env.IMAGE_TAG),
      'process.env.PUBLIC_PATH': JSON.stringify(env.PUBLIC_PATH || ''),
      'process.env.PUBLIC_BACKEND_HOST_URL': JSON.stringify(env.PUBLIC_BACKEND_HOST_URL || '/api/'),
    },
    server: {
      port: parseInt(process.env.PORT || DEFAULT_PORT.toString()),
      strictPort: true,
      proxy: {
        [env.PUBLIC_BACKEND_HOST_URL || '/api']: {
          target: 'http://localhost:9000',
          changeOrigin: true,
          rewrite: (path) => path.replace(new RegExp(`^${env.PUBLIC_BACKEND_HOST_URL || '/api'}`), '/'),
        },
        '/socket.io': {
          target: 'http://localhost:9000',
          changeOrigin: true,
          ws: true,
          secure: false,
        },
      },
    },
    build: {
      target: 'es2022',
      sourcemap: !!enableSentry,
    },
  };
});

const sentryPlugin = (env) => {
  return sentryVitePlugin({
    authToken: env.SENTRY_AUTH_TOKEN,
    org: 'aisera-org',
    project: 'ng-frontend',
    release: {
      name: env.IMAGE_TAG,
    },
    sourcemaps: {
      filesToDeleteAfterUpload: ['dist/**/*.js.map'],
    },
    telemetry: false,
  });
};
