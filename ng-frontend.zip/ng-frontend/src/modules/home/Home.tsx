import { useEffect } from 'react';
import getRbacService from '../../commons/modules/auth/service/rbac.service.ts';

export const Home = () => {
  useEffect(() => {
    console.log('Home page');
    getRbacService().getEntityAccesses();
  }, []);
  return <div>Home</div>;
};
