import { Prompt } from '../prompt.entity';

describe('Prompt Entity', () => {
  it('should create a Prompt with default values', () => {
    const prompt = new Prompt({});

    expect(prompt.id).toBe(0);
    expect(prompt.name).toBe('');
    expect(prompt.promptText).toBe('');
  });

  it('should create a Prompt with provided values', () => {
    const data = {
      id: 123,
      name: 'Test Prompt',
      promptText: 'This is a test prompt',
    };

    const prompt = new Prompt(data);

    expect(prompt.id).toBe(123);
    expect(prompt.name).toBe('Test Prompt');
    expect(prompt.promptText).toBe('This is a test prompt');
  });

  it('should calculate source property correctly', () => {
    // When sourceType is provided
    const promptWithSourceType = new Prompt({
      sourceType: 'Custom',
    });
    expect(promptWithSourceType.source).toBe('Custom');

    // When system is true
    const systemPrompt = new Prompt({
      system: true,
    });
    expect(systemPrompt.source).toBe('System');

    // When system is false
    const userPrompt = new Prompt({
      system: false,
    });
    expect(userPrompt.source).toBe('User');
  });

  it('should calculate model property correctly', () => {
    // With model info
    const prompt = new Prompt({
      modelId: 123,
    });

    // Without model info
    expect(prompt.model).toBe('Model ID: 123');

    // With model info
    prompt.setModelInfo({
      displayName: 'GPT-4',
    });
    expect(prompt.model).toBe('GPT-4');
  });

  it('should calculate isDraft property correctly', () => {
    const publishedPrompt = new Prompt({
      state: 'Published',
    });
    expect(publishedPrompt.isDraft).toBe(false);

    const draftPrompt = new Prompt({
      state: 'Draft',
    });
    expect(draftPrompt.isDraft).toBe(true);
  });
});
