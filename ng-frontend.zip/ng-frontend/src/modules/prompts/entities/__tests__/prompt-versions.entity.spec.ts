import { PromptVersionsCollection } from '../prompt-versions.entity';
import { PromptReviewStatus } from '../prompt-review-status.enum';

const makeInput = (id: number, date: string, name?: string, desc?: string, userName?: string) => ({
  entityId: id,
  name: name ?? null,
  description: desc ?? null,
  date,
  lastUpdateUserId: 'uid',
  lastUpdateUserName: userName ?? 'Bob',
});

describe('PromptVersionsCollection', () => {
  const mockData = {
    draftVersion: makeInput(1, '2024-01-01T12:00:00Z'),
    publishedVersion: makeInput(2, '2023-12-01T12:00:00Z'),
    archivedVersions: [makeInput(3, '2023-10-01T12:00:00Z'), makeInput(4, '2023-11-01T12:00:00Z')],
  };

  let collection: PromptVersionsCollection;

  beforeEach(() => {
    collection = new PromptVersionsCollection(mockData);
  });

  it('should return all versions', () => {
    const all = collection.all;
    expect(all.length).toBe(4);
    expect(all.map((v) => v.entityId)).toEqual([1, 2, 3, 4]);
  });

  it('should filter drafts', () => {
    const drafts = collection.drafts;
    expect(drafts.length).toBe(1);
    expect(drafts[0].status).toBe(PromptReviewStatus.DRAFT);
  });

  it('should filter published', () => {
    const published = collection.published;
    expect(published.length).toBe(1);
    expect(published[0].status).toBe(PromptReviewStatus.PUBLISHED);
  });

  it('should filter archived', () => {
    const archived = collection.archived;
    expect(archived.length).toBe(2);
    expect(archived.every((v) => v.status === PromptReviewStatus.ARCHIVE)).toBe(true);
  });

  it('should sort versions by date descending', () => {
    const sorted = collection.sortedByDate;
    const timestamps = sorted.map((v) => new Date(v.date).getTime());
    const isDescending = timestamps.every((val, i, arr) => i === 0 || val <= arr[i - 1]);
    expect(isDescending).toBe(true);
  });
});
