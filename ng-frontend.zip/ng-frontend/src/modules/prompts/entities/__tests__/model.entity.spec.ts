import ModelInfo from '../model.entity';

describe('ModelInfo', () => {
  describe('constructor', () => {
    it('should create an instance with default values when no data is provided', () => {
      const model = new ModelInfo();

      expect(model.id).toBe(0);
      expect(model.name).toBe('');
      expect(model.displayName).toBe('');
      expect(model.provider).toBe('');
      expect(model.configFields).toEqual([]);
      expect(model.version).toBe('');
      expect(model.maxTokens).toBe(0);
      expect(model.contextWindow).toBe(0);
      expect(model.isDefault).toBe(false);
    });

    it('should create an instance with provided values', () => {
      const data = {
        id: 123,
        name: 'gpt-4',
        displayName: 'GPT-4',
        provider: 'OpenAI',
        configFields: [{ name: 'temperature', type: 'number' }],
        version: '1.0',
        maxTokens: 4096,
        contextWindow: 8192,
        isDefault: true,
      };

      const model = new ModelInfo(data);

      expect(model.id).toBe(123);
      expect(model.name).toBe('gpt-4');
      expect(model.displayName).toBe('GPT-4');
      expect(model.provider).toBe('OpenAI');
      expect(model.configFields).toEqual([{ name: 'temperature', type: 'number' }]);
      expect(model.version).toBe('1.0');
      expect(model.maxTokens).toBe(4096);
      expect(model.contextWindow).toBe(8192);
      expect(model.isDefault).toBe(true);
    });
  });

  describe('displayValue', () => {
    it('should return provider and displayName when provider exists', () => {
      const model = new ModelInfo({
        id: 1,
        provider: 'OpenAI',
        displayName: 'GPT-4',
      });

      expect(model.displayValue).toBe('OpenAI - GPT-4');
    });

    it('should return just displayName when provider does not exist', () => {
      const model = new ModelInfo({
        id: 1,
        displayName: 'GPT-4',
      });

      expect(model.displayValue).toBe('GPT-4');
    });

    it('should return model ID when no displayName or provider exists', () => {
      const model = new ModelInfo({
        id: 1,
      });

      expect(model.displayValue).toBe('Model ID: 1');
    });
  });

  describe('fromApiResponse', () => {
    it('should create a ModelInfo instance from API response data', () => {
      const apiResponse = {
        id: 123,
        name: 'gpt-4',
        displayName: 'GPT-4',
        provider: 'OpenAI',
        configFields: [{ name: 'temperature', type: 'number' }],
        version: '1.0',
        maxTokens: 4096,
        contextWindow: 8192,
        isDefault: true,
      };

      const model = ModelInfo.fromApiResponse(apiResponse);

      expect(model).toBeInstanceOf(ModelInfo);
      expect(model.id).toBe(123);
      expect(model.name).toBe('gpt-4');
      expect(model.displayName).toBe('GPT-4');
      expect(model.provider).toBe('OpenAI');
    });

    it('should handle missing fields in API response', () => {
      const apiResponse = {
        id: 123,
      };

      const model = ModelInfo.fromApiResponse(apiResponse);

      expect(model).toBeInstanceOf(ModelInfo);
      expect(model.id).toBe(123);
      expect(model.name).toBe('');
      expect(model.displayName).toBe('');
      expect(model.provider).toBe('');
      expect(model.configFields).toEqual([]);
      expect(model.version).toBe('');
      expect(model.maxTokens).toBe(0);
      expect(model.contextWindow).toBe(0);
      expect(model.isDefault).toBe(false);
    });
  });
});
