import { PromptVersion, IVersionInput } from '../prompt-version.entity';
import { PromptReviewStatus } from '../prompt-review-status.enum';

describe('PromptVersion', () => {
  const baseInput: IVersionInput = {
    entityId: 1,
    name: null,
    description: null,
    date: '2024-01-01T10:30:00.000Z',
    lastUpdateUserId: 'user123',
    lastUpdateUserName: 'Alice',
  };

  it('should initialize with fallback name and description', () => {
    const version = new PromptVersion(baseInput, PromptReviewStatus.DRAFT);

    expect(version.entityId).toBe(1);
    expect(version.name).toBe('New Version');
    expect(version.description).toBe('N/A');
    expect(version.editor).toBe('Alice');
  });

  it('should format date correctly', () => {
    const version = new PromptVersion(baseInput, PromptReviewStatus.DRAFT);
    const formattedDate = new Date(baseInput.date).toLocaleString('en-US', {
      month: 'numeric',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    expect(version.date).toBe(formattedDate);
  });

  it('should return correct color classes', () => {
    expect(PromptVersion.getStatusColor(PromptReviewStatus.DRAFT)).toBe('text-warning-500 ');
    expect(PromptVersion.getStatusColor(PromptReviewStatus.DRAFT, true)).toBe('text-warning-500 bg-warning-50');
    expect(PromptVersion.getStatusColor(PromptReviewStatus.PUBLISHED)).toBe('text-success-600 ');
    expect(PromptVersion.getStatusColor(PromptReviewStatus.PUBLISHED, true)).toBe('text-success-600 bg-success-50');
    expect(PromptVersion.getStatusColor(PromptReviewStatus.ARCHIVE)).toBe('text-default-800');
  });

  it('should return colorClass and colorClassWithBackground correctly', () => {
    const version = new PromptVersion(baseInput, PromptReviewStatus.DRAFT);
    expect(version.colorClass).toBe(PromptVersion.getStatusColor(PromptReviewStatus.DRAFT));
    expect(version.colorClassWithBackground).toBe(PromptVersion.getStatusColor(PromptReviewStatus.DRAFT, true));
  });
});
