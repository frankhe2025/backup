import { Prompt } from '../prompt.entity';

describe('Prompt', () => {
  describe('constructor', () => {
    it('should create an instance with default values when no data is provided', () => {
      const prompt = new Prompt({});

      expect(prompt.id).toBe(0);
      expect(prompt.name).toBe('');
      expect(prompt.promptText).toBe('');
      expect(prompt.status).toBe('');
      expect(prompt.type).toBe('');
      expect(prompt.inputVariables).toEqual([]);
      expect(prompt.outputVariables).toEqual([]);
    });

    it('should create an instance with provided values', () => {
      const data = {
        id: 123,
        name: 'Test Prompt',
        promptText: 'Hello {{name}}',
        status: 'Active',
        type: 'Default',
        sourceType: 'System',
        scope: 'Global',
      };

      const prompt = new Prompt(data);

      expect(prompt.id).toBe(123);
      expect(prompt.name).toBe('Test Prompt');
      expect(prompt.promptText).toBe('Hello {{name}}');
      expect(prompt.status).toBe('Active');
      expect(prompt.type).toBe('Default');
      expect(prompt.sourceType).toBe('System');
      expect(prompt.scope).toBe('Global');
    });
  });

  describe('source getter', () => {
    it('should return sourceType if it exists', () => {
      const prompt = new Prompt({
        sourceType: 'Custom',
      });

      expect(prompt.source).toBe('Custom');
    });

    it('should return "System" if system flag is true and no sourceType', () => {
      const prompt = new Prompt({
        system: true,
      });

      expect(prompt.source).toBe('System');
    });

    it('should return "User" if system flag is false and no sourceType', () => {
      const prompt = new Prompt({
        system: false,
      });

      expect(prompt.source).toBe('User');
    });
  });

  describe('model getter', () => {
    it('should return model display name if _modelInfo exists', () => {
      const prompt = new Prompt({
        modelId: 123,
      });

      prompt.setModelInfo({
        displayName: 'GPT-4',
      });

      expect(prompt.model).toBe('GPT-4');
    });

    it('should return modelId if _modelInfo does not exist', () => {
      const prompt = new Prompt({
        modelId: 123,
      });

      expect(prompt.model).toBe('Model ID: 123');
    });
  });

  describe('lastUpdated getter', () => {
    it('should return a Date object if updatedAt exists', () => {
      const timestamp = 1619812800000; // May 1, 2021
      const prompt = new Prompt({
        updatedAt: timestamp,
      });

      expect(prompt.lastUpdated).toBeInstanceOf(Date);
      expect(prompt.lastUpdated?.getTime()).toBe(timestamp);
    });

    it('should return null if updatedAt does not exist', () => {
      const prompt = new Prompt({});

      expect(prompt.lastUpdated).toBeNull();
    });
  });

  describe('updatedByObj getter', () => {
    it('should return an object with user info if updatedBy exists', () => {
      const prompt = new Prompt({
        updatedBy: 'John Doe',
        updatedByEmail: 'john@example.com',
      });

      expect(prompt.updatedByObj).toEqual({
        name: 'John Doe',
        email: 'john@example.com',
        avatarUrl: '',
      });
    });

    it('should use updatedByEmail for name if updatedBy is missing', () => {
      const prompt = new Prompt({
        updatedByEmail: 'john@example.com',
      });

      expect(prompt.updatedByObj).toEqual({
        name: 'john@example.com',
        email: 'john@example.com',
        avatarUrl: '',
      });
    });

    it('should return null if both updatedBy and updatedByEmail are missing', () => {
      const prompt = new Prompt({});

      expect(prompt.updatedByObj).toBeNull();
    });
  });

  describe('isDraft getter', () => {
    it('should return true if state is not "Published"', () => {
      const prompt = new Prompt({
        state: 'Draft',
      });

      expect(prompt.isDraft).toBe(true);
    });

    it('should return false if state is "Published"', () => {
      const prompt = new Prompt({
        state: 'Published',
      });

      expect(prompt.isDraft).toBe(false);
    });
  });

  describe('template getter', () => {
    it('should return promptText', () => {
      const prompt = new Prompt({
        promptText: 'Hello {{name}}',
      });

      expect(prompt.template).toBe('Hello {{name}}');
    });

    it('should return empty string if promptText is missing', () => {
      const prompt = new Prompt({});

      expect(prompt.template).toBe('');
    });
  });

  describe('script getter', () => {
    it('should return transformationScript', () => {
      const prompt = new Prompt({
        transformationScript: 'function transform(data) { return data; }',
      });

      expect(prompt.script).toBe('function transform(data) { return data; }');
    });

    it('should return empty string if transformationScript is missing', () => {
      const prompt = new Prompt({});

      expect(prompt.script).toBe('');
    });
  });

  describe('getColumns', () => {
    it('should return an array of column configurations', () => {
      const prompt = new Prompt({});
      const columns = prompt.getColumns();

      expect(Array.isArray(columns)).toBe(true);
      expect(columns.length).toBeGreaterThan(0);

      // Check that it has the expected columns
      const columnKeys = columns.map((col) => col.key);
      expect(columnKeys).toContain('name');
      expect(columnKeys).toContain('source');
      expect(columnKeys).toContain('type');
      expect(columnKeys).toContain('scope');
      expect(columnKeys).toContain('model');
      expect(columnKeys).toContain('status');
      expect(columnKeys).toContain('updatedAt');
      expect(columnKeys).toContain('isDraft');
    });
  });
});
