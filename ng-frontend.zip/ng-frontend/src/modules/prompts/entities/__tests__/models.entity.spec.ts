import Models from '../models.entity';
import ModelInfo from '../model.entity';

describe('Models', () => {
  describe('constructor', () => {
    it('should create an instance with default values when no data is provided', () => {
      const models = new Models();

      expect(models.models).toEqual([]);
      expect(models.count).toBe(0);
    });

    it('should create an instance with provided values', () => {
      const modelInfo1 = new ModelInfo({ id: 1, name: 'Model 1' });
      const modelInfo2 = new ModelInfo({ id: 2, name: 'Model 2' });

      const modelsData = {
        models: [modelInfo1, modelInfo2],
        count: 2,
      };

      const models = new Models(modelsData);

      expect(models.models).toHaveLength(2);
      expect(models.models[0]).toBe(modelInfo1);
      expect(models.models[1]).toBe(modelInfo2);
      expect(models.count).toBe(2);
    });

    it('should convert plain objects to ModelInfo instances', () => {
      const modelsData = {
        models: [
          { id: 1, name: 'Model 1' },
          { id: 2, name: 'Model 2' },
        ],
        count: 2,
      };

      const models = new Models(modelsData);

      expect(models.models).toHaveLength(2);
      expect(models.models[0]).toBeInstanceOf(ModelInfo);
      expect(models.models[1]).toBeInstanceOf(ModelInfo);
      expect(models.models[0].id).toBe(1);
      expect(models.models[1].id).toBe(2);
      expect(models.count).toBe(2);
    });
  });

  describe('getById', () => {
    it('should return the model with the matching ID', () => {
      const models = new Models({
        models: [new ModelInfo({ id: 1, name: 'Model 1' }), new ModelInfo({ id: 2, name: 'Model 2' })],
      });

      const model = models.getById(2);

      expect(model).toBeDefined();
      expect(model?.id).toBe(2);
      expect(model?.name).toBe('Model 2');
    });

    it('should return undefined if no model has the matching ID', () => {
      const models = new Models({
        models: [new ModelInfo({ id: 1, name: 'Model 1' }), new ModelInfo({ id: 2, name: 'Model 2' })],
      });

      const model = models.getById(3);

      expect(model).toBeUndefined();
    });
  });

  describe('getModelMap', () => {
    it('should return a map of models indexed by ID', () => {
      const model1 = new ModelInfo({ id: 1, name: 'Model 1' });
      const model2 = new ModelInfo({ id: 2, name: 'Model 2' });

      const models = new Models({
        models: [model1, model2],
      });

      const modelMap = models.getModelMap();

      expect(modelMap).toBeInstanceOf(Map);
      expect(modelMap.size).toBe(2);
      expect(modelMap.get(1)).toBe(model1);
      expect(modelMap.get(2)).toBe(model2);
    });

    it('should return an empty map if there are no models', () => {
      const models = new Models();

      const modelMap = models.getModelMap();

      expect(modelMap).toBeInstanceOf(Map);
      expect(modelMap.size).toBe(0);
    });
  });

  describe('fromApiResponse', () => {
    it('should create a Models instance from API response with models array', () => {
      const apiResponse = {
        models: [
          { id: 1, name: 'Model 1', provider: 'OpenAI' },
          { id: 2, name: 'Model 2', provider: 'Anthropic' },
        ],
      };

      const models = Models.fromApiResponse(apiResponse);

      expect(models).toBeInstanceOf(Models);
      expect(models.models).toHaveLength(2);
      expect(models.models[0]).toBeInstanceOf(ModelInfo);
      expect(models.models[1]).toBeInstanceOf(ModelInfo);
      expect(models.models[0].id).toBe(1);
      expect(models.models[1].id).toBe(2);
      expect(models.count).toBe(2);
    });

    it('should handle API response with a single model (not in array)', () => {
      const apiResponse = {
        id: 1,
        name: 'Model 1',
        provider: 'OpenAI',
      };

      const models = Models.fromApiResponse(apiResponse);

      expect(models).toBeInstanceOf(Models);
      expect(models.models).toHaveLength(1);
      expect(models.models[0]).toBeInstanceOf(ModelInfo);
      expect(models.models[0].id).toBe(1);
      expect(models.count).toBe(1);
    });

    it('should handle empty or undefined API response', () => {
      const emptyModels = Models.fromApiResponse(undefined);
      expect(emptyModels).toBeInstanceOf(Models);
      expect(emptyModels.models).toHaveLength(0);
      expect(emptyModels.count).toBe(0);

      const nullModels = Models.fromApiResponse(null);
      expect(nullModels).toBeInstanceOf(Models);
      expect(nullModels.models).toHaveLength(0);
      expect(nullModels.count).toBe(0);
    });
  });
});
