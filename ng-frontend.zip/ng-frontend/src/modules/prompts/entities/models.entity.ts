import ModelInfo from './model.entity';

export class Models {
  models: ModelInfo[] = [];
  count: number = 0;

  constructor(data?: Partial<Models>) {
    if (data) {
      this.count = data.count || 0;
      if (data.models) {
        this.models = data.models.map((model) => {
          if (model instanceof ModelInfo) {
            return model;
          }
          return new ModelInfo(model);
        });
      }
    }
  }

  getById(id: number): ModelInfo | undefined {
    return this.models.find((model) => model.id === id);
  }

  getModelMap(): Map<number, ModelInfo> {
    const modelMap = new Map<number, ModelInfo>();
    this.models.forEach((model) => {
      modelMap.set(model.id, model);
    });
    return modelMap;
  }

  static fromApiResponse(data: any): Models {
    if (!data) return new Models();

    let modelsData = data.models || data;
    if (!Array.isArray(modelsData)) {
      modelsData = [modelsData];
    }

    const models = modelsData.map((modelData: any) => {
      return ModelInfo.fromApiResponse(modelData);
    });

    return new Models({
      models,
      count: models.length,
    });
  }
}

export default Models;
