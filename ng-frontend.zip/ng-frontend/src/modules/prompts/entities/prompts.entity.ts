import { Prompt } from './prompt.entity';

export class Prompts {
  prompts: Prompt[] = [];

  constructor(response: any) {
    const items = Array.isArray(response) ? response : response && response.items ? response.items : [];

    if (Array.isArray(items) && items.length > 0) {
      console.log(`Processing ${items.length} prompts`);
      items.forEach((item) => {
        this.prompts.push(new Prompt(item));
      });
    } else {
      console.warn('No valid prompt items found in response:', response);
    }
  }

  getRows() {
    return this.prompts;
  }

  getColumns(): any {
    if (this.prompts.length === 0) {
      return [
        { key: 'name', label: 'Name' },
        { key: 'displayName', label: 'Display Name' },
        { key: 'sourceType', label: 'Source' },
        { key: 'type', label: 'Type' },
        { key: 'scope', label: 'Scope' },
        { key: 'modelId', label: 'Model ID' },
        { key: 'status', label: 'Status' },
        { key: 'state', label: 'State' },
      ];
    }
    return this.prompts[0].getColumns();
  }

  getProcessedData(): any[] {
    return this.prompts.map((item) => {
      const processedItem: Record<string, any> = { ...item };

      if (processedItem.updatedAt) {
        try {
          const timestamp =
            typeof processedItem.updatedAt === 'string' ? parseInt(processedItem.updatedAt) : processedItem.updatedAt;

          const date = new Date(timestamp);
          if (!isNaN(date.getTime())) {
            processedItem.updatedAt = date;
          }
        } catch (e) {
          console.warn('Error formatting updatedAt:', e);
        }
      }

      if (processedItem.isDraft !== undefined) {
        processedItem.isDraft = processedItem.isDraft ? 'Yes' : 'No';
      }

      if (processedItem.updatedBy && !processedItem.updatedByEmail) {
        processedItem.updatedByEmail = processedItem.updatedBy;
      }

      if (processedItem._modelInfo) {
        processedItem.model = processedItem._modelInfo.provider;
      }

      return processedItem;
    });
  }

  getPrompById(id: number): Prompt | undefined {
    return this.prompts.find((prompt) => prompt.id === id);
  }
}
