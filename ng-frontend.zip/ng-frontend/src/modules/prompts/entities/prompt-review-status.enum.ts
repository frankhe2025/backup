export enum PromptReviewStatus {
  DRAFT = 'Draft',
  PUBLISHED = 'Published',
  ARCHIVE = 'Archived',
}
