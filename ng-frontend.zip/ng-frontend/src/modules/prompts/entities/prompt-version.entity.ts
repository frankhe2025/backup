import { PromptReviewStatus } from './prompt-review-status.enum';

export interface IVersionInput {
  entityId: number;
  name: string | null;
  description: string | null;
  date: string;
  lastUpdateUserId: string;
  lastUpdateUserName: string;
}

export class PromptVersion {
  readonly entityId: number;
  readonly status: PromptReviewStatus;
  readonly name: string;
  readonly description: string;
  readonly date: string;
  readonly editor: string;

  constructor(input: IVersionInput, status: PromptReviewStatus) {
    this.entityId = input.entityId;
    this.status = status;
    this.name = input.name ?? 'New Version';
    this.description = input.description ?? 'N/A';
    this.date = PromptVersion.formatDate(input.date);
    this.editor = input.lastUpdateUserName;
  }

  static formatDate(input: string): string {
    const date = new Date(input);
    return date.toLocaleString('en-US', {
      month: 'numeric',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  }

  static getStatusColor(status: PromptReviewStatus, showBGColor?: boolean): string {
    switch (status) {
      case PromptReviewStatus.DRAFT:
        return `text-warning-500 ${showBGColor ? 'bg-warning-50' : ''}`;
      case PromptReviewStatus.PUBLISHED:
        return `text-success-600 ${showBGColor ? 'bg-success-50' : ''}`;
      default:
        return 'text-default-800';
    }
  }

  get colorClass(): string {
    return PromptVersion.getStatusColor(this.status);
  }

  get colorClassWithBackground(): string {
    return PromptVersion.getStatusColor(this.status, true);
  }
}
