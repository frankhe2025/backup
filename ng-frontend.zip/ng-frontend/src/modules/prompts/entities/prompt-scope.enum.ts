export enum PromptScope {
  GLOBAL = 'global',
  APPLICATION = 'application',
  TENANT = 'tenant',
}
