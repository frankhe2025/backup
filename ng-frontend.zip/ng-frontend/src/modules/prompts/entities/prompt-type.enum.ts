export enum PromptType {
  DEFAULT = 'Default',
  CUSTOM = 'Custom',
  TUNED = 'Tuned',
}
