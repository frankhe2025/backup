export class ModelInfo {
  id: number = 0;
  name: string = '';
  displayName: string = '';
  provider: string = '';
  configFields: any[] = [];
  version: string = '';
  maxTokens: number = 0;
  contextWindow: number = 0;
  isDefault: boolean = false;

  constructor(data?: Partial<ModelInfo>) {
    if (data) {
      Object.assign(this, data);
    }
  }

  get displayValue(): string {
    return this.provider ? `${this.provider} - ${this.displayName}` : this.displayName || `Model ID: ${this.id}`;
  }

  static fromApiResponse(data: any): ModelInfo {
    return new ModelInfo({
      id: data.id,
      name: data.name || '',
      displayName: data.displayName || data.name || '',
      provider: data.provider || '',
      configFields: data.configFields || [],
      version: data.version || '',
      maxTokens: data.maxTokens || 0,
      contextWindow: data.contextWindow || 0,
      isDefault: data.isDefault || false,
    });
  }
}

export default ModelInfo;
