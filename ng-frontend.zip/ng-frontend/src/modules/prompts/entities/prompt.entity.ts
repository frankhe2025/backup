export class Prompt {
  id: number = 0;
  name: string = '';
  displayName: string = '';
  promptText: string = '';
  tenantId: number | null = null;
  botId: number | null = null;
  modelId: number | null = null;
  status: string = '';
  type: string = '';
  useCase: string | null = null;
  inputVariables: any[] = [];
  outputVariables: any[] = [];
  modelConfig: any = null;
  transformationScript: string | null = null;
  category: string = '';
  createdAt: number | null = null;
  updatedAt: number | null = null;
  userRequest: string | null = null;
  description: string | null = null;
  scope: string = '';
  entityGuid: string | null = null;
  reviewStatus: string = '';
  changeLogId: string | null = null;
  userId: string | null = null;
  createdBy: string | null = null;
  createdByEmail: string | null = null;
  updatedBy: string | null = null;
  updatedByEmail: string | null = null;
  state: string = '';
  system: boolean = false;
  default: boolean = false;
  imported: boolean = false;
  sourceType: string = '';

  private _modelInfo: any = null;
  private subscribers: Array<() => void> = [];
  private _originalValues: Record<string, any> = {};

  get source(): string {
    return this.sourceType || (this.system ? 'System' : 'User');
  }

  get model(): string {
    return this._modelInfo?.displayName || `Model ID: ${this.modelId}`;
  }

  get lastUpdated(): Date | null {
    return this.updatedAt ? new Date(this.updatedAt) : null;
  }

  get updatedByObj(): { name: string; email: string; avatarUrl: string } | null {
    if (!this.updatedByEmail && !this.updatedBy) return null;
    return {
      name: this.updatedBy || this.updatedByEmail || '',
      email: this.updatedByEmail || '',
      avatarUrl: '',
    };
  }

  get isDraft(): boolean {
    return this.state !== 'Published';
  }

  get template(): string {
    return this.promptText || '';
  }

  get script(): string {
    return this.transformationScript || '';
  }

  constructor(data: any) {
    if (data) {
      Object.keys(data).forEach((key) => {
        (this as any)[key] = data[key];
      });
    }
    this._saveOriginalValues();
  }

  // Snapshot the original values for change detection
  private _saveOriginalValues() {
    this._originalValues = {};
    Object.keys(this).forEach((key) => {
      if (!key.startsWith('_') && typeof this[key as keyof Prompt] !== 'function') {
        this._originalValues[key] = JSON.parse(JSON.stringify(this[key as keyof Prompt]));
      }
    });
  }

  //Subscribe to prompt changes
  subscribe(callback: () => void): () => void {
    this.subscribers.push(callback);
    return () => {
      this.subscribers = this.subscribers.filter((cb) => cb !== callback);
    };
  }

  //Update a field and notify all subscribers
  update(field: string, val: any): void {
    if (field in this) {
      (this as any)[field] = val;
      this.notifySubscribers();
    } else {
      console.warn(`Field '${field}' doesn't exist in Prompt`);
    }
  }

  // Tell all listeners about the change
  private notifySubscribers(): void {
    this.subscribers.forEach((cb) => cb());
  }

  // Check if any fields have changed
  hasChanges(): boolean {
    for (const key in this._originalValues) {
      if (JSON.stringify(this._originalValues[key]) !== JSON.stringify((this as any)[key])) {
        return true;
      }
    }
    return false;
  }

  // Create a deep copy of this prompt
  clone(): Prompt {
    const clonedData = JSON.parse(JSON.stringify(this));

    // Don't share subscribers between instances
    delete clonedData.subscribers;

    const clonedPrompt = new Prompt(clonedData);
    return clonedPrompt;
  }

  setModelInfo(modelInfo: any) {
    this._modelInfo = modelInfo;
  }

  getColumns(): any[] {
    return [
      { key: 'name', label: 'Name' },
      { key: 'source', label: 'Source' },
      { key: 'type', label: 'Type' },
      { key: 'scope', label: 'Scope' },
      { key: 'model', label: 'Model' },
      { key: 'status', label: 'Status' },
      { key: 'updatedAt', label: 'Last Updated' },
      { key: 'updatedByEmail', label: 'Updated by' },
      { key: 'isDraft', label: 'Draft' },
      { key: 'actions', label: 'Actions' },
    ];
  }
}
