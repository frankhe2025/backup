export enum PromptSourceType {
  SYSTEM = 'System',
  USER = 'User',
}
