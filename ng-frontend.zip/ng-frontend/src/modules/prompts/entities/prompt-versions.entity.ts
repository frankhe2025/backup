import { PromptReviewStatus } from './prompt-review-status.enum';
import { IVersionInput, PromptVersion } from './prompt-version.entity';

export interface PromptVersions {
  draftVersion?: IVersionInput;
  publishedVersion?: IVersionInput;
  archivedVersions?: IVersionInput[];
}

export type VersionType = 'draftVersion' | 'publishedVersion' | 'archivedVersions';

export class PromptVersionsCollection {
  private versions: PromptVersion[] = [];

  constructor(data: PromptVersions) {
    if (data?.draftVersion) {
      this.versions.push(new PromptVersion(data.draftVersion, PromptReviewStatus.DRAFT));
    }
    if (data?.publishedVersion) {
      this.versions.push(new PromptVersion(data.publishedVersion, PromptReviewStatus.PUBLISHED));
    }
    if (Array.isArray(data.archivedVersions)) {
      this.versions.push(...data.archivedVersions.map((item) => new PromptVersion(item, PromptReviewStatus.ARCHIVE)));
    }
  }

  get all(): PromptVersion[] {
    return this.versions;
  }

  get sortedByDate(): PromptVersion[] {
    return [...this.versions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  get drafts(): PromptVersion[] {
    return this.versions.filter((v) => v.status === PromptReviewStatus.DRAFT);
  }

  get published(): PromptVersion[] {
    return this.versions.filter((v) => v.status === PromptReviewStatus.PUBLISHED);
  }

  get archived(): PromptVersion[] {
    return this.versions.filter((v) => v.status === PromptReviewStatus.ARCHIVE);
  }
}
