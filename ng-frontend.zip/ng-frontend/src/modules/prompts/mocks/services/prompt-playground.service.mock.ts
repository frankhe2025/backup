import { IVersionInput } from '../../entities/prompt-version.entity';
import { PromptVersions, VersionType } from '../../entities/prompt-versions.entity';
import { Prompt } from '../../entities/prompt.entity';
import { PromptPlaygroundInterface } from '../../playground/prompt-playground.interface';

const mockPrompts: { [key: number]: Prompt } = {
  1: new Prompt({
    id: 1,
    name: 'Customer Support Agent',
    displayName: 'Customer Support Agent',
    promptText:
      'Act as a customer support agent.\nReturn a valid response JSON in the following format: {"requestCategory": str, "requestPreamble": str, "intents": [{"intent": str}, ...]}.',
    modelId: 1,
    status: 'Active',
    type: 'Chat',
    useCase: 'Customer Support',
    inputVariables: [
      { name: 'query', type: 'string', description: 'User query' },
      { name: 'context', type: 'string', description: 'Additional context' },
    ],
    outputVariables: [{ name: 'response', type: 'string', description: 'Response to user' }],
    systemMessage:
      'You are an AI assistant that helps customer support representatives respond to customer queries effectively.',
    modelConfig: {
      modelOptions: {
        temperature: 20,
        top_p: 0.9,
        max_tokens: 1000,
        presence_penalty: 10,
        frequency_penalty: 0,
      },
    },
  }),
  2: new Prompt({
    id: 2,
    name: 'Product Recommendation',
    displayName: 'Product Recommendation Engine',
    promptText:
      'Recommend products based on user preferences.\nReturn JSON in format: {"recommendations": [{"name": str, "reasons": [str]}]}',
    modelId: 2,
    status: 'Active',
    type: 'Completion',
    useCase: 'Product Recommendations',
    inputVariables: [
      { name: 'preferences', type: 'string', description: 'User preferences' },
      { name: 'history', type: 'string', description: 'Purchase history' },
    ],
    outputVariables: [{ name: 'recommendations', type: 'array', description: 'List of recommended products' }],
    systemMessage:
      'You are a product recommendation system that suggests relevant items based on user preferences and history.',
    modelConfig: {
      modelOptions: {
        temperature: 0,
        top_p: 0.9,
        max_tokens: 1000,
        presence_penalty: 0,
        frequency_penalty: 0,
      },
    },
  }),
};

const mockModels = [
  {
    id: 1,
    name: 'gpt-4',
    displayName: 'GPT-4',
    provider: 'OpenAI',
    maxTokens: 8192,
    temperature: 0.7,
    category: 'LLM',
  },
  {
    id: 2,
    name: 'claude-3-opus',
    displayName: 'Claude 3 Opus',
    provider: 'Anthropic',
    maxTokens: 100000,
    temperature: 0.5,
    category: 'LLM',
  },
];

export class PromptPlaygroundServiceMock implements PromptPlaygroundInterface {
  private mockPrompts: any[] = [];
  private mockVersions: PromptVersions = {};

  constructor() {
    console.log('PromptPlaygroundServiceMock: Initialized');
  }

  async getPromptById(promptId: number): Promise<Prompt> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const prompt = mockPrompts[promptId];
        if (prompt) {
          resolve(prompt);
        } else {
          const fallbackPrompt = new Prompt({
            id: promptId,
            entityGuid: `${promptId}`,
            name: `Dynamic Prompt ${promptId}`,
            displayName: `Dynamic Prompt ${promptId}`,
            promptText: `This is a dynamically generated prompt for ID ${promptId}`,
            status: 'Active',
            type: 'Chat',
            category: 'General',
            scope: 'bot',
            useCase: 'AgentAssist',
            description: 'This is a dynamically generated prompt.',
            inputVariables: [{ name: 'input', type: 'string', description: 'User input' }],
            outputVariables: [{ name: 'output', type: 'string', description: 'Generated output' }],
            systemMessage: `You are a demo assistant for prompt ID ${promptId}. Please provide helpful responses.`,
            modelConfig: {
              modelOptions: {
                temperature: 0.7,
                top_p: 0.9,
                max_tokens: 1000,
                presence_penalty: 0,
                frequency_penalty: 0,
              },
            },
          });
          resolve(fallbackPrompt);
        }
      }, 500);
    });
  }

  async getModels(): Promise<any[]> {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(mockModels);
      }, 500);
    });
  }

  async getModelById(modelId: number): Promise<any> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const model = mockModels.find((m) => m.id === modelId);
        if (model) {
          resolve(model);
        } else {
          reject(new Error(`Model with ID ${modelId} not found`));
        }
      }, 500);
    });
  }

  async executePrompt(
    promptId: number,
    userMessage?: string,
    modelId?: number | null,
    modelOptions?: Record<string, any>,
  ): Promise<any> {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log(
          'PromptPlaygroundServiceMock: Executing prompt',
          promptId,
          'with message:',
          userMessage,
          'using model:',
          modelId,
          'with options:',
          modelOptions,
        );

        let modelName = 'Default Model';
        if (modelId) {
          const model = mockModels.find((m) => m.id === modelId);
          if (model) {
            modelName = model.displayName || model.name;
          }
        }

        const mockResponse = {
          raw: `This is a mock response for prompt ID ${promptId} using model ${modelName}.\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.`,
          parsed: {
            requestCategory: 'Support Inquiry',
            requestPreamble: `I understand you need assistance with: ${userMessage || 'your request'}`,
            intents: ['Account access', 'Password reset'],
          },
        };

        resolve(mockResponse);
      }, 1500);
    });
  }

  async getVersions(entityGuid: string, promptId?: number): Promise<PromptVersions> {
    console.log('PromptPlaygroundServiceMock: Fetching versions', entityGuid);

    await new Promise((resolve) => setTimeout(resolve, 150));

    this.mockVersions = this.generateVersionsMockData(promptId || parseInt(entityGuid));

    return this.mockVersions;
  }

  async publishPrompt(promptId: number): Promise<Prompt> {
    console.log('PromptPlaygroundServiceMock: Publishing prompt by id:', promptId);

    await new Promise((resolve) => setTimeout(resolve, 200));

    this.updatePromptVersionsMock({
      promptId,
      action: 'publish',
      payload: {},
    });

    const foundPrompt = this.mockPrompts.find((p) => p.id === promptId);

    if (!foundPrompt) {
      const randomIndex = Math.floor(Math.random() * this.mockPrompts.length);
      const mockPrompt = {
        ...this.mockPrompts[randomIndex],
        id: promptId,
        entityGuid: `${promptId}`,
        name: `Dynamic Prompt ${promptId}`,
        displayName: `Dynamic Prompt ${promptId}`,
        promptText: `This is a dynamically generated prompt for ID ${promptId}`,
        reviewStatus: 'Published',
        state: 'Published',
        status: 'Active',
      };

      return new Prompt(mockPrompt);
    }

    return new Prompt(foundPrompt);
  }

  async updatePrompt(promptId: number, data: any): Promise<Prompt> {
    console.log('PromptPlaygroundServiceMock: Updating prompt by id:', promptId, 'with data:', data);

    await new Promise((resolve) => setTimeout(resolve, 200));

    if (data?.status === 'Archived') {
      this.updatePromptVersionsMock({
        promptId,
        action: 'deleteVersion',
        payload: {
          versionType: 'publishedVersion',
        },
      });
    }

    const foundPrompt = this.mockPrompts.find((p) => p.id === promptId);

    if (!foundPrompt) {
      const randomIndex = Math.floor(Math.random() * this.mockPrompts.length);
      const basePrompt = this.mockPrompts[randomIndex] || {};
      const mockPrompt = {
        ...basePrompt,
        ...data,
        id: promptId,
      };
      return new Prompt(mockPrompt);
    }

    const updatedPrompt = {
      ...foundPrompt,
      ...data,
    };

    return new Prompt(updatedPrompt);
  }

  async deletePrompt(promptId: number): Promise<Prompt> {
    console.log('PromptPlaygroundServiceMock: Deleting prompt by id:', promptId);

    await new Promise((resolve) => setTimeout(resolve, 200));

    const foundPrompt = this.mockPrompts.find((p) => p.id === promptId);

    if (!foundPrompt) {
      const randomIndex = Math.floor(Math.random() * this.mockPrompts.length);
      const mockPrompt = { ...this.mockPrompts[randomIndex], id: promptId };
      return new Prompt(mockPrompt);
    }

    return new Prompt(foundPrompt);
  }

  async deletePromptVersion(promptId: number): Promise<Prompt> {
    console.log('PromptPlaygroundServiceMock: Deleting prompt version by id:', promptId);

    await new Promise((resolve) => setTimeout(resolve, 200));

    const foundPrompt = this.mockPrompts.find((p) => p.id === promptId);

    if (!foundPrompt) {
      const randomIndex = Math.floor(Math.random() * this.mockPrompts.length);
      const mockPrompt = { ...this.mockPrompts[randomIndex], id: promptId };
      return new Prompt(mockPrompt);
    }

    return new Prompt(foundPrompt);
  }

  async createNewPrompt(data: any): Promise<Prompt> {
    console.log('PromptPlaygroundServiceMock: Creating new prompt by id:', data);

    await new Promise((resolve) => setTimeout(resolve, 200));

    const randomIndex = Math.floor(Math.random() * this.mockPrompts.length);
    const mockPrompt = { ...this.mockPrompts[randomIndex] };

    return new Prompt(mockPrompt);
  }

  async clonePrompt(promptId: number): Promise<Prompt> {
    console.log('PromptPlaygroundServiceMock: cloning the prompt by id:', promptId);

    await new Promise((resolve) => setTimeout(resolve, 200));

    const foundPrompt = this.mockPrompts.find((p) => p.id === promptId);

    if (!foundPrompt) {
      const randomIndex = Math.floor(Math.random() * this.mockPrompts.length);
      const mockPrompt = { ...this.mockPrompts[randomIndex], id: promptId };
      return new Prompt(mockPrompt);
    }

    return new Prompt(foundPrompt);
  }

  async createNewDraft(promptId: number): Promise<Prompt> {
    const newDraftPromptId = promptId + Math.floor(Math.random() * 10);

    console.log('PromptPlaygroundServiceMock: Creating new draft by id:', newDraftPromptId);

    await new Promise((resolve) => setTimeout(resolve, 200));

    this.updatePromptVersionsMock({
      promptId: newDraftPromptId,
      action: 'createDraft',
    });

    const foundPrompt = this.mockPrompts.find((p) => p.id === newDraftPromptId);

    if (!foundPrompt) {
      const randomIndex = Math.floor(Math.random() * this.mockPrompts.length);
      const mockPrompt = { ...this.mockPrompts[randomIndex], id: newDraftPromptId };
      return new Prompt(mockPrompt);
    }

    return new Prompt(foundPrompt);
  }

  async restorePrompt(promptId: number): Promise<Prompt> {
    console.log('PromptPlaygroundServiceMock: Restoring prompt by id:', promptId);
    const newDraftPromptId = promptId + Math.floor(Math.random() * 100);

    await new Promise((resolve) => setTimeout(resolve, 200));

    this.updatePromptVersionsMock({
      promptId: newDraftPromptId,
      action: 'createDraft',
    });

    const foundPrompt = this.mockPrompts.find((p) => p.id === newDraftPromptId);

    if (!foundPrompt) {
      const randomIndex = Math.floor(Math.random() * this.mockPrompts.length);
      const mockPrompt = { ...this.mockPrompts[randomIndex], id: newDraftPromptId };
      return new Prompt(mockPrompt);
    }

    return new Prompt(foundPrompt);
  }

  updatePromptVersionsMock = ({
    promptId,
    action,
    payload,
  }: {
    promptId: number;
    action: 'publish' | 'createDraft' | 'deleteVersion';
    payload?: {
      version?: IVersionInput;
      versionType?: VersionType;
      name?: string;
      description?: string;
      userId?: string;
      userName?: string;
    };
  }) => {
    const now = new Date().toISOString();

    const promptData = this.mockVersions ?? {
      draftVersion: undefined,
      publishedVersion: undefined,
      archivedVersions: [],
    };

    switch (action) {
      case 'publish': {
        const { name, description, userId, userName } = payload ?? {};

        if (!promptData.draftVersion) {
          throw new Error('No draft version to publish');
        }

        if (promptData.publishedVersion) {
          (promptData.archivedVersions ?? []).unshift({ ...promptData.publishedVersion });
        }

        promptData.publishedVersion = {
          ...promptData.draftVersion,
          name: name ?? promptData.draftVersion.name ?? 'New Version',
          description: description ?? null,
          date: now,
          lastUpdateUserId: userId ?? promptData.draftVersion.lastUpdateUserId,
          lastUpdateUserName: userName ?? promptData.draftVersion.lastUpdateUserName,
        };

        promptData.draftVersion = undefined;
        break;
      }

      case 'createDraft': {
        const { name, description, userId, userName } = payload ?? {};
        promptData.draftVersion = {
          entityId: promptId,
          name: name ?? null,
          description: description ?? null,
          date: now,
          lastUpdateUserId: userId ?? 'system',
          lastUpdateUserName: userName ?? 'system',
        };
        break;
      }

      case 'deleteVersion': {
        const { versionType } = payload ?? {};
        if (!versionType) return;

        if (versionType === 'archivedVersions') {
          (promptData.archivedVersions ?? []).shift();
        } else {
          const versionToDelete = promptData[versionType];
          if (versionToDelete) {
            (promptData.archivedVersions ?? []).unshift({
              ...versionToDelete,
              date: now,
            });
          }
          promptData[versionType] = undefined;
        }

        break;
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }
  };

  private generateVersionsMockData(promptId: number): PromptVersions {
    const isEmpty = !this.mockVersions || Object.keys(this.mockVersions).length === 0;
    // Initialize if not present

    if (isEmpty) {
      this.mockVersions = {
        draftVersion: {
          entityId: promptId,
          name: null,
          description: null,
          date: new Date().toISOString(),
          lastUpdateUserId: '1423317691103525971',
          lastUpdateUserName: 'mark.chen@aisera.com',
        },
        publishedVersion: undefined,
        archivedVersions: [],
      };
    }

    return this.mockVersions;
  }
}
