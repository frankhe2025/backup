import { PromptListServiceMock } from './prompt-list.service.mock';

describe('PromptListServiceMock', () => {
  it('getPromptLists()', async () => {
    const prompts = await new PromptListServiceMock().getPrompts();
    expect(prompts.prompts.length > 0).toBeTruthy();
  });
});
