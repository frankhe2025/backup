import { CategoryServiceInterface } from '../../services/category.interface';

export class CategoryServiceMock implements CategoryServiceInterface {
  private readonly categories: string[] = [
    'General',
    'Finance',
    'Healthcare',
    'Education',
    'Entertainment',
    'Travel',
    'Technology',
    'Sports',
    'Food',
    'Fashion',
    'Real Estate',
    'Automotive',
  ];

  async getCategories(tenantId?: number): Promise<string[]> {
    console.log('CategoryServiceMock: getCategories called with tenantId:', tenantId);
    return this.categories;
  }
}

export default CategoryServiceMock;
