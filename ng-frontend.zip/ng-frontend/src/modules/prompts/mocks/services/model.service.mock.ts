import { ModelServiceInterface } from '../../services/model.interface';
import Models from '../../entities/models.entity';
import ModelInfo from '../../entities/model.entity';

export class ModelServiceMock implements ModelServiceInterface {
  private mockModels: ModelInfo[] = [
    new ModelInfo({
      id: 200000,
      name: 'gpt-4',
      displayName: 'Azure Open AI Generic Job Chat Completions Prompt Group NC',
      provider: 'Microsoft Azure OpenAI',
      configFields: [
        {
          name: 'temperature',
          displayName: 'Temperature',
          type: 'Float',
          limits: [0, 1],
          defaultValue: 0,
        },
        {
          name: 'max_tokens',
          displayName: 'Max Tokens',
          type: 'Float',
          limits: [0, 4000],
          defaultValue: 2000,
        },
      ],
    }),
    new ModelInfo({
      id: 200001,
      name: 'gpt-3.5-turbo',
      displayName: 'GPT-3.5 Turbo',
      provider: 'OpenAI',
    }),
    new ModelInfo({
      id: 200002,
      name: 'claude-2',
      displayName: 'Claude 2',
      provider: 'Anthropic',
    }),
    new ModelInfo({
      id: 200003,
      name: 'llama-2-70b',
      displayName: 'Llama 2 70B',
      provider: 'Meta AI',
    }),
    new ModelInfo({
      id: 200004,
      name: 'palm-2',
      displayName: 'PaLM 2',
      provider: 'Google',
    }),
  ];

  private modelCache: Map<number, ModelInfo>;
  modelsFetched: boolean = false;

  constructor() {
    this.modelCache = new Map();
    this.mockModels.forEach((model) => {
      this.modelCache.set(model.id, model);
    });
    this.modelsFetched = true;
    console.log('ModelServiceMock: Initialized with mock models');
  }

  async getModels(tenantId?: number): Promise<Models> {
    console.log('ModelServiceMock: getModels called with tenantId:', tenantId);

    return new Models({
      models: this.mockModels,
      count: this.mockModels.length,
    });
  }

  async getModelById(id: number): Promise<ModelInfo | null> {
    console.log('ModelServiceMock: getModelById called with id:', id);
    return this.modelCache.get(id) || null;
  }

  getModelMap(): Map<number, ModelInfo> {
    return this.modelCache;
  }
}

export default ModelServiceMock;
