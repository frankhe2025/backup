import { PromptListInterface } from '../../list/prompt-list.interface';
import { Prompts } from '../../entities/prompts.entity';
import { generatePromptsData } from '../entities/prompts.entity.faker';
import getPromptsServiceInstance, { PROMPTS_SERVICE_TYPES } from '../../commons/prompts_service_factory';
import { ModelServiceInterface } from '../../services/model.interface';

export class PromptListServiceMock implements PromptListInterface {
  private modelService: ModelServiceInterface;
  private isFetching: boolean = false;
  private activePromise: Promise<Prompts> | null = null;
  private cache: Map<string, Prompts> = new Map();

  constructor() {
    this.modelService = getPromptsServiceInstance(PROMPTS_SERVICE_TYPES.MODEL);
    console.log('PromptListServiceMock: Initialized');
  }

  async getPrompts(botId?: number): Promise<Prompts> {
    const cacheKey = `botId_${botId || 'default'}`;

    if (this.cache.has(cacheKey)) {
      console.log(`PromptListServiceMock: Returning cached data for ${cacheKey}`);
      return this.cache.get(cacheKey)!;
    }

    if (this.isFetching && this.activePromise) {
      console.log('PromptListServiceMock: Already fetching prompts, reusing ongoing request');
      return this.activePromise;
    }

    this.isFetching = true;
    this.activePromise = this._fetchPrompts(botId);

    try {
      const result = await this.activePromise;

      this.cache.set(cacheKey, result);

      return result;
    } finally {
      this.isFetching = false;
      this.activePromise = null;
    }
  }

  private async _fetchPrompts(botId?: number): Promise<Prompts> {
    console.log('PromptListServiceMock: Generating mock data for botId:', botId);

    await new Promise((resolve) => setTimeout(resolve, 300));

    const mockData = generatePromptsData(100);
    const prompts = new Prompts(mockData);

    this.enhancePromptsWithModelInfo(prompts);

    return prompts;
  }

  private enhancePromptsWithModelInfo(prompts: Prompts): void {
    if (!prompts?.prompts) return;

    console.log(`PromptListServiceMock: Enhancing ${prompts.prompts.length} prompts with model info`);

    const modelMap = this.modelService.getModelMap();

    prompts.prompts.forEach((prompt) => {
      if (prompt.modelId && prompt.modelId > 0 && modelMap.has(prompt.modelId)) {
        prompt.setModelInfo(modelMap.get(prompt.modelId));
      }
    });
  }
}

export default PromptListServiceMock;
