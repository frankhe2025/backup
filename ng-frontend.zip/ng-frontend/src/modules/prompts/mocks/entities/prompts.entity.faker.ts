import { generateWords } from '../../../../commons/utils/faker.util';
import { PromptStatus } from '../../entities/prompt-status.enum';
import { PromptSourceType } from '../../entities/prompt-source-type.enum';
import { PromptType } from '../../entities/prompt-type.enum';
import { PromptScope } from '../../entities/prompt-scope.enum';

const generateRandomDate = () => {
  const now = new Date();
  const pastYear = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
  const randomTime = pastYear.getTime() + Math.random() * (now.getTime() - pastYear.getTime());
  return new Date(randomTime).getTime();
};

const generateUser = () => {
  const names = ['Aisera', 'Smith', 'Drake', 'Alex'];
  return names[Math.floor(Math.random() * names.length)];
};

const generateStatus = () => {
  const statuses = [PromptStatus.ACTIVE, PromptStatus.INACTIVE, PromptStatus.PENDING];
  return statuses[Math.floor(Math.random() * statuses.length)];
};

const generateSourceType = () => {
  const sources = [PromptSourceType.SYSTEM, PromptSourceType.USER];
  return sources[Math.floor(Math.random() * sources.length)];
};

const generateType = () => {
  const types = [PromptType.DEFAULT, PromptType.CUSTOM, PromptType.TUNED];
  return types[Math.floor(Math.random() * types.length)];
};

const generateScope = () => {
  const scopes = [PromptScope.GLOBAL, PromptScope.APPLICATION, PromptScope.TENANT];
  return scopes[Math.floor(Math.random() * scopes.length)];
};

const generateModelId = () => {
  return Math.floor(Math.random() * 5) + 200000;
};

const generatePromptText = () => {
  return `This is a prompt text`;
};

const generateModelConfigFields = () => [
  {
    name: 'temperature',
    displayName: 'Temperature',
    type: 'Float',
    limits: [0, 1],
    defaultValue: 0,
  },
  {
    name: 'max_tokens',
    displayName: 'Max Tokens',
    type: 'Float',
    limits: [0, 4000],
    defaultValue: 2000,
  },
  {
    name: 'top_p',
    displayName: 'TOP_P',
    type: 'Float',
    limits: [0, 1],
    defaultValue: 1,
  },
];

const generateModelInfo = (modelId: number) => {
  const providers = ['Microsoft Azure OpenAI', 'OpenAI', 'Anthropic', 'Meta AI', 'Google'];

  const modelNames = ['gpt-4', 'gpt-3.5-turbo', 'claude-2', 'llama-2-70b', 'palm-2'];

  const displayNames = [
    'Azure Open AI Generic Job Chat Completions Prompt Group NC',
    'GPT-3.5 Turbo',
    'Claude 2',
    'Llama 2 70B',
    'PaLM 2',
  ];

  const index = modelId % 5;

  return {
    id: modelId,
    name: modelNames[index],
    displayName: displayNames[index],
    provider: providers[index],
    configFields: generateModelConfigFields(),
    version: '',
    maxTokens: 0,
    contextWindow: 0,
    isDefault: false,
  };
};

const generateModelConfig = () => {
  return {
    modelOptions: {
      temperature: 0,
      top_p: 0.9,
      max_tokens: 1000,
      presence_penalty: 10,
      frequency_penalty: 0,
    },
  };
};

export const generatePromptsData = (count = 10) => {
  const res = [];
  for (let i = 0; i < count; i++) {
    const status = generateStatus();
    const updatedAt = generateRandomDate();
    const createdAt = updatedAt - Math.random() * 30 * 24 * 60 * 60 * 1000;
    const type = generateType();
    const sourceType = generateSourceType();
    const modelId = generateModelId();

    res.push({
      id: 5000 + i,
      name: `prompt_${i}_${generateWords(2)}`,
      displayName: `${type} Prompt ${i} ${generateWords(3)}`,
      promptText: generatePromptText(),
      tenantId: null,
      botId: null,
      modelId: modelId,
      status: status,
      type: type,
      useCase: null,
      inputVariables: [],
      outputVariables: [
        {
          name: 'Response',
          type: 'String',
        },
      ],
      modelConfig: generateModelConfig(),
      transformationScript: `var map = {};\nmap["Response"] = response;\nreturn map;`,
      category: 'Generic',
      createdAt: createdAt,
      updatedAt: updatedAt,
      userRequest: null,
      description: null,
      scope: generateScope(),
      entityGuid: `${5000 + i}`,
      reviewStatus: status === PromptStatus.ACTIVE ? 'Approved' : 'Pending',
      changeLogId: null,
      userId: null,
      createdBy: null,
      createdByEmail: generateUser(),
      updatedBy: null,
      updatedByEmail: generateUser(),
      state: status === PromptStatus.ACTIVE ? 'Published' : 'Draft',
      system: i % 3 === 0,
      default: i % 5 === 0,
      imported: false,
      sourceType: sourceType,
      _modelInfo: generateModelInfo(modelId),
    });
  }
  return res;
};
