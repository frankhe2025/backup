import getAuthService from '../../../commons/modules/auth/service/auth.service';
import callApi, { REQUEST_METHOD } from '../../../commons/utils/fetcher.util';
import { CategoryServiceInterface } from './category.interface';

export class CategoryService implements CategoryServiceInterface {
  async getCategories(tenantId?: number | string): Promise<string[]> {
    const path = `llm-gateway/v1/tenants/${tenantId}/llm/prompts/categories`;

    const response = await callApi({
      url: path,
      method: REQUEST_METHOD.GET,
      headers: {
        'Content-Type': 'application/json',
        jwt: getAuthService().getAuthToken(),
      },
    });

    if (response && response.statusCode === 200 && response.resp) {
      return response.resp;
    }
    return [];
  }
}
