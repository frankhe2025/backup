import { Prompts } from '../entities/prompts.entity';
import callApi, { REQUEST_METHOD } from '../../../commons/utils/fetcher.util';
import { PromptListInterface } from '../list/prompt-list.interface';
import getPromptsServiceInstance, { PROMPTS_SERVICE_TYPES } from '../commons/prompts_service_factory';
import { ModelServiceInterface } from './model.interface';
import getRegistrationService from '../../../commons/modules/connector-server/services/registration.service';
import getAuthService from '../../../commons/modules/auth/service/auth.service';

export class PromptListService implements PromptListInterface {
  private modelService: ModelServiceInterface;
  private isFetching: boolean = false;
  private activePromise: Promise<Prompts> | null = null;

  constructor() {
    this.modelService = getPromptsServiceInstance(PROMPTS_SERVICE_TYPES.MODEL);
    console.log('PromptListService: Initialized');
  }

  async getPrompts(botId?: number): Promise<Prompts> {
    if (this.isFetching && this.activePromise) {
      console.log('PromptListService: Already fetching prompts, reusing ongoing request');
      return this.activePromise;
    }

    this.isFetching = true;
    this.activePromise = this._fetchPrompts(botId);

    try {
      const result = await this.activePromise;
      return result;
    } finally {
      this.isFetching = false;
      this.activePromise = null;
    }
  }

  private async _fetchPrompts(botId?: number): Promise<Prompts> {
    try {
      await this.modelService.getModels();

      const tenantId = await getRegistrationService().getCurrentTenantId();

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts${botId ? `?botId=${botId}` : ''}`;

      console.log('PromptListService: Using proxy path:', path);

      const response = await callApi({
        url: path,
        method: REQUEST_METHOD.GET,
        headers: {
          'Content-Type': 'application/json',
          Authorization: getAuthService().getAuthToken(),
        },
      });

      console.log('PromptListService: Prompt API response received');

      if (response && response.statusCode === 200) {
        const data = response.resp;

        const prompts = new Prompts(data);

        this.enhancePromptsWithModelInfo(prompts);

        return prompts;
      } else {
        console.error('PromptListService: Error fetching prompts:', response);
        return new Prompts([]);
      }
    } catch (error) {
      console.error('PromptListService: Error in getPrompts:', error);
      return new Prompts([]);
    }
  }

  private enhancePromptsWithModelInfo(prompts: Prompts): void {
    if (!prompts?.prompts) return;

    console.log(`PromptListService: Enhancing ${prompts.prompts.length} prompts with model info`);

    const modelMap = this.modelService.getModelMap();

    prompts.prompts.forEach((prompt) => {
      if (prompt.modelId && modelMap.has(prompt.modelId)) {
        prompt.setModelInfo(modelMap.get(prompt.modelId));
      }
    });
  }
}

export default PromptListService;
