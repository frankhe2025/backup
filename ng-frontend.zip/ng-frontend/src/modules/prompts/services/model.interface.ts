import Models from '../entities/models.entity';
import ModelInfo from '../entities/model.entity';

export interface ModelServiceInterface {
  getModels(tenantId?: number): Promise<Models>;
  getModelById(id: number, tenantId?: number): Promise<ModelInfo | null>;
  getModelMap(): Map<number, ModelInfo>;
}

export default ModelServiceInterface;
