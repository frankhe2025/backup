export interface CategoryServiceInterface {
  getCategories(tenantId?: number | string): Promise<string[]>;
}
