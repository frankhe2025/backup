import { Prompt } from '../entities/prompt.entity';
import { PromptVersions } from '../entities/prompt-versions.entity';
import { IVersionInput } from '../entities/prompt-version.entity';
import getAuthService from '../../../commons/modules/auth/service/auth.service';
import callApi, { REQUEST_METHOD } from '../../../commons/utils/fetcher.util';
import {
  PromptPlaygroundInterface,
  PromptExecuteParams,
  PromptExecuteResponse,
} from '../playground/prompt-playground.interface';
import getRegistrationService from '../../../commons/modules/connector-server/services/registration.service';

export class PromptPlaygroundService implements PromptPlaygroundInterface {
  constructor() {
    console.log('PromptPlaygroundService: Initialized');
  }

  private convertApiResponseToVersions(apiResponse: any[]): PromptVersions {
    if (!apiResponse || apiResponse.length === 0) {
      return {
        draftVersion: undefined,
        publishedVersion: undefined,
        archivedVersions: [],
      };
    }

    const result: PromptVersions = {
      draftVersion: undefined,
      publishedVersion: undefined,
      archivedVersions: [],
    };

    const convertedVersions = apiResponse.map((item) => {
      const prompt = item.prompt;
      const convertedPrompt = { ...prompt };
      const changeLog = item?.changeLog;

      if (convertedPrompt.status === 'Archived' || convertedPrompt.reviewStatus === 'Archived') {
        convertedPrompt.reviewStatus = 'Approved';
        convertedPrompt.state = 'Inactive';
        convertedPrompt.status = 'Archived';
        if (!convertedPrompt.changeLogId) {
          convertedPrompt.changeLogId = 'archived-' + Date.now();
        }
      } else if (
        convertedPrompt.reviewStatus === 'Draft' ||
        convertedPrompt.state === 'Draft' ||
        (convertedPrompt.state === 'Inactive' && !convertedPrompt.changeLogId)
      ) {
        convertedPrompt.reviewStatus = 'Draft';
        convertedPrompt.state = 'Inactive';
        convertedPrompt.status = 'Active';
        convertedPrompt.changeLogId = null;
      } else if (
        convertedPrompt.reviewStatus === 'Approved' ||
        convertedPrompt.state === 'Published' ||
        (convertedPrompt.status === 'Active' && convertedPrompt.changeLogId)
      ) {
        convertedPrompt.reviewStatus = 'Approved';
        convertedPrompt.state = 'Published';
        convertedPrompt.status = 'Active';
        if (!convertedPrompt.changeLogId) {
          convertedPrompt.changeLogId = 'published-' + Date.now();
        }
      }

      const versionInput: IVersionInput = {
        entityId: convertedPrompt.id,
        name: changeLog?.name || convertedPrompt.name,
        description: changeLog?.notes || convertedPrompt.description,
        date: new Date(Math.max(convertedPrompt.createdAt || 0, convertedPrompt.updatedAt || 0)).toISOString(),
        lastUpdateUserId: convertedPrompt.userId || 'system',
        lastUpdateUserName: convertedPrompt.updatedByEmail || convertedPrompt.createdByEmail || 'system',
      };

      return {
        version: versionInput,
        reviewStatus: convertedPrompt.reviewStatus,
        state: convertedPrompt.state,
        status: convertedPrompt.status,
        changeLogId: convertedPrompt.changeLogId,
      };
    });

    convertedVersions.sort((a, b) => {
      return new Date(b.version.date).getTime() - new Date(a.version.date).getTime();
    });

    const draftVersions = convertedVersions.filter(
      (item) =>
        item.reviewStatus === 'Draft' && item.state === 'Inactive' && item.status === 'Active' && !item.changeLogId,
    );
    const publishedVersions = convertedVersions.filter(
      (item) =>
        item.reviewStatus === 'Approved' && item.state === 'Published' && item.status === 'Active' && item.changeLogId,
    );
    const archivedVersions = convertedVersions.filter(
      (item) =>
        item.reviewStatus === 'Approved' && item.state === 'Inactive' && item.status === 'Archived' && item.changeLogId,
    );

    if (draftVersions.length > 0) {
      result.draftVersion = draftVersions[0].version;
    }

    if (publishedVersions.length > 0) {
      result.publishedVersion = publishedVersions[0].version;
      if (publishedVersions.length > 1 && result.archivedVersions) {
        result.archivedVersions.push(...publishedVersions.slice(1).map((item) => item.version));
      }
    }

    if (result.archivedVersions) {
      result.archivedVersions.push(...archivedVersions.map((item) => item.version));

      result.archivedVersions.sort((a, b) => {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      });
    }
    return result;
  }

  async getPromptById(promptId: number): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/${promptId}`;

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.GET,
      });

      if (data?.err) {
        throw new Error('Failed to fetch prompt');
      }

      return new Prompt(data.resp);
    } catch (error) {
      console.error('Error fetching prompt:', error);
      throw error;
    }
  }

  async getModels(): Promise<any[]> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();

      const path = `llm-gateway/v1/tenants/${tenantId}/llm/prompts/models`;

      console.log('PromptPlaygroundService: Fetching available models');

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.GET,
      });

      if (data?.err) {
        throw new Error('Failed to fetch models');
      }

      return data.resp;
    } catch (error) {
      console.error('Error fetching models:', error);
      throw error;
    }
  }

  async getModelById(modelId: number): Promise<any> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-models/${modelId}`;

      console.log('PromptPlaygroundService: Fetching model with ID:', modelId);

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.GET,
      });

      if (data?.err) {
        throw new Error('Failed to fetch model details');
      }

      return data.resp;
    } catch (error) {
      console.error('Error fetching model details:', error);
      throw error;
    }
  }

  async executePrompt(
    promptId: number,
    userMessage?: string,
    modelId?: number | null,
    modelOptions?: Record<string, any>,
    currentPrompt?: Prompt,
  ): Promise<PromptExecuteResponse> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();
      const path = `llm-gateway/v1/tenants/${tenantId}/llm/prompts/execute`;

      const prompt = currentPrompt || (await this.getPromptById(promptId));

      const inputValues =
        prompt.inputVariables?.reduce((acc: Record<string, any>, v: any) => {
          if (v.name) {
            acc[v.name] = v.sampleValue || null;
          }
          return acc;
        }, {}) || {};

      const defaultModelConfig = {
        temperature: 0,
        max_tokens: 1000,
        top_p: 1,
        frequency_penalty: 0,
        presence_penalty: 0,
      };

      const savedModelConfig = prompt.modelConfig || {};

      const mergedModelConfig = {
        ...defaultModelConfig,
        ...savedModelConfig,
        ...(modelOptions || {}),
      };

      const transformedInputVariables =
        prompt.inputVariables?.map((v: any) => ({
          name: v.name,
          type: 'String',
        })) || [];

      const transformedOutputVariables =
        prompt.outputVariables?.map((v: any) => ({
          name: v.name,
          type: v.type === 'string' ? 'String' : v.type || 'String',
        })) || [];

      const requestData: PromptExecuteParams = {
        promptText: prompt.promptText || '',
        modelId: modelId || prompt.modelId || undefined,
        modelConfig: mergedModelConfig,
        inputVariables: transformedInputVariables,
        outputVariables:
          transformedOutputVariables.length > 0 ? transformedOutputVariables : [{ name: 'Response', type: 'String' }],
        transformationScript: prompt.transformationScript || null,
        userText: userMessage || '',
        inputValues: inputValues,
      };

      const data = await callApi(
        {
          url: path,
          method: REQUEST_METHOD.POST,
          data: requestData,
          headers: {
            'Content-Type': 'application/json',
            Authorization: getAuthService().getAuthToken(),
          },
        },
        false,
      );

      if (data?.err) {
        throw new Error('Failed to execute prompt');
      }

      return {
        raw: data.resp.raw || JSON.stringify(data.resp),
        parsed: data.resp.parsed || {},
      };
    } catch (error) {
      console.error('Error executing prompt:', error);
      throw error;
    }
  }

  async getVersions(promptId: string): Promise<PromptVersions> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();
      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/${promptId}/versions`;

      const data = await callApi(
        {
          url: path,
          method: REQUEST_METHOD.GET,
        },
        false,
      );

      if (data?.err) {
        throw new Error('Failed to fetch versions');
      }

      return this.convertApiResponseToVersions(data.resp);
    } catch (error) {
      console.error('Error fetching versions:', error);
      throw error;
    }
  }

  async publishPrompt(promptId: number, publishData: any): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();
      const userId = getAuthService().getUserId() || '';

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/publish-v2`;

      const requestData = {
        draftEntityId: promptId.toString(),
        userId: userId,
        changeLog: {
          name: publishData.name,
          notes: publishData.description,
        },
      };

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.POST,
        data: requestData,
      });

      if (data?.err) {
        throw new Error('Failed to publish prompt');
      }

      return data.resp;
    } catch (error) {
      console.error('Error publish prompt:', error);
      throw error;
    }
  }

  async updatePrompt(promptId: number, updatedData: Prompt): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();
      console.log('updatePrompt ***', promptId, updatedData);

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/${promptId}`;

      const cleanedData = { ...updatedData };
      delete (cleanedData as any)._modelInfo;
      delete (cleanedData as any).subscribers;
      delete (cleanedData as any)._originalValues;

      const userId = getAuthService().getUserId() || '';
      (cleanedData as any).userId = userId;
      (cleanedData as any).updatedBy = userId;
      (cleanedData as any).createdBy = userId;

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.PUT,
        data: cleanedData,
      });

      if (data?.err) {
        throw new Error('Failed to update prompt');
      }

      return data.resp;
    } catch (error) {
      console.error('Error updating prompt:', error);
      throw error;
    }
  }

  async archivePrompt(promptId: number, botId?: number): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/${promptId}`;

      const userId = getAuthService().getUserId() || '';
      const archiveData = {
        status: 'Archived',
        updatedBy: userId,
        ...(botId && { botId }),
      };

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.PUT,
        data: archiveData,
      });

      if (data?.err) {
        throw new Error('Failed to archive prompt');
      }

      return data.resp;
    } catch (error) {
      console.error('Error archiving prompt:', error);
      throw error;
    }
  }

  async deletePrompt(promptId: number): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();
      const userId = getAuthService().getUserId() || '';

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/delete-all-versions`;

      const requestData = {
        entityId: promptId,
        userId: userId,
      };

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.POST,
        data: requestData,
      });

      if (data?.err) {
        throw new Error('Failed to delete all prompts');
      }

      return data.resp;
    } catch (error) {
      console.error('Error deleting all prompts:', error);
      throw error;
    }
  }

  async deletePromptVersion(promptId: number): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();
      const userId = getAuthService().getUserId() || '';
      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/${promptId}`;

      const requestData = {
        id: promptId,
        userId: userId,
      };

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.DELETE,
        data: requestData,
      });

      if (data?.err) {
        throw new Error('Failed to delete prompt');
      }

      return data.resp;
    } catch (error) {
      console.error('Error deleting prompt:', error);
      throw error;
    }
  }

  async createNewPrompt(createPromptData: any): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts`;

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.POST,
        data: createPromptData,
      });

      if (data?.err) {
        throw new Error('Failed to create new prompt');
      }

      return data.resp;
    } catch (error) {
      console.error('Error creating new prompt:', error);
      throw error;
    }
  }

  async clonePrompt(promptId: number): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/${promptId}`;

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.POST,
      });

      if (data?.err) {
        throw new Error('Failed to clone prompt');
      }

      return data.resp;
    } catch (error) {
      console.error('Error cloning prompt:', error);
      throw error;
    }
  }

  async createNewDraft(promptId: number): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();
      const userId = getAuthService().getUserId() || '';

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/new-draft`;

      const requestData = {
        clonedEntityId: promptId.toString(),
        userId: userId,
      };

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.POST,
        data: requestData,
      });

      if (data?.err) {
        throw new Error('Failed to create new draft');
      }

      return data.resp;
    } catch (error) {
      console.error('Error creating new draft:', error);
      throw error;
    }
  }

  async restorePrompt(promptId: number): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();

      const path = `llm-gateway/v1/tenants/${tenantId}/version/llm-prompts/new-draft-v2`;

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.POST,
        data: {
          clonedEntityId: promptId,
        },
      });

      if (data?.err) {
        throw new Error('Failed to restore prompt');
      }

      return data.resp;
    } catch (error) {
      console.error('Error restoring prompt:', error);
      throw error;
    }
  }

  async tunePrompt(createPromptData: any): Promise<Prompt> {
    try {
      const tenantId = await getRegistrationService().getCurrentTenantId();

      const path = `llm-gateway/v1/tenants/${tenantId}/llm/prompts`;

      const data = await callApi({
        url: path,
        method: REQUEST_METHOD.POST,
        data: createPromptData,
      });

      if (data?.err) {
        throw new Error('Failed to create new prompt');
      }

      return data.resp;
    } catch (error) {
      console.error('Error creating new prompt:', error);
      throw error;
    }
  }
}
