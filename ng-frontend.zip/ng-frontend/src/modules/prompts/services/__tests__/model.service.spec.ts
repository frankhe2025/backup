import ModelService from '../model.service';
import Models from '../../entities/models.entity';
import ModelInfo from '../../entities/model.entity';
import callApi from '../../../../commons/utils/fetcher.util';
import getRegistrationService from '../../../../commons/modules/connector-server/services/registration.service';
import getAuthService from '../../../../commons/modules/auth/service/auth.service';

jest.mock('../../../../commons/utils/fetcher.util');
jest.mock('../../../../commons/modules/connector-server/services/registration.service');
jest.mock('../../../../commons/modules/auth/service/auth.service');

describe('ModelService', () => {
  let service: ModelService;

  const mockAuthToken = 'mock-auth-token';
  const mockTenantId = 123;

  const mockApiResponse = {
    statusCode: 200,
    resp: {
      models: [
        { id: 1, name: 'Model 1', provider: 'OpenAI', displayName: 'GPT-4' },
        { id: 2, name: 'Model 2', provider: 'Anthropic', displayName: 'Claude' },
      ],
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();

    (getAuthService as jest.Mock).mockReturnValue({
      getAuthToken: jest.fn().mockReturnValue(mockAuthToken),
    });

    (getRegistrationService as jest.Mock).mockReturnValue({
      getCurrentTenantId: jest.fn().mockResolvedValue(mockTenantId),
    });

    (callApi as jest.Mock).mockResolvedValue(mockApiResponse);

    service = new ModelService();
  });

  describe('getModels', () => {
    it('should use provided tenantId if supplied', async () => {
      const customTenantId = 456;
      await service.getModels(customTenantId);

      expect(callApi).toHaveBeenCalledWith(
        expect.objectContaining({
          url: expect.stringContaining(`llm-gateway/v1/tenants/${customTenantId}/llm/prompts/models`),
        }),
      );

      expect(getRegistrationService().getCurrentTenantId).not.toHaveBeenCalled();
    });

    it('should return cached models on subsequent calls', async () => {
      await service.getModels();
      expect(callApi).toHaveBeenCalledTimes(1);

      jest.clearAllMocks();

      const models = await service.getModels();

      expect(callApi).not.toHaveBeenCalled();
      expect(models).toBeInstanceOf(Models);
      expect(models.models.length).toBe(2);
    });

    it('should return empty models on API error', async () => {
      (callApi as jest.Mock).mockResolvedValue({
        statusCode: 500,
        resp: null,
      });

      const models = await service.getModels();

      expect(models).toBeInstanceOf(Models);
      expect(models.models.length).toBe(0);
    });

    it('should handle exception during API call', async () => {
      (callApi as jest.Mock).mockRejectedValue(new Error('Network error'));

      const models = await service.getModels();

      expect(models).toBeInstanceOf(Models);
      expect(models.models.length).toBe(0);
    });

    it('should prevent concurrent API calls', async () => {
      (callApi as jest.Mock).mockImplementation(() => {
        return new Promise((resolve) => {
          setTimeout(() => resolve(mockApiResponse), 100);
        });
      });

      const promise1 = service.getModels();
      const promise2 = service.getModels();

      const [models1, models2] = await Promise.all([promise1, promise2]);

      expect(callApi).toHaveBeenCalledTimes(1);

      expect(models1).toBeInstanceOf(Models);
      expect(models2).toBeInstanceOf(Models);
      expect(models1.models.length).toBe(2);
      expect(models2.models.length).toBe(2);
    });
  });

  describe('getModelById', () => {
    it('should return model from cache if exists', async () => {
      await service.getModels();

      jest.clearAllMocks();

      const model = await service.getModelById(1);

      expect(callApi).not.toHaveBeenCalled();
      expect(model).toBeInstanceOf(ModelInfo);
      expect(model?.id).toBe(1);
      expect(model?.name).toBe('Model 1');
    });

    it('should fetch models if cache is empty', async () => {
      const model = await service.getModelById(1);

      expect(callApi).toHaveBeenCalledTimes(1);
      expect(model).toBeInstanceOf(ModelInfo);
      expect(model?.id).toBe(1);
    });

    it('should return null if model is not found', async () => {
      await service.getModels();

      const model = await service.getModelById(999);

      expect(model).toBeNull();
    });

    it('should pass tenantId to getModels if provided', async () => {
      const customTenantId = 456;

      const getModelsSpy = jest.spyOn(service, 'getModels');

      await service.getModelById(1, customTenantId);

      expect(getModelsSpy).toHaveBeenCalledWith(customTenantId);
    });
  });

  describe('getModelMap', () => {
    it('should return the model cache map', async () => {
      await service.getModels();

      const modelMap = service.getModelMap();

      expect(modelMap).toBeInstanceOf(Map);
      expect(modelMap.size).toBe(2);
      expect(modelMap.get(1)).toBeInstanceOf(ModelInfo);
      expect(modelMap.get(2)).toBeInstanceOf(ModelInfo);
    });

    it('should return empty map if cache is empty', () => {
      const modelMap = service.getModelMap();

      expect(modelMap).toBeInstanceOf(Map);
      expect(modelMap.size).toBe(0);
    });
  });

  describe('waitForFetch', () => {
    it('should resolve when isFetching becomes false', async () => {
      Object.defineProperty(service, 'isFetching', {
        value: true,
        writable: true,
      });

      const waitPromise = (service as any).waitForFetch();

      setTimeout(() => {
        Object.defineProperty(service, 'isFetching', {
          value: false,
          writable: true,
        });
      }, 50);

      await expect(waitPromise).resolves.toBeUndefined();
    });
  });
});
