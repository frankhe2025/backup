import { PromptPlaygroundService } from '../prompt-playground.service';
import callApi from '../../../../commons/utils/fetcher.util';
import getRegistrationService from '../../../../commons/modules/connector-server/services/registration.service';
import getAuthService from '../../../../commons/modules/auth/service/auth.service';

// Mock PROXY_PATH global variable
(global as any).PROXY_PATH = '/api/';

jest.mock('../../../../commons/utils/fetcher.util');
jest.mock('../../../../commons/modules/connector-server/services/registration.service');
jest.mock('../../../../commons/modules/auth/service/auth.service');

const mockCallApi = callApi as jest.MockedFunction<typeof callApi>;
const mockGetRegistrationService = getRegistrationService as jest.MockedFunction<typeof getRegistrationService>;
const mockGetAuthService = getAuthService as jest.MockedFunction<typeof getAuthService>;

describe('PromptPlaygroundService', () => {
  let service: PromptPlaygroundService;
  let mockRegistrationService: any;
  let mockAuthService: any;

  beforeEach(() => {
    service = new PromptPlaygroundService();

    mockRegistrationService = {
      getCurrentTenantId: jest.fn(),
    };

    mockAuthService = {
      getAuthToken: jest.fn(),
      getUserId: jest.fn(),
    };

    mockGetRegistrationService.mockReturnValue(mockRegistrationService);
    mockGetAuthService.mockReturnValue(mockAuthService);

    mockRegistrationService.getCurrentTenantId.mockResolvedValue('tenant-123');
    mockAuthService.getAuthToken.mockReturnValue('token-123');
    mockAuthService.getUserId.mockReturnValue('user-123');

    jest.clearAllMocks();
  });

  describe('constructor', () => {
    it('should initialize service and log message', () => {
      const consoleSpy = jest.spyOn(console, 'log').mockImplementation();

      new PromptPlaygroundService();

      expect(consoleSpy).toHaveBeenCalledWith('PromptPlaygroundService: Initialized');

      consoleSpy.mockRestore();
    });
  });

  describe('getPromptById', () => {
    it('should handle API error response', async () => {
      mockCallApi.mockResolvedValue({ err: 'API Error' });

      await expect(service.getPromptById(1)).rejects.toThrow('Failed to fetch prompt');
    });

    it('should handle network/call error', async () => {
      mockCallApi.mockRejectedValue(new Error('Network error'));

      await expect(service.getPromptById(1)).rejects.toThrow('Network error');
    });
  });

  describe('updatePrompt', () => {
    it('should handle update error', async () => {
      mockCallApi.mockResolvedValue({ err: 'Update failed' });

      await expect(service.updatePrompt(1, { id: 1, name: 'test' } as any)).rejects.toThrow('Failed to update prompt');
    });
  });

  describe('executePrompt', () => {
    it('should handle execute error', async () => {
      const mockPromptData = { id: 1, promptText: 'Test', inputVariables: [] };
      mockCallApi.mockResolvedValueOnce({ resp: mockPromptData }).mockResolvedValueOnce({ err: 'Execute failed' });

      await expect(service.executePrompt(1)).rejects.toThrow('Failed to execute prompt');
    });
  });

  describe('publishPrompt', () => {
    it('should handle publish error', async () => {
      mockCallApi.mockResolvedValue({ err: 'Publish failed' });

      await expect(service.publishPrompt(1, {})).rejects.toThrow('Failed to publish prompt');
    });
  });

  describe('deletePrompt', () => {
    it('should handle delete error', async () => {
      mockCallApi.mockResolvedValue({ err: 'Delete failed' });

      await expect(service.deletePrompt(1)).rejects.toThrow('Failed to delete all prompts');
    });
  });

  describe('createNewPrompt', () => {
    it('should handle create error', async () => {
      mockCallApi.mockResolvedValue({ err: 'Create failed' });

      await expect(service.createNewPrompt({})).rejects.toThrow('Failed to create new prompt');
    });
  });

  describe('clonePrompt', () => {
    it('should handle clone error', async () => {
      mockCallApi.mockResolvedValue({ err: 'Clone failed' });

      await expect(service.clonePrompt(1)).rejects.toThrow('Failed to clone prompt');
    });
  });

  describe('restorePrompt', () => {
    it('should handle restore error', async () => {
      mockCallApi.mockResolvedValue({ err: 'Restore failed' });

      await expect(service.restorePrompt(1)).rejects.toThrow('Failed to restore prompt');
    });
  });

  describe('error handling with network failures', () => {
    it('should handle network error in getPromptById', async () => {
      mockCallApi.mockRejectedValue(new Error('Network failure'));

      await expect(service.getPromptById(1)).rejects.toThrow('Network failure');
    });

    it('should handle network error in updatePrompt', async () => {
      mockCallApi.mockRejectedValue(new Error('Network failure'));

      await expect(service.updatePrompt(1, { id: 1, name: 'test' } as any)).rejects.toThrow('Network failure');
    });

    it('should handle network error in executePrompt during getPromptById', async () => {
      mockCallApi.mockRejectedValue(new Error('Network failure'));

      await expect(service.executePrompt(1)).rejects.toThrow('Network failure');
    });

    it('should handle network error in executePrompt during execution', async () => {
      const mockPromptData = { id: 1, promptText: 'Test', inputVariables: [] };
      mockCallApi
        .mockResolvedValueOnce({ resp: mockPromptData })
        .mockRejectedValueOnce(new Error('Execution network failure'));

      await expect(service.executePrompt(1)).rejects.toThrow('Execution network failure');
    });
  });

  describe('console logging', () => {
    beforeEach(() => {
      jest.spyOn(console, 'log').mockImplementation();
      jest.spyOn(console, 'error').mockImplementation();
    });

    afterEach(() => {
      jest.restoreAllMocks();
    });

    it('should log model fetching', async () => {
      mockCallApi.mockResolvedValue({ resp: [] });

      await service.getModels();

      expect(console.log).toHaveBeenCalledWith('PromptPlaygroundService: Fetching available models');
    });

    it('should log model fetching by ID', async () => {
      mockCallApi.mockResolvedValue({ resp: { id: 2 } });

      await service.getModelById(2);

      expect(console.log).toHaveBeenCalledWith('PromptPlaygroundService: Fetching model with ID:', 2);
    });

    it('should log errors', async () => {
      mockCallApi.mockRejectedValue(new Error('Test error'));

      await expect(service.getPromptById(1)).rejects.toThrow();

      expect(console.error).toHaveBeenCalledWith('Error fetching prompt:', expect.any(Error));
    });
  });
});
