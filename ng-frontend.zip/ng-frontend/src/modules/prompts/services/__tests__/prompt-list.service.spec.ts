import { PromptListService } from '../prompt-list.service';
import { Prompts } from '../../entities/prompts.entity';
import callApi, { REQUEST_METHOD } from '../../../../commons/utils/fetcher.util';

jest.mock('../../../../commons/utils/fetcher.util');
jest.mock('../../commons/prompts_service_factory');
jest.mock('../../../../commons/modules/connector-server/services/registration.service');
jest.mock('../../../../commons/modules/auth/service/auth.service');

const mockCallApi = callApi as jest.MockedFunction<typeof callApi>;

const mockModelService = {
  getModels: jest.fn(),
  getModelMap: jest.fn(),
};

jest.mock('../../commons/prompts_service_factory', () => ({
  __esModule: true,
  default: jest.fn(() => mockModelService),
  PROMPTS_SERVICE_TYPES: {
    MODEL: 'MODEL',
  },
}));

const mockGetCurrentTenantId = jest.fn();
jest.mock('../../../../commons/modules/connector-server/services/registration.service', () => ({
  __esModule: true,
  default: () => ({
    getCurrentTenantId: mockGetCurrentTenantId,
  }),
}));

const mockGetAuthToken = jest.fn();
jest.mock('../../../../commons/modules/auth/service/auth.service', () => ({
  __esModule: true,
  default: () => ({
    getAuthToken: mockGetAuthToken,
  }),
}));

global.console = {
  ...console,
  log: jest.fn(),
  error: jest.fn(),
};

describe('PromptListService', () => {
  let promptListService: PromptListService;

  const mockPromptsData = [
    {
      id: 1,
      name: 'Test Prompt 1',
      modelId: 1,
      sourceType: 'System',
      type: 'Default',
      scope: 'Global',
      status: 'Active',
    },
    {
      id: 2,
      name: 'Test Prompt 2',
      modelId: 2,
      sourceType: 'User',
      type: 'Custom',
      scope: 'Tenant',
      status: 'Inactive',
    },
  ];

  beforeEach(() => {
    jest.clearAllMocks();

    mockGetCurrentTenantId.mockResolvedValue('test-tenant-id');
    mockGetAuthToken.mockReturnValue('Bearer test-token');
    mockModelService.getModels.mockResolvedValue([]);
    mockModelService.getModelMap.mockReturnValue(new Map());

    promptListService = new PromptListService();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('constructor', () => {
    it('should initialize with model service', () => {
      expect(promptListService).toBeInstanceOf(PromptListService);
    });
  });

  describe('getPrompts', () => {
    it('should fetch prompts successfully without botId', async () => {
      mockCallApi.mockResolvedValue({
        statusCode: 200,
        resp: mockPromptsData,
      });

      const result = await promptListService.getPrompts();

      expect(mockModelService.getModels).toHaveBeenCalled();
      expect(mockGetCurrentTenantId).toHaveBeenCalled();
      expect(mockCallApi).toHaveBeenCalledWith({
        url: 'llm-gateway/v1/tenants/test-tenant-id/version/llm-prompts',
        method: REQUEST_METHOD.GET,
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer test-token',
        },
      });
      expect(result).toBeInstanceOf(Prompts);
      expect(result.prompts).toHaveLength(2);
    });

    it('should fetch prompts successfully with botId', async () => {
      mockCallApi.mockResolvedValue({
        statusCode: 200,
        resp: mockPromptsData,
      });

      const botId = 123;
      const result = await promptListService.getPrompts(botId);

      expect(mockCallApi).toHaveBeenCalledWith({
        url: 'llm-gateway/v1/tenants/test-tenant-id/version/llm-prompts?botId=123',
        method: REQUEST_METHOD.GET,
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer test-token',
        },
      });
      expect(result).toBeInstanceOf(Prompts);
    });

    it('should enhance prompts with model info', async () => {
      const mockModelMap = new Map();
      mockModelMap.set(1, { id: 1, name: 'GPT-4', provider: 'OpenAI' });
      mockModelMap.set(2, { id: 2, name: 'Claude', provider: 'Anthropic' });

      mockModelService.getModelMap.mockReturnValue(mockModelMap);
      mockCallApi.mockResolvedValue({
        statusCode: 200,
        resp: mockPromptsData,
      });

      const result = await promptListService.getPrompts();

      expect(result.prompts).toHaveLength(2);
      expect(result.prompts[0].modelId).toBe(1);
      expect(result.prompts[1].modelId).toBe(2);
    });

    it('should handle API error responses', async () => {
      mockCallApi.mockResolvedValue({
        statusCode: 500,
        resp: { error: 'Internal Server Error' },
      });

      const result = await promptListService.getPrompts();

      expect(result).toBeInstanceOf(Prompts);
      expect(result.prompts).toHaveLength(0);
      expect(console.error).toHaveBeenCalledWith('PromptListService: Error fetching prompts:', expect.any(Object));
    });

    it('should handle network errors', async () => {
      mockCallApi.mockRejectedValue(new Error('Network error'));

      const result = await promptListService.getPrompts();

      expect(result).toBeInstanceOf(Prompts);
      expect(result.prompts).toHaveLength(0);
      expect(console.error).toHaveBeenCalledWith('PromptListService: Error in getPrompts:', expect.any(Error));
    });

    it('should handle model service errors gracefully', async () => {
      mockModelService.getModels.mockRejectedValue(new Error('Model service error'));
      mockCallApi.mockResolvedValue({
        statusCode: 200,
        resp: mockPromptsData,
      });

      const result = await promptListService.getPrompts();

      expect(result).toBeInstanceOf(Prompts);
      expect(result.prompts).toHaveLength(0);
      expect(console.error).toHaveBeenCalledWith('PromptListService: Error in getPrompts:', expect.any(Error));
    });

    it('should handle tenant ID fetch errors', async () => {
      mockGetCurrentTenantId.mockRejectedValue(new Error('Tenant ID error'));

      const result = await promptListService.getPrompts();

      expect(result).toBeInstanceOf(Prompts);
      expect(result.prompts).toHaveLength(0);
      expect(console.error).toHaveBeenCalledWith('PromptListService: Error in getPrompts:', expect.any(Error));
    });

    it('should reuse ongoing request when called multiple times', async () => {
      mockCallApi.mockImplementation(
        () =>
          new Promise((resolve) =>
            setTimeout(
              () =>
                resolve({
                  statusCode: 200,
                  resp: mockPromptsData,
                }),
              100,
            ),
          ),
      );

      const promise1 = promptListService.getPrompts();
      const promise2 = promptListService.getPrompts();
      const promise3 = promptListService.getPrompts();

      const [result1, result2, result3] = await Promise.all([promise1, promise2, promise3]);

      expect(result1).toEqual(result2);
      expect(result2).toEqual(result3);

      expect(mockCallApi).toHaveBeenCalledTimes(1);
      expect(console.log).toHaveBeenCalledWith('PromptListService: Already fetching prompts, reusing ongoing request');
    });

    it('should allow new requests after previous one completes', async () => {
      mockCallApi.mockResolvedValue({
        statusCode: 200,
        resp: mockPromptsData,
      });

      await promptListService.getPrompts();
      expect(mockCallApi).toHaveBeenCalledTimes(1);

      await promptListService.getPrompts();
      expect(mockCallApi).toHaveBeenCalledTimes(2);
    });
  });

  describe('enhancePromptsWithModelInfo', () => {
    it('should not throw error when prompts is null', () => {
      const mockModelMap = new Map();
      mockModelService.getModelMap.mockReturnValue(mockModelMap);

      expect(() => {
        (promptListService as any).enhancePromptsWithModelInfo(null);
      }).not.toThrow();
    });

    it('should not throw error when prompts.prompts is null', () => {
      const mockModelMap = new Map();
      mockModelService.getModelMap.mockReturnValue(mockModelMap);

      const prompts = new Prompts([]);
      prompts.prompts = null as any;

      expect(() => {
        (promptListService as any).enhancePromptsWithModelInfo(prompts);
      }).not.toThrow();
    });

    it('should enhance prompts with model info when model exists', () => {
      const mockModelMap = new Map();
      const modelInfo = { id: 1, name: 'GPT-4', provider: 'OpenAI' };
      mockModelMap.set(1, modelInfo);
      mockModelService.getModelMap.mockReturnValue(mockModelMap);

      const mockPrompt = {
        modelId: 1,
        setModelInfo: jest.fn(),
      };
      const prompts = { prompts: [mockPrompt] };

      (promptListService as any).enhancePromptsWithModelInfo(prompts);

      expect(mockPrompt.setModelInfo).toHaveBeenCalledWith(modelInfo);
    });

    it('should skip prompts without modelId', () => {
      const mockModelMap = new Map();
      mockModelService.getModelMap.mockReturnValue(mockModelMap);

      const mockPrompt = {
        modelId: null,
        setModelInfo: jest.fn(),
      };
      const prompts = { prompts: [mockPrompt] };

      (promptListService as any).enhancePromptsWithModelInfo(prompts);

      expect(mockPrompt.setModelInfo).not.toHaveBeenCalled();
    });

    it('should skip prompts when model not found in map', () => {
      const mockModelMap = new Map();
      mockModelService.getModelMap.mockReturnValue(mockModelMap);

      const mockPrompt = {
        modelId: 999,
        setModelInfo: jest.fn(),
      };
      const prompts = { prompts: [mockPrompt] };

      (promptListService as any).enhancePromptsWithModelInfo(prompts);

      expect(mockPrompt.setModelInfo).not.toHaveBeenCalled();
    });
  });

  describe('error handling edge cases', () => {
    it('should handle empty response data', async () => {
      mockCallApi.mockResolvedValue({
        statusCode: 200,
        resp: null,
      });

      const result = await promptListService.getPrompts();

      expect(result).toBeInstanceOf(Prompts);
      expect(result.prompts).toEqual([]);
    });

    it('should handle malformed response data', async () => {
      mockCallApi.mockResolvedValue({
        statusCode: 200,
        resp: 'invalid-json',
      });

      const result = await promptListService.getPrompts();

      expect(result).toBeInstanceOf(Prompts);
    });

    it('should handle response without statusCode', async () => {
      mockCallApi.mockResolvedValue({
        resp: mockPromptsData,
      } as any);

      const result = await promptListService.getPrompts();

      expect(result).toBeInstanceOf(Prompts);
      expect(result.prompts).toHaveLength(0);
    });
  });

  describe('logging', () => {
    it('should log initialization', () => {
      new PromptListService();

      expect(console.log).toHaveBeenCalledWith('PromptListService: Initialized');
    });

    it('should log API usage', async () => {
      mockCallApi.mockResolvedValue({
        statusCode: 200,
        resp: [],
      });

      await promptListService.getPrompts();

      expect(console.log).toHaveBeenCalledWith(
        'PromptListService: Using proxy path:',
        'llm-gateway/v1/tenants/test-tenant-id/version/llm-prompts',
      );
      expect(console.log).toHaveBeenCalledWith('PromptListService: Prompt API response received');
    });

    it('should log enhancement process', async () => {
      mockCallApi.mockResolvedValue({
        statusCode: 200,
        resp: [{ id: 1, name: 'Test' }],
      });

      await promptListService.getPrompts();

      expect(console.log).toHaveBeenCalledWith('PromptListService: Enhancing 1 prompts with model info');
    });
  });
});
