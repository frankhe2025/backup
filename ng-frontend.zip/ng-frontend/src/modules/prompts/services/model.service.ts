import Models from '../entities/models.entity';
import ModelInfo from '../entities/model.entity';
import { ModelServiceInterface } from './model.interface';
import callApi, { REQUEST_METHOD } from '../../../commons/utils/fetcher.util';
import getRegistrationService from '../../../commons/modules/connector-server/services/registration.service';
import getAuthService from '../../../commons/modules/auth/service/auth.service';

export class ModelService implements ModelServiceInterface {
  private modelCache: Map<number, ModelInfo> = new Map();
  private modelsFetched: boolean = false;
  private isFetching: boolean = false;

  async getModels(tenantId?: number): Promise<Models> {
    if (this.isFetching) {
      console.log('ModelService: Already fetching models, waiting...');
      await this.waitForFetch();
    }

    if (this.modelsFetched && this.modelCache.size > 0) {
      console.log('ModelService: Returning cached models');
      const models = Array.from(this.modelCache.values());
      return new Models({ models, count: models.length });
    }

    try {
      this.isFetching = true;

      if (!tenantId) {
        const registrationService = getRegistrationService();
        const currentTenantId = await registrationService.getCurrentTenantId();
        tenantId = Number(currentTenantId);
      }

      const path = `llm-gateway/v1/tenants/${tenantId}/llm/prompts/models`;
      console.log('ModelService: Fetching models from:', path);

      const response = await callApi({
        url: path,
        method: REQUEST_METHOD.GET,
        headers: {
          'Content-Type': 'application/json',
          jwt: getAuthService().getAuthToken(),
        },
      });

      if (response && (response.statusCode < 200 || response.statusCode >= 300)) {
        console.error(`ModelService: API error (${response.statusCode})`, response);
        this.isFetching = false;
        this.modelsFetched = true;
        return new Models();
      }

      if (!response || !response.resp) {
        console.error('ModelService: No response or invalid response structure');
        this.isFetching = false;
        this.modelsFetched = true;
        return new Models();
      }

      const models = Models.fromApiResponse(response.resp);

      this.modelCache.clear();
      models.models.forEach((model) => {
        this.modelCache.set(model.id, model);
      });

      this.modelsFetched = true;
      console.log(`ModelService: Cached ${this.modelCache.size} models`);

      this.isFetching = false;
      return models;
    } catch (error) {
      console.error('ModelService: Error fetching models:', error);
      this.isFetching = false;
      this.modelsFetched = true;
      return new Models();
    }
  }

  private async waitForFetch(): Promise<void> {
    return new Promise<void>((resolve) => {
      const checkFetching = () => {
        if (!this.isFetching) {
          resolve();
        } else {
          setTimeout(checkFetching, 100);
        }
      };
      checkFetching();
    });
  }

  async getModelById(id: number, tenantId?: number): Promise<ModelInfo | null> {
    if (this.modelCache.has(id)) {
      return this.modelCache.get(id) || null;
    }

    if (!this.modelsFetched) {
      await this.getModels(tenantId);
    }

    return this.modelCache.get(id) || null;
  }

  getModelMap(): Map<number, ModelInfo> {
    return this.modelCache;
  }
}

export default ModelService;
