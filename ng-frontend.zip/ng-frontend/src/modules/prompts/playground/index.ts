export { PromptPlaygroundComponent, default as PromptPlayground } from './prompt-playground.component';
