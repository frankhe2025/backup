import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { useNavigate } from 'react-router';
import { Prompt } from '../entities/prompt.entity';
import getPromptsServiceInstance, { PROMPTS_SERVICE_TYPES } from '../commons/prompts_service_factory';
import { PromptPlaygroundInterface } from './prompt-playground.interface';
import { ROUTES } from '../../../commons/config/routes';

interface PromptContextType {
  prompt: Prompt | null;
  originalPrompt: Prompt | null;
  versions: any;
  loading: boolean;
  error: string | null;
  userMessage: string;
  savePrompt: (onSaveComplete?: () => void) => Promise<void>;
  resetPrompt: () => void;
  setUserMessage: (message: string) => void;
  fetchModels: () => Promise<void>;
  publishPrompt: (data: any) => Promise<void>;
  updatePrompt: (promptId: number, data?: any) => Promise<void>;
  archivePrompt: (promptId: number, botId?: number) => Promise<void>;
  deletePrompt: () => Promise<void>;
  createNewPrompt: (data: any) => Promise<void>;
  createNewDraft: () => Promise<void>;
  restorePrompt: () => Promise<void>;
  deletePromptVersion: (promptId: number) => Promise<void>;
  fetchVersions: (entityGuid: string) => Promise<void>;
  subscribeToPrompt: (callback: () => void) => (() => void) | undefined;
  tunePrompt: (data: any) => Promise<void>;
}

const PromptContext = createContext<PromptContextType>({
  prompt: null,
  originalPrompt: null,
  loading: false,
  error: null,
  userMessage: '',
  versions: {},
  savePrompt: async (_onSaveComplete?: () => void) => {},
  resetPrompt: () => {},
  setUserMessage: () => {},
  fetchModels: async () => {},
  publishPrompt: async () => {},
  updatePrompt: async () => {},
  archivePrompt: async () => {},
  deletePrompt: async () => {},
  createNewPrompt: async () => {},
  createNewDraft: async () => {},
  restorePrompt: async () => {},
  deletePromptVersion: async () => {},
  fetchVersions: async () => {},
  subscribeToPrompt: () => undefined,
  tunePrompt: async () => {},
});

interface PromptProviderProps {
  promptId: number;
  children: ReactNode;
}

export const PromptProvider: React.FC<PromptProviderProps> = ({ promptId, children }) => {
  const navigate = useNavigate();

  const [prompt, setPrompt] = useState<Prompt | null>(null);
  const [originalPrompt, setOriginalPrompt] = useState<Prompt | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [userMessage, setUserMessage] = useState<string>('');
  const [versions, setVersions] = useState<any>({});

  const promptService: PromptPlaygroundInterface = getPromptsServiceInstance(PROMPTS_SERVICE_TYPES.PROMPT_PLAYGROUND);

  useEffect(() => {
    const fetchPrompt = async () => {
      setLoading(true);
      setError(null);
      try {
        const fetchedPrompt = await promptService.getPromptById(promptId);
        // Store the original prompt for reset functionality
        setOriginalPrompt(fetchedPrompt);

        // Create a clone for working with
        const clonedPrompt = fetchedPrompt.clone();
        setPrompt(clonedPrompt);

        // Initialize user message if available
        if (fetchedPrompt.userRequest) {
          setUserMessage(fetchedPrompt.userRequest);
        }
        setLoading(false);
      } catch (err) {
        console.error('Error fetching prompt:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch prompt');
        setLoading(false);
      }
    };

    fetchPrompt();
  }, [promptId, promptService]);

  const savePrompt = async (onSaveComplete?: () => void) => {
    if (!prompt) return;

    try {
      const updatedPrompt = await promptService.updatePrompt(promptId, prompt);
      setOriginalPrompt(updatedPrompt);
      const freshPrompt = new Prompt(updatedPrompt);
      setPrompt(freshPrompt);
      if (onSaveComplete) {
        onSaveComplete();
      }
    } catch (err) {
      console.error('Error saving prompt:', err);
      setError(err instanceof Error ? err.message : 'Failed to save prompt');
    }
  };

  const resetPrompt = () => {
    if (originalPrompt) {
      setPrompt(originalPrompt.clone());
      setUserMessage(originalPrompt.userRequest || '');
    }
  };

  const fetchModels = async () => {
    try {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const models = await promptService.getModels();
    } catch (error) {
      console.error('Error fetching models:', error);
    }
  };

  const executePrompt = async (userMessage?: string, modelId?: number | null) => {
    try {
      if (promptService.executePrompt) {
        await promptService.executePrompt(promptId, userMessage, modelId);
      } else {
        await new Promise((resolve) => setTimeout(resolve, 1500));
      }
    } catch (error) {
      console.error('Error executing prompt:', error);
    }
  };

  const fetchVersions = useCallback(
    async (entityGuid: string) => {
      try {
        const versions = await promptService.getVersions(entityGuid, promptId);
        setVersions(versions);
      } catch (error) {
        console.error('Error fetching versions:', error);
      }
    },
    [promptId, promptService],
  );

  const publishPrompt = useCallback(
    async (data: any) => {
      try {
        await promptService.publishPrompt(promptId, data);
        await fetchVersions(promptId.toString());

        setPrompt((prev: any) => ({
          ...prev,
          reviewStatus: 'Approved',
          state: 'Published',
        }));
      } catch (error) {
        console.error('Error publishing prompt:', error);
      }
    },
    [fetchVersions, promptId, promptService],
  );

  const updatePrompt = useCallback(
    async (promptId: number, data?: any) => {
      try {
        // Prepare prompt data by removing _modelInfo, _originValues, and subscribers
        let promptData = data || prompt;
        if (promptData) {
          const { _modelInfo, _originalValues, subscribers: _subscribers, ...rest } = promptData;
          promptData = rest;
        }
        const updatedPrompt = await promptService.updatePrompt(promptId, promptData);
        setOriginalPrompt(updatedPrompt);
        const freshPrompt = new Prompt(updatedPrompt);
        setPrompt(freshPrompt);
      } catch (error) {
        console.error('Error updating prompt:', error);
      }
    },
    [prompt, promptService],
  );

  const archivePrompt = useCallback(
    async (promptId: number, botId?: number) => {
      try {
        const archivedPrompt = await promptService.archivePrompt(promptId, botId);
        setOriginalPrompt(archivedPrompt);
        setPrompt(archivedPrompt.clone());
      } catch (error) {
        console.error('Error archiving prompt:', error);
      }
    },
    [promptService],
  );

  const deletePrompt = useCallback(async () => {
    try {
      await promptService.deletePrompt(promptId);
    } catch (error) {
      console.error('Error deleting prompt:', error);
    }
  }, [promptId, promptService]);

  const deletePromptVersion = useCallback(
    async (promptId: number) => {
      try {
        await promptService.deletePromptVersion(promptId);
      } catch (error) {
        console.error('Error deleting prompt version:', error);
      }
    },
    [promptService],
  );

  const createNewPrompt = useCallback(
    async (data: any) => {
      try {
        const { _modelInfo, _originalValues, subscribers: _subscribers, ...rest } = data;
        const createdPrompt = await promptService.createNewPrompt(rest);
        setOriginalPrompt(createdPrompt);
        setPrompt(createdPrompt.clone());
      } catch (error) {
        console.error('Error creating new prompt:', error);
      }
    },
    [promptService],
  );

  const createNewDraft = useCallback(async () => {
    try {
      const newDraft = await promptService.createNewDraft(promptId);
      setPrompt(newDraft);
      navigate(`${ROUTES.PROMPT_PLAYGROUND}/${newDraft.id}`);
    } catch (error) {
      console.error('Error creating new draft:', error);
    }
  }, [promptId, navigate, promptService]);

  const restorePrompt = useCallback(async () => {
    try {
      const restorePrompt = await promptService.restorePrompt(promptId);
      navigate(`${ROUTES.PROMPT_PLAYGROUND}/${restorePrompt.id}`);
    } catch (error) {
      console.error('Error restoring prompt:', error);
    }
  }, [promptId, navigate, promptService]);

  const tunePrompt = useCallback(
    async (data: any) => {
      try {
        const { _modelInfo, _originalValues, subscribers: _subscribers, ...rest } = data;
        const tunedPrompt = await promptService.tunePrompt(rest);
        navigate(`${ROUTES.PROMPT_PLAYGROUND}/${tunedPrompt.id}`);
      } catch (error) {
        console.error('Error creating new prompt:', error);
      }
    },
    [navigate, promptService],
  );

  const subscribeToPrompt = useCallback(
    (callback: () => void) => {
      if (!prompt) return undefined;
      const unsubscribe = prompt.subscribe(callback);
      return unsubscribe;
    },
    [prompt],
  );

  const contextValue = {
    prompt,
    originalPrompt,
    loading,
    error,
    versions,
    savePrompt,
    resetPrompt,
    userMessage,
    setUserMessage,
    fetchModels,
    publishPrompt,
    updatePrompt,
    archivePrompt,
    deletePrompt,
    deletePromptVersion,
    createNewPrompt,
    createNewDraft,
    restorePrompt,
    executePrompt,
    fetchVersions,
    subscribeToPrompt,
    tunePrompt,
  };

  return <PromptContext.Provider value={contextValue}>{children}</PromptContext.Provider>;
};

export const usePrompt = () => useContext(PromptContext);
