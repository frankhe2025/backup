export { default as ResponseComponent } from './response.component';
