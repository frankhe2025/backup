import React, { FC, useState, useEffect } from 'react';
import { Icon } from '@iconify/react';
import { usePrompt } from '../../prompt-context';
import getPromptsServiceInstance, { PROMPTS_SERVICE_TYPES } from '../../../commons/prompts_service_factory';
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Modal,
  ModalBody,
  ModalContent,
  ModalHeader,
  ModalFooter,
  Select,
  SelectItem,
  Slider,
  ListboxSection,
} from '@aisera-ui/react';
import { useNgTransaltion } from '../../../../../i18n/hooks/translation.hook';
import PromptPlaygroundInterface from '../../prompt-playground.interface';
import { useModelList } from '../../../hooks/use-model-list';

export const ResponseComponent: FC = () => {
  const { _t } = useNgTransaltion('Prompt');
  const { prompt, userMessage } = usePrompt();
  const { items: modelItems, isLoading: modelsLoading } = useModelList();
  const [selectedModelId, setSelectedModelId] = useState<number | null>(null);
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);
  const [isModelParamsOpen, setIsModelParamsOpen] = useState<boolean>(false);
  const [response, setResponse] = useState<string | null>(null);
  const [outputValues, setOutputValues] = useState<Record<string, any> | null>(null);
  const [responseLoading, setResponseLoading] = useState<boolean>(false);

  const [temperature, setTemperature] = useState<number>(0);
  const [maxLength, setMaxLength] = useState<number>(1000);
  const [presencePenalty, setPresencePenalty] = useState<number>(0);
  const [frequencyPenalty, setFrequencyPenalty] = useState<number>(0);
  const [topP, setTopP] = useState<number>(1);

  const promptService = getPromptsServiceInstance<PromptPlaygroundInterface>(PROMPTS_SERVICE_TYPES.PROMPT_PLAYGROUND);

  useEffect(() => {
    if (prompt?.modelConfig) {
      const {
        temperature: t,
        max_tokens: mt,
        presence_penalty: pp,
        frequency_penalty: fp,
        top_p: tp,
      } = prompt.modelConfig;

      if (t !== undefined) setTemperature(t);
      if (mt !== undefined) setMaxLength(mt);
      if (pp !== undefined) setPresencePenalty(pp);
      if (fp !== undefined) setFrequencyPenalty(fp);
      if (tp !== undefined) setTopP(tp);

      console.log('Loaded model parameters from prompt:', prompt.modelConfig);
    }
  }, [prompt]);

  const allModels = modelItems;

  useEffect(() => {
    if (allModels?.length > 0 && !selectedModelId) {
      const firstGroup = allModels[0] as any;
      const defaultModelId = prompt?.modelId || parseInt(firstGroup?.options?.[0]?.key || firstGroup?.key || '0');
      setSelectedModelId(defaultModelId);
    }
  }, [allModels, prompt, selectedModelId]);

  const handleExecute = async () => {
    if (!prompt?.id) return;

    setResponseLoading(true);

    try {
      if (promptService.executePrompt) {
        const modelOptions = {
          temperature,
          max_tokens: maxLength,
          presence_penalty: presencePenalty,
          frequency_penalty: frequencyPenalty,
          top_p: topP,
        };

        const responseData = await promptService.executePrompt(
          prompt.id,
          userMessage,
          selectedModelId,
          modelOptions,
          prompt,
        );

        let displayResponse = responseData.raw;
        const parsedOutputValues: Record<string, any> | null = responseData.parsed || null;

        try {
          const apiResponse = JSON.parse(displayResponse);
          if (Object.prototype.hasOwnProperty.call(apiResponse, 'response')) {
            const responseContent = apiResponse.response;
            if (responseContent === '') {
              displayResponse = '';
            } else {
              try {
                const parsedContent = JSON.parse(responseContent);
                displayResponse = JSON.stringify(parsedContent, null, 2);
              } catch {
                displayResponse = responseContent;
              }
            }
          }
        } catch {
          // If the whole response is not JSON, keep as is
        }

        setResponse(displayResponse);
        setOutputValues(parsedOutputValues);
      } else {
        await new Promise((resolve) => setTimeout(resolve, 1500));
        const mockResponseData = {
          raw: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
          parsed: {
            requestCategory: 'Support Inquiry',
            requestPreamble: `I understand you need assistance with your request. Using model: ${selectedModelId || 'default'}`,
            intents: ['Account access', 'Password reset'],
          },
        };
        setResponse(mockResponseData.raw);
        setOutputValues(mockResponseData.parsed);
      }
    } catch (error) {
      console.error('Error executing prompt:', error);
      setResponse(`Error: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
      setOutputValues(null);
    } finally {
      setResponseLoading(false);
    }
  };

  const handleCopy = () => {
    if (response) {
      navigator.clipboard.writeText(response);
    }
  };

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const handleOpenModelParams = () => {
    setIsModelParamsOpen(true);
  };

  const handleCloseModelParams = () => {
    setIsModelParamsOpen(false);
  };

  const handleResetToDefaults = () => {
    setTemperature(0);
    setMaxLength(1000);
    setPresencePenalty(0);
    setFrequencyPenalty(0);
    setTopP(1);
  };

  const handleSaveChanges = () => {
    if (prompt) {
      const updatedModelConfig = {
        temperature,
        max_tokens: maxLength,
        presence_penalty: presencePenalty,
        frequency_penalty: frequencyPenalty,
        top_p: topP,
      };

      prompt.update('modelConfig', updatedModelConfig);

      console.log('Saved model parameters:', updatedModelConfig);
    }

    setIsModelParamsOpen(false);
  };

  const handleModelSelection = (keys: any) => {
    const selectedKeys = Array.from(keys);
    if (selectedKeys.length > 0) {
      const newModelId = Number(selectedKeys[0]);
      setSelectedModelId(newModelId);

      if (prompt) {
        prompt.update('modelId', newModelId);
      }
    }
  };

  return (
    <div className='w-full'>
      <div className='flex justify-between items-center mb-6 bg-gray-50 p-3 rounded-lg'>
        <div className='flex-1'>
          <div className='flex items-center'>
            <div className='w-[320px]'>
              <Select
                label='Model'
                labelPlacement='outside-left'
                className='w-full'
                size='sm'
                isLoading={modelsLoading}
                isDisabled={responseLoading}
                selectedKeys={selectedModelId ? [selectedModelId.toString()] : []}
                onSelectionChange={handleModelSelection}
                classNames={{
                  trigger: 'bg-white !w-[300px]',
                  value: 'text-ellipsis overflow-hidden whitespace-nowrap',
                  selectorIcon: 'w-4 h-4',
                  innerWrapper: 'pr-6',
                  mainWrapper: '!w-[300px]',
                }}>
                {modelItems.length &&
                  modelItems.map((item: any, index) => (
                    <ListboxSection key={item.key} showDivider={index !== modelItems.length - 1} title={item.label}>
                      {item.options.map((option: any) => (
                        <SelectItem key={option.key} textValue={option.label}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </ListboxSection>
                  ))}
              </Select>
            </div>

            <button
              onClick={handleOpenModelParams}
              className='ml-10 flex-shrink-0 text-gray-500 hover:text-blue-500 transition-colors'
              title={_t('PLAYGROUND.TOOLTIPS.MODEL-PARAMETERS')}>
              <Icon icon='solar:settings-linear' className='w-5 h-5' />
            </button>
          </div>
        </div>

        <div className='flex items-center'>
          <Button
            color='primary'
            onClick={handleExecute}
            isDisabled={responseLoading}
            isLoading={responseLoading}
            startContent={!responseLoading && <Icon icon='heroicons:play' className='w-5 h-5' />}
            className='mr-2'>
            {responseLoading ? _t('PLAYGROUND.BUTTONS.EXECUTING') : _t('PLAYGROUND.BUTTONS.EXECUTE')}
          </Button>

          <Button
            isIconOnly
            variant='light'
            onClick={toggleCollapse}
            className='ml-2 rounded-full'
            aria-label={isCollapsed ? _t('PLAYGROUND.BUTTONS.EXPAND') : _t('PLAYGROUND.BUTTONS.COLLAPSE')}>
            <Icon
              icon={isCollapsed ? 'heroicons:chevron-down' : 'heroicons:chevron-up'}
              className='w-5 h-5 text-gray-600'
            />
          </Button>
        </div>
      </div>

      {!isCollapsed && (
        <div className='flex flex-col lg:flex-row gap-6'>
          <div className='w-full lg:w-2/3'>
            <div className='mb-6'>
              <div className='flex justify-between items-center mb-2'>
                <h2 className='text-xl font-semibold text-gray-800'>{_t('PLAYGROUND.RESPONSE')}</h2>
                {response && (
                  <Button
                    variant='light'
                    onClick={handleCopy}
                    className='text-gray-500 hover:text-blue-500'
                    size='sm'
                    startContent={<Icon icon='solar:copy-linear' className='w-5 h-5' />}>
                    {_t('PLAYGROUND.BUTTONS.COPY')}
                  </Button>
                )}
              </div>

              <div className='w-full border border-gray-300 rounded-xl overflow-hidden'>
                {!response || response === '' ? (
                  <div className='flex flex-col items-center justify-center py-16 px-4 text-center bg-white'>
                    <p className='text-gray-500 mb-4'>{_t('PLAYGROUND.MESSAGES.NO-RESPONSE')}</p>
                  </div>
                ) : (
                  <div className='font-mono text-sm bg-white text-gray-800 p-4 min-h-[200px] whitespace-pre-wrap overflow-auto rounded-xl'>
                    {response}
                  </div>
                )}
              </div>

              <div className='mt-2 text-sm text-gray-400'>{_t('PLAYGROUND.MESSAGES.AI-DISCLAIMER')}</div>
            </div>
          </div>

          <div className='w-full lg:w-1/3'>
            <Card className='bg-gray-100'>
              <CardHeader className='px-4 py-3'>
                <h3 className='text-lg font-medium'>{_t('PLAYGROUND.OUTPUT-VALUES.TITLE')}</h3>
              </CardHeader>
              <CardBody>
                <p className='text-gray-600 text-sm mb-4'>{_t('PLAYGROUND.OUTPUT-VALUES.DESCRIPTION')}</p>
                <Card className='bg-white'>
                  <CardBody>
                    <h4 className='text-sm text-gray-500 mb-2'>{_t('PLAYGROUND.OUTPUT-VALUES.TITLE')}</h4>
                    <div className='space-y-2 min-h-[60px]'>
                      {outputValues === null ? (
                        <p className='text-gray-400 italic'>null</p>
                      ) : outputValues && Object.keys(outputValues).length > 0 ? (
                        Object.entries(outputValues).map(([key, value]) => (
                          <div key={key} className='text-sm'>
                            <span className='font-medium'>{key}:</span>{' '}
                            {typeof value === 'string' ? (
                              value
                            ) : Array.isArray(value) ? (
                              <span>[{value.join(', ')}]</span>
                            ) : (
                              JSON.stringify(value)
                            )}
                          </div>
                        ))
                      ) : (
                        <p className='text-gray-400 italic'>{_t('PLAYGROUND.OUTPUT-VALUES.NO-VALUES')}</p>
                      )}
                    </div>
                  </CardBody>
                </Card>
              </CardBody>
            </Card>
          </div>
        </div>
      )}

      <Modal isOpen={isModelParamsOpen} onClose={handleCloseModelParams} size='md'>
        <ModalContent>
          <ModalHeader className='flex flex-col gap-1'>
            <h3 className='text-xl font-semibold'>{_t('PLAYGROUND.TOOLTIPS.MODEL-PARAMETERS')}</h3>
            <p className='text-sm text-gray-500'>Configure your model parameters</p>
          </ModalHeader>
          <ModalBody>
            <div className='space-y-6'>
              <div>
                <div className='flex justify-between mb-2'>
                  <label className='text-sm font-medium'>{_t('PLAYGROUND.LABELS.TEMPERATURE')}</label>
                  <span className='text-sm'>{temperature}</span>
                </div>
                <Slider
                  size='sm'
                  step={0.1}
                  minValue={0}
                  maxValue={1}
                  defaultValue={temperature}
                  onChange={(val) => setTemperature(typeof val === 'number' ? val : 0)}
                  className='max-w-full'
                />
              </div>

              <div>
                <div className='flex justify-between mb-2'>
                  <label className='text-sm font-medium'>{_t('PLAYGROUND.LABELS.MAX-LENGTH')}</label>
                  <span className='text-sm'>{maxLength}</span>
                </div>
                <Slider
                  size='sm'
                  step={1}
                  minValue={1}
                  maxValue={4096}
                  defaultValue={maxLength}
                  onChange={(val) => setMaxLength(typeof val === 'number' ? val : 1000)}
                  className='max-w-full'
                />
              </div>

              <div>
                <div className='flex justify-between mb-2'>
                  <label className='text-sm font-medium'>{_t('PLAYGROUND.LABELS.PRESENCE-PENALTY')}</label>
                  <span className='text-sm'>{presencePenalty}</span>
                </div>
                <Slider
                  size='sm'
                  step={0.1}
                  minValue={0}
                  maxValue={2}
                  defaultValue={presencePenalty}
                  onChange={(val) => setPresencePenalty(typeof val === 'number' ? val : 0)}
                  className='max-w-full'
                />
              </div>

              <div>
                <div className='flex justify-between mb-2'>
                  <label className='text-sm font-medium'>{_t('PLAYGROUND.LABELS.FREQUENCY-PENALTY')}</label>
                  <span className='text-sm'>{frequencyPenalty}</span>
                </div>
                <Slider
                  size='sm'
                  step={0.1}
                  minValue={0}
                  maxValue={2}
                  defaultValue={frequencyPenalty}
                  onChange={(val) => setFrequencyPenalty(typeof val === 'number' ? val : 0)}
                  className='max-w-full'
                />
              </div>

              <div>
                <div className='flex justify-between mb-2'>
                  <label className='text-sm font-medium'>{_t('PLAYGROUND.LABELS.TOP-P')}</label>
                  <span className='text-sm'>{topP}</span>
                </div>
                <Slider
                  size='sm'
                  step={0.1}
                  minValue={0}
                  maxValue={1}
                  defaultValue={topP}
                  onChange={(val) => setTopP(typeof val === 'number' ? val : 1)}
                  className='max-w-full'
                />
              </div>
            </div>
          </ModalBody>
          <ModalFooter>
            <Button variant='flat' color='default' onClick={handleResetToDefaults}>
              {_t('PLAYGROUND.BUTTONS.RESET-TO-DEFAULTS')}
            </Button>
            <Button color='primary' onClick={handleSaveChanges}>
              {_t('PLAYGROUND.BUTTONS.SAVE-CHANGES')}
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </div>
  );
};

export default ResponseComponent;
