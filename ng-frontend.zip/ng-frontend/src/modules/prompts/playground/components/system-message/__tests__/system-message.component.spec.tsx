import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { SystemMessageComponent } from '../system-message.component';
import { Prompt } from '../../../../entities/prompt.entity';

const mockUsePrompt = jest.fn();
jest.mock('../../../prompt-context', () => ({
  usePrompt: () => mockUsePrompt(),
}));

const mockUseNgTransaltion = jest.fn();
jest.mock('../../../../../../i18n/hooks/translation.hook', () => ({
  useNgTransaltion: () => mockUseNgTransaltion(),
}));

Object.assign(navigator, {
  clipboard: {
    writeText: jest.fn(),
  },
});

jest.mock('@iconify/react', () => ({
  Icon: ({ icon, className }: any) => <span data-testid={`icon-${icon}`} className={className} />,
}));

describe('SystemMessageComponent', () => {
  let mockPrompt: Prompt;
  let mockPromptContext: any;
  let mockTranslation: jest.Mock;

  beforeEach(() => {
    mockPrompt = new Prompt({
      id: 1,
      name: 'Test Prompt',
      promptText: 'Test system message content',
    });

    mockPromptContext = {
      prompt: mockPrompt,
      loading: false,
    };

    mockTranslation = jest.fn((key: string, options?: any) => {
      const translations: Record<string, string> = {
        'PLAYGROUND.LOADING.SYSTEM-MESSAGE': 'Loading system message...',
        'PLAYGROUND.BUTTONS.ATTACH': 'Attach',
        'PLAYGROUND.BUTTONS.VOICE-COMMANDS': 'Voice Commands',
        'PLAYGROUND.BUTTONS.TEMPLATES': 'Templates',
        'PLAYGROUND.LABELS.CHARACTER-COUNT': options ? `${options.count}/2000` : '0/2000',
      };
      return translations[key] || key;
    });

    mockUsePrompt.mockReturnValue(mockPromptContext);
    mockUseNgTransaltion.mockReturnValue({
      _t: mockTranslation,
      i18n: {} as any,
    });

    mockPrompt.update = jest.fn();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('loading state', () => {
    it('should show translated loading message when loading is true', () => {
      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        loading: true,
      });

      render(<SystemMessageComponent />);

      expect(screen.getByText('Loading system message...')).toBeInTheDocument();
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.LOADING.SYSTEM-MESSAGE');
    });
  });

  describe('initial render', () => {
    it('should render translated button labels', () => {
      render(<SystemMessageComponent />);

      expect(screen.getByText('Attach')).toBeInTheDocument();
      expect(screen.getByText('Voice Commands')).toBeInTheDocument();
      expect(screen.getByText('Templates')).toBeInTheDocument();

      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.BUTTONS.ATTACH');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.BUTTONS.VOICE-COMMANDS');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.BUTTONS.TEMPLATES');
    });
  });

  describe('accessibility', () => {
    it('should have proper ARIA attributes for buttons', () => {
      render(<SystemMessageComponent />);

      const buttons = screen.getAllByRole('button');
      expect(buttons.length).toBeGreaterThan(0);
    });
  });

  describe('translation integration', () => {
    it('should call translation function for basic translatable strings', () => {
      render(<SystemMessageComponent />);

      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.BUTTONS.ATTACH');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.BUTTONS.VOICE-COMMANDS');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.BUTTONS.TEMPLATES');
    });

    it('should handle missing translations gracefully', () => {
      mockTranslation.mockImplementation((key: string) => key);

      render(<SystemMessageComponent />);

      expect(screen.getByText('PLAYGROUND.BUTTONS.ATTACH')).toBeInTheDocument();
    });
  });
});
