import React, { FC, useEffect, useRef } from 'react';
import { Icon } from '@iconify/react';
import { usePrompt } from '../../../prompt-context';
import { useNgTransaltion } from '../../../../../../i18n/hooks/translation.hook';

interface UserMessageComponentProps {
  isVisible?: boolean;
  onVisibilityChange?: (visible: boolean) => void;
}

export const UserMessageComponent: FC<UserMessageComponentProps> = ({ isVisible = true, onVisibilityChange }) => {
  const { _t } = useNgTransaltion('Prompt');
  const { prompt, loading, userMessage, setUserMessage } = usePrompt();
  const editorRef = useRef<HTMLDivElement>(null);

  const isDisabled = !!(prompt && (prompt.state === 'Published' || prompt.status === 'Archived'));

  const handleChange = (e: React.FormEvent<HTMLDivElement>) => {
    if (isDisabled) {
      return;
    }

    const content = e.currentTarget.textContent || '';
    setUserMessage(content);

    if (prompt) {
      prompt.update('userRequest', content);
    }
  };

  const handleDeleteClick = () => {
    if (isDisabled) {
      return;
    }
    setUserMessage('');
    if (editorRef.current) {
      editorRef.current.textContent = '';
      editorRef.current.focus();
    }

    if (prompt) {
      prompt.update('userRequest', '');
    }

    if (onVisibilityChange) {
      onVisibilityChange(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(userMessage || '');
  };

  const handleFocus = () => {
    if (!isDisabled && !userMessage && editorRef.current) {
      editorRef.current.textContent = '';
    }
  };

  useEffect(() => {
    if (editorRef.current && userMessage !== undefined) {
      if (editorRef.current.textContent !== userMessage) {
        editorRef.current.textContent = userMessage;
      }
    }
  }, [userMessage]);

  if (loading) {
    return <div>{_t('PLAYGROUND.LOADING.DEFAULT')}</div>;
  }

  if (!isVisible) {
    return null;
  }

  return (
    <div className='w-full mb-4'>
      <div className='flex justify-between items-center mb-2'>
        <div className='flex items-center'>
          <span className={`text-xl font-semibold ${isDisabled ? 'text-gray-500' : ''}`}>
            {_t('PLAYGROUND.USER-MESSAGE')}
          </span>
          <button
            onClick={() => onVisibilityChange && onVisibilityChange(false)}
            disabled={isDisabled}
            className='bg-transparent border-0 ml-1'>
            <Icon icon='heroicons:chevron-down' className={`ml-1 ${isDisabled ? 'text-gray-400' : 'text-gray-500'}`} />
          </button>
          <button
            className={`ml-2 bg-transparent border-0 ${isDisabled ? 'text-gray-400' : 'text-gray-400'}`}
            onClick={handleCopy}
            title={_t('PLAYGROUND.BUTTONS.COPY')}>
            <Icon icon='mdi:content-copy' className='w-5 h-5' />
          </button>
        </div>

        <div className='flex items-center'>
          <button
            className={`bg-transparent border-0 ${isDisabled ? 'text-gray-400' : 'text-gray-400'}`}
            onClick={handleDeleteClick}
            disabled={isDisabled}
            title={_t('PLAYGROUND.TOOLTIPS.DELETE-MESSAGE')}>
            <Icon icon='heroicons:trash' className='w-5 h-5' />
          </button>
        </div>
      </div>

      <div className='relative'>
        <div
          className={`border rounded-xl overflow-hidden flex flex-col ${
            isDisabled ? 'border-gray-200 bg-gray-50' : 'border-gray-300 bg-gray-50'
          }`}>
          <div
            ref={editorRef}
            contentEditable={!isDisabled}
            className={`w-full min-h-[150px] border-none font-mono text-sm focus:ring-0 focus:outline-none p-4 ${
              isDisabled ? 'bg-gray-100 text-gray-600' : 'bg-white'
            }`}
            onInput={handleChange}
            onFocus={handleFocus}
            suppressContentEditableWarning={true}
            data-placeholder={_t('PLAYGROUND.PLACEHOLDERS.USER-MESSAGE')}
            style={{
              position: 'relative',
            }}
          />
          {!userMessage && (
            <div
              className={`absolute top-4 left-4 pointer-events-none ${isDisabled ? 'text-gray-400' : 'text-gray-400'}`}
              style={{ zIndex: 1 }}>
              {_t('PLAYGROUND.PLACEHOLDERS.USER-MESSAGE')}
            </div>
          )}
        </div>
      </div>

      <div className={`mt-2 text-sm ${isDisabled ? 'text-gray-400' : 'text-gray-400'}`}>
        {_t('PLAYGROUND.MESSAGES.AI-DISCLAIMER')}
      </div>
    </div>
  );
};

export default UserMessageComponent;
