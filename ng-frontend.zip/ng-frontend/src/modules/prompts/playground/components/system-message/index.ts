export { default as SystemMessageComponent } from './system-message.component';
