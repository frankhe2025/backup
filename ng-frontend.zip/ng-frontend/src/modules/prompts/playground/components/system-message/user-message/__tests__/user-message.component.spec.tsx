import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { UserMessageComponent } from '../user-message.component';
import { Prompt } from '../../../../../entities/prompt.entity';

const mockUsePrompt = jest.fn();
jest.mock('../../../../prompt-context', () => ({
  usePrompt: () => mockUsePrompt(),
}));

const mockUseNgTransaltion = jest.fn();
jest.mock('../../../../../../../i18n/hooks/translation.hook', () => ({
  useNgTransaltion: () => mockUseNgTransaltion(),
}));

Object.assign(navigator, {
  clipboard: {
    writeText: jest.fn(),
  },
});

jest.mock('@iconify/react', () => ({
  Icon: ({ icon, className }: any) => <span data-testid={`icon-${icon}`} className={className} />,
}));

describe('UserMessageComponent', () => {
  let mockPrompt: Prompt;
  let mockPromptContext: any;
  let mockTranslation: jest.Mock;
  let mockSetUserMessage: jest.Mock;
  let mockOnVisibilityChange: jest.Mock;

  beforeEach(() => {
    mockPrompt = new Prompt({
      id: 1,
      name: 'Test Prompt',
      userRequest: 'Test user message content',
    });

    mockSetUserMessage = jest.fn();
    mockOnVisibilityChange = jest.fn();

    mockPromptContext = {
      prompt: mockPrompt,
      loading: false,
      userMessage: 'Test user message content',
      setUserMessage: mockSetUserMessage,
    };

    mockTranslation = jest.fn((key: string) => {
      const translations: Record<string, string> = {
        'PLAYGROUND.LOADING.DEFAULT': 'Loading...',
        'PLAYGROUND.USER-MESSAGE': 'User Message',
        'PLAYGROUND.BUTTONS.COPY': 'Copy',
        'PLAYGROUND.TOOLTIPS.DELETE-MESSAGE': 'Delete message',
        'PLAYGROUND.PLACEHOLDERS.USER-MESSAGE': 'Add User Message',
        'PLAYGROUND.MESSAGES.AI-DISCLAIMER': 'Acme AI can make mistakes. Consider checking important information.',
      };
      return translations[key] || key;
    });

    mockUsePrompt.mockReturnValue(mockPromptContext);
    mockUseNgTransaltion.mockReturnValue({
      _t: mockTranslation,
      i18n: {} as any,
    });

    mockPrompt.update = jest.fn();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('loading state', () => {
    it('should show translated loading message when loading is true', () => {
      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        loading: true,
      });

      render(<UserMessageComponent />);

      expect(screen.getByText('Loading...')).toBeInTheDocument();
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.LOADING.DEFAULT');
    });
  });

  describe('visibility', () => {
    it('should render when isVisible is true', () => {
      render(<UserMessageComponent isVisible={true} />);

      expect(screen.getByText('User Message')).toBeInTheDocument();
    });

    it('should not render when isVisible is false', () => {
      render(<UserMessageComponent isVisible={false} />);

      expect(screen.queryByText('User Message')).not.toBeInTheDocument();
    });

    it('should render by default when isVisible is not provided', () => {
      render(<UserMessageComponent />);

      expect(screen.getByText('User Message')).toBeInTheDocument();
    });
  });

  describe('initial render', () => {
    it('should render translated labels and text', () => {
      render(<UserMessageComponent />);

      expect(screen.getByText('User Message')).toBeInTheDocument();
      expect(
        screen.getByText('Acme AI can make mistakes. Consider checking important information.'),
      ).toBeInTheDocument();

      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.USER-MESSAGE');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.MESSAGES.AI-DISCLAIMER');
    });

    it('should render placeholder when no user message', () => {
      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        userMessage: '',
      });

      render(<UserMessageComponent />);

      expect(screen.getByText('Add User Message')).toBeInTheDocument();
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.PLACEHOLDERS.USER-MESSAGE');
    });
  });

  describe('copy functionality', () => {
    it('should copy user message to clipboard when copy button is clicked', async () => {
      render(<UserMessageComponent />);

      const copyButton = screen.getByTitle('Copy');
      fireEvent.click(copyButton);

      expect(navigator.clipboard.writeText).toHaveBeenCalledWith('Test user message content');
    });

    it('should copy empty string when userMessage is null', async () => {
      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        userMessage: null,
      });

      render(<UserMessageComponent />);

      const copyButton = screen.getByTitle('Copy');
      fireEvent.click(copyButton);

      expect(navigator.clipboard.writeText).toHaveBeenCalledWith('');
    });
  });

  describe('delete functionality', () => {
    it('should clear user message when delete button is clicked', () => {
      render(<UserMessageComponent onVisibilityChange={mockOnVisibilityChange} />);

      const deleteButton = screen.getByTitle('Delete message');
      fireEvent.click(deleteButton);

      expect(mockSetUserMessage).toHaveBeenCalledWith('');
      expect(mockPrompt.update).toHaveBeenCalledWith('userRequest', '');
      expect(mockOnVisibilityChange).toHaveBeenCalledWith(false);
    });

    it('should not call onVisibilityChange when not provided', () => {
      render(<UserMessageComponent />);

      const deleteButton = screen.getByTitle('Delete message');
      fireEvent.click(deleteButton);

      expect(mockSetUserMessage).toHaveBeenCalledWith('');
    });
  });

  describe('visibility toggle', () => {
    it('should call onVisibilityChange when chevron button is clicked', () => {
      render(<UserMessageComponent onVisibilityChange={mockOnVisibilityChange} />);

      const chevronButton = screen.getByTestId('icon-heroicons:chevron-down').parentElement;
      if (chevronButton) {
        fireEvent.click(chevronButton);
      }

      expect(mockOnVisibilityChange).toHaveBeenCalledWith(false);
    });

    it('should not call onVisibilityChange when not provided', () => {
      render(<UserMessageComponent />);

      const chevronButton = screen.getByTestId('icon-heroicons:chevron-down').parentElement;
      if (chevronButton) {
        fireEvent.click(chevronButton);
      }
    });
  });

  describe('translation integration', () => {
    it('should call translation function for all translatable strings', () => {
      render(<UserMessageComponent />);

      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.USER-MESSAGE');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.BUTTONS.COPY');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.TOOLTIPS.DELETE-MESSAGE');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.MESSAGES.AI-DISCLAIMER');
    });

    it('should handle missing translations gracefully', () => {
      mockTranslation.mockImplementation((key: string) => key);

      render(<UserMessageComponent />);

      expect(screen.getByText('PLAYGROUND.USER-MESSAGE')).toBeInTheDocument();
    });
  });
});
