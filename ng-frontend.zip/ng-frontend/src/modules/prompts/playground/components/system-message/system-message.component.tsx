import React, { FC, useState, useEffect, useRef } from 'react';
import { Icon } from '@iconify/react';
import { usePrompt } from '../../prompt-context';
import { useNgTransaltion } from '../../../../../i18n/hooks/translation.hook';

interface SystemMessageComponentProps {
  expanded?: boolean;
}

export const SystemMessageComponent: FC<SystemMessageComponentProps> = ({ expanded = false }) => {
  const { _t } = useNgTransaltion('Prompt');
  const { prompt, loading } = usePrompt();
  const [systemMessage, setSystemMessage] = useState<string>('');
  const editorRef = useRef<HTMLDivElement>(null);

  const isDisabled = !!(prompt && (prompt.state === 'Published' || prompt.status === 'Archived'));

  useEffect(() => {
    if (prompt) {
      setSystemMessage(prompt.promptText || '');
      if (editorRef.current) {
        editorRef.current.innerText = prompt.promptText || '';
      }
    }
  }, [prompt]);

  const handleChange = (e: React.FormEvent<HTMLDivElement>) => {
    if (isDisabled) {
      return;
    }
    const content = e.currentTarget.innerText;
    setSystemMessage(content);

    if (prompt) {
      prompt.update('promptText', content);
    }
  };

  if (loading) {
    return <div>{_t('PLAYGROUND.LOADING.SYSTEM-MESSAGE')}</div>;
  }

  return (
    <div
      className={`w-full relative border rounded-xl overflow-hidden h-full flex flex-col ${
        isDisabled ? 'border-gray-200 bg-gray-50' : 'border-gray-300'
      }`}>
      <div
        ref={editorRef}
        contentEditable={!isDisabled}
        className={`w-full font-mono text-sm focus:ring-0 focus:outline-none p-4 overflow-auto ${
          expanded ? 'h-[calc(100vh-350px)]' : 'min-h-[400px]'
        } ${isDisabled ? 'bg-gray-100 text-gray-600' : 'bg-white'}`}
        onInput={handleChange}
        suppressContentEditableWarning={true}
      />

      <div
        className={`flex justify-between items-center p-2 border-t border-gray-200 ${
          isDisabled ? 'bg-gray-50' : 'bg-white'
        }`}>
        <div className='flex'>
          <button
            disabled={isDisabled}
            className={`inline-flex items-center px-3 py-1.5 mr-2 text-sm border border-gray-200 rounded-md ${
              isDisabled ? 'text-gray-400 bg-gray-50' : 'text-gray-600 bg-gray-100 cursor-pointer hover:bg-gray-200'
            }`}>
            <Icon icon='heroicons:paper-clip' className='w-5 h-5 mr-1' />
            <span>{_t('PLAYGROUND.BUTTONS.ATTACH')}</span>
          </button>
          <button
            disabled={isDisabled}
            className={`inline-flex items-center px-3 py-1.5 mr-2 text-sm border border-gray-200 rounded-md ${
              isDisabled ? 'text-gray-400 bg-gray-50' : 'text-gray-600 bg-gray-100 cursor-pointer hover:bg-gray-200'
            }`}>
            <Icon icon='heroicons:microphone' className='w-5 h-5 mr-1' />
            <span>{_t('PLAYGROUND.BUTTONS.VOICE-COMMANDS')}</span>
          </button>
          <button
            disabled={isDisabled}
            className={`inline-flex items-center px-3 py-1.5 text-sm border border-gray-200 rounded-md ${
              isDisabled ? 'text-gray-400 bg-gray-50' : 'text-gray-600 bg-gray-100 cursor-pointer hover:bg-gray-200'
            }`}>
            <Icon icon='heroicons:document-text' className='w-5 h-5 mr-1' />
            <span>{_t('PLAYGROUND.BUTTONS.TEMPLATES')}</span>
          </button>
        </div>
        <div>
          <span className={`text-sm ${isDisabled ? 'text-gray-400' : 'text-gray-500'}`}>
            {_t('PLAYGROUND.LABELS.CHARACTER-COUNT', { count: systemMessage.length })}
          </span>
        </div>
      </div>
    </div>
  );
};

export default SystemMessageComponent;
