export { default as VariablesComponent } from './variables.component';
