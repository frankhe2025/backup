import React, { FC, useState, useEffect } from 'react';
import { usePrompt } from '../../prompt-context';
import { Icon } from '@iconify/react';
import { useNgTransaltion } from '../../../../../i18n/hooks/translation.hook';

interface TempVariable {
  id: string;
  name: string;
  sampleValue?: string;
  type: string;
}

export const VariablesComponent: FC = () => {
  const { _t } = useNgTransaltion('Prompt');
  const { prompt, loading } = usePrompt();

  const isDisabled = !!(prompt && (prompt.state === 'Published' || prompt.status === 'Archived'));

  const [tempInputVariables, setTempInputVariables] = useState<TempVariable[]>([]);
  const [tempOutputVariables, setTempOutputVariables] = useState<TempVariable[]>([]);
  const [inputVariables, setInputVariables] = useState<any[]>([]);
  const [outputVariables, setOutputVariables] = useState<any[]>([]);
  const [inputSampleValues, setInputSampleValues] = useState<{ [key: number]: string }>({});
  const [transformationScriptValue, setTransformationScriptValue] = useState<string>('');
  const [openTypeDropdown, setOpenTypeDropdown] = useState<number | null>(null);
  const [openTempTypeDropdown, setOpenTempTypeDropdown] = useState<string | null>(null);

  const outputVariableTypes = ['String', 'Integer'];

  useEffect(() => {
    if (prompt) {
      const cleanedInputVariables = (prompt.inputVariables || []).map((v: any) => ({
        name: v.name,
        type: 'String',
      }));

      const sampleValues: { [key: number]: string } = {};
      (prompt.inputVariables || []).forEach((v: any, index: number) => {
        if (v.sampleValue) {
          sampleValues[index] = v.sampleValue;
        }
      });

      setInputVariables(cleanedInputVariables);
      setInputSampleValues(sampleValues);
      setOutputVariables(prompt.outputVariables || []);
      setTransformationScriptValue(prompt.transformationScript || '');
    }
  }, [prompt]);

  useEffect(() => {
    if (prompt?.transformationScript) {
      setTransformationScriptValue(prompt.transformationScript);
    }
  }, [prompt?.transformationScript]);

  useEffect(() => {
    const handleClickOutside = () => {
      setOpenTypeDropdown(null);
      setOpenTempTypeDropdown(null);
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  if (loading) {
    return (
      <div className='h-full bg-gray-50 p-6 rounded-lg flex-grow'>
        <div className='flex items-center justify-center h-32'>
          <span className='text-gray-500'>{_t('PLAYGROUND.LOADING.VARIABLES')}</span>
        </div>
      </div>
    );
  }

  const handleAddInputVariable = () => {
    if (isDisabled) return;

    const newVariable: TempVariable = {
      id: `temp-${Date.now()}`,
      name: '',
      sampleValue: '',
      type: 'String',
    };
    setTempInputVariables([...tempInputVariables, newVariable]);
  };

  const handleAddOutputVariable = () => {
    if (isDisabled) return;

    const newVariable: TempVariable = {
      id: `temp-${Date.now()}`,
      name: '',
      type: 'String',
    };

    const newTempVariables = [...tempOutputVariables, newVariable];

    setTempOutputVariables(newTempVariables);
  };

  const handleDeleteTempInputVariable = (id: string) => {
    const newTempVariables = tempInputVariables.filter((v) => v.id !== id);
    setTempInputVariables(newTempVariables);
  };

  const handleDeleteTempOutputVariable = (id: string) => {
    const newTempVariables = tempOutputVariables.filter((v) => v.id !== id);
    setTempOutputVariables(newTempVariables);
  };

  const handleUpdateTempInputVariable = (id: string, field: 'name' | 'sampleValue', value: string) => {
    const updatedTempVariables = tempInputVariables.map((v) => (v.id === id ? { ...v, [field]: value } : v));
    setTempInputVariables(updatedTempVariables);

    const updatedVariable = updatedTempVariables.find((v) => v.id === id);
    if (updatedVariable && updatedVariable.name.trim() !== '' && field === 'name') {
      const newVariable = {
        name: updatedVariable.name,
        type: 'String',
      };

      const newInputVariables = [...inputVariables, newVariable];
      setInputVariables(newInputVariables);
      prompt?.update('inputVariables', newInputVariables);

      setTempInputVariables((prev) => prev.filter((v) => v.id !== id));
    }
  };

  const handleUpdateTempOutputVariable = (id: string, field: 'name' | 'type', value: string) => {
    const updatedTempVariables = tempOutputVariables.map((v) => (v.id === id ? { ...v, [field]: value } : v));
    setTempOutputVariables(updatedTempVariables);

    const updatedVariable = updatedTempVariables.find((v) => v.id === id);
    if (updatedVariable && updatedVariable.name.trim() !== '' && field === 'name') {
      const newVariable = {
        name: updatedVariable.name,
        type: updatedVariable.type,
      };

      const newOutputVariables = [...outputVariables, newVariable];
      setOutputVariables(newOutputVariables);
      prompt?.update('outputVariables', newOutputVariables);

      setTempOutputVariables((prev) => prev.filter((v) => v.id !== id));
    }
  };

  const handleUpdateInputVariable = (index: number, field: 'name' | 'sampleValue', value: string) => {
    if (!prompt) return;

    const newInputVariables = [...inputVariables];
    if (field === 'name') {
      newInputVariables[index] = {
        name: value,
        type: 'String',
      };

      setInputVariables(newInputVariables);
      prompt.update('inputVariables', newInputVariables);
    } else if (field === 'sampleValue') {
      setInputSampleValues((prev) => ({
        ...prev,
        [index]: value,
      }));
    }
  };

  const handleDeleteInputVariable = (index: number) => {
    if (!prompt) return;

    const newInputVariables = [...inputVariables];
    newInputVariables.splice(index, 1);

    const newSampleValues = { ...inputSampleValues };
    delete newSampleValues[index];
    Object.keys(newSampleValues).forEach((key) => {
      const numKey = parseInt(key);
      if (numKey > index) {
        newSampleValues[numKey - 1] = newSampleValues[numKey];
        delete newSampleValues[numKey];
      }
    });

    setInputVariables(newInputVariables);
    setInputSampleValues(newSampleValues);
    prompt.update('inputVariables', newInputVariables);
  };

  const handleDeleteOutputVariable = (index: number) => {
    console.log('Deleting output variable at index:', index, 'Current variables:', outputVariables);
    if (!prompt) return;

    const newOutputVariables = [...outputVariables];
    newOutputVariables.splice(index, 1);
    console.log('New output variables after deletion:', newOutputVariables);

    setOutputVariables(newOutputVariables);
    prompt.update('outputVariables', newOutputVariables);
  };

  const handleUpdateOutputVariable = (index: number, field: 'name' | 'type', value: string) => {
    if (!prompt) return;

    const newOutputVariables = [...outputVariables];
    newOutputVariables[index] = {
      ...newOutputVariables[index],
      [field]: value,
    };

    setOutputVariables(newOutputVariables);
    prompt.update('outputVariables', newOutputVariables);
  };

  const toggleTypeDropdown = (index: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setOpenTypeDropdown(openTypeDropdown === index ? null : index);
  };

  const toggleTempTypeDropdown = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setOpenTempTypeDropdown(openTempTypeDropdown === id ? null : id);
  };

  const handleTransformationScriptChange = (value: string) => {
    if (isDisabled) return;

    setTransformationScriptValue(value);
    if (prompt) {
      prompt.update('transformationScript', value);
    }
  };

  return (
    <div className={`h-full p-6 rounded-lg flex-grow ${isDisabled ? 'bg-gray-100' : 'bg-gray-50'}`}>
      <div className='mb-10'>
        <div className='flex justify-between items-center mb-2'>
          <h4 className={`text-2xl font-semibold ${isDisabled ? 'text-gray-500' : ''}`}>
            {_t('PLAYGROUND.INPUT-VARIABLES')}
          </h4>
          <button
            className={`flex items-center ${isDisabled ? 'text-gray-400' : 'text-blue-500'}`}
            onClick={handleAddInputVariable}
            disabled={isDisabled}>
            <div
              className={`flex items-center justify-center rounded-full w-8 h-8 mr-2 ${
                isDisabled ? 'bg-gray-200 text-gray-400' : 'bg-blue-100 text-blue-500'
              }`}>
              <Icon icon='heroicons:plus' className='w-5 h-5' />
            </div>
            <span className='text-sm'>{_t('PLAYGROUND.BUTTONS.NEW')}</span>
          </button>
        </div>
        <p className={`text-base mb-6 ${isDisabled ? 'text-gray-400' : 'text-gray-500'}`}>
          {_t('PLAYGROUND.DESCRIPTIONS.INPUT-VARIABLES')}
        </p>

        <div className='space-y-6'>
          {inputVariables.length > 0 && (
            <>
              {inputVariables.map((variable: any, index: number) => (
                <div key={index} className='space-y-2'>
                  <div className={`mb-1 ${isDisabled ? 'text-gray-400' : 'text-gray-600'}`}>
                    {_t('PLAYGROUND.LABELS.VARIABLE-NAME')}
                  </div>
                  <div className='flex items-center space-x-2'>
                    <div className={`flex-1 rounded-lg p-3 shadow-sm ${isDisabled ? 'bg-gray-100' : 'bg-white'}`}>
                      <input
                        type='text'
                        className={`text-base w-full outline-none border-none bg-transparent ${
                          isDisabled ? 'text-gray-500' : ''
                        }`}
                        placeholder={_t('PLAYGROUND.PLACEHOLDERS.VARIABLE-NAME')}
                        value={variable.name}
                        onChange={(e) => handleUpdateInputVariable(index, 'name', e.target.value)}
                        disabled={isDisabled}
                      />
                    </div>
                    <button
                      className={`p-2 rounded border transition-colors ${
                        isDisabled
                          ? 'border-gray-200 text-gray-400'
                          : 'border-gray-300 hover:border-red-400 hover:bg-red-50 hover:text-red-600'
                      }`}
                      onClick={() => handleDeleteInputVariable(index)}
                      disabled={isDisabled}
                      title={_t('PLAYGROUND.TOOLTIPS.DELETE-VARIABLE')}>
                      <Icon
                        icon='mdi:trash-can-outline'
                        className={`w-6 h-6 ${isDisabled ? 'text-gray-400' : 'text-gray-500 hover:text-red-600'}`}
                      />
                    </button>
                  </div>
                  <div className={`mb-1 mt-4 ${isDisabled ? 'text-gray-400' : 'text-gray-600'}`}>
                    {_t('PLAYGROUND.LABELS.SAMPLE-VALUE')}
                  </div>
                  <div className='flex items-center'>
                    <div className={`flex-1 rounded-lg p-3 shadow-sm ${isDisabled ? 'bg-gray-100' : 'bg-white'}`}>
                      <input
                        type='text'
                        className={`text-base w-full outline-none border-none bg-transparent ${
                          isDisabled ? 'text-gray-500' : ''
                        }`}
                        placeholder={_t('PLAYGROUND.PLACEHOLDERS.SAMPLE-VALUE')}
                        value={inputSampleValues[index] || ''}
                        onChange={(e) => handleUpdateInputVariable(index, 'sampleValue', e.target.value)}
                        disabled={isDisabled}
                      />
                    </div>
                    <div className='w-10'></div>
                  </div>
                </div>
              ))}
            </>
          )}

          {tempInputVariables.map((variable) => (
            <div key={variable.id} className='space-y-2'>
              <div className='text-gray-600 mb-1'>{_t('PLAYGROUND.LABELS.VARIABLE-NAME')}</div>
              <div className='flex items-center space-x-2'>
                <div className='flex-1 bg-white rounded-lg p-3 shadow-sm flex items-center justify-between'>
                  <input
                    type='text'
                    className='text-base w-full outline-none border-none bg-transparent'
                    placeholder={_t('PLAYGROUND.PLACEHOLDERS.VARIABLE-NAME')}
                    value={variable.name}
                    onChange={(e) => handleUpdateTempInputVariable(variable.id, 'name', e.target.value)}
                  />
                  <button className='p-1 rounded hover:bg-gray-100'>
                    <Icon icon='mdi:dots-horizontal' className='w-5 h-5 text-gray-400' />
                  </button>
                </div>
                <button
                  className='p-2 rounded border border-gray-300 hover:border-red-400 hover:bg-red-50 hover:text-red-600 transition-colors'
                  onClick={() => handleDeleteTempInputVariable(variable.id)}
                  title={_t('PLAYGROUND.TOOLTIPS.DELETE-VARIABLE')}>
                  <Icon icon='mdi:trash-can-outline' className='w-6 h-6 text-gray-500 hover:text-red-600' />
                </button>
              </div>
              <div className='text-gray-600 mb-1 mt-4'>{_t('PLAYGROUND.LABELS.SAMPLE-VALUE')}</div>
              <div className='flex items-center'>
                <div className='flex-1 bg-white rounded-lg p-3 shadow-sm'>
                  <input
                    type='text'
                    className='text-base w-full outline-none border-none bg-transparent'
                    placeholder={_t('PLAYGROUND.PLACEHOLDERS.SAMPLE-VALUE')}
                    value={variable.sampleValue || ''}
                    onChange={(e) => handleUpdateTempInputVariable(variable.id, 'sampleValue', e.target.value)}
                  />
                </div>
                <div className='w-10'></div>
              </div>
            </div>
          ))}

          {inputVariables.length === 0 && tempInputVariables.length === 0 && <div></div>}
        </div>
      </div>

      <div className='mb-10'>
        <div className='flex justify-between items-center mb-2'>
          <h4 className={`text-2xl font-semibold ${isDisabled ? 'text-gray-500' : ''}`}>
            {_t('PLAYGROUND.OUTPUT-VARIABLES')}
          </h4>
          <button
            className={`flex items-center ${isDisabled ? 'text-gray-400' : 'text-blue-500'}`}
            onClick={handleAddOutputVariable}
            disabled={isDisabled}>
            <div
              className={`flex items-center justify-center rounded-full w-8 h-8 mr-2 ${
                isDisabled ? 'bg-gray-200 text-gray-400' : 'bg-blue-100 text-blue-500'
              }`}>
              <Icon icon='heroicons:plus' className='w-5 h-5' />
            </div>
            <span className='text-sm'>{_t('PLAYGROUND.BUTTONS.NEW')}</span>
          </button>
        </div>
        <p className={`text-base mb-6 ${isDisabled ? 'text-gray-400' : 'text-gray-500'}`}>
          {_t('PLAYGROUND.DESCRIPTIONS.OUTPUT-VARIABLES')}
        </p>

        <div className='space-y-6'>
          {outputVariables.length > 0 && (
            <>
              {outputVariables.map((variable: any, index: number) => (
                <div key={index} className='space-y-2'>
                  <div className='text-gray-600 mb-1'>{_t('PLAYGROUND.LABELS.VARIABLE-NAME')}</div>
                  <div className='flex items-center space-x-2'>
                    <div className='flex-1 bg-white rounded-lg p-3 shadow-sm'>
                      <input
                        type='text'
                        className='text-base w-full outline-none border-none bg-transparent'
                        placeholder={_t('PLAYGROUND.PLACEHOLDERS.VARIABLE-NAME')}
                        value={variable.name}
                        onChange={(e) => handleUpdateOutputVariable(index, 'name', e.target.value)}
                      />
                    </div>
                    <button
                      className='p-2 rounded border border-gray-300 hover:border-red-400 hover:bg-red-50 hover:text-red-600 transition-colors'
                      onClick={() => {
                        handleDeleteOutputVariable(index);
                      }}
                      title={_t('PLAYGROUND.TOOLTIPS.DELETE-VARIABLE')}>
                      <Icon icon='mdi:trash-can-outline' className='w-6 h-6 text-gray-500 hover:text-red-600' />
                    </button>
                  </div>
                  <div className='text-gray-600 mb-1 mt-4'>{_t('PLAYGROUND.LABELS.TYPE')}</div>
                  <div className='flex items-center'>
                    <div className='flex-1 bg-white rounded-lg p-3 shadow-sm flex items-center justify-between'>
                      <span className='text-base'>{variable.type || 'String'}</span>
                      <button className='p-1 rounded hover:bg-gray-100' onClick={(e) => toggleTypeDropdown(index, e)}>
                        <Icon icon='mdi:chevron-down' className='w-5 h-5 text-gray-400' />
                      </button>
                    </div>
                    <div className='w-10'></div>
                  </div>
                  {openTypeDropdown === index && (
                    <div className='relative'>
                      <div className='absolute right-10 z-10 mt-1 w-full max-w-[calc(100%-2.5rem)] bg-white rounded-md shadow-lg py-1'>
                        {outputVariableTypes.map((type) => (
                          <div
                            key={type}
                            className='px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer'
                            onClick={(e) => {
                              e.stopPropagation();
                              handleUpdateOutputVariable(index, 'type', type);
                              setOpenTypeDropdown(null);
                            }}>
                            {type}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </>
          )}

          {tempOutputVariables.map((variable) => (
            <div key={variable.id} className='space-y-2'>
              <div className='text-gray-600 mb-1'>{_t('PLAYGROUND.LABELS.VARIABLE-NAME')}</div>
              <div className='flex items-center space-x-2'>
                <div className='flex-1 bg-white rounded-lg p-3 shadow-sm'>
                  <input
                    type='text'
                    className='text-base w-full outline-none border-none bg-transparent'
                    placeholder={_t('PLAYGROUND.PLACEHOLDERS.VARIABLE-NAME')}
                    value={variable.name}
                    onChange={(e) => handleUpdateTempOutputVariable(variable.id, 'name', e.target.value)}
                  />
                </div>
                <button
                  className='p-2 rounded border border-gray-300 hover:border-red-400 hover:bg-red-50 hover:text-red-600 transition-colors'
                  onClick={() => handleDeleteTempOutputVariable(variable.id)}
                  title={_t('PLAYGROUND.TOOLTIPS.DELETE-VARIABLE')}>
                  <Icon icon='mdi:trash-can-outline' className='w-6 h-6 text-gray-500 hover:text-red-600' />
                </button>
              </div>
              <div className='text-gray-600 mb-1 mt-4'>{_t('PLAYGROUND.LABELS.TYPE')}</div>
              <div className='flex items-center'>
                <div className='flex-1 bg-white rounded-lg p-3 shadow-sm flex items-center justify-between'>
                  <span className='text-base'>{variable.type}</span>
                  <button
                    className='p-1 rounded hover:bg-gray-100'
                    onClick={(e) => toggleTempTypeDropdown(variable.id + '-output', e)}>
                    <Icon icon='mdi:chevron-down' className='w-5 h-5 text-gray-400' />
                  </button>
                </div>
                <div className='w-10'></div>
              </div>
              {openTempTypeDropdown === variable.id + '-output' && (
                <div className='relative'>
                  <div className='absolute right-10 z-10 mt-1 w-full max-w-[calc(100%-2.5rem)] bg-white rounded-md shadow-lg py-1'>
                    {outputVariableTypes.map((type) => (
                      <div
                        key={type}
                        className='px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer'
                        onClick={(e) => {
                          e.stopPropagation();
                          handleUpdateTempOutputVariable(variable.id, 'type', type);
                          setOpenTempTypeDropdown(null);
                        }}>
                        {type}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}

          {outputVariables.length === 0 && tempOutputVariables.length === 0 && <div></div>}
        </div>
      </div>

      <div className='mt-10'>
        <h4 className={`text-2xl font-semibold mb-2 ${isDisabled ? 'text-gray-500' : ''}`}>
          {_t('PLAYGROUND.TRANSFORMATION-SCRIPT')}
        </h4>
        <p className={`text-base mb-4 ${isDisabled ? 'text-gray-400' : 'text-gray-500'}`}>
          {_t('PLAYGROUND.DESCRIPTIONS.TRANSFORMATION-SCRIPT')}
        </p>
        <div className={`shadow-sm rounded-lg p-4 font-mono text-sm ${isDisabled ? 'bg-gray-100' : 'bg-white'}`}>
          <textarea
            className={`w-full h-32 p-3 rounded-md text-sm font-mono resize-none border focus:outline-none focus:ring-2 ${
              isDisabled ? 'bg-gray-50 text-gray-500 border-gray-200' : 'bg-white border-gray-200 focus:ring-blue-500'
            }`}
            value={transformationScriptValue}
            onChange={(e) => handleTransformationScriptChange(e.target.value)}
            placeholder={_t('PLAYGROUND.PLACEHOLDERS.TRANSFORMATION-SCRIPT')}
            disabled={isDisabled}
          />
        </div>
      </div>
    </div>
  );
};

export default VariablesComponent;
