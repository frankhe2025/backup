import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { VariablesComponent } from '../variables.component';
const mockUsePrompt = jest.fn();
jest.mock('../../../prompt-context', () => ({
  usePrompt: () => mockUsePrompt(),
}));

const mockUseNgTransaltion = jest.fn();
jest.mock('../../../../../../i18n/hooks/translation.hook', () => ({
  useNgTransaltion: () => mockUseNgTransaltion(),
}));

jest.mock('@iconify/react', () => ({
  Icon: ({ icon, className }: { icon: string; className?: string }) => (
    <div data-testid={`icon-${icon}`} className={className}>
      {icon}
    </div>
  ),
}));

describe('VariablesComponent', () => {
  let mockPrompt: any;
  let mockPromptContext: any;
  let mockTranslation: jest.Mock;

  beforeEach(() => {
    mockPrompt = {
      id: 1,
      name: 'Test Prompt',
      inputVariables: [
        { name: 'variable1', sampleValue: 'value1' },
        { name: 'variable2', sampleValue: 'value2' },
      ],
      outputVariables: [
        { name: 'output1', type: 'string' },
        { name: 'output2', type: 'number' },
      ],
      transformationScript: 'console.log("test");',
      update: jest.fn(),
    };

    mockPromptContext = {
      prompt: mockPrompt,
      loading: false,
    };

    mockTranslation = jest.fn((key: string) => {
      const translations: Record<string, string> = {
        'PLAYGROUND.INPUT-VARIABLES': 'Input Variables',
        'PLAYGROUND.OUTPUT-VARIABLES': 'Output Variables',
        'PLAYGROUND.TRANSFORMATION-SCRIPT': 'Transformation Script',
        'PLAYGROUND.BUTTONS.NEW': 'New',
        'PLAYGROUND.LABELS.VARIABLE-NAME': 'Variable Name',
        'PLAYGROUND.LABELS.SAMPLE-VALUE': 'Sample Value',
        'PLAYGROUND.LABELS.TYPE': 'Type',
        'PLAYGROUND.DESCRIPTIONS.INPUT-VARIABLES': 'Define input variables for your prompt',
        'PLAYGROUND.DESCRIPTIONS.OUTPUT-VARIABLES': 'Define expected output variables',
        'PLAYGROUND.DESCRIPTIONS.TRANSFORMATION-SCRIPT': 'Script to transform the output',
        'PLAYGROUND.PLACEHOLDERS.VARIABLE-NAME': 'Enter variable name',
        'PLAYGROUND.PLACEHOLDERS.SAMPLE-VALUE': 'Enter sample value',
        'PLAYGROUND.PLACEHOLDERS.TRANSFORMATION-SCRIPT': 'Enter your transformation script code here',
        'PLAYGROUND.TOOLTIPS.DELETE-VARIABLE': 'Delete variable',
        'PLAYGROUND.LOADING.VARIABLES': 'Loading variables...',
        'PLAYGROUND.LOADING.SYSTEM-MESSAGE': 'Loading system message...',
        'PLAYGROUND.LOADING.DEFAULT': 'Loading...',
      };
      return translations[key] || key;
    });

    mockUsePrompt.mockReturnValue(mockPromptContext);
    mockUseNgTransaltion.mockReturnValue({
      _t: mockTranslation,
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('loading state', () => {
    it('should show loading state when loading is true', () => {
      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        loading: true,
      });

      render(<VariablesComponent />);

      expect(screen.getByText('Loading variables...')).toBeInTheDocument();
    });
  });

  describe('initial render', () => {
    it('should render input and output variables sections', () => {
      render(<VariablesComponent />);

      // Check main sections
      expect(screen.getByText('Input Variables')).toBeInTheDocument();
      expect(screen.getByText('Output Variables')).toBeInTheDocument();
      expect(screen.getByText('Transformation Script')).toBeInTheDocument();
    });

    it('should render input variables from prompt', () => {
      render(<VariablesComponent />);

      // Variable names are in input fields
      expect(screen.getByDisplayValue('variable1')).toBeInTheDocument();
      expect(screen.getByDisplayValue('variable2')).toBeInTheDocument();
      // Sample values are also in input fields
      expect(screen.getByDisplayValue('value1')).toBeInTheDocument();
      expect(screen.getByDisplayValue('value2')).toBeInTheDocument();
    });

    it('should render output variables from prompt', () => {
      render(<VariablesComponent />);

      expect(screen.getByDisplayValue('output1')).toBeInTheDocument();
      expect(screen.getByDisplayValue('output2')).toBeInTheDocument();
      expect(screen.getByText('string')).toBeInTheDocument();
      expect(screen.getByText('number')).toBeInTheDocument();
    });

    it('should render transformation script', () => {
      render(<VariablesComponent />);

      expect(screen.getByDisplayValue('console.log("test");')).toBeInTheDocument();
    });

    it('should render when prompt has no variables', () => {
      const emptyPrompt = {
        id: 1,
        inputVariables: [],
        outputVariables: [],
        transformationScript: '',
        update: jest.fn(),
      };

      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        prompt: emptyPrompt,
      });

      render(<VariablesComponent />);

      expect(screen.getByText('Input Variables')).toBeInTheDocument();
      expect(screen.getByText('Output Variables')).toBeInTheDocument();
    });
  });

  describe('input variables management', () => {
    it('should have add new input variable button', () => {
      render(<VariablesComponent />);

      const addButtons = screen.getAllByText('New');
      expect(addButtons).toHaveLength(2); // One for input, one for output
    });

    it('should delete existing input variable', () => {
      render(<VariablesComponent />);

      const deleteButtons = screen.getAllByTitle('Delete variable');
      const firstDeleteButton = deleteButtons[0]; // First delete button for input variables
      fireEvent.click(firstDeleteButton);

      expect(mockPrompt.update).toHaveBeenCalledWith('inputVariables', [{ name: 'variable2', type: 'String' }]);
    });
  });

  describe('output variables management', () => {
    it('should update output variable name', () => {
      render(<VariablesComponent />);

      const nameInput = screen.getByDisplayValue('output1');
      fireEvent.change(nameInput, { target: { value: 'newOutput1' } });

      expect(mockPrompt.update).toHaveBeenCalledWith('outputVariables', [
        { name: 'newOutput1', type: 'string' },
        { name: 'output2', type: 'number' },
      ]);
    });

    it('should delete existing output variable', () => {
      render(<VariablesComponent />);

      const deleteButtons = screen.getAllByTitle('Delete variable');
      const outputDeleteButton = deleteButtons[2]; // Assuming first 2 are for input variables
      fireEvent.click(outputDeleteButton);

      expect(mockPrompt.update).toHaveBeenCalledWith('outputVariables', [{ name: 'output2', type: 'number' }]);
    });
  });

  describe('transformation script', () => {
    it('should update transformation script', () => {
      render(<VariablesComponent />);

      const textarea = screen.getByDisplayValue('console.log("test");');
      fireEvent.change(textarea, { target: { value: 'console.log("updated");' } });

      expect(mockPrompt.update).toHaveBeenCalledWith('transformationScript', 'console.log("updated");');
    });

    it('should handle empty transformation script', () => {
      const promptWithEmptyScript = {
        ...mockPrompt,
        transformationScript: '',
      };

      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        prompt: promptWithEmptyScript,
      });

      render(<VariablesComponent />);

      const textarea = screen.getByPlaceholderText('Enter your transformation script code here');
      expect(textarea).toHaveValue('');
    });
  });

  describe('translation integration', () => {
    it('should call translation function for all UI strings', () => {
      render(<VariablesComponent />);

      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.INPUT-VARIABLES');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.OUTPUT-VARIABLES');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.TRANSFORMATION-SCRIPT');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.BUTTONS.NEW');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.LABELS.VARIABLE-NAME');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.LABELS.SAMPLE-VALUE');
      expect(mockTranslation).toHaveBeenCalledWith('PLAYGROUND.LABELS.TYPE');
    });

    it('should handle missing translations gracefully', () => {
      mockTranslation.mockImplementation((key: string) => key);

      render(<VariablesComponent />);

      expect(screen.getByText('PLAYGROUND.INPUT-VARIABLES')).toBeInTheDocument();
      expect(screen.getByText('PLAYGROUND.OUTPUT-VARIABLES')).toBeInTheDocument();
    });
  });

  describe('edge cases', () => {
    it('should handle null prompt gracefully', () => {
      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        prompt: null,
      });

      render(<VariablesComponent />);

      expect(screen.getByText('Input Variables')).toBeInTheDocument();
      expect(screen.getByText('Output Variables')).toBeInTheDocument();
    });

    it('should handle prompt without transformationScript', () => {
      const promptWithoutScript = {
        ...mockPrompt,
        transformationScript: undefined,
      };

      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        prompt: promptWithoutScript,
      });

      render(<VariablesComponent />);

      const textarea = screen.getByPlaceholderText('Enter your transformation script code here');
      expect(textarea).toHaveValue('');
    });

    it('should handle prompt without variables arrays', () => {
      const promptWithoutArrays = {
        ...mockPrompt,
        inputVariables: undefined,
        outputVariables: undefined,
      };

      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        prompt: promptWithoutArrays,
      });

      render(<VariablesComponent />);

      expect(screen.getByText('Input Variables')).toBeInTheDocument();
      expect(screen.getByText('Output Variables')).toBeInTheDocument();
    });
  });

  describe('prompt updates', () => {
    it('should update local state when prompt changes', () => {
      const { rerender } = render(<VariablesComponent />);

      const updatedPrompt = {
        ...mockPrompt,
        inputVariables: [{ name: 'newVar', sampleValue: 'newValue' }],
        transformationScript: 'new script',
      };

      mockUsePrompt.mockReturnValue({
        ...mockPromptContext,
        prompt: updatedPrompt,
      });

      rerender(<VariablesComponent />);

      expect(screen.getByDisplayValue('newVar')).toBeInTheDocument();
      expect(screen.getByDisplayValue('new script')).toBeInTheDocument();
    });
  });

  describe('user interactions', () => {
    it('should handle add new input variable button click', () => {
      render(<VariablesComponent />);

      const addButtons = screen.getAllByText('New');
      const inputAddButton = addButtons[0]; // First "New" button is for input variables

      expect(inputAddButton).toBeInTheDocument();
      fireEvent.click(inputAddButton);
    });

    it('should handle add new output variable button click', () => {
      render(<VariablesComponent />);

      const addButtons = screen.getAllByText('New');
      const outputAddButton = addButtons[1]; // Second "New" button is for output variables

      expect(outputAddButton).toBeInTheDocument();
      fireEvent.click(outputAddButton);
    });
  });

  describe('component state management', () => {
    it('should handle component unmounting gracefully', () => {
      const { unmount } = render(<VariablesComponent />);

      expect(() => unmount()).not.toThrow();
    });
  });
});
