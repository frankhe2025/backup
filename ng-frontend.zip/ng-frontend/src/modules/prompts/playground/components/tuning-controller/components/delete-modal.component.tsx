import { useState } from 'react';
import { Icon } from '@iconify/react';
import { DataTable } from '@aisera-ui/data-table';
import { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, Button } from '@aisera-ui/react';
import { PromptReviewStatus } from '../../../../entities/prompt-review-status.enum';
import { useNgTransaltion } from '../../../../../../i18n/hooks/translation.hook';
import { PromptVersion } from '../../../../entities/prompt-version.entity';

interface IProps {
  name?: string;
  status: PromptReviewStatus;
  mode: 'multi' | 'single';
  promptVersions: PromptVersion[];
  onClose: () => void;
  onDelete: (ids?: number[]) => void;
}

export const DeletePromptModal = ({ name, status, promptVersions, mode, onClose, onDelete }: IProps) => {
  const { _t } = useNgTransaltion('Prompt');
  const isSingle = mode === 'single' || promptVersions.length === 1;
  const title = _t(
    isSingle ? 'TUNING-CONTROLLER.MODALS.DELETE.TITLE.SINGLE' : 'TUNING-CONTROLLER.MODALS.DELETE.TITLE.MULTI',
  );
  const [selectedIDs, setSelectedIDs] = useState(new Set());
  const tableData = promptVersions.map((version) => ({ ...version, id: version.entityId }));

  const handleSelectionChange = (selection: any) => {
    setSelectedIDs(selection);
  };

  const handleDelete = () => {
    let idsToDelete: number[] = [];

    if (selectedIDs.has('all')) {
      idsToDelete = tableData.map((row) => Number(row.id));
    } else {
      idsToDelete = Array.from(selectedIDs).map((id) => Number(id));
    }

    onDelete(idsToDelete);
  };

  return (
    <Modal isOpen size={isSingle ? 'md' : '3xl'} onOpenChange={() => onClose()}>
      <ModalContent>
        <ModalHeader className='flex flex-col gap-1'>{title}</ModalHeader>
        <ModalBody className='border-y py-4'>
          <div className='flex items-start gap-2'>
            <span className='mt-1'>
              <Icon className='text-danger-500' icon='solar:shield-warning-outline' width={20} />
            </span>
            <div>
              <span className='text-danger-500 text-sm font-semibold'>
                {_t('TUNING-CONTROLLER.MODALS.DELETE.WARNING')}
              </span>
              <p className='text-sm text-default-900 mt-1'>
                {isSingle
                  ? status === PromptReviewStatus.DRAFT
                    ? _t('TUNING-CONTROLLER.MODALS.DELETE.DESC.SINGLE.DRAFT')
                    : _t('TUNING-CONTROLLER.MODALS.DELETE.DESC.SINGLE.VERSION', { name })
                  : _t('TUNING-CONTROLLER.MODALS.DELETE.DESC.MULTI', { name })}
              </p>
            </div>
          </div>
          {!isSingle && (
            <div>
              <DataTable
                configuration={{
                  columns: [
                    {
                      key: 'name',
                      sortable: true,
                      title: _t('TUNING-CONTROLLER.MODALS.DELETE.TABLE.VERSION'),
                    },
                    {
                      key: 'description',
                      sortable: true,
                      title: _t('TUNING-CONTROLLER.MODALS.DELETE.TABLE.DESCRIPTION'),
                    },
                    {
                      key: 'date',
                      sortable: true,
                      title: _t('TUNING-CONTROLLER.MODALS.DELETE.TABLE.LAST-UPDATED'),
                    },
                    {
                      key: 'editor',
                      sortable: true,
                      title: _t('TUNING-CONTROLLER.MODALS.DELETE.TABLE.EDITED-BY'),
                    },
                  ],
                  onSelectionChange: handleSelectionChange,
                  selectionMode: 'multiple',
                }}
                data={tableData}
              />
            </div>
          )}
        </ModalBody>
        <ModalFooter>
          <Button size='sm' color='default' variant='light' onClick={() => onClose()}>
            {_t('TUNING-CONTROLLER.BUTTONS.CANCEL')}
          </Button>
          <Button size='sm' color='danger' onClick={handleDelete}>
            {title}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};
