import { Icon } from '@iconify/react';
import { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, Button } from '@aisera-ui/react';

interface IProps {
  title?: string;
  desc: string;
  onClose: () => void;
  onConfirm: () => void;
}

export const ConfirmDraftModal = ({ title, desc, onClose, onConfirm }: IProps) => {
  return (
    <Modal isOpen onOpenChange={onClose}>
      <ModalContent>
        <ModalHeader className='flex flex-col gap-1'>{title}</ModalHeader>
        <ModalBody>
          <div className='flex items-start gap-2'>
            <span>
              <Icon icon='solar:question-circle-bold' width={20} />
            </span>
            <p className='text-sm text-default-900'>{desc}</p>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button size='sm' color='default' variant='light' onClick={() => onClose()}>
            Cancel
          </Button>
          <Button size='sm' color='primary' onClick={onConfirm}>
            OK
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};
