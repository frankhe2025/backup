import { FC, useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { Icon } from '@iconify/react';
import { Button, Dropdown, DropdownTrigger, DropdownMenu, DropdownItem, useDisclosure } from '@aisera-ui/react';

import { useNgTransaltion } from '../../../../../i18n/hooks/translation.hook';
import { VersionCard, PublishPromptModal, DeletePromptModal, ConfirmDraftModal } from './components';
import { usePrompt } from '../../prompt-context';
import { PromptReviewStatus } from '../../../entities/prompt-review-status.enum';
import { PromptVersion } from '../../../entities/prompt-version.entity';
import { PromptVersionsCollection } from '../../../entities/prompt-versions.entity';
import { ROUTES } from '../../../../../commons/config/routes';
import CreateEditPrompt from '../../../commons/components/create-edit-prompt';
import { PromptScope } from '../../../entities/prompt-scope.enum';
import { PromptSourceType } from '../../../entities/prompt-source-type.enum';
import { PromptType } from '../../../entities/prompt-type.enum';
import { AppContext } from '../../../../../commons/context/app-context.context';
import { Scope } from '../../../enums/scope';
import getRbacService from '../../../../../commons/modules/auth/service/rbac.service';
import getAuthService from '../../../../../commons/modules/auth/service/auth.service';
import getCacheManager from '../../../../../commons/utils/cache_manager.util';

export const TuningControllerComponent: FC = () => {
  const { _t } = useNgTransaltion('Prompt');
  const {
    prompt,
    versions,
    savePrompt,
    publishPrompt,
    updatePrompt,
    archivePrompt,
    deletePrompt,
    createNewPrompt,
    createNewDraft,
    restorePrompt,
    deletePromptVersion,
    fetchVersions,
    subscribeToPrompt,
    tunePrompt,
  } = usePrompt();

  const navigate = useNavigate();

  const promptVersionsCollection = new PromptVersionsCollection(versions);
  const promptVersions = promptVersionsCollection.all;
  const [openPublishModal, setOpenPublishModal] = useState<boolean>(false);
  const [openConfirmDraftModal, setOpenConfirmDraftModal] = useState<boolean>(false);
  const [openCloneModal, setOpenCloneModal] = useState<boolean>(false);
  const [openDeleteModal, setOpenDeleteModal] = useState<number | undefined | null>(undefined);
  const [openConfirmArchiveModal, setOpenConfirmArchiveModal] = useState<number | undefined>(undefined);
  const [openConfirmRestoreModal, setOpenConfirmRestoreModal] = useState<boolean>(false);
  const [openConfirmTuneModal, setOpenConfirmTuneModal] = useState<boolean>(false);
  const [hasChanges, setHasChanges] = useState<boolean>(false);

  // Permission states
  const [promptStudioReadable, setPromptStudioReadable] = useState<boolean>(false);
  const [systemReadable, setSystemReadable] = useState<boolean>(false);
  const [systemWritable, setSystemWritable] = useState<boolean>(false);
  const [userWritable, setUserWritable] = useState<boolean>(false);

  const { selectedBot } = useContext(AppContext);

  let curVersionStatus = promptVersions.find((version) => version.entityId === prompt?.id)
    ?.status as PromptReviewStatus;

  if (!curVersionStatus && promptVersions.length === 1) {
    curVersionStatus = promptVersions[0].status as PromptReviewStatus;
  }

  const isDraftVersion =
    promptVersions.length > 1 &&
    promptVersions.filter((version) => version.status === PromptReviewStatus.DRAFT).length === 1;
  const isTune = prompt?.scope === PromptScope.GLOBAL && prompt?.sourceType === PromptSourceType.SYSTEM;

  // Get role access for all required permissions
  useEffect(() => {
    const checkAccess = async () => {
      // Check promptStudio permissions
      const promptStudioReadable = await getRbacService().isEntityReadable('promptStudio');
      setPromptStudioReadable(promptStudioReadable);

      // Check llmPromptsSystem permissions
      const systemReadable = await getRbacService().isEntityReadable('llmPromptsSystem');
      const systemWritable = await getRbacService().isEntityWritable('llmPromptsSystem');
      setSystemReadable(systemReadable);
      setSystemWritable(systemWritable);

      // Check llmPromptsUser permissions
      const userWritable = await getRbacService().isEntityWritable('llmPromptsUser');
      setUserWritable(userWritable);
    };
    checkAccess();
  }, [promptVersions, curVersionStatus, isDraftVersion]);

  useEffect(() => {
    if (prompt?.id) {
      fetchVersions(prompt.id.toString());
    }
  }, [fetchVersions, prompt?.id]);

  useEffect(() => {
    if (prompt && typeof prompt.hasChanges === 'function') {
      setHasChanges(prompt.hasChanges());

      const unsubscribe = subscribeToPrompt(() => {
        if (prompt && typeof prompt.hasChanges === 'function') {
          setHasChanges(prompt.hasChanges());
        }
      });

      return () => {
        if (unsubscribe) unsubscribe();
      };
    }
  }, [prompt, subscribeToPrompt]);

  const handlePublishModal = () => {
    setOpenPublishModal(!openPublishModal);
  };

  const handleConfirmPublish = async (data: any) => {
    try {
      await publishPrompt(data);
    } catch (error) {
      console.error('Error publishing prompt:', error);
    }
    handlePublishModal();
  };

  const handleSavePrompt = async (data: any) => {
    try {
      if (data.scope === Scope.Application && selectedBot?.id) {
        data.botId = selectedBot.id;
      }
      if (prompt?.id) {
        await updatePrompt(prompt.id, data);
        await refreshData();
      }
    } catch (error) {
      console.error('Error saving prompt:', error);
    }
  };

  const handleDeleteModal = (id?: number | null) => {
    if (id === null) {
      if (promptVersions.length === 1 && prompt?.id) {
        setOpenDeleteModal(prompt.id);
      } else {
        setOpenDeleteModal(null);
      }
    } else {
      setOpenDeleteModal(id);
    }
  };

  const handleDelete = async (versionIds: number[] = []) => {
    try {
      if (promptVersions.length > 1) {
        if (versionIds.length > 0) {
          await Promise.all(versionIds.map((id) => deletePromptVersion(id)));

          if (versionIds.length === promptVersions.length) {
            navigate(ROUTES.PROMPTS);
          } else {
            const remainingVersions = promptVersions.filter((version) => !versionIds.includes(version.entityId));
            if (versionIds.includes(prompt?.id || -1)) {
              navigate(`${ROUTES.PROMPT_PLAYGROUND}/${remainingVersions[0].entityId}`);
            }
            await refreshData();
          }
        } else {
          const deleteID = openDeleteModal ?? prompt?.id;

          if (deleteID) {
            await deletePromptVersion(deleteID);
            if (deleteID === prompt?.id) {
              const remainingVersions = promptVersions.filter((version) => version.entityId !== deleteID);
              navigate(`${ROUTES.PROMPT_PLAYGROUND}/${remainingVersions[0].entityId}`);
            }
            await refreshData();
          }
        }
      } else {
        await deletePrompt();
        navigate(ROUTES.PROMPTS);
      }
    } catch (error) {
      console.error('Error deleting prompt:', error);
    }

    handleDeleteModal();
  };

  const handleConfirmDraftModal = () => {
    if (isDraftVersion) {
      navigate(
        `${ROUTES.PROMPT_PLAYGROUND}/${promptVersions.filter((version) => version.status === PromptReviewStatus.DRAFT)[0].entityId}`,
      );
    } else {
      setOpenConfirmDraftModal(!openConfirmDraftModal);
    }
  };

  const handleConfirmDraft = () => {
    createNewDraft();
    handleConfirmDraftModal();
  };

  const handleArchiveModal = (id?: number) => {
    setOpenConfirmArchiveModal(id);
  };

  const handleConfirmArchive = async () => {
    const archiveID = openConfirmArchiveModal ?? prompt?.id;

    if (archiveID) {
      try {
        await archivePrompt(archiveID, selectedBot?.id || undefined);
        await refreshData();
      } catch (error) {
        console.error('Error archiving prompt:', error);
      }
      handleArchiveModal();
    }
  };

  const handleTuneModal = () => {
    setOpenConfirmTuneModal(!openConfirmTuneModal);
  };

  const handleConfirmTune = () => {
    tunePrompt({
      ...prompt,
      name: prompt?.name + '_tuned',
      sourceType: PromptSourceType.SYSTEM,
      type: PromptType.TUNED,
      state: 'Inactive',
      reviewStatus: 'Draft',
      scope: PromptScope.APPLICATION,
      botId: selectedBot?.id,
    });
    handleTuneModal();
  };

  const handleClonePrompt = async (data: any) => {
    try {
      console.log('Clone prompt with data:', data);
      if (!selectedBot?.id) {
        throw new Error('No bot selected');
      }
      if (data.scope === Scope.Application) {
        data.botId = selectedBot.id;
      }

      // Set user and prompt metadata like in home page create
      const userId = getAuthService().getUserId();
      data.createdBy = userId;
      data.sourceType = 'User';
      data.type = 'Custom';

      // Clone the current prompt content with new metadata
      const cloneData = {
        ...prompt, // Start with current prompt content
        ...data, // Override with new form data (name, description, category, scope, useCase, modelId)
        id: undefined, // Remove ID to create new prompt
        entityGuid: undefined, // Remove entityGuid to create new prompt
        // Ensure the new metadata is preserved
        name: data.name,
        createdBy: data.createdBy,
        sourceType: data.sourceType,
        type: data.type,
        botId: data.botId,
      };

      await createNewPrompt(cloneData);
      await refreshData();
    } catch (error) {
      console.error('Error cloning prompt:', error);
    }
    handleClonePromptModal();
  };

  const handleClonePromptModal = () => {
    setOpenCloneModal(!openCloneModal);
  };

  const handleConfirmRestore = () => {
    if (promptVersions.filter((version) => version.status === PromptReviewStatus.DRAFT).length > 0) {
      restorePrompt();
    } else {
      createNewDraft();
    }

    handleRestoreModal();
  };

  const handleRestoreModal = () => {
    setOpenConfirmRestoreModal(!openConfirmRestoreModal);
  };

  const {
    isOpen: isEditOpen,
    onOpen: onEditOpen,
    onOpenChange: onEditOpenChange,
    onClose: onEditClose,
  } = useDisclosure();

  const refreshData = async () => {
    try {
      getCacheManager().clear();

      if (prompt?.id) {
        await fetchVersions(prompt.id.toString());
      }
    } catch (error) {
      console.error('Error refreshing data:', error);
      window.location.reload();
    }
  };

  return (
    <div className='flex items-center justify-between'>
      <div className='flex items-center gap-3'>
        <h3 className='text-2xl font-bold'>{prompt?.name}</h3>
        {/* Edit button - requires user write permission */}
        {userWritable && (
          <Button color='default' isIconOnly variant='light' size='sm' onClick={onEditOpen} radius='full'>
            <Icon className='text-primary-500' icon='solar:file-text-broken' width={20} />
          </Button>
        )}
        {isEditOpen && (
          <CreateEditPrompt
            data={{
              name: prompt?.name,
              description: prompt?.description,
              useCase: prompt?.useCase,
              category: prompt?.category,
              scope: prompt?.scope,
            }}
            isOpen={isEditOpen}
            onOpenChange={onEditOpenChange}
            onSave={(data) => {
              handleSavePrompt(data);
              onEditClose();
            }}
          />
        )}
      </div>
      <div className='flex items-center gap-4'>
        {isTune ? (
          // Tune button - requires system write permission
          systemWritable && (
            <div>
              <Button
                fullWidth
                color='primary'
                variant='bordered'
                size='sm'
                startContent={<Icon icon='solar:tuning-4-linear' width={16} />}
                onClick={handleTuneModal}>
                {_t('TUNING-CONTROLLER.BUTTONS.TUNE')}
              </Button>
            </div>
          )
        ) : curVersionStatus === PromptReviewStatus.ARCHIVE ? (
          // Restore button - requires user write permission
          userWritable && (
            <div>
              <Button
                fullWidth
                color='primary'
                variant='bordered'
                size='sm'
                startContent={<Icon icon='solar:circle-top-up-broken' width={16} />}
                onClick={handleRestoreModal}>
                {_t('TUNING-CONTROLLER.BUTTONS.RESTORE')}
              </Button>
            </div>
          )
        ) : curVersionStatus === PromptReviewStatus.PUBLISHED ? (
          <div className='flex items-center gap-4'>
            {/* New/Edit Draft button - requires user write permission */}

            {userWritable && (
              <Button
                fullWidth
                size='sm'
                color='primary'
                variant='bordered'
                startContent={<Icon icon='solar:document-add-outline' width={16} />}
                onClick={() => handleConfirmDraftModal()}>
                {_t(isDraftVersion ? 'TUNING-CONTROLLER.BUTTONS.EDIT-DRAFT' : 'TUNING-CONTROLLER.BUTTONS.NEW-DRAFT')}
              </Button>
            )}
            {/* Clone button - requires system read permission */}
            {systemReadable && (
              <Button color='primary' variant='bordered' size='sm' onClick={handleClonePromptModal}>
                {_t('TUNING-CONTROLLER.BUTTONS.CLONE')}
              </Button>
            )}
          </div>
        ) : (
          <div className='flex items-center gap-4'>
            {/* Publish button - requires system write permission */}
            {systemWritable && (
              <Button
                fullWidth
                color='primary'
                size='sm'
                isDisabled={hasChanges}
                startContent={<Icon icon='solar:plain-linear' width={16} />}
                onClick={handlePublishModal}>
                {_t('TUNING-CONTROLLER.BUTTONS.PUBLISH')}
              </Button>
            )}
            {/* Save button - requires user write permission */}
            {userWritable && (
              <Button
                color='primary'
                variant='bordered'
                size='sm'
                isDisabled={!hasChanges}
                onClick={() => savePrompt(() => setHasChanges(false))}>
                {_t('Save', { ns: 'Common', defaultValue: 'Save' })}
              </Button>
            )}
          </div>
        )}

        {!isTune && userWritable && (
          <Dropdown placement='bottom' radius='lg' shadow='md' size='md'>
            <DropdownTrigger>
              <Button color='default' isIconOnly variant='light' size='sm'>
                <Icon className='text-default-400' icon='solar:menu-dots-linear' width={20} />
              </Button>
            </DropdownTrigger>
            <DropdownMenu aria-label='Actions'>
              {curVersionStatus === PromptReviewStatus.PUBLISHED && (
                <DropdownItem
                  onClick={() => handleArchiveModal(prompt?.id)}
                  startContent={<Icon icon='solar:archive-down-outline' width={16} />}>
                  {_t('TUNING-CONTROLLER.BUTTONS.ARCHIVE')}
                </DropdownItem>
              )}
              <DropdownItem
                color='danger'
                className='text-danger'
                onClick={() => handleDeleteModal(null)}
                startContent={<Icon icon='solar:trash-bin-minimalistic-outline' width={16} />}>
                {_t('TUNING-CONTROLLER.BUTTONS.DELETE')}
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>
        )}
        <span className='border-r h-[24px] border-default' />
        {/* Version history dropdown - requires promptStudio read permission */}
        {promptStudioReadable && (
          <Dropdown placement='bottom' radius='lg' shadow='md' size='md' className='p-0'>
            <DropdownTrigger>
              <Button
                fullWidth
                size='sm'
                color='default'
                variant='bordered'
                className='px-2 gap-1'
                endContent={<Icon className='text-default-400' icon='solar:alt-arrow-down-linear' width={16} />}>
                <span className={`font-medium ${PromptVersion.getStatusColor(curVersionStatus)}`}>
                  {curVersionStatus}
                </span>
              </Button>
            </DropdownTrigger>
            <DropdownMenu aria-label='Actions' className='p-0'>
              <DropdownItem isDisabled className='bg-default'>
                <span className='w-full font-sm font-bold text-default-800 flex justify-center'>
                  {_t('TUNING-CONTROLLER.VERSION-HISTORY')}
                </span>
              </DropdownItem>
              {promptVersions?.map((version: any) => (
                <DropdownItem key={version.entityId} className='p-0'>
                  <VersionCard
                    version={version}
                    userWritable={userWritable}
                    isSelected={version.entityId === prompt?.id}
                    onDelete={handleDeleteModal}
                    onArchive={handleArchiveModal}
                  />
                </DropdownItem>
              ))}
            </DropdownMenu>
          </Dropdown>
        )}
      </div>
      {openPublishModal && <PublishPromptModal onClose={handlePublishModal} onPublish={handleConfirmPublish} />}
      {openDeleteModal !== undefined && (
        <DeletePromptModal
          name={prompt?.name}
          status={curVersionStatus}
          promptVersions={promptVersions}
          mode={promptVersions.length === 0 ? 'single' : openDeleteModal === null ? 'multi' : 'single'}
          onClose={handleDeleteModal}
          onDelete={handleDelete}
        />
      )}
      {openConfirmDraftModal && (
        <ConfirmDraftModal
          title={_t('TUNING-CONTROLLER.MODALS.CONFIRM-DRAFT.TITLE')}
          desc={_t('TUNING-CONTROLLER.MODALS.CONFIRM-DRAFT.DESC')}
          onClose={handleConfirmDraftModal}
          onConfirm={handleConfirmDraft}
        />
      )}
      {openConfirmArchiveModal && (
        <ConfirmDraftModal
          title={_t('TUNING-CONTROLLER.MODALS.CONFIRM-ARCHIVE.TITLE')}
          desc={_t('TUNING-CONTROLLER.MODALS.CONFIRM-ARCHIVE.DESC', {
            name: promptVersions.find((version) => version.entityId === openConfirmArchiveModal)?.name,
          })}
          onClose={handleArchiveModal}
          onConfirm={handleConfirmArchive}
        />
      )}
      {openConfirmRestoreModal && (
        <ConfirmDraftModal
          title={_t('TUNING-CONTROLLER.MODALS.CONFIRM-RESTORE.TITLE')}
          desc={_t('TUNING-CONTROLLER.MODALS.CONFIRM-RESTORE.DESC')}
          onClose={handleRestoreModal}
          onConfirm={handleConfirmRestore}
        />
      )}
      {openConfirmTuneModal && (
        <ConfirmDraftModal
          title={_t('TUNING-CONTROLLER.MODALS.CONFIRM-TUNE.TITLE')}
          desc={_t('TUNING-CONTROLLER.MODALS.CONFIRM-TUNE.DESC')}
          onClose={handleTuneModal}
          onConfirm={handleConfirmTune}
        />
      )}
      {openCloneModal && (
        <CreateEditPrompt isOpen={openCloneModal} onOpenChange={handleClonePromptModal} onSave={handleClonePrompt} />
      )}
    </div>
  );
};

export default TuningControllerComponent;
