import { useForm, Controller } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, Input, Button, Textarea } from '@aisera-ui/react';
import { useNgTransaltion } from '../../../../../../i18n/hooks/translation.hook';

const schema = z.object({
  name: z.string().min(1, 'Required'),
  description: z.string().optional(),
});

type IPublishVersion = z.infer<typeof schema>;

interface IProps {
  onClose: () => void;
  onPublish: (newVersionInfo: IPublishVersion) => void;
}

export const PublishPromptModal = ({ onClose, onPublish }: IProps) => {
  const { _t } = useNgTransaltion('Prompt');
  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<IPublishVersion>({
    mode: 'all',
    defaultValues: {
      name: '',
      description: '',
    },
    resolver: zodResolver(schema) as any,
  });

  const onSubmit = (data: IPublishVersion): void => {
    if (data.name) {
      onPublish(data);
    }
  };

  return (
    <Modal isOpen onOpenChange={onClose}>
      <ModalContent>
        <form onSubmit={handleSubmit(onSubmit)}>
          <ModalHeader className='flex flex-col gap-1'>{_t('TUNING-CONTROLLER.MODALS.PUBLISH.TITLE')}</ModalHeader>
          <ModalBody>
            <p className='text-xs text-default-900'>{_t('TUNING-CONTROLLER.MODALS.PUBLISH.DESC')}</p>
            <div className='flex flex-col gap-3 mt-1'>
              <div className='flex items-baseline'>
                <label style={{ width: '142px' }} className='text-sm whitespace-nowrap font-bold text-default-600'>
                  {_t('TUNING-CONTROLLER.MODALS.PUBLISH.VERSION-NAME')} *
                </label>
                <div className='flex-1'>
                  <Controller
                    name='name'
                    control={control}
                    render={({ field: { onChange, value, name } }): JSX.Element => (
                      <Input
                        autoFocus
                        size='sm'
                        variant='bordered'
                        value={value}
                        name={name}
                        fullWidth={false}
                        isInvalid={!!errors.name}
                        errorMessage={errors.name?.message}
                        onChange={onChange}
                      />
                    )}
                  />
                </div>
              </div>
              <div className='flex items-baseline'>
                <label style={{ width: '142px' }} className='text-sm whitespace-nowrap font-bold text-default-600'>
                  {_t('TUNING-CONTROLLER.MODALS.PUBLISH.VERSION-DESC')}
                </label>
                <div className='flex-1'>
                  <Controller
                    name='description'
                    control={control}
                    render={({ field: { onChange, value, name } }): JSX.Element => (
                      <Textarea
                        fullWidth={false}
                        size='sm'
                        variant='bordered'
                        value={value ?? ''}
                        name={name}
                        onChange={onChange}
                      />
                    )}
                  />
                </div>
              </div>
            </div>
          </ModalBody>
          <ModalFooter>
            <Button size='sm' color='primary' variant='light' onClick={onClose}>
              {_t('TUNING-CONTROLLER.BUTTONS.CANCEL')}
            </Button>
            <Button size='sm' color='primary' type='submit'>
              {_t('TUNING-CONTROLLER.BUTTONS.OK')}
            </Button>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
};
