export { default as TuningControllerComponent } from './tuning-controller.component';
