import { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, Button } from '@aisera-ui/react';

interface IProps {
  onClose: () => void;
  onClone: () => void;
}

export const ClonePromptModal = ({ onClose, onClone }: IProps) => {
  return (
    <Modal isOpen onOpenChange={onClose}>
      <ModalContent>
        <ModalHeader className='flex flex-col gap-1'>Clone Prompt</ModalHeader>
        <ModalBody></ModalBody>
        <ModalFooter>
          <Button size='sm' color='primary' variant='light' onClick={onClose}>
            Cancel
          </Button>
          <Button size='sm' color='primary' onClick={onClone}>
            OK
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};
