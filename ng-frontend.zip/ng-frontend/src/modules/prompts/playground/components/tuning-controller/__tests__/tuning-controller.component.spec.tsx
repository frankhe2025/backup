import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { TuningControllerComponent } from '../tuning-controller.component';
import { PromptReviewStatus } from '../../../../entities/prompt-review-status.enum';
import { PromptScope } from '../../../../entities/prompt-scope.enum';
import { PromptSourceType } from '../../../../entities/prompt-source-type.enum';

// Mock external dependencies
const mockNavigate = jest.fn();
jest.mock('react-router', () => ({
  useNavigate: () => mockNavigate,
}));

const mockUsePrompt = jest.fn();
jest.mock('../../../prompt-context', () => ({
  usePrompt: () => mockUsePrompt(),
}));

const mockUseNgTransaltion = jest.fn();
jest.mock('../../../../../../i18n/hooks/translation.hook', () => ({
  useNgTransaltion: () => mockUseNgTransaltion(),
}));

// Mock RBAC and Auth services to avoid localStorage issues
const mockRbacService = {
  isEntityReadable: jest.fn(),
  isEntityWritable: jest.fn(),
};
jest.mock('../../../../../../commons/modules/auth/service/rbac.service', () => ({
  __esModule: true,
  default: jest.fn(() => mockRbacService),
}));

const mockAuthService = {
  isUserSignedIn: jest.fn(() => true),
  getAuth: jest.fn(() => ({ user: { id: 'test-user' } })),
  getTenantId: jest.fn(() => 'test-tenant'),
  getUserId: jest.fn(() => 'test-user'),
};
jest.mock('../../../../../../commons/modules/auth/service/auth.service', () => ({
  __esModule: true,
  default: jest.fn(() => mockAuthService),
}));

// Mock AppContext
jest.mock('../../../../../../commons/context/app-context.context', () => ({
  AppContext: React.createContext({
    selectedBot: { id: 'test-bot' },
  }),
}));

// Mock UI components
jest.mock('@aisera-ui/react', () => ({
  Button: ({ children, onClick, isDisabled, ...props }: any) => (
    <button onClick={onClick} disabled={isDisabled} data-testid='button' {...props}>
      {children}
    </button>
  ),
  Dropdown: ({ children }: any) => <div data-testid='dropdown'>{children}</div>,
  DropdownTrigger: ({ children }: any) => <div data-testid='dropdown-trigger'>{children}</div>,
  DropdownMenu: ({ children }: any) => <div data-testid='dropdown-menu'>{children}</div>,
  DropdownItem: ({ children, onClick, ...props }: any) => (
    <div onClick={onClick} data-testid='dropdown-item' {...props}>
      {children}
    </div>
  ),
  useDisclosure: () => ({
    isOpen: false,
    onOpen: jest.fn(),
    onOpenChange: jest.fn(),
    onClose: jest.fn(),
  }),
}));

jest.mock('@iconify/react', () => ({
  Icon: ({ icon }: any) => <span data-testid={`icon-${icon}`} />,
}));

// Mock modal components
jest.mock('../components', () => ({
  VersionCard: ({ version }: any) => (
    <div data-testid='version-card'>
      <span>{version.status}</span>
    </div>
  ),
  PublishPromptModal: ({ onClose, onPublish }: any) => (
    <div data-testid='publish-modal'>
      <button onClick={onClose} data-testid='close-publish'>
        Close
      </button>
      <button onClick={onPublish} data-testid='confirm-publish'>
        Publish
      </button>
    </div>
  ),
  DeletePromptModal: ({ onClose, onDelete }: any) => (
    <div data-testid='delete-modal'>
      <button onClick={onClose} data-testid='close-delete'>
        Close
      </button>
      <button onClick={() => onDelete()} data-testid='confirm-delete'>
        Delete
      </button>
    </div>
  ),
  ConfirmDraftModal: ({ onClose, onConfirm }: any) => (
    <div data-testid='confirm-modal'>
      <button onClick={onClose} data-testid='close-confirm'>
        Close
      </button>
      <button onClick={onConfirm} data-testid='confirm-action'>
        Confirm
      </button>
    </div>
  ),
}));

jest.mock('../../../../commons/components/create-edit-prompt', () => ({
  __esModule: true,
  default: ({ isOpen, onSave }: any) =>
    isOpen ? (
      <div data-testid='create-edit-modal'>
        <button onClick={() => onSave({ name: 'Test' })} data-testid='save-edit'>
          Save
        </button>
      </div>
    ) : null,
}));

// Mock PromptVersionsCollection
jest.mock('../../../../entities/prompt-versions.entity', () => ({
  PromptVersionsCollection: jest.fn().mockImplementation((versions) => ({
    all: versions || [],
  })),
}));

// Mock PromptVersion
jest.mock('../../../../entities/prompt-version.entity', () => ({
  PromptVersion: {
    getStatusColor: jest.fn((status) => `color-${status}`),
  },
}));

// Mock routes
jest.mock('../../../../../../commons/config/routes', () => ({
  ROUTES: {
    PROMPTS: '/prompts',
    PROMPT_PLAYGROUND: '/prompts/playground',
  },
}));

// Mock localStorage to prevent errors
const mockLocalStorage = {
  getItem: jest.fn(() => null),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};
Object.defineProperty(window, 'localStorage', {
  value: mockLocalStorage,
  writable: true,
});

// Mock window.location.reload
delete (window as any).location;
(window as any).location = { reload: jest.fn() };

describe('TuningControllerComponent', () => {
  let mockPrompt: any;
  let mockPromptContext: any;
  let mockTranslation: jest.Mock;
  let mockVersions: any[];

  beforeEach(() => {
    // Reset all mocks
    jest.clearAllMocks();

    // Setup default mock data
    mockPrompt = {
      id: 1,
      name: 'Test Prompt',
      description: 'Test Description',
      useCase: 'Test Use Case',
      category: 'Test Category',
      scope: PromptScope.TENANT,
      sourceType: PromptSourceType.USER,
      hasChanges: jest.fn(() => false),
    };

    mockVersions = [
      {
        entityId: 1,
        status: PromptReviewStatus.DRAFT,
        name: 'Version 1',
      },
    ];

    mockPromptContext = {
      prompt: mockPrompt,
      versions: mockVersions,
      savePrompt: jest.fn(),
      publishPrompt: jest.fn(),
      updatePrompt: jest.fn(),
      archivePrompt: jest.fn(),
      deletePrompt: jest.fn(),
      createNewPrompt: jest.fn(),
      createNewDraft: jest.fn(),
      restorePrompt: jest.fn(),
      deletePromptVersion: jest.fn(),
      fetchVersions: jest.fn(),
      subscribeToPrompt: jest.fn(() => jest.fn()), // Return unsubscribe function
    };

    mockTranslation = jest.fn((key: string, options?: any) => {
      const translations: Record<string, string> = {
        'TUNING-CONTROLLER.BUTTONS.TUNE': 'Tune',
        'TUNING-CONTROLLER.BUTTONS.RESTORE': 'Restore',
        'TUNING-CONTROLLER.BUTTONS.NEW-DRAFT': 'New Draft',
        'TUNING-CONTROLLER.BUTTONS.EDIT-DRAFT': 'Edit Draft',
        'TUNING-CONTROLLER.BUTTONS.CLONE': 'Clone',
        'TUNING-CONTROLLER.BUTTONS.PUBLISH': 'Publish',
        'TUNING-CONTROLLER.BUTTONS.SAVE': 'Save',
        'TUNING-CONTROLLER.BUTTONS.ARCHIVE': 'Archive',
        'TUNING-CONTROLLER.BUTTONS.DELETE': 'Delete',
        'TUNING-CONTROLLER.BUTTONS.CANCEL': 'Cancel',
        'TUNING-CONTROLLER.BUTTONS.OK': 'OK',
        'TUNING-CONTROLLER.VERSION-HISTORY': 'Version History',
        'TUNING-CONTROLLER.MODALS.CONFIRM-DRAFT.TITLE': 'Confirm Draft',
        'TUNING-CONTROLLER.MODALS.CONFIRM-DRAFT.DESC': 'Are you sure you want to create a new draft?',
        'TUNING-CONTROLLER.MODALS.CONFIRM-ARCHIVE.TITLE': 'Confirm Archive',
        'TUNING-CONTROLLER.MODALS.CONFIRM-ARCHIVE.DESC': 'Are you sure you want to archive this prompt?',
        'TUNING-CONTROLLER.MODALS.CONFIRM-RESTORE.TITLE': 'Confirm Restore',
        'TUNING-CONTROLLER.MODALS.CONFIRM-RESTORE.DESC': 'Are you sure you want to restore this prompt?',
        'TUNING-CONTROLLER.MODALS.CONFIRM-TUNE.TITLE': 'Confirm Tune',
        'TUNING-CONTROLLER.MODALS.CONFIRM-TUNE.DESC': 'Are you sure you want to tune this prompt?',
        Save: 'Save', // For Common namespace
      };

      // Handle namespace-specific translations
      if (options?.ns === 'Common' && key === 'Save') {
        return 'Save';
      }

      return translations[key] || options?.defaultValue || key;
    });

    // Setup mocks
    mockUsePrompt.mockReturnValue(mockPromptContext);
    mockUseNgTransaltion.mockReturnValue({
      _t: mockTranslation,
    });

    // Setup RBAC permissions
    mockRbacService.isEntityReadable.mockImplementation((_entity: string) => {
      return Promise.resolve(true); // Default to true for all entities
    });

    mockRbacService.isEntityWritable.mockImplementation((_entity: string) => {
      return Promise.resolve(true); // Default to true for all entities
    });
  });

  describe('initial render', () => {
    it('should render the component with prompt name', async () => {
      render(<TuningControllerComponent />);

      expect(screen.getByText('Test Prompt')).toBeInTheDocument();
    });

    it('should fetch versions on mount', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        expect(mockPromptContext.fetchVersions).toHaveBeenCalledWith('1');
      });
    });

    it('should check permissions on mount', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        expect(mockRbacService.isEntityReadable).toHaveBeenCalledWith('promptStudio');
        expect(mockRbacService.isEntityReadable).toHaveBeenCalledWith('llmPromptsSystem');
        expect(mockRbacService.isEntityWritable).toHaveBeenCalledWith('llmPromptsSystem');
        expect(mockRbacService.isEntityWritable).toHaveBeenCalledWith('llmPromptsUser');
      });
    });
  });

  describe('draft status', () => {
    beforeEach(() => {
      mockVersions[0].status = PromptReviewStatus.DRAFT;
      mockPromptContext.versions = mockVersions;
    });

    it('should show publish and save buttons for draft status', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        expect(screen.getByText('Publish')).toBeInTheDocument();
        expect(screen.getByText('Save')).toBeInTheDocument();
      });
    });

    it('should handle save action', async () => {
      mockPrompt.hasChanges = jest.fn(() => true); // Enable save button

      render(<TuningControllerComponent />);

      await waitFor(() => {
        const saveButton = screen.getByText('Save');
        expect(saveButton).not.toBeDisabled();
        fireEvent.click(saveButton);
        expect(mockPromptContext.savePrompt).toHaveBeenCalled();
      });
    });

    it('should handle publish action', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        const publishButton = screen.getByText('Publish');
        fireEvent.click(publishButton);
        expect(screen.getByTestId('publish-modal')).toBeInTheDocument();
      });
    });
  });

  describe('published status', () => {
    beforeEach(() => {
      mockVersions[0].status = PromptReviewStatus.PUBLISHED;
      mockPromptContext.versions = mockVersions;
    });

    it('should show new draft and clone buttons for published status', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        expect(screen.getByText('New Draft')).toBeInTheDocument();
        expect(screen.getByText('Clone')).toBeInTheDocument();
      });
    });

    it('should handle new draft action', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        const newDraftButton = screen.getByText('New Draft');
        fireEvent.click(newDraftButton);
        expect(screen.getByTestId('confirm-modal')).toBeInTheDocument();
      });
    });

    it('should handle clone action', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        const cloneButton = screen.getByText('Clone');
        fireEvent.click(cloneButton);
        expect(screen.getByTestId('create-edit-modal')).toBeInTheDocument();
      });
    });
  });

  describe('archived status', () => {
    beforeEach(() => {
      mockVersions[0].status = PromptReviewStatus.ARCHIVE;
      mockPromptContext.versions = mockVersions;
    });

    it('should show restore button for archived status', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        expect(screen.getByText('Restore')).toBeInTheDocument();
      });
    });

    it('should handle restore action', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        const restoreButton = screen.getByText('Restore');
        fireEvent.click(restoreButton);
        expect(screen.getByTestId('confirm-modal')).toBeInTheDocument();
      });
    });
  });

  describe('tune functionality', () => {
    beforeEach(() => {
      mockPrompt.scope = PromptScope.GLOBAL;
      mockPrompt.sourceType = PromptSourceType.SYSTEM;
    });

    it('should show tune button for global system prompts', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        expect(screen.getByText('Tune')).toBeInTheDocument();
      });
    });

    it('should handle tune action', async () => {
      render(<TuningControllerComponent />);

      await waitFor(() => {
        const tuneButton = screen.getByText('Tune');
        fireEvent.click(tuneButton);
        expect(screen.getByTestId('confirm-modal')).toBeInTheDocument();
      });
    });
  });

  describe('permissions', () => {
    it('should hide buttons when user lacks write permissions', async () => {
      mockRbacService.isEntityWritable.mockImplementation((_entity: string) => {
        if (_entity === 'llmPromptsUser') return Promise.resolve(false);
        return Promise.resolve(true);
      });

      render(<TuningControllerComponent />);

      await waitFor(() => {
        expect(screen.queryByText('Save')).not.toBeInTheDocument();
      });
    });

    it('should hide system buttons when user lacks system write permissions', async () => {
      mockRbacService.isEntityWritable.mockImplementation((_entity: string) => {
        if (_entity === 'llmPromptsSystem') return Promise.resolve(false);
        return Promise.resolve(true);
      });

      render(<TuningControllerComponent />);

      await waitFor(() => {
        expect(screen.queryByText('Publish')).not.toBeInTheDocument();
      });
    });
  });

  describe('changes tracking', () => {
    it('should track changes and update button states', async () => {
      mockPrompt.hasChanges = jest.fn(() => true);

      render(<TuningControllerComponent />);

      await waitFor(() => {
        const saveButton = screen.getByText('Save');
        expect(saveButton).not.toBeDisabled();

        const publishButton = screen.getByText('Publish');
        expect(publishButton).toBeDisabled();
      });
    });

    it('should subscribe to prompt changes', async () => {
      const mockUnsubscribe = jest.fn();
      mockPromptContext.subscribeToPrompt.mockReturnValue(mockUnsubscribe);

      const { unmount } = render(<TuningControllerComponent />);

      await waitFor(() => {
        expect(mockPromptContext.subscribeToPrompt).toHaveBeenCalled();
      });

      unmount();

      expect(mockUnsubscribe).toHaveBeenCalled();
    });
  });
});
