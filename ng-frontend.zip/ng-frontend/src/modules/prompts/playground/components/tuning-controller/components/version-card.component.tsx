import { useMemo } from 'react';
import { Icon } from '@iconify/react';
import { useNavigate } from 'react-router';
import { PromptReviewStatus } from '../../../../entities/prompt-review-status.enum';
import { PromptVersion } from '../../../../entities/prompt-version.entity';
import { ROUTES } from '../../../../../../commons/config/routes';

interface IVersionCard {
  version: PromptVersion;
  isSelected: boolean;
  userWritable: boolean;
  onDelete: (id: number) => void;
  onArchive: (id: number) => void;
}

export const VersionCard = ({ isSelected, version, userWritable, onDelete, onArchive }: IVersionCard) => {
  const navigate = useNavigate();
  const { entityId, name, status, date, editor } = version;

  const handleVersion = () => {
    navigate(`${ROUTES.PROMPT_PLAYGROUND}/${entityId}`);
  };

  const handleDelete = (e: any) => {
    e.stopPropagation();
    onDelete(entityId);
  };

  const handleArchive = (e: any) => {
    e.stopPropagation();
    onArchive(entityId);
  };

  const editedInfo = useMemo(() => {
    return `${status === PromptReviewStatus.DRAFT ? 'Edited by ' : 'Published by '}  ${editor}`;
  }, [editor, status]);

  return (
    <div
      className={`relative flex flex-col gap-2 py-1.5 px-2 group hover:!bg-primary-400 ${isSelected ? '!bg-primary-400' : ''}`}
      onClick={handleVersion}>
      <div className='flex items-center gap-2'>
        <span className={`text-sm text-default-800 group-hover:text-white ${isSelected ? 'text-white' : ''}`}>
          {name}
        </span>
        {status !== PromptReviewStatus.ARCHIVE && (
          <span className={`rounded-sm px-2 py-0.5 text-sm font-bold ${PromptVersion.getStatusColor(status, true)}`}>
            {status}
          </span>
        )}
      </div>
      <div>
        <span className={`block text-xs text-default-600 group-hover:text-white ${isSelected ? 'text-white' : ''}`}>
          {date}
        </span>
        <span className={`text-xs text-default-600 group-hover:text-white ${isSelected ? 'text-white' : ''}`}>
          {editedInfo}
        </span>
      </div>
      {status !== PromptReviewStatus.PUBLISHED
        ? userWritable && (
            <span
              className={`absolute z-9 right-2 top-2 opacity-0 group-hover:opacity-100 ${isSelected ? 'opacity-100' : ''}`}
              onClick={handleDelete}>
              <Icon className='text-white' icon='solar:trash-bin-minimalistic-outline' width={16} />
            </span>
          )
        : userWritable && (
            <span
              className={`absolute z-9 right-2 top-2 opacity-0 group-hover:opacity-100 ${isSelected ? 'opacity-100' : ''}`}
              onClick={handleArchive}>
              <Icon className='text-white' icon='solar:archive-down-outline' width={16} />
            </span>
          )}
    </div>
  );
};
