import { Prompt } from '../entities/prompt.entity';
import { PromptVersions } from '../entities/prompt-versions.entity';

export interface PromptExecuteParams {
  promptText: string;
  modelId?: number;
  modelConfig?: {
    temperature?: number;
    max_tokens?: number;
    top_p?: number;
    frequency_penalty?: number;
    presence_penalty?: number;
  };
  inputVariables?: Array<{
    name: string;
    type: string;
    description?: string;
  }>;
  outputVariables?: Array<{
    name: string;
    type: string;
    description?: string;
  }>;
  transformationScript?: string | null;
  userText?: string;
  inputValues?: Record<string, any>;
}

export interface PromptExecuteResponse {
  raw: string;
  parsed?: Record<string, any>;
}

export interface PromptPlaygroundInterface {
  getPromptById(promptId: number): Promise<Prompt>;
  getModels(): Promise<any>;
  getModelById(modelId: number): Promise<any>;
  getVersions(entityGuid: string, promptId?: number): Promise<PromptVersions>;
  publishPrompt(promptId: number, data: any): Promise<Prompt>;
  updatePrompt(promptId: number, data: any): Promise<Prompt>;
  archivePrompt(promptId: number, botId?: number): Promise<Prompt>;
  deletePrompt(promptId: number): Promise<Prompt>;
  deletePromptVersion(promptId: number): Promise<Prompt>;
  createNewPrompt(data: any): Promise<Prompt>;
  clonePrompt(promptId: number): Promise<Prompt>;
  createNewDraft(promptId: number): Promise<Prompt>;
  restorePrompt(promptId: number): Promise<Prompt>;
  tunePrompt(data: any): Promise<Prompt>;
  executePrompt(
    promptId: number,
    userMessage?: string,
    modelId?: number | null,
    modelOptions?: Record<string, any>,
    currentPrompt?: Prompt,
  ): Promise<PromptExecuteResponse>;
}

export default PromptPlaygroundInterface;
