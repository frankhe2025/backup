import { FC, useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { Spinner } from '@aisera-ui/react';
import {
  TuningControllerComponent,
  SystemMessageComponent,
  VariablesComponent,
  ResponseComponent,
  UserMessageComponent,
} from './components';
import { Icon } from '@iconify/react';
import { PromptProvider, usePrompt } from './prompt-context';
import { useNgTransaltion } from '../../../i18n/hooks/translation.hook';
import { ROUTES } from '../../../commons/config/routes';

const PromptPlaygroundContent: FC = () => {
  const { _t } = useNgTransaltion('Prompt');
  const { prompt, loading } = usePrompt();
  const [isUserMessageVisible, setIsUserMessageVisible] = useState<boolean>(true);

  const handleAddMessage = () => {
    setIsUserMessageVisible(true);
  };

  const handleSystemMessageCopy = () => {
    if (prompt?.promptText) {
      navigator.clipboard.writeText(prompt.promptText);
    }
  };

  if (loading || !prompt) {
    return (
      <div className='flex h-64 w-full items-center justify-center'>
        <Spinner size='lg' />
      </div>
    );
  }

  return (
    <div className='container mx-auto p-4 space-y-6'>
      <div className='w-full'>
        <TuningControllerComponent />
      </div>

      <div className='flex flex-row gap-12 justify-between'>
        <div className='flex flex-col flex-1'>
          <div className='flex flex-col'>
            <div className='flex justify-between items-center mb-2'>
              <div className='flex items-center'>
                <h3 className='text-xl font-semibold text-gray-800'>{_t('PLAYGROUND.SYSTEM-MESSAGE')}</h3>
                <button
                  className='ml-2 text-gray-400 bg-transparent border-0 cursor-pointer'
                  onClick={handleSystemMessageCopy}
                  title={_t('PLAYGROUND.BUTTONS.COPY')}>
                  <Icon icon='mdi:content-copy' className='w-5 h-5' />
                </button>
              </div>
              <button
                onClick={handleAddMessage}
                className='flex items-center text-blue-500 bg-transparent border-none cursor-pointer'>
                <div className='flex items-center justify-center bg-blue-100 text-blue-500 rounded-full p-1 mr-2'>
                  <Icon icon='heroicons:plus' className='w-5 h-5' />
                </div>
                <span className='text-blue-500 font-medium'>{_t('PLAYGROUND.ADD-MESSAGE')}</span>
              </button>
            </div>
            <div className='flex-grow' style={{ minHeight: isUserMessageVisible ? '400px' : 'auto' }}>
              <SystemMessageComponent expanded={!isUserMessageVisible} />
            </div>
          </div>

          {isUserMessageVisible && (
            <div className='w-full mt-6'>
              <UserMessageComponent isVisible={true} onVisibilityChange={setIsUserMessageVisible} />
            </div>
          )}
        </div>

        <div className='max-w-sm'>
          <VariablesComponent />
        </div>
      </div>

      <div className='w-full'>
        <ResponseComponent />
      </div>
    </div>
  );
};

export const PromptPlaygroundComponent: FC = () => {
  const { promptId } = useParams<{ promptId: string }>();
  const navigate = useNavigate();

  if (!promptId) {
    navigate(ROUTES.PROMPTS);
    return null;
  }

  return (
    <PromptProvider promptId={Number(promptId)}>
      <PromptPlaygroundContent />
    </PromptProvider>
  );
};

export default PromptPlaygroundComponent;
