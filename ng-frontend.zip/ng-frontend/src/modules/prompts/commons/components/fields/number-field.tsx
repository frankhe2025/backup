import { NumberInput } from '@aisera-ui/react';
import { Control, Controller } from 'react-hook-form';
import { InputStyles } from '../../../constants/styles';

type NumberFieldProps = {
  control: Control<any, any, any>;

  label: string;
  name: string;
  maxValue?: number;
  minValue?: number;
  defaultValue?: number;
};

const NumberField = ({ control, label, name, defaultValue, minValue, maxValue }: NumberFieldProps) => {
  return (
    <Controller
      control={control}
      name={name}
      render={({ field: { name, value, onChange, onBlur, ref }, fieldState: { invalid, error } }) => (
        <NumberInput
          ref={ref}
          // isRequired
          errorMessage={error?.message}
          // Let React Hook Form handle validation instead of the browser.
          validationBehavior='aria'
          isInvalid={invalid}
          label={label}
          defaultValue={defaultValue}
          maxValue={maxValue || 1}
          minValue={minValue || 0}
          labelPlacement='outside-left'
          name={name}
          value={value}
          onBlur={onBlur}
          onValueChange={onChange}
          classNames={InputStyles}
          size='sm'
        />
      )}
      rules={{ required: label + ' is required.' }}
    />
  );
};

export default NumberField;
