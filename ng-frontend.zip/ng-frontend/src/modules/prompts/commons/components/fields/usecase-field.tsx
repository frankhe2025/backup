import { Select, SelectItem } from '@aisera-ui/react';
import { Control, Controller } from 'react-hook-form';
import { UsecasesOptions } from '../../../constants/usecases';
import { SelectStyles } from '../../../constants/styles';

type UsecaseFieldProps = {
  control: Control<any, any, any>;
};

const UsecaseField = ({ control }: UsecaseFieldProps) => {
  return (
    <Controller
      control={control}
      name='useCase'
      render={({ field: { name, value, onChange, onBlur, ref }, fieldState: { invalid, error } }) => (
        <Select
          ref={ref}
          label='Usecase'
          selectedKeys={value}
          onSelectionChange={onChange}
          isInvalid={invalid}
          errorMessage={error?.message}
          validationBehavior='aria'
          name={name}
          onBlur={onBlur}
          classNames={SelectStyles}
          labelPlacement='outside-left'
          size='sm'>
          <SelectItem key={''}>No Use Case</SelectItem>
          {/* <Divider /> */}
          {UsecasesOptions.map((usecase) => (
            <SelectItem key={usecase.key}>{usecase.label}</SelectItem>
          ))}
        </Select>
      )}
    />
  );
};

export default UsecaseField;
