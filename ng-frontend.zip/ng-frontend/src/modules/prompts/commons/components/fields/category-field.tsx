import { Select, SelectItem } from '@aisera-ui/react';
import { Control, Controller } from 'react-hook-form';
import { useCategoryList } from '../../../hooks/use-category-list';
import { SelectStyles } from '../../../constants/styles';

type CategoryFieldProps = {
  control: Control<any, any, any>;
};

const CategoryField = ({ control }: CategoryFieldProps) => {
  const { items, isLoading } = useCategoryList();

  return (
    <Controller
      control={control}
      name='category'
      render={({ field: { name, value, onChange, onBlur, ref }, fieldState: { invalid, error } }) => (
        <Select
          ref={ref}
          isLoading={isLoading}
          items={items}
          label='Category'
          selectedKeys={value}
          onSelectionChange={onChange}
          isInvalid={invalid}
          errorMessage={error?.message}
          validationBehavior='aria'
          name={name}
          onBlur={onBlur}
          isRequired
          classNames={SelectStyles}
          labelPlacement='outside-left'
          size='sm'>
          {(item: any) => <SelectItem key={item.key}>{item.label}</SelectItem>}
        </Select>
      )}
      rules={{ required: 'Category is required.' }}
    />
  );
};

export default CategoryField;
