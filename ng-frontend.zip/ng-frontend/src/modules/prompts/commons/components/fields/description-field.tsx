import { Input } from '@aisera-ui/react';
import { Control, Controller } from 'react-hook-form';
import { InputStyles } from '../../../constants/styles';

type DescriptionFieldProps = {
  control: Control<any, any, any>;
};

const DescriptionField = ({ control }: DescriptionFieldProps) => {
  return (
    <Controller
      control={control}
      name='description'
      render={({ field: { name, value, onChange, onBlur, ref }, fieldState: { invalid, error } }) => (
        <Input
          ref={ref}
          errorMessage={error?.message}
          // Let React Hook Form handle validation instead of the browser.
          validationBehavior='aria'
          isInvalid={invalid}
          label='Description'
          name={name}
          value={value}
          onBlur={onBlur}
          onChange={onChange}
          classNames={InputStyles}
          labelPlacement='outside-left'
          size='sm'
        />
      )}
    />
  );
};

export default DescriptionField;
