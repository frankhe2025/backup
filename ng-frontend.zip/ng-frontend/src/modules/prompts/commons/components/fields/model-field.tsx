import { ListboxSection, Select, SelectItem } from '@aisera-ui/react';
import { Control, Controller, useFormContext } from 'react-hook-form';
import { SelectStyles } from '../../../constants/styles';
import { useModelList } from '../../../hooks/use-model-list';
import { useEffect, useState } from 'react';
import getPromptsServiceInstance, { PROMPTS_SERVICE_TYPES } from '../../prompts_service_factory';
import ModelServiceInterface from '../../../services/model.interface';
import ModelInfo from '../../../entities/model.entity';
import SliderField from './slider-field';
import NumberField from './number-field';

type ModelFieldProps = {
  control: Control<any, any, any>;
};

const ModelField = ({ control }: ModelFieldProps) => {
  const { items, isLoading } = useModelList();
  console.log('ModelField items:', items);

  const { setValue, watch } = useFormContext();

  const modelId = watch('modelId');

  console.log('ModelField modelId:', modelId);

  useEffect(() => {
    if (modelId) {
      getPromptsServiceInstance<ModelServiceInterface>(PROMPTS_SERVICE_TYPES.MODEL)
        .getModelById(Number(modelId))
        .then((model: ModelInfo | null) => {
          console.log('Fetched model:', model);
          if (model) {
            setSelectedItem(model);
            const modelConfig: any = {};
            model.configFields.forEach((field) => {
              if (field.defaultValue !== undefined) {
                // Set the default value for the modelConfig field
                modelConfig[field.name] = field.defaultValue;
              }
            });
            setValue(`modelConfig`, modelConfig);
          }
        })
        .catch((error) => {
          console.error('Error fetching model by ID:', error);
        });
    }
  }, [modelId, setValue]);

  const [selectedItem, setSelectedItem] = useState<ModelInfo>();

  const handleSelectionChange = async (event: any[], callback: (...event: any[]) => void) => {
    const keys = Array.from(event[0]);

    const model: ModelInfo | null = await getPromptsServiceInstance<ModelServiceInterface>(
      PROMPTS_SERVICE_TYPES.MODEL,
    ).getModelById(Number(keys[0]));

    if (model) {
      setSelectedItem(model);
      const modelConfig: any = {};
      model.configFields.forEach((field) => {
        if (field.defaultValue !== undefined) {
          modelConfig[field.name] = field.defaultValue;
        }
      });
      setValue(`modelConfig`, modelConfig);

      callback(...event);
    }
  };

  return (
    <>
      <Controller
        control={control}
        name='modelId'
        render={({ field: { name, value, onChange, onBlur, ref }, fieldState: { invalid, error } }) => (
          <Select
            ref={ref}
            isLoading={isLoading}
            // items={items}
            label='Model'
            disallowEmptySelection
            selectedKeys={value}
            onSelectionChange={(...event: any[]) => handleSelectionChange(event, onChange)}
            isInvalid={invalid}
            errorMessage={error?.message}
            validationBehavior='aria'
            name={name}
            onBlur={onBlur}
            isRequired
            classNames={SelectStyles}
            labelPlacement='outside-left'
            size='sm'>
            {items.length &&
              items.map((item: any, index) => (
                <ListboxSection key={item.key} showDivider={index !== items.length - 1} title={item.label}>
                  {item.options.map((option: any) => (
                    <SelectItem key={option.key} textValue={option.label}>
                      {option.label}
                    </SelectItem>
                  ))}
                </ListboxSection>
              ))}
          </Select>
        )}
        rules={{ required: 'Model is required.' }}
      />
      {selectedItem && selectedItem.configFields && selectedItem.configFields.length > 0 && (
        <>
          <h3 className='text-sm font-semibold mb-2 ps-2'>Model Configurations</h3>
          {selectedItem.configFields.map((field) => (
            <>
              {field.type === 'Float' && field.limits && field.limits[1] <= 1 ? (
                <SliderField
                  key={field.name}
                  control={control}
                  name={'modelConfig.' + field.name}
                  label={field.displayName}
                  maxValue={field.limits[1]}
                  minValue={field.limits[0]}
                  step={field.step || 0.01}
                  showSteps={false}
                  defaultValue={field.defaultValue}
                />
              ) : (
                <NumberField
                  key={field.name}
                  control={control}
                  name={'modelConfig.' + field.name}
                  label={field.displayName}
                  maxValue={field.limits[1]}
                  minValue={field.limits[0]}
                  defaultValue={field.defaultValue}
                />
              )}
            </>
          ))}
        </>
      )}
    </>
  );
};

export default ModelField;
