import { Select, SelectItem } from '@aisera-ui/react';
import { useMemo } from 'react';
import { Control, Controller } from 'react-hook-form';
import { ScopeOptions } from '../../../constants/scope';
import { Scope } from '../../../enums/scope';
import { SelectStyles } from '../../../constants/styles';

type ScopeFieldProps = {
  control: Control<any, any, any>;
};

const ScopeField = ({ control }: ScopeFieldProps) => {
  const scopes = useMemo(() => {
    return ScopeOptions.filter((scope) => {
      if (scope.key === Scope.Global) {
        return false;
      }
      return true;
    });
  }, []);

  return (
    <Controller
      control={control}
      name='scope'
      render={({ field: { name, value, onChange, onBlur, ref }, fieldState: { invalid, error } }) => (
        <Select
          ref={ref}
          label='Scope'
          selectedKeys={value}
          onSelectionChange={onChange}
          isInvalid={invalid}
          errorMessage={error?.message}
          validationBehavior='aria'
          name={name}
          onBlur={onBlur}
          isRequired
          classNames={SelectStyles}
          labelPlacement='outside-left'
          size='sm'>
          {scopes.map((scope) => (
            // TODO: add icon to scope
            <SelectItem key={scope.key} textValue={scope.label}>
              {scope.label}
            </SelectItem>
          ))}
        </Select>
      )}
      rules={{ required: 'Scope is required.' }}
    />
  );
};

export default ScopeField;
