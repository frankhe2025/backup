import { Control, Controller } from 'react-hook-form';
import { SliderStyles } from '../../../constants/styles';
import { Slider } from '@aisera-ui/react';

type SliderFieldProps = {
  control: Control<any, any, any>;
  label: string;
  name: string;
  maxValue?: number;
  minValue?: number;
  step?: number;
  showSteps?: boolean;
  defaultValue?: number;
};

const SliderField = ({ control, name, label, maxValue, minValue, showSteps, step, defaultValue }: SliderFieldProps) => {
  return (
    <Controller
      control={control}
      name={name}
      render={({ field: { name, value, onChange }, fieldState: { invalid, error } }) => (
        <Slider
          color='foreground'
          defaultValue={defaultValue}
          value={value as number}
          label={label}
          maxValue={maxValue || 1}
          minValue={minValue || 0}
          step={step || 0.1}
          showSteps={showSteps || false}
          size='sm'
          name={name}
          onChange={onChange}
          errorMessage={error?.message}
          isInvalid={invalid}
          labelPlacement='outside-left'
          classNames={SliderStyles}
        />
      )}
      rules={{ required: label + ' is required.' }}
    />
  );
};

export default SliderField;
