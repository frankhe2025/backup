import { Input } from '@aisera-ui/react';
import { Control, Controller } from 'react-hook-form';
import { InputStyles } from '../../../constants/styles';

type NameFieldProps = {
  control: Control<any, any, any>;
};

const NameField = ({ control }: NameFieldProps) => {
  return (
    <Controller
      control={control}
      name='name'
      render={({ field: { name, value, onChange, onBlur, ref }, fieldState: { invalid, error } }) => (
        <Input
          ref={ref}
          isRequired
          errorMessage={error?.message}
          // Let React Hook Form handle validation instead of the browser.
          validationBehavior='aria'
          isInvalid={invalid}
          label='Name'
          labelPlacement='outside-left'
          name={name}
          value={value}
          onBlur={onBlur}
          onChange={onChange}
          classNames={InputStyles}
          size='sm'
          autoComplete='off'
        />
      )}
      rules={{ required: 'Name is required.' }}
    />
  );
};

export default NameField;
