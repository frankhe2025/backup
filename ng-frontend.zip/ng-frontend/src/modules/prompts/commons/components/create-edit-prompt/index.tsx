import { Button, Form, Modal, ModalBody, ModalContent, ModalFooter, ModalHeader } from '@aisera-ui/react';
import { FormProvider, useForm } from 'react-hook-form';
import NameField from '../fields/name-field';
import DescriptionField from '../fields/description-field';
import CategoryField from '../fields/category-field';
import ScopeField from '../fields/scope-field';
import UsecaseField from '../fields/usecase-field';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMemo } from 'react';
import ModelField from '../fields/model-field';

const schema = z.object({
  name: z.string({ message: 'Name is required.' }).min(1, { message: 'Name is required.' }),
  description: z.string().optional(),
  category: z
    .set(z.string({ message: 'Category is required.' }).min(1, { message: 'Category is required.' }))
    .min(1, { message: 'Category is required.' }),
  scope: z
    .set(z.string({ message: 'Scope is required.' }).min(1, { message: 'Scope is required.' }))
    .min(1, { message: 'Scope is required.' }),
  useCase: z.set(z.string().optional()).optional(),
  modelId: z.set(z.string({ message: 'Model is required.' }).min(1, { message: 'Model is required.' })),
  modelConfig: z.any().optional(),
});

const schemaForEdit = z.object({
  name: z.string({ message: 'Name is required.' }).min(1, { message: 'Name is required.' }),
  description: z.string().optional(),
  category: z.set(z.string({ message: 'Category is required.' }).min(1, { message: 'Category is required.' })),
  scope: z.set(z.string({ message: 'Scope is required.' }).min(1, { message: 'Scope is required.' })),
  useCase: z.set(z.string().optional()).optional(),
});

type CreateEditPromptProps = {
  data?: any;
  onSave: (data: any) => void;
  isOpen: boolean;
  onOpenChange: () => void;
};

const CreateEditPrompt = ({ data, isOpen, onOpenChange, onSave }: CreateEditPromptProps) => {
  const defaultValues = useMemo(() => {
    return {
      name: data?.name || '',
      description: data?.description || '',
      category: new Set(data && data.category ? [data.category] : []),
      scope: new Set(data && data.scope ? [data.scope] : []),
      useCase: new Set(data && data.useCase ? [data.useCase] : ['']),
    };
  }, [data]);

  const methods = useForm({
    defaultValues: {
      ...defaultValues,
    },
    resolver: zodResolver(data ? schemaForEdit : schema),
  });

  const { handleSubmit, control, getValues, reset } = methods;

  const onSubmit = async (formData: any) => {
    // Call your API here.
    console.log('Form submitted:', formData);
    console.log('Raw form data:', getValues());
    const cleanedData = {
      ...formData,
      useCase: formData.useCase.size > 0 ? Array.from(formData.useCase)[0] : '',
      category: formData.category.size > 0 ? Array.from(formData.category)[0] : '',
      scope: formData.scope.size > 0 ? Array.from(formData.scope)[0] : '',
    };

    if (!data) {
      cleanedData['modelId'] = formData.modelId.size > 0 ? Number(Array.from(formData.modelId)[0]) : '';
    }
    console.log('Cleaned data:', cleanedData);
    await onSave(cleanedData);

    if (!data) {
      reset();
    }
  };

  return (
    <Modal
      size='lg'
      isOpen={isOpen}
      placement='top-center'
      onOpenChange={onOpenChange}
      className='bg-default-50 shadow-inner drop-shadow-lg'>
      <FormProvider {...methods}>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <ModalContent>
            {(onClose) => (
              <>
                <ModalHeader className='flex flex-col gap-1'>
                  <h3 className='text-lg leading-7 font-medium text-foreground-800'>Details</h3>
                  <p className='text-small text-foreground-500 font-normal'>
                    {data ? 'Edit' : 'Enter'} your prompt details
                  </p>
                </ModalHeader>
                <ModalBody className='w-full'>
                  <NameField control={control} />
                  <DescriptionField control={control} />
                  <CategoryField control={control} />
                  <ScopeField control={control} />
                  <UsecaseField control={control} />
                  {!data && <ModelField control={control} />}
                </ModalBody>
                <ModalFooter>
                  <Button variant='bordered' radius='lg' type='button' onClick={onClose}>
                    Cancel
                  </Button>
                  <Button variant='solid' color='primary' radius='lg' type='submit'>
                    Save Changes
                  </Button>
                </ModalFooter>
              </>
            )}
          </ModalContent>
        </Form>
      </FormProvider>
    </Modal>
  );
};

export default CreateEditPrompt;
