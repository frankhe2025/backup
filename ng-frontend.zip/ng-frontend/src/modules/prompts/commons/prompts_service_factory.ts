import config from '../../../commons/config/config';
import CategoryServiceMock from '../mocks/services/category.service.mock';
import ModelServiceMock from '../mocks/services/model.service.mock';
import PromptListServiceMock from '../mocks/services/prompt-list.service.mock';
import { PromptPlaygroundServiceMock } from '../mocks/services/prompt-playground.service.mock';
import { CategoryService } from '../services/category.service';
import ModelService from '../services/model.service';
import PromptListService from '../services/prompt-list.service';
import { PromptPlaygroundService } from '../services/prompt-playground.service';

const SERVICE_REGISTRY: any = {};

export enum PROMPTS_SERVICE_TYPES {
  PROMPT_LIST = 'prompt-list',
  MODEL = 'model',
  PROMPT_PLAYGROUND = 'prompt-playground',
  CATEGORY = 'category',
}

const getPromptsServiceInstance = <T>(type: PROMPTS_SERVICE_TYPES, fkType: string = 'default') => {
  if (!(type in SERVICE_REGISTRY)) {
    SERVICE_REGISTRY[type] = {};
  }

  if (!(fkType in SERVICE_REGISTRY[type])) {
    if (config.usingMock) {
      // This is for mock services
      switch (type) {
        case PROMPTS_SERVICE_TYPES.PROMPT_LIST:
          SERVICE_REGISTRY[type][fkType] = new PromptListServiceMock();
          break;
        case PROMPTS_SERVICE_TYPES.MODEL:
          SERVICE_REGISTRY[type][fkType] = new ModelServiceMock();
          break;
        case PROMPTS_SERVICE_TYPES.PROMPT_PLAYGROUND:
          SERVICE_REGISTRY[type][fkType] = new PromptPlaygroundServiceMock();
          break;
        case PROMPTS_SERVICE_TYPES.CATEGORY:
          SERVICE_REGISTRY[type][fkType] = new CategoryServiceMock();
          break;
      }
    } else {
      // This is for real services
      switch (type) {
        case PROMPTS_SERVICE_TYPES.PROMPT_LIST:
          SERVICE_REGISTRY[type][fkType] = new PromptListService();
          break;
        case PROMPTS_SERVICE_TYPES.MODEL:
          SERVICE_REGISTRY[type][fkType] = new ModelService();
          break;
        case PROMPTS_SERVICE_TYPES.PROMPT_PLAYGROUND:
          SERVICE_REGISTRY[type][fkType] = new PromptPlaygroundService();
          break;
        case PROMPTS_SERVICE_TYPES.CATEGORY:
          SERVICE_REGISTRY[type][fkType] = new CategoryService();
          break;
      }
    }
  }

  return SERVICE_REGISTRY[type][fkType] as T;
};

export default getPromptsServiceInstance;
