import { useEffect, useState } from 'react';
import getPromptsServiceInstance, { PROMPTS_SERVICE_TYPES } from '../commons/prompts_service_factory';
import { CategoryServiceInterface } from '../services/category.interface';
import getRegistrationService from '../../../commons/modules/connector-server/services/registration.service.ts';

export function useCategoryList() {
  const [items, setItems] = useState<{ key: string; label: string }[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadCategory = async () => {
    try {
      setIsLoading(true);
      const tenantId = await getRegistrationService().getCurrentTenantId();
      const categories: string[] = await getPromptsServiceInstance<CategoryServiceInterface>(
        PROMPTS_SERVICE_TYPES.CATEGORY,
      ).getCategories(tenantId);
      // Append new results to existing ones
      const options = categories.map((item) => ({
        key: item,
        label: item,
      }));
      setItems(options);
    } catch (error: any) {
      console.error('There was an error with the fetch operation:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCategory();
  }, []);

  return {
    items,
    isLoading,
  };
}
