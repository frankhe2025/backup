import { useEffect, useState, useRef } from 'react';
import getPromptsServiceInstance, { PROMPTS_SERVICE_TYPES } from '../commons/prompts_service_factory';
import ModelServiceInterface from '../services/model.interface';
import Models from '../entities/models.entity';

export function useModelList() {
  const [items, setItems] = useState<{ key: string; label: string }[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const hasLoaded = useRef(false);
  const hasErrored = useRef(false);

  const loadModel = async () => {
    if (hasLoaded.current || hasErrored.current) return;

    try {
      setIsLoading(true);
      const models: Models = await getPromptsServiceInstance<ModelServiceInterface>(
        PROMPTS_SERVICE_TYPES.MODEL,
      ).getModels();
      hasLoaded.current = true;

      const options = models.models.map((item) => ({
        key: item.id.toString(),
        label: item.displayName || item.name,
        group: item.provider,
      }));

      const groups = Array.from(new Set(options.map((item) => item.group)));

      const groupedOptions = groups.map((group) => ({
        key: group,
        label: group,
        options: options.filter((item) => item.group === group),
      }));

      setItems(groupedOptions);
    } catch (error) {
      console.error('Error loading models:', error);
      hasErrored.current = true;
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadModel();
  }, []);

  return {
    items,
    isLoading,
  };
}
