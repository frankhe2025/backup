import { InputProps, SelectProps } from '@aisera-ui/react';
import { clsx } from '@aisera-ui/shared-utils';

type IClassNamesType = InputProps['classNames'];
type SClassNamesType = SelectProps['classNames'];

export const InputStyles: IClassNamesType = {
  label: 'w-40 text-tiny text-default-600',
  mainWrapper: 'w-full',
  inputWrapper: 'bg-white hover:!bg-white focus-within:!bg-white',
};

export const SelectStyles: SClassNamesType = {
  ...InputStyles,
  label: clsx(InputStyles.label, 'ps-2'),
  trigger: InputStyles.inputWrapper,
  mainWrapper: 'w-[calc(100%_-_theme(spacing.40))]',
};

export const SliderStyles: SClassNamesType = {
  ...InputStyles,
  label: clsx(InputStyles.label, 'ps-2'),
  trigger: InputStyles.inputWrapper,
  base: 'flex-row py-1.5',
  labelWrapper: 'w-40 pe-2',
  trackWrapper: 'w-full',
};
