import { Scope } from '../enums/scope';

export const ScopeOptions = [
  {
    key: Scope.Global,
    label: 'Global',
    icon: 'globe',
  },
  {
    key: Scope.Application,
    label: 'Application',
    icon: 'globe',
  },
  {
    key: Scope.Tenant,
    label: 'Tenant',
    icon: 'globe',
  },
];
