import { Scope } from '../enums/scope';
import { Usecases } from '../enums/usecases';

export const ScopeOptions = [
  {
    key: Scope.Global,
    label: 'Global',
    icon: 'globe',
  },
  {
    key: Scope.Application,
    label: 'Application',
    icon: 'globe',
  },
  {
    key: Scope.Tenant,
    label: 'Tenant',
    icon: 'globe',
  },
];

export const UsecasesOptions = [
  {
    key: Usecases.AgentAssist,
    label: Usecases.AgentAssist,
  },
  {
    key: Usecases.ConversationalDisambiguation,
    label: Usecases.ConversationalDisambiguation,
  },
  {
    key: Usecases.TicketAI,
    label: 'Ticket AI',
  },
];
