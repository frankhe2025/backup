import { Prompts } from '../entities/prompts.entity';

export interface PromptListInterface {
  getPrompts(groupId: number): Promise<Prompts | null>;
}
