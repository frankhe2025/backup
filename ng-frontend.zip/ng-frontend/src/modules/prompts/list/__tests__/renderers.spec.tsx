import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { appCellRenderer, appActionRenderer } from '../renderers';

jest.mock('@aisera-ui/react', () => ({
  Chip: ({ children, color, size, variant, className }: any) => (
    <div data-testid='chip' data-color={color} data-size={size} data-variant={variant} className={className}>
      {children}
    </div>
  ),
  User: ({ name, description, avatarProps }: any) => (
    <div data-testid='user'>
      <div data-testid='user-name'>{name}</div>
      <div data-testid='user-description'>{description}</div>
      <img data-testid='user-avatar' src={avatarProps?.src} className={avatarProps?.className} alt='avatar' />
    </div>
  ),
  Badge: ({ children, variant, color, size, className }: any) => (
    <div data-testid='badge' data-variant={variant} data-color={color} data-size={size} className={className}>
      {children}
    </div>
  ),
}));

const mockUseNavigate = jest.fn();

jest.mock('react-router', () => ({
  useNavigate: () => mockUseNavigate,
}));

jest.mock('@iconify/react', () => ({
  Icon: ({ icon, width, height, className }: any) => (
    <span data-testid={`icon-${icon}`} data-width={width} data-height={height} className={className} />
  ),
}));

const mockLocation = {
  href: '',
};
Object.defineProperty(window, 'location', {
  value: mockLocation,
  writable: true,
});

global.console = {
  ...console,
  log: jest.fn(),
};

describe('Renderers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockLocation.href = '';
  });

  describe('appCellRenderer', () => {
    const mockItem = {
      id: 'test-prompt-1',
      modelId: 123,
      _modelInfo: {
        id: 1,
        name: 'GPT-4',
        displayName: 'GPT-4',
        provider: 'OpenAI',
        configFields: [],
      },
    };

    describe('navigation functionality', () => {
      it('should navigate to prompt playground when cell is clicked', () => {
        const result = appCellRenderer('test value', mockItem, 'name');
        render(<div>{result}</div>);

        const cell = screen.getByText('test value');
        fireEvent.click(cell);

        expect(mockUseNavigate).toHaveBeenCalledWith('/prompts/playground/test-prompt-1');
        expect(console.log).toHaveBeenCalledWith('Cell clicked, navigating to prompt playground ID:', mockItem);
      });

      it('should not navigate when clicking on button inside cell', () => {
        const result = appCellRenderer('test value', mockItem, 'name');
        render(
          <div>
            {result}
            <button>Test Button</button>
          </div>,
        );

        const button = screen.getByText('Test Button');
        fireEvent.click(button);

        expect(window.location.href).toBe('');
      });

      it('should stop event propagation when cell is clicked', () => {
        const result = appCellRenderer('test value', mockItem, 'name');
        const mockStopPropagation = jest.fn();

        render(<div>{result}</div>);

        const cell = screen.getByText('test value');
        const event = new MouseEvent('click', { bubbles: true });
        event.stopPropagation = mockStopPropagation;

        fireEvent(cell, event);

        expect(mockStopPropagation).toHaveBeenCalled();
      });
    });

    describe('model column rendering', () => {
      it('should render model provider when _modelInfo is available', () => {
        const result = appCellRenderer('some value', mockItem, 'model');
        render(<div>{result}</div>);

        expect(screen.getByText('OpenAI')).toBeInTheDocument();
      });

      it('should render value when _modelInfo provider is not available but value exists', () => {
        const itemWithoutProvider = { ...mockItem, _modelInfo: undefined };
        const result = appCellRenderer('Custom Model', itemWithoutProvider, 'model');
        render(<div>{result}</div>);

        expect(screen.getByText('Custom Model')).toBeInTheDocument();
      });

      it('should render modelId when no _modelInfo or value', () => {
        const itemWithoutProvider = { ...mockItem, _modelInfo: undefined };
        const result = appCellRenderer(null, itemWithoutProvider, 'model');
        render(<div>{result}</div>);

        expect(screen.getByText('Model ID: 123')).toBeInTheDocument();
      });

      it('should render empty string when no model information available', () => {
        const itemWithoutModel = { id: 'test', modelId: undefined };
        const result = appCellRenderer(null, itemWithoutModel, 'model');

        render(<div data-testid='test-container'>{result}</div>);
        const container = screen.getByTestId('test-container');
        expect(container.firstChild).toHaveClass('w-full h-full');
        expect(container.firstChild).toHaveTextContent('');
      });
    });

    describe('null and undefined value handling', () => {
      it('should return empty string for undefined value', () => {
        const result = appCellRenderer(undefined, mockItem, 'name');
        expect(result).toBe('');
      });

      it('should return empty string for null value', () => {
        const result = appCellRenderer(null, mockItem, 'name');
        expect(result).toBe('');
      });
    });

    describe('status column rendering', () => {
      it('should render Published status with success color', () => {
        const result = appCellRenderer('Published', mockItem, 'status');
        render(<div>{result}</div>);

        const chip = screen.getByTestId('chip');
        expect(chip).toHaveAttribute('data-color', 'success');
        expect(screen.getByText('Published')).toBeInTheDocument();
      });

      it('should render Active status with success color', () => {
        const result = appCellRenderer('Active', mockItem, 'status');
        render(<div>{result}</div>);

        const chip = screen.getByTestId('chip');
        expect(chip).toHaveAttribute('data-color', 'success');
        expect(screen.getByText('Active')).toBeInTheDocument();
      });

      it('should render Draft status with warning color', () => {
        const result = appCellRenderer('Draft', mockItem, 'status');
        render(<div>{result}</div>);

        const chip = screen.getByTestId('chip');
        expect(chip).toHaveAttribute('data-color', 'warning');
        expect(screen.getByText('Draft')).toBeInTheDocument();
      });

      it('should render Inactive status with danger color', () => {
        const result = appCellRenderer('Inactive', mockItem, 'status');
        render(<div>{result}</div>);

        const chip = screen.getByTestId('chip');
        expect(chip).toHaveAttribute('data-color', 'danger');
        expect(screen.getByText('Inactive')).toBeInTheDocument();
      });

      it('should render unknown status with default color', () => {
        const result = appCellRenderer('Unknown', mockItem, 'status');
        render(<div>{result}</div>);

        const chip = screen.getByTestId('chip');
        expect(chip).toHaveAttribute('data-color', 'default');
        expect(screen.getByText('Unknown')).toBeInTheDocument();
      });
    });

    describe('updatedBy column rendering', () => {
      it('should render user from JSON string', () => {
        const userData = JSON.stringify({
          name: 'John Doe',
          email: 'john.doe@example.com',
        });
        const result = appCellRenderer(userData, mockItem, 'updatedBy');
        render(<div>{result}</div>);

        expect(screen.getByTestId('user-name')).toHaveTextContent('John Doe');
        expect(screen.getByTestId('user-description')).toHaveTextContent('@john.doe');
        expect(screen.getByTestId('user-avatar')).toHaveAttribute(
          'src',
          'https://ui-avatars.com/api/?name=John%20Doe&background=random',
        );
      });

      it('should render user from object', () => {
        const userData = {
          name: 'Jane Smith',
          email: 'jane.smith@company.org',
        };
        const result = appCellRenderer(userData, mockItem, 'updatedBy');
        render(<div>{result}</div>);

        expect(screen.getByTestId('user-name')).toHaveTextContent('Jane Smith');
        expect(screen.getByTestId('user-description')).toHaveTextContent('@jane.smith');
      });

      it('should handle missing name with Unknown User', () => {
        const userData = JSON.stringify({ email: 'test@example.com' });
        const result = appCellRenderer(userData, mockItem, 'updatedBy');
        render(<div>{result}</div>);

        expect(screen.getByTestId('user-name')).toHaveTextContent('Unknown User');
        expect(screen.getByTestId('user-description')).toHaveTextContent('@test');
      });

      it('should handle missing email', () => {
        const userData = JSON.stringify({ name: 'Test User' });
        const result = appCellRenderer(userData, mockItem, 'updatedBy');
        render(<div>{result}</div>);

        expect(screen.getByTestId('user-name')).toHaveTextContent('Test User');
        expect(screen.getByTestId('user-description')).toHaveTextContent('@test');
      });

      it('should handle invalid JSON by returning string value', () => {
        const result = appCellRenderer('invalid json', mockItem, 'updatedBy');
        render(<div>{result}</div>);

        expect(screen.getByText('invalid json')).toBeInTheDocument();
      });
    });

    describe('type-based rendering', () => {
      describe('date/datetime type', () => {
        it('should render date with calendar icon for date type', () => {
          const result = appCellRenderer('2023-12-15', mockItem, 'createdAt', 'date');
          render(<div>{result}</div>);

          expect(screen.getByTestId('icon-solar:calendar-mark-outline')).toBeInTheDocument();
          expect(screen.getByText(/12\/\d{1,2}\/2023/)).toBeInTheDocument();
        });

        it('should render date with calendar icon for datetime type', () => {
          const result = appCellRenderer('2023-12-15T10:30:00Z', mockItem, 'updatedAt', 'datetime');
          render(<div>{result}</div>);

          expect(screen.getByTestId('icon-solar:calendar-mark-outline')).toBeInTheDocument();
          expect(screen.getByText('12/15/2023')).toBeInTheDocument();
        });

        it('should handle invalid date', () => {
          const result = appCellRenderer('invalid-date', mockItem, 'date', 'date');
          render(<div>{result}</div>);

          expect(screen.getByTestId('icon-solar:calendar-mark-outline')).toBeInTheDocument();
          expect(screen.getByText('Invalid Date')).toBeInTheDocument();
        });

        it('should handle empty date', () => {
          const result = appCellRenderer('', mockItem, 'date', 'date');
          render(<div>{result}</div>);

          expect(screen.getByTestId('icon-solar:calendar-mark-outline')).toBeInTheDocument();
          expect(screen.getByTestId('icon-solar:calendar-mark-outline')).toBeInTheDocument();
        });
      });

      describe('user type', () => {
        it('should render user component for user type', () => {
          const userData = {
            name: 'Alice Johnson',
            avatarUrl: 'https://example.com/avatar.jpg',
          };
          const result = appCellRenderer(userData, mockItem, 'user', 'user');
          render(<div>{result}</div>);

          expect(screen.getByTestId('user-name')).toHaveTextContent('Alice Johnson');
          expect(screen.getByTestId('user-description')).toHaveTextContent('@alice');
          expect(screen.getByTestId('user-avatar')).toHaveAttribute('src', 'https://example.com/avatar.jpg');
        });

        it('should use default avatar when avatarUrl is not provided', () => {
          const userData = { name: 'Bob Wilson' };
          const result = appCellRenderer(userData, mockItem, 'user', 'user');
          render(<div>{result}</div>);

          expect(screen.getByTestId('user-avatar')).toHaveAttribute('src', 'https://i.pravatar.cc/150?u=Bob Wilson');
        });

        it('should return empty string for empty user value', () => {
          const result = appCellRenderer(null, mockItem, 'user', 'user');
          expect(result).toBe('');
        });
      });

      describe('status type', () => {
        it('should render status chip for Published', () => {
          const result = appCellRenderer('Published', mockItem, 'status', 'status');
          render(<div>{result}</div>);

          const chip = screen.getByTestId('chip');
          expect(chip).toHaveAttribute('data-color', 'success');
          expect(screen.getByText('Published')).toBeInTheDocument();
        });

        it('should render status chip for Draft', () => {
          const result = appCellRenderer('Draft', mockItem, 'status', 'status');
          render(<div>{result}</div>);

          const chip = screen.getByTestId('chip');
          expect(chip).toHaveAttribute('data-color', 'warning');
        });

        it('should render status chip for Inactive', () => {
          const result = appCellRenderer('Inactive', mockItem, 'status', 'status');
          render(<div>{result}</div>);

          const chip = screen.getByTestId('chip');
          expect(chip).toHaveAttribute('data-color', 'danger');
        });
      });

      describe('badge type', () => {
        it('should render badge component', () => {
          const result = appCellRenderer('Important', mockItem, 'tag', 'badge');
          render(<div>{result}</div>);

          const badge = screen.getByTestId('badge');
          expect(badge).toHaveAttribute('data-variant', 'flat');
          expect(badge).toHaveAttribute('data-color', 'default');
          expect(badge).toHaveAttribute('data-size', 'sm');
          expect(screen.getByText('Important')).toBeInTheDocument();
        });
      });

      describe('boolean type', () => {
        it('should render "Yes" for true value', () => {
          const result = appCellRenderer(true, mockItem, 'active', 'boolean');
          render(<div>{result}</div>);

          expect(screen.getByText('Yes')).toBeInTheDocument();
        });

        it('should render "No" for false value', () => {
          const result = appCellRenderer(false, mockItem, 'active', 'boolean');
          render(<div>{result}</div>);

          expect(screen.getByText('No')).toBeInTheDocument();
        });
      });

      describe('number type', () => {
        it('should render formatted number for numeric value', () => {
          const result = appCellRenderer(1234567, mockItem, 'count', 'number');
          render(<div>{result}</div>);

          expect(screen.getByText('1,234,567')).toBeInTheDocument();
        });

        it('should render as-is for non-numeric value', () => {
          const result = appCellRenderer('not a number', mockItem, 'count', 'number');
          render(<div>{result}</div>);

          expect(screen.getByText('not a number')).toBeInTheDocument();
        });
      });

      describe('default type', () => {
        it('should render string value for unknown type', () => {
          const result = appCellRenderer('test value', mockItem, 'name', 'unknown' as any);
          render(<div>{result}</div>);

          expect(screen.getByText('test value')).toBeInTheDocument();
        });

        it('should convert non-string values to string', () => {
          const result = appCellRenderer(123, mockItem, 'name');
          render(<div>{result}</div>);

          expect(screen.getByText('123')).toBeInTheDocument();
        });
      });
    });
  });

  describe('appActionRenderer', () => {
    const mockItem = { id: 'test-prompt-1' };

    it('should return null when no actions provided', () => {
      const result = appActionRenderer(mockItem, null);
      expect(result).toBeNull();
    });

    it('should return null when actions is undefined', () => {
      const result = appActionRenderer(mockItem, undefined);
      expect(result).toBeNull();
    });

    describe('copy action', () => {
      it('should render copy button and handle click', () => {
        const mockCopyHandler = jest.fn();
        const actions = {
          copy: {
            handler: mockCopyHandler,
            label: 'Copy Prompt',
          },
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        const copyButton = screen.getByLabelText('Copy Prompt');
        expect(copyButton).toBeInTheDocument();
        expect(screen.getByTestId('icon-solar:copy-linear')).toBeInTheDocument();

        fireEvent.click(copyButton);
        expect(mockCopyHandler).toHaveBeenCalledWith('test-prompt-1');
      });

      it('should use default label when not provided', () => {
        const mockCopyHandler = jest.fn();
        const actions = {
          copy: { handler: mockCopyHandler },
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        expect(screen.getByLabelText('copy')).toBeInTheDocument();
      });

      it('should stop event propagation on click', () => {
        const mockCopyHandler = jest.fn();
        const mockStopPropagation = jest.fn();
        const actions = {
          copy: { handler: mockCopyHandler },
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        const copyButton = screen.getByLabelText('copy');
        const event = new MouseEvent('click', { bubbles: true });
        event.stopPropagation = mockStopPropagation;

        fireEvent(copyButton, event);

        expect(mockStopPropagation).toHaveBeenCalled();
      });
    });

    describe('delete action', () => {
      it('should render delete button and handle click', () => {
        const mockDeleteHandler = jest.fn();
        const actions = {
          delete: {
            handler: mockDeleteHandler,
            label: 'Delete Prompt',
          },
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        const deleteButton = screen.getByLabelText('Delete Prompt');
        expect(deleteButton).toBeInTheDocument();
        expect(screen.getByTestId('icon-solar:trash-bin-minimalistic-broken')).toBeInTheDocument();

        fireEvent.click(deleteButton);
        expect(mockDeleteHandler).toHaveBeenCalledWith('test-prompt-1');
      });

      it('should use default label when not provided', () => {
        const mockDeleteHandler = jest.fn();
        const actions = {
          delete: { handler: mockDeleteHandler },
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        expect(screen.getByLabelText('delete')).toBeInTheDocument();
      });
    });

    describe('function action', () => {
      it('should render function action as button with default icon', () => {
        const mockActionFunction = jest.fn();
        const actions = {
          customAction: mockActionFunction,
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        const actionButton = screen.getByLabelText('customAction');
        expect(actionButton).toBeInTheDocument();
        expect(screen.getByTestId('icon-solar:info-circle-line-duotone')).toBeInTheDocument();

        fireEvent.click(actionButton);
        expect(mockActionFunction).toHaveBeenCalledWith('test-prompt-1');
      });
    });

    describe('custom action with icon', () => {
      it('should render custom action with provided icon', () => {
        const mockHandler = jest.fn();
        const customIcon = <span data-testid='custom-icon'>Custom</span>;
        const actions = {
          customAction: {
            handler: mockHandler,
            icon: customIcon,
            label: 'Custom Action',
          },
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        const actionButton = screen.getByLabelText('Custom Action');
        expect(actionButton).toBeInTheDocument();
        expect(screen.getByTestId('custom-icon')).toBeInTheDocument();

        fireEvent.click(actionButton);
        expect(mockHandler).toHaveBeenCalledWith('test-prompt-1');
      });

      it('should not render action when icon is missing', () => {
        const mockHandler = jest.fn();
        const actions = {
          customAction: {
            handler: mockHandler,
            label: 'Custom Action',
            // icon is missing
          },
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        expect(screen.queryByLabelText('Custom Action')).not.toBeInTheDocument();
      });

      it('should use default label when not provided', () => {
        const mockHandler = jest.fn();
        const customIcon = <span data-testid='custom-icon'>Custom</span>;
        const actions = {
          customAction: {
            handler: mockHandler,
            icon: customIcon,
          },
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        expect(screen.getByLabelText('customAction')).toBeInTheDocument();
      });
    });

    describe('multiple actions', () => {
      it('should render multiple actions', () => {
        const mockCopyHandler = jest.fn();
        const mockDeleteHandler = jest.fn();
        const mockCustomHandler = jest.fn();

        const actions = {
          copy: { handler: mockCopyHandler },
          delete: { handler: mockDeleteHandler },
          custom: mockCustomHandler,
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        expect(screen.getByLabelText('copy')).toBeInTheDocument();
        expect(screen.getByLabelText('delete')).toBeInTheDocument();
        expect(screen.getByLabelText('custom')).toBeInTheDocument();
      });

      it('should filter out null actions', () => {
        const mockCopyHandler = jest.fn();
        const actions = {
          copy: { handler: mockCopyHandler },
          delete: null,
          edit: undefined,
        };

        const result = appActionRenderer(mockItem, actions);
        render(<div>{result}</div>);

        expect(screen.getByLabelText('copy')).toBeInTheDocument();
        expect(screen.queryByLabelText('delete')).not.toBeInTheDocument();
        expect(screen.queryByLabelText('edit')).not.toBeInTheDocument();
      });
    });

    describe('item id conversion', () => {
      it('should handle numeric item id', () => {
        const mockHandler = jest.fn();
        const numericItem = { id: 123 };
        const actions = {
          copy: { handler: mockHandler },
        };

        const result = appActionRenderer(numericItem, actions);
        render(<div>{result}</div>);

        const copyButton = screen.getByLabelText('copy');
        fireEvent.click(copyButton);

        expect(mockHandler).toHaveBeenCalledWith('123');
      });

      it('should handle string item id', () => {
        const mockHandler = jest.fn();
        const stringItem = { id: 'abc-123' };
        const actions = {
          copy: { handler: mockHandler },
        };

        const result = appActionRenderer(stringItem, actions);
        render(<div>{result}</div>);

        const copyButton = screen.getByLabelText('copy');
        fireEvent.click(copyButton);

        expect(mockHandler).toHaveBeenCalledWith('abc-123');
      });
    });
  });
});
