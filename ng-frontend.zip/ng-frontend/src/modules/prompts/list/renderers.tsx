import { CellRenderer, ActionRenderer, DataTableColumnType } from '@aisera-ui/advanced-data-table';
import { Chip, User, Badge } from '@aisera-ui/react';
import { Icon } from '@iconify/react';
import { ROUTES } from '../../../commons/config/routes';
import { useNavigate } from 'react-router';

const formatDate = (value: string): string => {
  if (!value) return '';
  const date = new Date(value);
  return date.toLocaleDateString();
};

type ExtendedColumnType = DataTableColumnType | 'status' | 'user' | 'badge' | 'datetime';

interface ModelInfo {
  id: number;
  name: string;
  displayName: string;
  provider: string;
  configFields: any[];
}

interface DataItem {
  id: string | number;
  _modelInfo?: ModelInfo;
  modelId?: number;
  [key: string]: any;
}

export const appCellRenderer: CellRenderer = (
  value: any,
  item: DataItem,
  columnKey: string,
  type?: DataTableColumnType,
) => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const navigate = useNavigate();
  const navigateToPromptPlayground = (promptId: string | number) => {
    navigate(`${ROUTES.PROMPT_PLAYGROUND}/${promptId}`);
  };
  const handleCellClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget || !(e.target as HTMLElement).closest('button')) {
      console.log('Cell clicked, navigating to prompt playground ID:', item);
      navigateToPromptPlayground(item.id);
    }
    e.stopPropagation();
  };

  let cellContent;

  if (columnKey === 'model') {
    if (item._modelInfo && item._modelInfo.provider) {
      cellContent = item._modelInfo.provider;
    } else if (value) {
      cellContent = value;
    } else {
      cellContent = item.modelId ? `Model ID: ${item.modelId}` : '';
    }
  } else if (value === undefined || value === null) {
    return '';
  } else if (columnKey === 'status') {
    cellContent = (
      <Chip
        color={
          value === 'Published' || value === 'Active'
            ? 'success'
            : value === 'Draft'
              ? 'warning'
              : value === 'Inactive'
                ? 'danger'
                : 'default'
        }
        size='sm'
        variant='dot'
        className='font-medium'>
        {value}
      </Chip>
    );
  } else if (columnKey === 'updatedBy') {
    try {
      const userData = typeof value === 'string' ? JSON.parse(value) : value;
      const name = userData?.name || 'Unknown User';
      const username = userData?.email?.split('@')[0] || '';

      cellContent = (
        <User
          name={name}
          description={`@${username || name.toLowerCase().split(' ')[0]}`}
          avatarProps={{
            src: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`,
            size: 'sm',
            className: 'h-8 w-8',
          }}
        />
      );
    } catch {
      cellContent = String(value);
    }
  } else {
    switch (type as ExtendedColumnType) {
      case 'date':
      case 'datetime':
        cellContent = (
          <div className='flex items-center'>
            <Icon icon='solar:calendar-mark-outline' width={18} height={18} className='mr-2' />
            {formatDate(value)}
          </div>
        );
        break;

      case 'user':
        if (!value) return '';
        cellContent = (
          <User
            name={value.name}
            description={`@${value.name.toLowerCase().split(' ')[0]}`}
            avatarProps={{
              src: value.avatarUrl || `https://i.pravatar.cc/150?u=${value.name}`,
              size: 'sm',
              className: 'h-8 w-8',
            }}
          />
        );
        break;

      case 'status':
        cellContent = (
          <Chip
            color={
              value === 'Published'
                ? 'success'
                : value === 'Draft'
                  ? 'warning'
                  : value === 'Inactive'
                    ? 'danger'
                    : 'default'
            }
            size='sm'
            variant='dot'
            className='font-medium'>
            {value}
          </Chip>
        );
        break;

      case 'badge':
        cellContent = (
          <Badge variant='flat' color='default' size='sm' className='font-normal bg-transparent text-gray-700 px-0'>
            {value}
          </Badge>
        );
        break;

      case 'boolean':
        cellContent = value ? 'Yes' : 'No';
        break;

      case 'number':
        cellContent = typeof value === 'number' ? value.toLocaleString() : value;
        break;

      default:
        cellContent = String(value);
        break;
    }
  }

  return (
    <div onClick={handleCellClick} className='w-full h-full'>
      {cellContent}
    </div>
  );
};

export const appActionRenderer: ActionRenderer = (item: DataItem, actions: any) => {
  if (!actions) return null;

  return (
    <div className='flex gap-4 justify-end'>
      {Object.entries(actions).map(([key, actionConfig]: [string, any]) => {
        if (!actionConfig) return null;

        if (key === 'copy') {
          return (
            <button
              key={key}
              className='text-gray-400 hover:text-gray-600 transition-colors'
              onClick={(e) => {
                e.stopPropagation();
                actionConfig.handler(String(item.id));
              }}
              aria-label={actionConfig.label || key}>
              <Icon icon='solar:copy-linear' width={24} height={24} />
            </button>
          );
        }

        if (key === 'delete') {
          return (
            <button
              key={key}
              className='text-gray-400 hover:text-gray-600 transition-colors'
              onClick={(e) => {
                e.stopPropagation();
                actionConfig.handler(String(item.id));
              }}
              aria-label={actionConfig.label || key}>
              <Icon icon='solar:trash-bin-minimalistic-broken' width={24} height={24} />
            </button>
          );
        }

        if (typeof actionConfig === 'function') {
          return (
            <button
              key={key}
              className='text-gray-400 hover:text-gray-600 transition-colors'
              onClick={(e) => {
                e.stopPropagation();
                actionConfig(String(item.id));
              }}
              aria-label={key}>
              <Icon icon='solar:info-circle-line-duotone' width={24} height={24} />
            </button>
          );
        }

        if (!actionConfig.icon) return null;

        return (
          <button
            key={key}
            className='text-gray-400 hover:text-gray-600 transition-colors'
            onClick={(e) => {
              e.stopPropagation();
              actionConfig.handler(String(item.id));
            }}
            aria-label={actionConfig.label || key}>
            {actionConfig.icon}
          </button>
        );
      })}
    </div>
  );
};
