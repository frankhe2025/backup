import { StoryObj } from '@storybook/react';
import PromptListComponent from './prompt-list.component';

const meta = {
  title: 'Demo/Prompt List',
  component: PromptListComponent,
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: {},
};
