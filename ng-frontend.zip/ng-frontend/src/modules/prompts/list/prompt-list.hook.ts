import { Prompts } from '../entities/prompts.entity';
import { useState } from 'react';
import getPromptsServiceInstance, { PROMPTS_SERVICE_TYPES } from '../commons/prompts_service_factory';
import PromptPlaygroundInterface from '../playground/prompt-playground.interface';
import { PromptListInterface } from './prompt-list.interface';
import getCacheManager from '../../../commons/utils/cache_manager.util';

export function usePromptList() {
  const [prompts, setPrompts] = useState<Prompts | null>(null);
  const [savedTableConfigs, _setSavedTableConfigs] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const [groupId, setGroupId] = useState<number | null>(null);

  const handler = {
    getPrompts: async (groupId: number) => {
      setGroupId(groupId);
      setIsLoading(true);
      const prompts: Prompts | null = await getPromptsServiceInstance<PromptListInterface>(
        PROMPTS_SERVICE_TYPES.PROMPT_LIST,
      ).getPrompts(groupId);
      setPrompts(prompts);
      setIsLoading(false);
    },
    deletePrompt: async (promptId: number) => {
      await getPromptsServiceInstance<PromptPlaygroundInterface>(PROMPTS_SERVICE_TYPES.PROMPT_PLAYGROUND).deletePrompt(
        promptId,
      );
      getCacheManager().clear();
      handler.getPrompts(groupId!);
    },
    createNewPrompt: async (data: any) => {
      await getPromptsServiceInstance<PromptPlaygroundInterface>(
        PROMPTS_SERVICE_TYPES.PROMPT_PLAYGROUND,
      ).createNewPrompt(data);
      getCacheManager().clear();
      handler.getPrompts(groupId!);
    },
  };
  return { prompts, savedTableConfigs, handler, isLoading };
}
