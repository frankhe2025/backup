import { usePromptList } from './prompt-list.hook';
import { useEffect, useMemo, useState, useCallback, useContext } from 'react';
import { DataTableWithControls } from '@aisera-ui/advanced-data-table';
import { DataTableConfiguration, DataTableColumn, DataTableActionConfig } from '@aisera-ui/advanced-data-table';
import { Button, Chip, Selection, useDisclosure } from '@aisera-ui/react';
import { Icon } from '@iconify/react';
import { FilterType, FilterItem } from '@aisera-ui/general-filter';
import { appCellRenderer, appActionRenderer } from './renderers';
import { AppContext } from '../../../commons/context/app-context.context';
import { useTableController } from '../../../commons/modules/table-controller/table-controller.hook.ts';
import { TableConfigEntityType } from '../../../commons/modules/table-controller/table-controller-service-factory.ts';
import getAuthService from '../../../commons/modules/auth/service/auth.service.ts';
import { useNgTransaltion } from '../../../i18n/hooks/translation.hook';
import CreateEditPrompt from '../commons/components/create-edit-prompt/index.tsx';
import { Scope } from '../enums/scope.ts';
import { Prompt } from '../entities/prompt.entity.ts';
import { DeletePromptModal } from '../playground/components/tuning-controller/components/delete-modal.component.tsx';
import { PromptReviewStatus } from '../entities/prompt-review-status.enum.ts';

const TopBar = ({ count, handler }: { count: number; handler: any }) => {
  const { _t } = useNgTransaltion();
  const { selectedBot } = useContext(AppContext);
  const {
    isOpen: isCreateOpen,
    onOpen: onCreateOpen,
    onOpenChange: onCreateOpenChange,
    onClose: onCreateClose,
  } = useDisclosure();

  const handleCreatePrompt = async (data: any) => {
    console.log('Save new prompt:', data);
    if (!selectedBot?.id) {
      throw new Error('No bot selected');
    }
    if (data.scope === Scope.Application) {
      data.botId = selectedBot.id;
    }
    const userId = getAuthService().getUserId();
    data.createdBy = userId;
    data.sourceType = 'User';
    data.type = 'Custom';

    await handler.createNewPrompt(data);
    onCreateClose();
  };

  return (
    <div className='mb-[18px] flex items-center justify-between'>
      <div className='flex items-center gap-2'>
        <h1 className='text-3xl font-[700] leading-[32px]'>
          {_t('PROMPT-STUDIO', { ns: 'Prompt', defaultValue: 'Prompt Studio' })}
        </h1>
        <Chip className='hidden items-center text-default-500 sm:flex' size='sm' variant='flat'>
          {count || '-'}
        </Chip>
      </div>
      {/* New Prompt */}
      <Button
        color='primary'
        startContent={<Icon icon='solar:add-circle-bold' width={20} />}
        onClick={() => {
          onCreateOpen();
        }}>
        {_t('NEW-PROMPT', { ns: 'Prompt', defaultValue: 'New Prompt' })}
      </Button>
      <CreateEditPrompt isOpen={isCreateOpen} onOpenChange={onCreateOpenChange} onSave={handleCreatePrompt} />
    </div>
  );
};

const PromptListComponent = () => {
  const { selectedBot } = useContext(AppContext);
  const { prompts, handler, isLoading } = usePromptList();
  const { savedTableConfigs, tableControllerHandler } = useTableController();
  const { _t } = useNgTransaltion();
  const [filteredDataCount, setFilteredDataCount] = useState(0);

  const { isOpen: isDeleteOpen, onOpen: onDeleteOpen, onClose: onDeleteClose } = useDisclosure();
  const [selectedPrompt, setSelectedPrompt] = useState<Prompt>();

  const handleDeleteModal = useCallback(
    (id: string) => {
      onDeleteOpen();
      const prompt = prompts?.getPrompById(Number(id));
      if (!prompt) {
        console.warn('Prompt not found for ID:', id);
        return;
      }
      setSelectedPrompt(prompt);
    },
    [onDeleteOpen, prompts],
  );

  const handleCopy = useCallback((promptId: string) => {
    console.log('Copy prompt:', promptId);
  }, []);

  const handleDelete = (_ids?: number[]) => {
    console.log('Delete prompt:', selectedPrompt);
    handler.deletePrompt(Number(selectedPrompt?.id)).then(() => {
      console.log('Prompt deleted successfully');
      setSelectedPrompt(undefined);
      onDeleteClose();
    });
  };

  const handleSelectionChange = useCallback((selectedKeys: Selection) => {
    console.log('Selected prompts:', selectedKeys);
  }, []);

  const handleFilterChange = useCallback((filters: any) => {
    console.log('Filter applied:', filters);
    if (filters && filters.filteredData) {
      setFilteredDataCount(filters.filteredData.length);
    }
  }, []);

  const columns: DataTableColumn[] = useMemo(
    () => [
      { key: 'name', title: _t('NAME', { ns: 'Prompt', defaultValue: 'Name' }), sortable: true },
      { key: 'sourceType', title: _t('SOURCE', { ns: 'Prompt', defaultValue: 'Source' }), sortable: true },
      { key: 'type', title: _t('TYPE', { ns: 'Prompt', defaultValue: 'Type' }), sortable: true },
      { key: 'scope', title: _t('SCOPE', { ns: 'Prompt', defaultValue: 'Scope' }), type: 'text', sortable: true },
      {
        key: 'model',
        title: _t('MODEL', { ns: 'Prompt', defaultValue: 'Model' }),
        sortable: true,
        getValue: (item: any) => {
          return item._modelInfo?.provider || '';
        },
      },
      {
        key: 'status',
        title: _t('STATUS', { ns: 'Prompt', defaultValue: 'Status' }),
        type: 'text',
        sortable: true,
      },
      {
        key: 'updatedAt',
        title: _t('LAST-UPDATED', { ns: 'Prompt', defaultValue: 'Last Updated' }),
        type: 'date',
        sortable: true,
      },
      {
        key: 'updatedByEmail',
        title: _t('UPDATED-BY', { ns: 'Prompt', defaultValue: 'Updated By' }),
        type: 'text',
        sortable: true,
      },
      {
        key: 'isDraft',
        title: _t('DRAFT', { ns: 'Prompt', defaultValue: 'Draft' }),
        type: 'boolean',
        sortable: true,
      },
    ],
    [_t],
  );

  const tableConfiguration = useMemo<DataTableConfiguration>(
    () => ({
      columns: columns,
      selectionMode: 'single',
      onSelectionChange: handleSelectionChange,
      actions: {
        delete: {
          handler: handleDeleteModal,
          icon: <Icon icon='solar:trash-bin-minimalistic-broken' width={24} height={24} />,
          label: 'Delete',
        } as DataTableActionConfig,
      },
      defaultCellRenderer: appCellRenderer,
      actionRenderer: appActionRenderer,
      classNames: {
        base: 'border-collapse',
        thead: 'bg-gray-50',
        th: 'bg-default-100 text-default-900 border-b border-divider font-semibold text-xs uppercase',
        td: 'px-4 py-3 border-b border-divider cursor-pointer',
        tr: 'transition-colors hover:bg-default-100',
        actionButton: 'text-gray-600 hover:text-gray-900',
        sortIndicator: 'ml-2 text-blue-600 font-bold',
      },
      ariaLabel: 'Prompts Table',
    }),
    [columns, handleSelectionChange, handleCopy, handleDeleteModal],
  );

  const filterItems = useMemo(
    () => [
      new FilterItem({
        key: 'name',
        label: _t('NAME', { ns: 'Prompt', defaultValue: 'Name' }),
        type: FilterType.TEXT,
      }),
      new FilterItem({
        key: 'sourceType',
        label: _t('SOURCE', { ns: 'Prompt', defaultValue: 'Source' }),
        type: FilterType.MULTI_SELECT,
        options: [
          { value: 'System', label: 'System' },
          { value: 'User', label: 'User' },
        ],
      }),
      new FilterItem({
        key: 'type',
        label: _t('TYPE', { ns: 'Prompt', defaultValue: 'Type' }),
        type: FilterType.MULTI_SELECT,
        options: [
          { value: 'Default', label: 'Default' },
          { value: 'Custom', label: 'Custom' },
          { value: 'Tuned', label: 'Tuned' },
        ],
      }),
      new FilterItem({
        key: 'status',
        label: _t('STATUS', { ns: 'Prompt', defaultValue: 'Status' }),
        type: FilterType.SINGLE_SELECT,
        options: [
          { value: 'Active', label: 'Active' },
          { value: 'Inactive', label: 'Inactive' },
        ],
      }),
      new FilterItem({
        key: 'scope',
        label: _t('SCOPE', { ns: 'Prompt', defaultValue: 'Scope' }),
        type: FilterType.MULTI_SELECT,
        options: [
          { value: 'Global', label: 'Global' },
          { value: 'Application', label: 'Application' },
          { value: 'Tenant', label: 'Tenant' },
        ],
      }),
      new FilterItem({
        key: 'updatedAt',
        label: _t('LAST-UPDATED', { ns: 'Prompt', defaultValue: 'Last Updated' }),
        type: FilterType.DATE,
      }),
      new FilterItem({
        key: 'isDraft',
        label: _t('DRAFT', { ns: 'Prompt', defaultValue: 'Draft' }),
        type: FilterType.SINGLE_SELECT,
        options: [
          { value: 'true', label: 'Yes' },
          { value: 'false', label: 'No' },
        ],
      }),
    ],
    [_t],
  );

  const defaultVisibleColumns = useMemo(
    () => ['name', 'source', 'type', 'scope', 'model', 'status', 'updatedAt', 'updatedByEmail'],
    [],
  );

  const tableData = useMemo(() => {
    if (!prompts) return [];
    return prompts.getProcessedData();
  }, [prompts]);

  useEffect(() => {
    if (prompts) {
      setFilteredDataCount(prompts.getProcessedData().length);
    }
  }, [prompts]);

  useEffect(() => {
    if (selectedBot?.id) {
      handler.getPrompts(selectedBot.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedBot?.id]);

  const { getSavedTableConfigs } = tableControllerHandler;

  useEffect(() => {
    getSavedTableConfigs(TableConfigEntityType.NG_PROMPT_LIST);
  }, [getSavedTableConfigs]);

  return (
    <div className='pt-4'>
      <TopBar count={filteredDataCount} handler={handler} />
      {isDeleteOpen && (
        <DeletePromptModal
          name={selectedPrompt?.name || ''}
          mode='single'
          status={PromptReviewStatus.PUBLISHED}
          promptVersions={[]}
          onClose={onDeleteClose}
          onDelete={handleDelete}
        />
      )}
      {isLoading ? (
        <div className='flex justify-center items-center h-64'>
          <div className='animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500'></div>
        </div>
      ) : (
        // <Card className='p-6'>
        <>
          {savedTableConfigs && (
            <DataTableWithControls
              data={tableData}
              configuration={tableConfiguration}
              filterItems={filterItems}
              defaultVisibleColumns={defaultVisibleColumns}
              onFilterChange={handleFilterChange}
              savedTableConfigs={savedTableConfigs}
              onSaveNewTableConfig={(data) =>
                tableControllerHandler.saveNewTableConfig(TableConfigEntityType.NG_PROMPT_LIST, data)
              }
              onSavedTableConfigUpdated={(data) =>
                tableControllerHandler.savedTableConfigUpdated(TableConfigEntityType.NG_PROMPT_LIST, data)
              }
              currentUserId={getAuthService().getUserId()}
            />
          )}
        </>

        // </Card>
      )}
    </div>
  );
};

export default PromptListComponent;
