export enum Scope {
  Global = 'global',
  Application = 'bot',
  Tenant = 'tenant',
}
