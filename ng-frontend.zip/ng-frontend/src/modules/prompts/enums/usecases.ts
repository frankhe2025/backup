export enum Usecases {
  AgentAssist = 'AgentAssist',
  ConversationalDisambiguation = 'ConversationalDisambiguation',
  TicketAI = 'TicketAI',
}
