import AppRoutes from './AppRoutes';
import { useEffect } from 'react';
import getAuthService from './commons/modules/auth/service/auth.service';
import { isSSOCallback } from './commons/utils/utils';
import { addCollection } from '@iconify/react';
import { aiBrandJson } from '@aisera-ui/icons';
import { useLoader } from './commons/hooks/loader/loader.hook';

addCollection(aiBrandJson, 'aisera');

const App = () => {
  const { setLoading } = useLoader();
  useEffect(() => {
    if (isSSOCallback()) {
      setLoading('SHOW');
      getAuthService().getUserDetails();
    }
  }, [setLoading]);

  return <AppRoutes />;
};

export default App;
