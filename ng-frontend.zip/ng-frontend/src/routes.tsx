import { redirect, RouteObject } from 'react-router';
import type { LoaderFunctionArgs } from 'react-router';
import { AppLayout } from './layout';
import PromptListComponent from './modules/prompts/list/prompt-list.component';
import { Analytics } from './commons/components/analytics';
import { PrivateRoute } from './commons/components/private-route';
import { Home } from './modules/home/Home';
import { Providers } from './commons/components/providers';
import { ROUTES } from './commons/config/routes';
import { isSSOCallback } from './commons/utils/utils.ts';
import getAuthService from './commons/modules/auth/service/auth.service.ts';
import getRbacService from './commons/modules/auth/service/rbac.service.ts';
import { PromptPlaygroundComponent } from './modules/prompts/playground';
import { LoginV2 } from './commons/modules/auth/login-v2.component';

const routerGuard = async ({ request }: LoaderFunctionArgs) => {
  if (!isSSOCallback() && !document.location.pathname.includes('/login') && !getAuthService().isUserSignedIn()) {
    return redirect('/login');
  }
  const url = new URL(request.url);

  const rbacAccessibility = await getRbacService().checkCurrentPageAccess(
    url.pathname.replace(process.env.PUBLIC_PATH || '', '').substring(1),
  );
  if (!rbacAccessibility) {
    return redirect('/');
  }

  return null;
};

export const routes: RouteObject[] = [
  {
    Component: Providers,
    children: [
      {
        Component: Analytics,
        children: [
          {
            path: '/',
            Component: PrivateRoute,
            children: [
              {
                Component: AppLayout,
                children: [
                  { index: true, Component: Home, id: 'Home' },
                  { path: ROUTES.PROMPTS, Component: PromptListComponent, id: 'Prompt List', loader: routerGuard },
                  {
                    path: `${ROUTES.PROMPT_PLAYGROUND}/:promptId`,
                    Component: PromptPlaygroundComponent,
                    id: 'Prompt Playground',
                    loader: routerGuard,
                  },
                ],
              },
            ],
          },
          {
            path: ROUTES.LOGIN,
            element: <LoginV2 />,
          },
        ],
      },
    ],
  },
  {
    path: '*',
    element: <div>404 Not Found</div>,
  },
];
