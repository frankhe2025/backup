import { render, screen } from '@testing-library/react';
import { Button } from '@aisera-ui/react';

describe('Button tests', () => {
  it('should contains the heading 1', () => {
    render(<Button>Hello</Button>);
    const heading = screen.getByText(/Hello/i);
    expect(heading).toBeDefined();
  });
});
