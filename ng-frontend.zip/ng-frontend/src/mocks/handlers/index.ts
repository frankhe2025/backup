import { http, HttpResponse } from 'msw';
import config from '../../commons/config/config';

export const handlers = [
  http.get(config.BACKEND_HOST_URL + 'llm-gateway/v1/tenants/:tenantId/version/llm-prompts', ({ request }) => {
    const url = new URL(request.url);
    const botId = url.searchParams.get('botId');

    if (!botId) {
      return new HttpResponse(null, { status: 404 });
    }
    return HttpResponse.json({ botId });
  }),
  http.get(config.BACKEND_HOST_URL + 'connector-server/v1/registrations/url/:host', ({ request }) => {
    const url = new URL(request.url);
    const botId = url.searchParams.get('botId');

    return HttpResponse.json({ botId });
  }),
];
