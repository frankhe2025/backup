import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import Backend from 'i18next-http-backend';

// Initialize i18next with configuration
i18n
  .use(Backend) // Load translation files
  .use(LanguageDetector) // Detect user's language
  .use(initReactI18next) // Integrate with React
  .init({
    fallbackLng: 'en', // Fallback language if none is detected
    debug: true, // Enable debugging for development
    interpolation: {
      escapeValue: false, // React already escapes HTML
    },
    //preload: ['en', 'fr'],
    react: {
      useSuspense: true, // Disable Suspense for synchronous rendering
    },
    ns: ['translation', 'Common', 'Prompt'],
    backend: {
      loadPath: process.env.PUBLIC_PATH + '/locales/{{lng}}/{{ns}}.json', // Path to the translation files
    },
  });

export default i18n;
