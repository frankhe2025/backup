import { useTranslation } from 'react-i18next';

export const useNgTransaltion = (ns?: 'translation' | 'Common' | 'Prompt' | undefined) => {
  const { t: _t, i18n } = useTranslation(ns || 'translation');

  return { _t, i18n };
};
