// Declare module 'i18next' to extend the type definitions
import 'i18next';

import en from '../../public/locales/en/translation.json';
import promptEn from '../../public/locales/en/Prompt.json';
import commonEn from '../../public/locales/en/Common.json';

declare module 'i18next' {
  // Extend the CustomTypeOptions to declare the structure of your resources
  interface CustomTypeOptions {
    // Define the key-value structure of your translation files here
    resources: {
      translation: typeof en;
      Prompt: typeof promptEn;
      Common: typeof commonEn;
    };
  }
}
