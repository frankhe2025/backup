import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import SentryBoundary from './commons/components/sentry/SentryBoundary';
import { AppProvider } from './commons/context/app-context.context';
import './i18n';
import './styles.css';

import { AnalyticsManager, ServiceProvider, AnalyticsConfigOptions } from '@aisera-ui/analytics-adapter-ui';
import callApi, { REQUEST_METHOD } from './commons/utils/fetcher.util';

callApi({
  url: '/config',
  method: REQUEST_METHOD.GET,
})
  .then(async (response) => {
    if (!response.resp?.googleAnalyticsId) {
      return;
    }

    const googleAnalyticsId = response.resp.googleAnalyticsId;

    if (!(window as any)._googleAnalyticsAdapter) {
      const config: AnalyticsConfigOptions = {
        type: ServiceProvider.GoogleAnalytics,
        measurementId: googleAnalyticsId,
        options: {
          send_page_view: false,
        },
      };

      const googleAnalyticsAdapter = new AnalyticsManager(config);
      (window as any)._googleAnalyticsAdapter = googleAnalyticsAdapter;
      await googleAnalyticsAdapter.initialize();
    }
  })
  .catch((error) => {
    console.error('Failed to fetch configuration:', error);
  })
  .finally(() => {
    renderApp();
  });

async function enableMocking() {
  return false;

  if (process.env.NODE_ENV !== 'development') {
    return;
  }

  const { worker } = await import('./mocks/browser');
  return worker.start({
    onUnhandledRequest: 'warn',
  });
}

async function renderApp() {
  const rootEl = document.getElementById('root');

  if (!rootEl) throw new Error('Cannot initialize app: root element not found');

  const root = ReactDOM.createRoot(rootEl);

  try {
    await enableMocking();
  } catch (error) {
    console.error('Failed to enable mocking', error);
  }

  root.render(
    <React.StrictMode>
      <SentryBoundary>
        <AppProvider>
          <App />
        </AppProvider>
      </SentryBoundary>
    </React.StrictMode>,
  );
}
