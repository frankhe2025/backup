import { AppShell } from '@aisera-ui/app-shell';
import { NavBar } from '../commons/components/navbar/navbar.component';
import { Sidebar } from '../commons/components/sidebar';
import { Outlet } from 'react-router';

export const AppLayout = () => {
  return (
    <AppShell
      className='p-4'
      sidebar={<Sidebar />}
      classNames={{
        main: 'overflow-hidden !p-0',
      }}>
      <div className='h-full w-full overflow-auto p-4'>
        <NavBar />
        <Outlet />
      </div>
    </AppShell>
  );
};

export default AppLayout;
