import { createBrowserRouter, RouterProvider } from 'react-router';
import { routes } from './routes';

const router = createBrowserRouter(routes, {
  basename: process.env.PUBLIC_PATH || '',
});

const AppRoutes = () => {
  return <RouterProvider router={router} />;
};

export default AppRoutes;
