import { useEffect, useState } from 'react';
import { Icon } from '@iconify/react';
import { Button, Input } from '@aisera-ui/react';
import { useLogin } from './login.hook';
import { useNavigate } from 'react-router';
import { useNgTransaltion } from '../../../i18n/hooks/translation.hook';
import { ILogin } from './login.interface';
import getRegistrationService from '../connector-server/services/registration.service';
import config from '../../config/config';

export const LoginV2 = () => {
  const navigate = useNavigate();
  const { _t } = useNgTransaltion();
  const [tenantId, setTenantId] = useState<string>('');
  const { loginSuccess, setLoginSuccess, handler, isLoading } = useLogin();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoginSuccess(null);

    const data = {
      ...Object.fromEntries(new FormData(e.currentTarget)),
      tenantId,
    } as ILogin;

    handler.login(data);
  };

  const getTenantId = async () => {
    setTenantId(await getRegistrationService().getCurrentTenantId());
  };

  useEffect(() => {
    if (loginSuccess) {
      navigate('/');
    }
  }, [loginSuccess, navigate]);

  useEffect(() => {
    getTenantId();
  }, []);

  const handleCompanySSO = () => {
    document.location.href = `${config.BACKEND_HOST_URL}auth/sso/login?tenantId=${tenantId}`;
  };

  return (
    <div className='min-h-screen bg-gradient-to-br from-orange-50 via-rose-50 to-amber-50 flex items-center justify-center p-4 relative overflow-hidden'>
      {/* Background AI-related imagery */}
      <div className='absolute inset-0'>
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] bg-cover bg-center opacity-5"></div>
        <div className='absolute top-1/4 left-1/4 w-96 h-96 bg-orange-200/30 rounded-full blur-3xl animate-pulse'></div>
        <div className='absolute bottom-1/4 right-1/4 w-96 h-96 bg-rose-200/30 rounded-full blur-3xl animate-pulse delay-1000'></div>
        <div className='absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-200/30 rounded-full blur-3xl animate-pulse delay-500'></div>
      </div>

      <div className='w-full max-w-6xl grid lg:grid-cols-2 gap-12 items-center relative z-10'>
        {/* Left Side - AI Branding */}
        <div className='hidden lg:block space-y-8'>
          <div className='space-y-6'>
            <div className='flex items-center space-x-3'>
              {/* <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-rose-500 rounded-xl flex items-center justify-center shadow-lg">
                <Icon icon="lucide:hexagon" width={24} height={24} className="text-white" />
              </div>
              <span className="text-2xl font-bold text-slate-900">Aisera</span> */}
              <img src='/assets/logo.png' style={{ width: 150 }} />
            </div>

            <div className='space-y-4'>
              <h1 className='text-5xl font-bold text-slate-900 leading-tight'>
                Self-Service
                <span className='block bg-gradient-to-r from-orange-600 to-rose-600 bg-clip-text text-transparent'>
                  Admin Portal
                </span>
              </h1>
              <p className='text-xl text-slate-700 leading-relaxed max-w-md'>
                Manage accounts, automate workflows, and resolve issues-no IT required.
              </p>
            </div>
          </div>

          <div className='grid grid-cols-2 gap-6'>
            <div className='bg-white/80 backdrop-blur-xl border border-orange-200/50 rounded-xl p-6 shadow-lg'>
              <div className='w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mb-4'>
                <Icon icon='lucide:users' className='text-xl text-orange-600' />
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>User Management</h3>
              <p className='text-sm text-slate-600'>
                Create accounts, reset passwords, and manage user permissions instantly.
              </p>
            </div>

            <div className='bg-white/80 backdrop-blur-xl border border-rose-200/50 rounded-xl p-6 shadow-lg'>
              <div className='w-10 h-10 bg-rose-100 rounded-lg flex items-center justify-center mb-4'>
                <Icon icon='lucide:settings' className='text-xl text-rose-600' />
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>Quick Actions</h3>
              <p className='text-sm text-slate-600'>One-click solutions for common tasks and system configurations.</p>
            </div>

            <div className='bg-white/80 backdrop-blur-xl border border-amber-200/50 rounded-xl p-6 shadow-lg'>
              <div className='w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center mb-4'>
                <Icon icon='lucide:zap' className='text-xl text-amber-600' />
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>Workflow Automation</h3>
              <p className='text-sm text-slate-600'>Intelligent process automation with self-learning capabilities.</p>
            </div>

            <div className='bg-white/80 backdrop-blur-xl border border-orange-200/50 rounded-xl p-6 shadow-lg'>
              <div className='w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mb-4'>
                <span className='text-orange-600 text-sm font-bold'>AI</span>
              </div>
              <h3 className='font-semibold text-slate-900 mb-2'>Model Management</h3>
              <p className='text-sm text-slate-600'>Deploy, monitor, and optimize AI models at enterprise scale.</p>
            </div>
          </div>

          {/* AI Network Visualization */}
          {/* <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-orange-200/30 to-rose-200/30 rounded-2xl blur-xl"></div>
            <div className="relative bg-white/70 backdrop-blur-xl border border-orange-200/50 rounded-2xl p-6 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-slate-900 font-medium">Active AI Agents</h4>
                <span className="text-orange-600 text-sm font-mono">24/7 Operations</span>
              </div>
              <div className="grid grid-cols-4 gap-3">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="h-2 bg-gradient-to-r from-orange-500 to-rose-500 rounded-full opacity-80 animate-pulse"
                    style={{ animationDelay: `${i * 200}ms` }}
                  ></div>
                ))}
              </div>
            </div>
          </div> */}
          {/* Self-Service Stats */}
          <div className='relative'>
            <div className='absolute inset-0 bg-gradient-to-r from-orange-200/30 to-rose-200/30 rounded-2xl blur-xl'></div>
            <div className='relative bg-white/70 backdrop-blur-xl border border-orange-200/50 rounded-2xl p-6 shadow-lg'>
              <div className='flex items-center justify-between mb-4'>
                <h4 className='text-slate-900 font-medium'>Today&apos;s Self-Service Activity</h4>
                <span className='text-orange-600 text-sm font-mono'>Live Updates</span>
              </div>
              <div className='grid grid-cols-3 gap-4 text-center'>
                <div>
                  <div className='text-2xl font-bold text-slate-900'>47</div>
                  <div className='text-xs text-slate-600'>Requests Resolved</div>
                </div>
                <div>
                  <div className='text-2xl font-bold text-slate-900'>12</div>
                  <div className='text-xs text-slate-600'>Users Created</div>
                </div>
                <div>
                  <div className='text-2xl font-bold text-slate-900'>98%</div>
                  <div className='text-xs text-slate-600'>Success Rate</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className='w-full max-w-md mx-auto lg:mx-0'>
          <div className='bg-white/90 backdrop-blur-xl border border-orange-200/50 rounded-2xl shadow-2xl p-8'>
            <div className='text-center mb-8'>
              <div className='inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-orange-500 to-rose-500 rounded-2xl mb-6 shadow-lg'>
                {/* <Bot className="w-8 h-8 text-white" /> */}
                <Icon icon='lucide:users' width={24} height={24} className='text-white' />
              </div>
              <h2 className='text-2xl font-bold text-slate-900 mb-2'>Welcome Back</h2>
              <p className='text-slate-600'>Access your self-service portal</p>
            </div>

            <form onSubmit={handleSubmit} className='space-y-6'>
              <div className='space-y-4'>
                <div>
                  <label className='text-sm font-medium mb-1 block'>
                    {_t('USERNAME', { ns: 'Common', defaultValue: 'Username' })}
                  </label>
                  <Input
                    type='text'
                    name='email'
                    placeholder={_t('ENTER-USERNAME', { ns: 'Common', defaultValue: 'Enter your username' })}
                    errorMessage={_t('ERROR-USERNAME', { ns: 'Common', defaultValue: 'Please enter a Username' })}
                    isRequired
                    variant='bordered'
                    radius='sm'
                    classNames={{
                      inputWrapper: 'border-default-200 group-data-[focus=true]:border-[#e87556]',
                    }}
                  />
                </div>

                <div>
                  <label className='text-sm font-medium mb-1 block'>
                    {_t('PASSWORD', { ns: 'Common', defaultValue: 'Password' })}
                  </label>
                  <Input
                    type='password'
                    name='password'
                    placeholder={_t('ENTER-PASSWORD', { ns: 'Common', defaultValue: 'Enter your password' })}
                    errorMessage={_t('PASSWORD-ERROR', { ns: 'Common', defaultValue: 'Please enter a password' })}
                    isRequired
                    variant='bordered'
                    radius='sm'
                    classNames={{
                      inputWrapper: 'border-default-200 group-data-[focus=true]:border-[#e87556]',
                    }}
                    endContent={<Icon icon='lucide:eye' className='text-default-400 cursor-pointer' />}
                  />
                </div>
              </div>

              {/* <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="remember"
                    className="border-slate-300 data-[state=checked]:bg-orange-500 data-[state=checked]:border-orange-500"
                  />
                  <label htmlFor="remember" className="text-sm text-slate-600">
                    Remember me
                  </label>
                </div>
                <button type="button" className="text-sm text-orange-600 hover:text-orange-700 font-medium">
                  Forgot password?
                </button>
              </div> */}

              <Button
                type='submit'
                className='w-full h-11 bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white font-medium rounded-lg group shadow-lg'
                isLoading={isLoading}
                endContent={!isLoading && <Icon icon='lucide:arrow-right' />}>
                {_t('Login', { ns: 'Common', defaultValue: 'Sign In' })}
              </Button>

              <div className='relative'>
                <div className='absolute inset-0 flex items-center'>
                  <span className='w-full border-t border-slate-200' />
                </div>
                <div className='relative flex justify-center text-xs uppercase'>
                  <span className='bg-white px-2 text-slate-500'>Or continue with</span>
                </div>
              </div>

              <div className='grid grid-cols-1 gap-3'>
                <Button
                  variant='bordered'
                  className='h-11 border-slate-300 hover:bg-slate-50 text-slate-700 font-medium'
                  onPress={handleCompanySSO}>
                  <svg className='w-5 h-5 mr-2' viewBox='0 0 24 24'>
                    <path
                      fill='currentColor'
                      d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.94-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z'
                    />
                  </svg>
                  Single Sign-On (SSO)
                </Button>

                {/* <Button
                  variant="bordered"
                  className="h-11 border-slate-300 hover:bg-slate-50 text-slate-700 font-medium"
                >
                  <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                    <path
                      fill="currentColor"
                      d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"
                    />
                  </svg>
                  SAML Authentication
                </Button> */}
              </div>

              <div className='mt-6 pt-6 border-t border-slate-200 text-center'>
                <p className='text-sm text-slate-600'>
                  Self-Service Enabled • <span className='text-orange-600 font-medium'>Instant Access</span>
                </p>
              </div>
            </form>
          </div>

          {/* Security Badge */}
          <div className='mt-6 text-center'>
            <div className='inline-flex items-center space-x-2 bg-white/70 backdrop-blur-xl border border-orange-200/50 rounded-full px-4 py-2 shadow-sm'>
              <div className='w-2 h-2 bg-green-500 rounded-full animate-pulse'></div>
              <span className='text-sm text-slate-600'>24/7 Self-Service Available</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
