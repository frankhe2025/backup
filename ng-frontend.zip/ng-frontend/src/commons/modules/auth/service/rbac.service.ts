import { EntityAccessesEntity } from '../entities/entity-accesses.entity.ts';
import getAuthService from './auth.service.ts';
import callApi, { REQUEST_METHOD } from '../../../utils/fetcher.util.ts';

export class RbacService {
  constructor() {}

  async getEntityAccesses() {
    const url = `access-control-service/v1/tenants/${getAuthService().getTenantId()}/users/${getAuthService().getUserId()}`;
    const data = await callApi({
      url,
      method: REQUEST_METHOD.GET,
    }).catch((e) => e);
    return new EntityAccessesEntity(data.resp);
  }

  // this function is to check user's accessibility to a path
  async checkCurrentPageAccess(pathName: string) {
    const entityAccesses = await this.getEntityAccesses();
    if (entityAccesses) {
      return entityAccesses.havingAccessToPage(pathName);
    }
    return false; // If no entity accesses are found, deny access
  }

  async isEntityAccessible(entityType: string) {
    const entityAccesses = await this.getEntityAccesses();

    if (entityAccesses) {
      return entityAccesses.isEntityAccessible(entityType);
    }
    return false; // If no entity accesses are found, deny access
  }
  async isEntityReadable(entityType: string) {
    const entityAccesses = await this.getEntityAccesses();
    if (entityAccesses) {
      return entityAccesses.isEntityReadable(entityType);
    }
    return false; // If no entity accesses are found, deny read access
  }
  async isEntityWritable(entityType: string) {
    const entityAccesses = await this.getEntityAccesses();
    if (entityAccesses) {
      return entityAccesses.isEntityWritable(entityType);
    }
    return false; // If no entity accesses are found, deny read access
  }
}

let _rbacService: RbacService | null = null;

const getRbacService = () => {
  if (!_rbacService) {
    _rbacService = new RbacService();
  }
  return _rbacService;
};
export default getRbacService;
