import callApi, { REQUEST_METHOD } from '../../../utils/fetcher.util';
import { Auth } from '../entities/auth.entity';
import { ILogin } from '../login.interface';
import getAuthService from './auth.service';

export class LoginService {
  async login(formData: ILogin): Promise<boolean> {
    const url = `auth/login`;

    const data = await callApi({
      url,
      method: REQUEST_METHOD.POST,
      data: formData,
    });

    if (data?.err) {
      return false;
    }

    getAuthService().setAuth(
      new Auth({
        token: data.resp?.token,
        userName: data.resp?.email,
        tenantId: formData.tenantId,
        userId: data.resp?.userId,
        tenantName: data.resp?.tenantName,
      }),
    );

    return true;
  }
}
