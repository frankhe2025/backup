import { RbacService } from './rbac.service.ts';
import callApi from '../../../utils/fetcher.util.ts';

jest.mock('../../../utils/fetcher.util.ts', () => ({
  __esModule: true, // This ensures the module is treated as an ES module
  default: jest.fn(), // Mock the default export
  REQUEST_METHOD: {
    GET: 'GET',
    POST: 'POST',
    PUT: 'PUT',
    DELETE: 'DELETE',
  },
}));

describe('rbacService', () => {
  it('constructs with default values', () => {
    const rbacService = new RbacService();
    expect(rbacService).toBeDefined();
  });
});

describe('RbacService - getEntityAccesses', () => {
  let rbacService: RbacService;

  beforeEach(() => {
    rbacService = new RbacService();
    jest.clearAllMocks();
  });

  it('should fetch entity accesses and return an EntityAccessesEntity instance', async () => {
    let mockResponse: any = { resp: { admin: true, privileges: [] } };

    (callApi as jest.Mock).mockResolvedValue(mockResponse);

    let result = await rbacService.isEntityAccessible('TEST1');
    expect(result).toBe(false);

    mockResponse = { resp: { admin: true, privileges: [{ entityType: 'TEST1', privileges: ['READ'] }] } };

    (callApi as jest.Mock).mockResolvedValue(mockResponse);

    result = await rbacService.isEntityAccessible('TEST1');
    expect(result).toBe(true);
    expect(await rbacService.isEntityReadable('TEST1')).toBeTruthy();
    expect(await rbacService.isEntityWritable('TEST1')).toBeFalsy();
  });
});
