export const mapper: any = {
  prompts: ['promptStudio'],
  'prompts/playground': ['promptStudio'],
};
