import { ROUTES } from '../../../config/routes';
import callApi, { REQUEST_METHOD } from '../../../utils/fetcher.util';
import { Auth } from '../entities/auth.entity';

const JWT_NAME = 'JWT';
export class AuthService {
  setAuth(auth: Auth) {
    localStorage.setItem(JWT_NAME, JSON.stringify(auth));
  }

  logout() {
    localStorage.removeItem(JWT_NAME);
  }

  isUserSignedIn() {
    return localStorage.getItem(JWT_NAME) !== null;
  }

  getAuth(): Auth | null {
    if (this.isUserSignedIn()) {
      return new Auth(JSON.parse(localStorage.getItem(JWT_NAME) || '{}'));
    } else {
      return null;
    }
  }

  getAuthToken() {
    return this.getAuth()?.token;
  }

  getTenantId() {
    return this.getAuth()?.tenantId;
  }

  getUserId() {
    return this.getAuth()?.userId;
  }

  getUserName() {
    return this.getAuth()?.userName;
  }

  async getUserDetails() {
    const search = document.location.search;
    const token = search.replace('?jwt=', '');

    const data = await callApi({
      url: '/auth/profile',
      method: REQUEST_METHOD.GET,
      headers: {
        jwt: token,
      },
    });

    if (data?.statusCode === 401) {
      document.location.href = process.env.PUBLIC_PATH + ROUTES.LOGIN;
    } else {
      this.setAuth(
        new Auth({
          token,
          userName: data?.resp?.email,
          tenantId: data?.resp?.tenantId,
          userId: data?.resp?.userId,
          tenantName: data?.resp?.tenantName,
        }),
      );

      document.location.href = process.env.PUBLIC_PATH ?? '/';
    }
  }
}

let _authService: AuthService | null = null;
const getAuthService = (): AuthService => {
  if (!_authService) {
    _authService = new AuthService();
  }
  return _authService;
};

export default getAuthService;
