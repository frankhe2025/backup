import { AuthService } from './auth.service';
import { Auth } from '../entities/auth.entity';

describe('AuthService', () => {
  let authService: AuthService;

  beforeEach(() => {
    authService = new AuthService();
    localStorage.clear();
  });

  it('should set auth in localStorage', () => {
    const auth = new Auth({ token: 'test-token', userId: '123', tenantId: '456' });
    authService.setAuth(auth);

    expect(localStorage.getItem('JWT')).toEqual(JSON.stringify(auth));
  });

  it('should remove auth from localStorage on logout', () => {
    localStorage.setItem('JWT', JSON.stringify({ token: 'test-token' }));
    authService.logout();

    expect(localStorage.getItem('JWT')).toBeNull();
  });

  it('should return true if user is signed in', () => {
    localStorage.setItem('JWT', JSON.stringify({ token: 'test-token' }));
    expect(authService.isUserSignedIn()).toBe(true);
  });

  it('should return false if user is not signed in', () => {
    expect(authService.isUserSignedIn()).toBe(false);
  });

  it('should return auth object if user is signed in', () => {
    const auth = new Auth({ token: 'test-token', userId: '123', tenantId: '456' });
    localStorage.setItem('JWT', JSON.stringify(auth));

    expect(authService.getAuth()).toEqual(auth);
  });

  it('should return null if user is not signed in', () => {
    expect(authService.getAuth()).toBeNull();
  });

  it('should return auth token if user is signed in', () => {
    const auth = new Auth({ token: 'test-token', userId: '123', tenantId: '456' });
    localStorage.setItem('JWT', JSON.stringify(auth));

    expect(authService.getAuthToken()).toBe('test-token');
  });

  it('should return undefined for auth token if user is not signed in', () => {
    expect(authService.getAuthToken()).toBeUndefined();
  });

  it('should return tenantId if user is signed in', () => {
    const auth = new Auth({ token: 'test-token', userId: '123', tenantId: '456' });
    localStorage.setItem('JWT', JSON.stringify(auth));

    expect(authService.getTenantId()).toBe('456');
  });

  it('should return undefined for tenantId if user is not signed in', () => {
    expect(authService.getTenantId()).toBeUndefined();
  });

  it('should return userId if user is signed in', () => {
    const auth = new Auth({ token: 'test-token', userId: '123', tenantId: '456' });
    localStorage.setItem('JWT', JSON.stringify(auth));

    expect(authService.getUserId()).toBe('123');
  });

  it('should return undefined for userId if user is not signed in', () => {
    expect(authService.getUserId()).toBeUndefined();
  });
});
