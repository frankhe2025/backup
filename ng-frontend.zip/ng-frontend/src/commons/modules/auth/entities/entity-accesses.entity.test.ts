import { EntityAccessesEntity, EntityAccessPrivilege } from './entity-accesses.entity.ts';
import { getEntityAccessMockData } from '../mocks/entity-access.faker.ts';

jest.mock('../service/path-entity-mapper.ts', () => ({
  mapper: {
    prompts: ['modelJob', 'user', 'convMessage', 'PromptStudio'],
  },
}));

describe('EntityAccessesEntity', () => {
  it('should initialize with default values', () => {
    const entityAccessesEntity = new EntityAccessesEntity(getEntityAccessMockData());
    expect(entityAccessesEntity.entityAccesses.length > 10).toBeTruthy();
    expect(entityAccessesEntity.admin).toBeFalsy();
    entityAccessesEntity.entityAccesses.forEach((entityAccessesEntity) => {
      expect(entityAccessesEntity.privileges.length).toBeGreaterThan(0);
    });
  });
});

describe('EntityAccessesEntity - havingAccessToPage', () => {
  it('should return true if no mapping exists for the path', () => {
    const entityAccessesEntity = new EntityAccessesEntity();
    const result = entityAccessesEntity.havingAccessToPage('nonExistentPath');
    expect(result).toBe(false);
  });

  it('should return true if all mapped entities have privileges other than None', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [
        { entityType: 'modelJob', privileges: [EntityAccessPrivilege.Read] },
        { entityType: 'user', privileges: [EntityAccessPrivilege.ReadWrite] },
        { entityType: 'convMessage', privileges: [EntityAccessPrivilege.Read] },
        { entityType: 'PromptStudio', privileges: [EntityAccessPrivilege.ReadWrite] },
      ],
    });
    let result = entityAccessesEntity.havingAccessToPage('prompts');
    expect(result).toBe(true);
    result = entityAccessesEntity.havingAccessToPage('prompts/playground');
    expect(result).toBe(true);
  });

  it('should return false if any mapped entity has None privilege', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [
        { entityType: 'modelJob', privileges: [EntityAccessPrivilege.None] },
        { entityType: 'user', privileges: [EntityAccessPrivilege.ReadWrite] },
      ],
    });
    const result = entityAccessesEntity.havingAccessToPage('prompts');
    expect(result).toBe(false);
  });

  it('should return true if the entityAccesses list is empty', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [],
    });
    const result = entityAccessesEntity.havingAccessToPage('prompts');
    expect(result).toBe(false);
  });

  it('should return false if any mapped entity has no privileges at all', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [
        { entityType: 'modelJob', privileges: [] },
        { entityType: 'user', privileges: [EntityAccessPrivilege.ReadWrite] },
      ],
    });
    let result = entityAccessesEntity.havingAccessToPage('prompts');
    expect(result).toBe(false);
    result = entityAccessesEntity.havingAccessToPage('prompts/playground');
    expect(result).toBe(false);
  });
});

describe('EntityAccessesEntity - Access Methods', () => {
  it('should return true for isEntityReadable if the entity has READ or READWRITE privilege', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [
        { entityType: 'modelJob', privileges: [EntityAccessPrivilege.Read] },
        { entityType: 'user', privileges: [EntityAccessPrivilege.ReadWrite] },
      ],
    });

    expect(entityAccessesEntity.isEntityReadable('modelJob')).toBe(true);
    expect(entityAccessesEntity.isEntityReadable('user')).toBe(true);
  });

  it('should return false for isEntityReadable if the entity has NONE privilege or no privileges', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [
        { entityType: 'modelJob', privileges: [EntityAccessPrivilege.None] },
        { entityType: 'user', privileges: [] },
      ],
    });

    expect(entityAccessesEntity.isEntityReadable('modelJob')).toBe(false);
    expect(entityAccessesEntity.isEntityReadable('user')).toBe(false);
  });

  it('should return true for isEntityWritable if the entity has READWRITE privilege', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [{ entityType: 'modelJob', privileges: [EntityAccessPrivilege.ReadWrite] }],
    });

    expect(entityAccessesEntity.isEntityWritable('modelJob')).toBe(true);
  });

  it('should return false for isEntityWritable if the entity does not have READWRITE privilege', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [
        { entityType: 'modelJob', privileges: [EntityAccessPrivilege.Read] },
        { entityType: 'user', privileges: [EntityAccessPrivilege.None] },
      ],
    });

    expect(entityAccessesEntity.isEntityWritable('modelJob')).toBe(false);
    expect(entityAccessesEntity.isEntityWritable('user')).toBe(false);
  });

  it('should return true for isEntityAccessible if the entity has READ or READWRITE privilege', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [
        { entityType: 'modelJob', privileges: [EntityAccessPrivilege.Read] },
        { entityType: 'user', privileges: [EntityAccessPrivilege.ReadWrite] },
      ],
    });

    expect(entityAccessesEntity.isEntityAccessible('modelJob')).toBe(true);
    expect(entityAccessesEntity.isEntityAccessible('user')).toBe(true);
  });

  it('should return false for isEntityAccessible if the entity has NONE privilege or no privileges', () => {
    const entityAccessesEntity = new EntityAccessesEntity({
      entityAccesses: [
        { entityType: 'modelJob', privileges: [EntityAccessPrivilege.None] },
        { entityType: 'user', privileges: [] },
      ],
    });

    expect(entityAccessesEntity.isEntityAccessible('modelJob')).toBe(false);
    expect(entityAccessesEntity.isEntityAccessible('user')).toBe(false);
  });
});
