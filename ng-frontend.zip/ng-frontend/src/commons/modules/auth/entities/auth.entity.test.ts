import { Auth } from './auth.entity';

describe('Auth Class', () => {
  test('should initialize with default values', () => {
    const auth = new Auth();
    expect(auth.userName).toBe('');
    expect(auth.token).toBe('');
    expect(auth.tenantId).toBe('');
  });

  test('should initialize with provided values', () => {
    const auth = new Auth({ userName: 'John Doe', token: 'abc123', tenantId: 'tenant1' });
    expect(auth.userName).toBe('John Doe');
    expect(auth.token).toBe('abc123');
    expect(auth.tenantId).toBe('tenant1');
  });

  test('should return initials for full name', () => {
    const auth = new Auth({ userName: 'John Doe' });
    expect(auth.initial).toBe('J D');
  });

  test('should return first initial for single name', () => {
    const auth = new Auth({ userName: 'John' });
    expect(auth.initial).toBe('J');
  });

  test('should return empty string when userName is empty', () => {
    const auth = new Auth({ userName: '' });
    expect(auth.initial).toBe('');
  });

  test('should handle multiple spaces correctly', () => {
    const auth = new Auth({ userName: ' John   Doe  ' });
    expect(auth.initial).toBe('J D');
  });

  test('should handle edge cases for initials', () => {
    const auth = new Auth({ userName: 'A B C' });
    expect(auth.initial).toBe('A B');
  });
});
