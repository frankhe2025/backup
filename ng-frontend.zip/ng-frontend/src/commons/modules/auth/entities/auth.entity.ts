export class Auth {
  userName = '';
  token = '';
  tenantId = '';
  userId = '';
  tenantName = '';

  get initial() {
    const names = this.userName?.trim()?.replace(/\s+/g, ' ')?.split(' ');
    return names?.length > 1
      ? `${names?.[0]?.trim()?.charAt(0)} ${names?.[1]?.trim()?.charAt(0)}`
      : names?.[0]?.trim()?.charAt(0) || '';
  }

  constructor(obj: any = null) {
    if (obj) {
      this.userName = obj.userName || '';
      this.token = obj.token || '';
      this.tenantId = obj.tenantId || '';
      this.userId = obj.userId || '';
      this.tenantName = obj.tenantName || '';
    }
  }
}
