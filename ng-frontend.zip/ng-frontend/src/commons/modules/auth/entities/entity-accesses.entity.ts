import { EntityAccess } from './entity-access.entity.ts';
import { mapper } from '../service/path-entity-mapper.ts';

export enum EntityAccessPrivilege {
  Read = 'READ',
  ReadWrite = 'ReadWrite',
  None = 'None',
}

export class EntityAccessesEntity {
  entityAccesses: EntityAccess[];
  admin: boolean;
  constructor(data: any = null) {
    this.entityAccesses = [];
    this.admin = false;
    if (data) {
      if ('admin' in data) {
        this.admin = data.admin;
      }
      const dataList = data.privileges || data.entityAccesses;

      dataList.forEach((entityAccesse: any) => {
        this.entityAccesses.push(new EntityAccess(entityAccesse));
      });
    }
  }

  // this function is to check user's accessibility to a path
  // we neeed to make sure none of the entityType listed in the path-entity-mapper has None privilege
  havingAccessToPage(pathName: string): boolean {
    const mappedEntities = Object.keys(mapper).find((key) => pathName.toLowerCase().includes(key.toLowerCase()))?.length
      ? mapper[pathName.split('/')[0].toLowerCase()]
      : null;
    if (!mappedEntities) {
      return false; // If no mapping exists for the path, assume access is allowed
    }

    for (const entityType of mappedEntities) {
      const entityAccess = this.entityAccesses.find((access) => access.entityType === entityType);

      if (!entityAccess) {
        // if there is no entityAccess for the entityType, we assume it has no access
        return false;
      }

      // if there is no privilege for the entityType, we assume it has no access
      if (
        entityAccess &&
        (entityAccess.privileges.includes(EntityAccessPrivilege.None) || entityAccess.privileges.length === 0)
      ) {
        return false; // Deny access if any entityType has 'None' privilege
      }
    }

    return true; // Allow access if no restrictions are found
  }

  isEntityReadable(entityType: string): boolean {
    const entityAccess = this.entityAccesses.find((access) => access.entityType === entityType);
    return entityAccess ? entityAccess.isReadable() : false;
  }
  isEntityWritable(entityType: string): boolean {
    const entityAccess = this.entityAccesses.find((access) => access.entityType === entityType);
    return entityAccess ? entityAccess.isWritable() : false;
  }
  isEntityAccessible(entityType: string): boolean {
    const entityAccess = this.entityAccesses.find((access) => access.entityType === entityType);
    return entityAccess ? entityAccess.isAccessible() : false;
  }
}
