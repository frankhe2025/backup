export enum EntityAccessPrivileges {
  READ = 'READ',
  READWRITE = 'READWRITE',
  NONE = 'NONE',
}
export class EntityAccess {
  entityType: string;
  entityTypeLabel: string;
  privileges: string[];
  defaultPrivilege: any;
  description: string;
  constructor(data: any = null) {
    this.entityType = data?.entityType ?? '';
    this.entityTypeLabel = data?.entityTypeLabel ?? '';
    this.privileges = data?.privileges || [];
    this.defaultPrivilege = data?.defaultPrivilege ?? null;
    this.description = data?.description ?? '';
    this.normalizePrivileges();
  }
  normalizePrivileges(): void {
    if (this.privileges.length > 0) {
      const privileges: string[] = [];
      this.privileges.forEach((privilege) => {
        if (privilege.toLowerCase() === 'read') {
          privileges.push(EntityAccessPrivileges.READ);
        } else if (privilege.toLowerCase() === 'none') {
          privileges.push(EntityAccessPrivileges.NONE);
        } else if (privilege.toLowerCase() === 'readwrite') {
          privileges.push(EntityAccessPrivileges.READWRITE);
        }
      });
      this.privileges = privileges;
    }
  }
  isReadable(): boolean {
    return (
      this.privileges.includes(EntityAccessPrivileges.READ) ||
      this.privileges.includes(EntityAccessPrivileges.READWRITE)
    );
  }
  isWritable(): boolean {
    return this.privileges.includes(EntityAccessPrivileges.READWRITE);
  }
  isAccessible(): boolean {
    return this.isReadable() || this.isWritable();
  }
}
