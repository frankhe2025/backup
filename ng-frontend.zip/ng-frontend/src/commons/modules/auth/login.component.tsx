import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Input, Button, Alert, Card, CardHeader, CardBody } from '@aisera-ui/react';
import { useLogin } from './login.hook';
import getRegistrationService from '../connector-server/services/registration.service';
import { ILogin } from './login.interface';
import { useNavigate } from 'react-router';
import { useNgTransaltion } from '../../../i18n/hooks/translation.hook';
import { SSOButtons } from './sso-buttons';
import { Icon } from '@iconify/react';
import getSocketService from '../../services/socket.service.ts';

export const Login = () => {
  const navigate = useNavigate();
  const { _t } = useNgTransaltion();
  const [tenantId, setTenantId] = React.useState<string>('');
  const { loginSuccess, setLoginSuccess, handler, isLoading } = useLogin();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoginSuccess(null);

    const data = {
      ...Object.fromEntries(new FormData(e.currentTarget)),
      tenantId,
    } as ILogin;

    handler.login(data);
  };

  const getTenantId = async () => {
    setTenantId(await getRegistrationService().getCurrentTenantId());
  };

  useEffect(() => {
    if (loginSuccess) {
      //After login, we need to register the socket here
      getSocketService()
        .subscribeNotification()
        .then((data: any) => {
          console.log('data: ', data);
          navigate('/prompts');
        });
    }
  }, [loginSuccess, navigate]);

  useEffect(() => {
    getTenantId();
  }, [navigate]);

  return (
    <div className='min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-content2 p-4'>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className='w-full max-w-md'>
        <Card className='shadow-lg border border-content2 overflow-hidden'>
          <div className='absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-bl-full -z-10'></div>
          <div className='absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-primary/10 to-secondary/10 rounded-tr-full -z-10'></div>

          <CardHeader className='flex flex-col gap-1 pb-0 pt-8'>
            <img src='/assets/logo.png' style={{ width: 200 }} className='mb-2' />
            <p className='text-default-500 text-small text-center'>Sign in to continue to your workspace</p>
          </CardHeader>

          <CardBody className='px-8 py-6 space-y-8'>
            <form onSubmit={handleSubmit} className='space-y-5'>
              {loginSuccess === false && (
                <div key={'danger'} className='w-full block w-100 mb-2'>
                  <Alert
                    color={'danger'}
                    title={_t('INVALID-CREDENTIALS', {
                      ns: 'Common',
                      defaultValue: 'invalid username or password',
                    })}
                  />
                </div>
              )}
              <Input
                label={_t('USERNAME', { ns: 'Common', defaultValue: 'Username' })}
                type='text'
                name='email'
                placeholder={_t('ENTER-USERNAME', { ns: 'Common', defaultValue: 'Enter your username' })}
                isRequired
                errorMessage={_t('ERROR-USERNAME', { ns: 'Common', defaultValue: 'Please enter a Username' })}
                variant='bordered'
                radius='sm'
                classNames={{
                  inputWrapper: 'border-content3 group-data-[focus=true]:border-primary',
                }}
                startContent={<Icon icon='lucide:mail' className='text-default-400' />}
              />

              <Input
                errorMessage={_t('PASSWORD-ERROR', { ns: 'Common', defaultValue: 'Please enter a password' })}
                label={_t('PASSWORD', { ns: 'Common', defaultValue: 'Password' })}
                type='password'
                name='password'
                placeholder={_t('ENTER-PASSWORD', { ns: 'Common', defaultValue: 'Enter your password' })}
                isRequired
                variant='bordered'
                radius='sm'
                classNames={{
                  inputWrapper: 'border-content3 group-data-[focus=true]:border-primary',
                }}
                startContent={<Icon icon='lucide:lock' className='text-default-400' />}
              />

              <Button
                type='submit'
                color='primary'
                fullWidth
                isLoading={isLoading}
                className='mt-2 font-medium shadow-sm'
                radius='sm'>
                {_t('Login', { ns: 'Common', defaultValue: 'Sign In' })}
              </Button>
            </form>

            <div className='relative flex items-center'>
              <div className='flex-grow border-t border-default-200'></div>
              <span className='mx-2 text-tiny text-default-400'>OR</span>
              <div className='flex-grow border-t border-default-200'></div>
            </div>

            <SSOButtons tenantId={tenantId} />
          </CardBody>
        </Card>
      </motion.div>
    </div>
  );
};
