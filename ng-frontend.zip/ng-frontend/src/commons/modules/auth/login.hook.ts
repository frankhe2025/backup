import { useState } from 'react';
import { ILogin } from './login.interface';
import { LoginService } from './service/login.service';

export function useLogin() {
  const [loginSuccess, setLoginSuccess] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const handler = {
    login: async (formData: ILogin) => {
      setIsLoading(true);
      const success: boolean = await new LoginService().login(formData);
      setLoginSuccess(success);
      setIsLoading(false);
    },
  };
  return { loginSuccess, setLoginSuccess, handler, isLoading };
}
