import React from 'react';
import { Button } from '@aisera-ui/react';
import { Icon } from '@iconify/react';
import config from '../../config/config';

interface SSOButtonsProps {
  tenantId?: string;
}

export const SSOButtons: React.FC<SSOButtonsProps> = ({ tenantId }) => {
  const handleCompanySSO = () => {
    document.location.href = `${config.BACKEND_HOST_URL}auth/sso/login?tenantId=${tenantId}`;
  };

  return (
    <div className='space-y-4'>
      <Button
        fullWidth
        variant='bordered'
        radius='sm'
        className='h-12 border-content3 hover:bg-content2/50'
        startContent={
          <div className='bg-primary/10 p-1.5 rounded-full'>
            <Icon icon='lucide:briefcase' className='text-primary' />
          </div>
        }
        onPress={handleCompanySSO}>
        <span className='font-medium'>Sign in with Company SSO</span>
      </Button>
    </div>
  );
};
