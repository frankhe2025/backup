import { RegistrationInterface } from './registration.interface';
import { Registration } from '../entities/registration';
import callApi, { REQUEST_METHOD } from '../../../utils/fetcher.util';
import getAuthService from '../../auth/service/auth.service';

export class RegistrationService implements RegistrationInterface {
  registration: Registration | null = null;
  async getRegistrationFromCurrentUrl(): Promise<Registration | null> {
    if (window?.location?.hostname) {
      const url = 'connector-server/v1/registrations/url/' + window.location.hostname;
      // const url = 'connector-server/v1/registrations/url/dev4-1000.login.aws-006-us-west-2.aisera.cloud';
      const data = await callApi({
        url,
        method: REQUEST_METHOD.GET,
        headers: {
          jwt: getAuthService().getAuthToken(),
        },
      });
      return new Registration(data.resp);
    } else {
      return null;
    }
  }

  async getCurrentTenantId() {
    if (!this.registration) {
      this.registration = await this.getRegistrationFromCurrentUrl();
    }
    return this.registration?.tenantId || '10000'; // return default 100000
  }
}

let registrationServiceInstance: RegistrationService | null = null;

const getRegistrationService = () => {
  if (!registrationServiceInstance) {
    registrationServiceInstance = new RegistrationService();
  }
  return registrationServiceInstance;
};

export default getRegistrationService;
