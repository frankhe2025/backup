import { Registration } from '../entities/registration';

export interface RegistrationInterface {
  getRegistrationFromCurrentUrl(): Promise<Registration | null>;
}
