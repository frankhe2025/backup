export class Registration {
  tenantId: string = '';
  tenantName: string = '';
  status: string = '';
  createdAt: Date | null = null;
  updatedAt: Date | null = null;
  tenantEmail: string = '';

  constructor(data: any) {
    Object.keys(data).forEach((key) => {
      if (key === 'createdAt' || key === 'updatedAt') {
        (this as any)[key] = new Date(data[key]);
      } else {
        (this as any)[key] = data[key];
      }
    });
  }
}
