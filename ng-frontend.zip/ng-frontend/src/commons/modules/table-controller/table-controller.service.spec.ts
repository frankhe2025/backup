import { TableControllerService } from './table-controller.service';
import { TableConfigEntityType } from './table-controller-service-factory';
import callApi, { REQUEST_METHOD } from '../../utils/fetcher.util';
import { SavedTableConfig } from './entities/saved-table-config';
import { SavedTableConfigs } from './entities/saved-table-configs';
import { EntityFilter } from './entities/entity-filter';
import { EntityFilters } from './entities/entity-filters';

// Mock the dependencies
jest.mock('../../utils/fetcher.util');
jest.mock('./entities/saved-table-config');
jest.mock('./entities/saved-table-configs');
jest.mock('./entities/entity-filter');
jest.mock('./entities/entity-filters');

describe('TableControllerService', () => {
  let service: TableControllerService;
  const mockType = 'test-type';
  const mockEntityType = TableConfigEntityType.NG_PROMPT_LIST;

  beforeEach(() => {
    // Reset all mocks
    jest.clearAllMocks();

    // Create a new instance of the service
    service = new TableControllerService();

    // Mock the callApi function
    (callApi as jest.Mock).mockImplementation(async () => {
      return { resp: [] };
    });

    // Mock the EntityFilters constructor and generateSavedTableConfigs method
    (EntityFilters as jest.Mock).mockImplementation(() => {
      return {
        generateSavedTableConfigs: jest.fn().mockReturnValue(new SavedTableConfigs()),
      };
    });

    // Mock the SavedTableConfig constructor and generateEntityFilter method
    (SavedTableConfig as jest.Mock).mockImplementation(() => {
      return {
        generateEntityFilter: jest.fn().mockReturnValue(new EntityFilter()),
      };
    });

    // Mock the SavedTableConfigs constructor and generateEntityFilters method
    (SavedTableConfigs as jest.Mock).mockImplementation(() => {
      return {
        generateEntityFilters: jest.fn().mockReturnValue([]),
      };
    });

    // Mock the EntityFilter constructor
    (EntityFilter as jest.Mock).mockImplementation(() => {
      return {};
    });
  });

  describe('getSavedTableConfigsForType', () => {
    it('should call _getEntityFilters with the correct type and return the result', async () => {
      // Arrange
      const mockEntityFilters = [{ id: 1, name: 'Filter 1' }];
      (callApi as jest.Mock).mockResolvedValueOnce({ resp: mockEntityFilters });

      // Act
      const result = await service.getSavedTableConfigsForType(mockType);

      // Assert
      expect(callApi).toHaveBeenCalledWith(
        {
          url: `entity-filter/${mockEntityType}`,
          method: REQUEST_METHOD.GET,
        },
        false,
      );
      expect(EntityFilters).toHaveBeenCalledWith(mockEntityFilters);
      expect(result).toBeDefined();
    });
  });

  describe('saveNewTableConfig', () => {
    it('should convert table config to entity filter and call API', async () => {
      // Arrange
      const mockConfig = { name: 'New Config' };
      const mockEntityFilter = { id: 1, name: 'Entity Filter' };
      const mockResponse = { resp: mockEntityFilter };

      (SavedTableConfig as jest.Mock).mockImplementation(() => {
        return {
          generateEntityFilter: jest.fn().mockReturnValue(mockEntityFilter),
        };
      });

      (callApi as jest.Mock).mockResolvedValueOnce(mockResponse);

      // Act
      const result = await service.saveNewTableConfig(mockType, mockConfig);

      // Assert
      expect(SavedTableConfig).toHaveBeenCalledWith(mockConfig);
      expect(callApi).toHaveBeenCalledWith({
        url: `entity-filter/${mockEntityType}`,
        method: REQUEST_METHOD.POST,
        data: mockEntityFilter,
      });
      expect(EntityFilter).toHaveBeenCalledWith(mockResponse.resp);
      expect(result).toBeDefined();
    });
  });

  describe('saveUpdatedTableConfigs', () => {
    it('should update existing configs and delete removed ones', async () => {
      // Arrange
      const mockConfigs = [{ id: 1, name: 'Config 1' }];
      const mockEntityFilters = [
        { id: 1, name: 'Entity Filter 1' },
        { id: 2, name: 'Entity Filter 2' },
      ];
      const mockExistingFilters = [
        { id: 1, name: 'Existing Filter 1' },
        { id: 2, name: 'Existing Filter 2' },
        { id: 3, name: 'Existing Filter 3' },
      ];

      (SavedTableConfigs as jest.Mock).mockImplementation(() => {
        return {
          generateEntityFilters: jest.fn().mockReturnValue(mockEntityFilters),
        };
      });

      (callApi as jest.Mock)
        .mockResolvedValueOnce({ resp: mockExistingFilters }) // For _getEntityFilters
        .mockResolvedValueOnce({ resp: [] }) // For update
        .mockResolvedValueOnce({ resp: [] }); // For delete

      // Act
      await service.saveUpdatedTableConfigs(mockType, mockConfigs);

      // Assert
      expect(SavedTableConfigs).toHaveBeenCalledWith(mockConfigs);
      expect(callApi).toHaveBeenCalledWith(
        {
          url: `entity-filter/${mockEntityType}`,
          method: REQUEST_METHOD.GET,
        },
        false,
      );
      expect(callApi).toHaveBeenCalledWith({
        url: `entity-filter/${mockEntityType}`,
        method: REQUEST_METHOD.PUT,
        data: mockEntityFilters,
      });
      expect(callApi).toHaveBeenCalledWith({
        url: `entity-filter/${mockEntityType}/3`,
        method: REQUEST_METHOD.DELETE,
      });
    });
  });

  describe('_getEntityFilters', () => {
    it('should call API with correct parameters', async () => {
      // Arrange
      const mockResponse = { resp: [{ id: 1, name: 'Filter 1' }] };
      (callApi as jest.Mock).mockResolvedValueOnce(mockResponse);

      // Act
      const result = await (service as any)._getEntityFilters(mockType);

      // Assert
      expect(callApi).toHaveBeenCalledWith(
        {
          url: `entity-filter/${mockEntityType}`,
          method: REQUEST_METHOD.GET,
        },
        false,
      );
      expect(result).toEqual(mockResponse.resp);
    });
  });
});
