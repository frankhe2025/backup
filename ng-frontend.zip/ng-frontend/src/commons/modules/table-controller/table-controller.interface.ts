export interface TableControllerInterface {
  getSavedTableConfigsForType(type: string);
  saveNewTableConfig(type: string, tableConfig: any);
  saveUpdatedTableConfigs(type: string, tableConfigs: any);
}
