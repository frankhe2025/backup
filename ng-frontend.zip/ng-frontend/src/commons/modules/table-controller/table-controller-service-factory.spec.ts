import { TableControllerService } from './table-controller.service';
import { TableControllerServiceMock } from './mocks/table-controller.service.mock';
import getTableControllerServiceInstance, { TableConfigEntityType } from './table-controller-service-factory';
import config from '../../config/config';

// Mock the config module
jest.mock('../../config/config', () => ({
  __esModule: true,
  default: {
    usingMock: false,
  },
}));

describe('Table Controller Service Factory', () => {
  let originalConfig: any;

  beforeEach(() => {
    // Save original config
    originalConfig = { ...config };
    // Reset mocks
    jest.clearAllMocks();
  });

  afterEach(() => {
    // Restore original config
    Object.assign(config, originalConfig);
  });

  describe('getTableControllerServiceInstance', () => {
    it('should return TableControllerService instance when usingMock is false', () => {
      // Arrange
      config.usingMock = false;

      // Act
      const service = getTableControllerServiceInstance();

      // Assert
      expect(service).toBeInstanceOf(TableControllerService);
    });

    it('should return TableControllerServiceMock instance when usingMock is true', () => {
      // Arrange
      config.usingMock = true;

      // Act
      const service = getTableControllerServiceInstance();

      // Assert
      expect(service).toBeInstanceOf(TableControllerServiceMock);
    });

    it('should return the same instance when called multiple times with the same config', () => {
      // Arrange
      config.usingMock = false;

      // Act
      const service1 = getTableControllerServiceInstance();
      const service2 = getTableControllerServiceInstance();

      // Assert
      expect(service1).toBe(service2);
    });

    it('should return a new instance when config changes', () => {
      // Arrange
      config.usingMock = false;
      const service1 = getTableControllerServiceInstance();

      // Act
      config.usingMock = true;
      const service2 = getTableControllerServiceInstance();

      // Assert
      expect(service1).not.toBe(service2);
      expect(service2).toBeInstanceOf(TableControllerServiceMock);
    });
  });

  describe('TableConfigEntityType enum', () => {
    it('should have NG_PROMPT_LIST defined', () => {
      expect(TableConfigEntityType.NG_PROMPT_LIST).toBe('NG_PROMPT_LIST');
    });
  });
});
