import { TableControllerInterface } from './table-controller.interface.ts';
import { TableConfigEntityType } from './table-controller-service-factory.ts';
import callApi, { REQUEST_METHOD } from '../../utils/fetcher.util.ts';
import { SavedTableConfig } from './entities/saved-table-config.ts';
import { EntityFilters } from './entities/entity-filters.ts';
import { EntityFilter } from './entities/entity-filter.ts';
import { SavedTableConfigs } from './entities/saved-table-configs.ts';

export class TableControllerService implements TableControllerInterface {
  async getSavedTableConfigsForType(type: string) {
    // returned value is Entity Filter Schema, we must conver it into table config format
    return new EntityFilters(await this._getEntityFilters(type)).generateSavedTableConfigs();
  }

  async saveNewTableConfig(type: string, cfg: any) {
    const tableConfig: SavedTableConfig = new SavedTableConfig(cfg);
    // API is expecting Entity Filter format, we have to convert Table Config into Entity Filter format
    const entityFilter: EntityFilter = tableConfig.generateEntityFilter(type, true);
    const path = 'entity-filter/' + TableConfigEntityType.NG_PROMPT_LIST;
    const response = await callApi({
      url: path,
      method: REQUEST_METHOD.POST,
      data: entityFilter,
    });
    return new EntityFilter(response.resp);
  }

  async saveUpdatedTableConfigs(type: string, cfg: any) {
    const tableConfigs: SavedTableConfigs = new SavedTableConfigs(cfg);
    const entityFilters: EntityFilter[] = tableConfigs.generateEntityFilters(type);

    // now we need to delete as well
    const entityFiltersData = await this._getEntityFilters(type);
    const totalIds = entityFiltersData.map((item) => item.id);
    const entityFilterIds = entityFilters.map((filter) => filter.id);
    const idsToDelete = totalIds.filter((id) => !entityFilterIds.includes(id));

    // Update
    const updatePath = 'entity-filter/' + TableConfigEntityType.NG_PROMPT_LIST;
    const updatePromise = callApi({
      url: updatePath,
      method: REQUEST_METHOD.PUT,
      data: entityFilters,
    });

    const deletePath = 'entity-filter/' + TableConfigEntityType.NG_PROMPT_LIST + '/' + idsToDelete.join(',');
    const deletePromise = callApi({
      url: deletePath,
      method: REQUEST_METHOD.DELETE,
    });

    Promise.all([updatePromise, deletePromise]);
  }

  private entityFiltersCache = new Map();
  private cacheTTL = 30000;

  async _getEntityFilters(_type: string) {
    const path = 'entity-filter/' + TableConfigEntityType.NG_PROMPT_LIST;
    const cacheKey = path;

    const cachedData = this.entityFiltersCache.get(cacheKey);
    if (cachedData && Date.now() - cachedData.timestamp < this.cacheTTL) {
      return cachedData.data;
    }

    const response = await callApi(
      {
        url: path,
        method: REQUEST_METHOD.GET,
      },
      false,
    );

    this.entityFiltersCache.set(cacheKey, {
      data: response.resp,
      timestamp: Date.now(),
    });

    return response.resp;
  }
}
