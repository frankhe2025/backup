import { renderHook, act } from '@testing-library/react';
import { useTableController } from './table-controller.hook';
import getTableControllerServiceInstance from './table-controller-service-factory';

// Mock the service factory
jest.mock('./table-controller-service-factory', () => ({
  __esModule: true,
  default: jest.fn(),
}));

describe('useTableController', () => {
  // Mock service instance
  const mockServiceInstance = {
    saveNewTableConfig: jest.fn(),
    saveUpdatedTableConfigs: jest.fn(),
    getSavedTableConfigsForType: jest.fn(),
  };

  beforeEach(() => {
    // Reset all mocks before each test
    jest.clearAllMocks();

    // Setup the mock service instance
    (getTableControllerServiceInstance as jest.Mock).mockReturnValue(mockServiceInstance);
  });

  it('should initialize with null savedTableConfigs', () => {
    const { result } = renderHook(() => useTableController());

    expect(result.current.savedTableConfigs).toBeNull();
  });

  it('should call saveNewTableConfig on the service', () => {
    const { result } = renderHook(() => useTableController());

    const type = 'test-type';
    const tableConfig = { id: 1, name: 'Test Config' };

    act(() => {
      result.current.tableControllerHandler.saveNewTableConfig(type, tableConfig);
    });

    expect(mockServiceInstance.saveNewTableConfig).toHaveBeenCalledWith(type, tableConfig);
  });

  it('should call saveUpdatedTableConfigs on the service', () => {
    const { result } = renderHook(() => useTableController());

    const type = 'test-type';
    const tableConfigs = [{ id: 1, name: 'Test Config' }];

    act(() => {
      result.current.tableControllerHandler.savedTableConfigUpdated(type, tableConfigs);
    });

    expect(mockServiceInstance.saveUpdatedTableConfigs).toHaveBeenCalledWith(type, tableConfigs);
  });

  it('should update savedTableConfigs when getSavedTableConfigs is called', async () => {
    const mockConfigs = [{ id: 1, name: 'Test Config' }];
    mockServiceInstance.getSavedTableConfigsForType.mockResolvedValue(mockConfigs);

    const { result } = renderHook(() => useTableController());

    act(() => {
      result.current.tableControllerHandler.getSavedTableConfigs('test-type');
    });

    // Wait for the async operation to complete
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });

    expect(mockServiceInstance.getSavedTableConfigsForType).toHaveBeenCalledWith('test-type');
    expect(result.current.savedTableConfigs).toEqual(mockConfigs);
  });
});
