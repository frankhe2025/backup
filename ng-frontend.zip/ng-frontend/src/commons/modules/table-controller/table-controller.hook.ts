import { useState, useCallback } from 'react';
import getTableControllerServiceInstance from './table-controller-service-factory.ts';

export function useTableController() {
  const [savedTableConfigs, setSavedTableConfigs] = useState(null);

  const saveNewTableConfig = useCallback((type: string, tableConfig: any) => {
    getTableControllerServiceInstance().saveNewTableConfig(type, tableConfig);
  }, []);

  const savedTableConfigUpdated = useCallback((type: string, tableConfigs: any) => {
    getTableControllerServiceInstance().saveUpdatedTableConfigs(type, tableConfigs);
  }, []);

  const getSavedTableConfigs = useCallback(async (type: string) => {
    setSavedTableConfigs(await getTableControllerServiceInstance().getSavedTableConfigsForType(type));
  }, []);

  const tableControllerHandler = {
    saveNewTableConfig,
    savedTableConfigUpdated,
    getSavedTableConfigs,
  };

  return { savedTableConfigs, tableControllerHandler };
}
