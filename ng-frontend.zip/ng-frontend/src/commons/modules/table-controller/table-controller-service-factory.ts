import config from '../../config/config.ts';
import { TableControllerServiceMock } from './mocks/table-controller.service.mock.ts';
import { TableControllerService } from './table-controller.service.ts';

const SERVICE_REGISTRY: any = {
  TABLE_CONFIG: {},
};
export enum TableConfigEntityType {
  NG_PROMPT_LIST = 'NG_PROMPT_LIST',
}
const getTableControllerServiceInstance = () => {
  if (config.usingMock) {
    if (!(config.usingMock in SERVICE_REGISTRY['TABLE_CONFIG'])) {
      SERVICE_REGISTRY['TABLE_CONFIG'][config.usingMock] = new TableControllerServiceMock();
    }
  } else {
    if (!(config.usingMock in SERVICE_REGISTRY['TABLE_CONFIG'])) {
      SERVICE_REGISTRY['TABLE_CONFIG'][config.usingMock] = new TableControllerService();
    }
  }

  return SERVICE_REGISTRY['TABLE_CONFIG'][config.usingMock];
};

export default getTableControllerServiceInstance;
