import { TableControllerInterface } from '../table-controller.interface.ts';

export class TableControllerServiceMock implements TableControllerInterface {
  getSavedTableConfigsForType(_type: string) {
    return new Promise((resolve) => {
      resolve([]);
    });
  }

  saveNewTableConfig(_type: string, _tableConfig: any) {}

  saveUpdatedTableConfigs(_type: string, _tableConfigs: any) {}
}
