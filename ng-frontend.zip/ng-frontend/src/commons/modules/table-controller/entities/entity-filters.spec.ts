import { EntityFilters } from './entity-filters.ts';
import { SavedTableConfigs } from './saved-table-configs.ts';

describe('EntityFilters', () => {
  const data = [
    {
      id: 83,
      name: 'frank1',
      entityType: 'NG_PROMPT_LIST',
      criteria:
        '{"id":"","savedFilter":{"name":"frank1","scope":"private","finalFilters":{"finalFilters":[{"key":"GLOBAL_SEARCH_KEY","operand":"Like","value":"test123"}]}},"columns":["name","source","type","scope","model","status","updatedAt","updatedByEmail"],"sortBy":"","asc":true,"columnOrder":["name","sourceType","type","scope","model","status","updatedAt","updatedByEmail","isDraft"],"sortOrder":[]}',
      userId: '-1254269206384808175',
      sysUpdatedAt: '2025-04-20T02:29:19.000Z',
      isPublic: false,
    },
    {
      id: 84,
      name: 'Frank 2',
      entityType: 'NG_PROMPT_LIST',
      criteria:
        '{"id":"","savedFilter":{"name":"Frank 2","scope":"public","finalFilters":{"finalFilters":[{"key":"GLOBAL_SEARCH_KEY","operand":"Like","value":"tasfadfasfewr"},{"key":"name","operand":"Like","value":"frank1234"},{"key":"sourceType","operand":"Include","value":["System"]}]}},"columns":["name","source","type","scope","model","status","updatedAt","updatedByEmail"],"sortBy":"","asc":true,"columnOrder":["name","sourceType","type","scope","model","status","updatedAt","updatedByEmail","isDraft"],"sortOrder":[]}',
      sysUpdatedAt: '2025-04-20T03:01:14.000Z',
      isPublic: true,
    },
  ];
  it('constructs', () => {
    let entityFilters = new EntityFilters(data);
    expect(entityFilters.entityFilters.length).toBe(2);
    expect(entityFilters.entityFilters[0].id).toEqual(83);
    expect(entityFilters.entityFilters[0].userId).toEqual('-1254269206384808175');
    expect(entityFilters.entityFilters[1].userId).toEqual('');

    entityFilters = new EntityFilters(entityFilters.entityFilters);
    expect(entityFilters.entityFilters.length).toBe(2);
    expect(entityFilters.entityFilters[0].id).toEqual(83);
    expect(entityFilters.entityFilters[0].userId).toEqual('-1254269206384808175');
    expect(entityFilters.entityFilters[1].userId).toEqual('');
  });
  it('generateSavedTableConfigs()', () => {
    const entityFilters = new EntityFilters(data);
    const savedTableConfigs: SavedTableConfigs = entityFilters.generateSavedTableConfigs();
    expect(savedTableConfigs.savedTableConfigs.length).toBe(2);
    expect(savedTableConfigs.savedTableConfigs[0].id).toBe(83);
    expect(savedTableConfigs.savedTableConfigs[0].userId).toBe('-1254269206384808175');
    expect(savedTableConfigs.savedTableConfigs[1].userId).toBe('');
    expect(savedTableConfigs.savedTableConfigs[0].savedFilter.name).toBe('frank1');
  });
});
