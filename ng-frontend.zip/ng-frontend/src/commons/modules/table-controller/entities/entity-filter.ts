export class EntityFilter {
  id: number;
  name: string;
  entityType: string;
  criteria: string;
  isPublic: boolean;
  userId: string;

  constructor(data: any = null) {
    this.id = 0;
    this.name = '';
    this.entityType = '';
    this.criteria = '';
    this.isPublic = false;
    this.userId = '';

    if (data) {
      if (data.id) this.id = data.id;
      this.name = data.name;
      this.entityType = data.entityType;
      this.criteria = data.criteria;
      this.isPublic = data.isPublic;
      this.userId = data.userId || '';
    }
  }
}
