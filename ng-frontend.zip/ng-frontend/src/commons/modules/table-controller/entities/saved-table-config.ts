import { EntityFilter } from './entity-filter.ts';

export class SavedTableConfig {
  id?: any;
  savedFilter?: any;
  columns?: string[];
  sortBy?: string;
  asc?: boolean;
  columnOrder?: string[];
  sortOrder?: {
    column: string;
    direction: 'asc' | 'desc' | 'none';
  }[];
  userId?: string;

  constructor(data: any = null) {
    this.id = '';
    this.savedFilter = null;
    this.columns = [];
    this.sortBy = '';
    this.asc = true;
    this.columnOrder = [];
    this.sortOrder = [];
    this.userId = '';
    if (data) {
      this.savedFilter = data?.savedFilter;
      this.columns = data?.columns;
      this.sortBy = data?.sortBy;
      this.asc = data?.asc;
      this.columnOrder = data?.columnOrder;
      this.sortOrder = data?.sortOrder;
      if (data.id) {
        this.id = data.id;
      }
      if (!this.id && data.savedFilter.id) {
        this.id = data.savedFilter.id;
      }
      if (data.userId) {
        this.userId = data.userId;
      }
    }
  }

  // this is to convert backend recognized format
  generateEntityFilter(entityType: string, deleteId = true) {
    const entityFilter = new EntityFilter();
    if (deleteId) {
      delete entityFilter.id;
    } else {
      entityFilter.id = this.id;
    }
    entityFilter.name = this.savedFilter?.name;
    entityFilter.entityType = entityType;
    entityFilter.criteria = JSON.stringify(this);
    entityFilter.isPublic = this.savedFilter?.scope === 'public';
    return entityFilter;
  }
}
