import { SavedTableConfig } from './saved-table-config.ts';
import { EntityFilter } from './entity-filter.ts';

export class SavedTableConfigs {
  savedTableConfigs: SavedTableConfig[];
  constructor(data: any = null) {
    this.savedTableConfigs = [];
    if (data) {
      if (Array.isArray(data)) {
        data.forEach((item) => {
          this.savedTableConfigs.push(new SavedTableConfig(item));
        });
      } else if (Array.isArray(data.savedTableConfigs)) {
        data.savedTableConfigs.forEach((item) => {
          this.savedTableConfigs.push(new SavedTableConfig(item));
        });
      }
    }
  }

  generateEntityFilters(type) {
    const entityFilters: EntityFilter[] = [];
    this.savedTableConfigs.forEach((savedTableConfig) => {
      // here, we need to keep id so that backend can update
      entityFilters.push(savedTableConfig.generateEntityFilter(type, false));
    });
    return entityFilters;
  }
}
