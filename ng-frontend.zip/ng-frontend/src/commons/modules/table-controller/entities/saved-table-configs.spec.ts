import { SavedTableConfigs } from './saved-table-configs.ts';

describe('SavedTableConfigs', () => {
  const data = [
    {
      id: '',
      savedFilter: {
        id: 83,
        name: 'frank1',
        scope: 'private',
        finalFilters: {
          finalFilters: [
            {
              key: 'GLOBAL_SEARCH_KEY',
              operand: 'Like',
              value: 'test123',
            },
          ],
        },
      },
      columns: [],
      sortBy: '',
      asc: true,
      columnOrder: [],
      sortOrder: [],
    },
    {
      id: '',
      savedFilter: {
        id: 84,
        name: 'Frank 2',
        scope: 'public',
        finalFilters: {
          finalFilters: [
            {
              key: 'GLOBAL_SEARCH_KEY',
              operand: 'Like',
              value: 'tasfadfasfewr',
            },
            {
              key: 'name',
              operand: 'Like',
              value: 'frank1234',
            },
            {
              key: 'sourceType',
              operand: 'Include',
              value: ['System'],
            },
          ],
        },
      },
      columns: [],
      sortBy: '',
      asc: true,
      columnOrder: [],
      sortOrder: [],
    },
  ];

  it('constructor', () => {
    const savedTableConfigs: SavedTableConfigs = new SavedTableConfigs(data);
    expect(savedTableConfigs.savedTableConfigs.length).toBe(2);
    expect(savedTableConfigs.savedTableConfigs[0].id).toBe(83);

    const newObj: SavedTableConfigs = new SavedTableConfigs(savedTableConfigs);
    expect(newObj.savedTableConfigs.length).toBe(2);
    expect(newObj.savedTableConfigs[0].id).toBe(83);
  });

  it('generateEntityFilters()', () => {
    const savedTableConfigs: SavedTableConfigs = new SavedTableConfigs(data);
    const entityFilters = savedTableConfigs.generateEntityFilters('MyTYPE');
    expect(entityFilters.length).toBe(2);
    expect(entityFilters[0].id).toBe(83);
    expect(entityFilters[0].entityType).toBe('MyTYPE');
  });
});
