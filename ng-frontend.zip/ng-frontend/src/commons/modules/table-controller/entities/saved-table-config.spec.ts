import { SavedTableConfig } from './saved-table-config.ts';

describe('SavedTableConfig', () => {
  const data = {
    savedFilter: {
      name: 'frank3',
      scope: 'public',
      finalFilters: {
        finalFilters: [
          {
            key: 'GLOBAL_SEARCH_KEY',
            operand: 'Like',
            value: 'teast123',
          },
          {
            key: 'name',
            operand: 'Like',
            value: 'tasdfasdf',
          },
        ],
      },
    },
    columns: ['name', 'source', 'type', 'scope', 'model', 'status', 'updatedAt', 'updatedByEmail'],
    sortBy: '',
    asc: true,
    columnOrder: ['name', 'sourceType', 'type', 'scope', 'model', 'status', 'updatedAt', 'updatedByEmail', 'isDraft'],
    sortOrder: [],
  };

  it('constructor()', () => {
    let obj = new SavedTableConfig();
    expect(obj).toBeTruthy();
    expect(obj.savedFilter === null).toBeTruthy();
    expect(obj.columns?.length).toEqual(0);

    obj = new SavedTableConfig(data);
    expect(obj.columns?.length).toEqual(8);
    expect(typeof obj.savedFilter).toEqual('object');
  });

  it('generateEntityFilter()', () => {
    const obj = new SavedTableConfig(data);
    const entityFitler = obj.generateEntityFilter('NG-FILTER', true);
    expect(entityFitler.name).toBe('frank3');
    expect(entityFitler.isPublic).toBe(true);
    expect(entityFitler.entityType).toBe('NG-FILTER');
    expect(entityFitler.id).toBe(undefined);
  });
});
