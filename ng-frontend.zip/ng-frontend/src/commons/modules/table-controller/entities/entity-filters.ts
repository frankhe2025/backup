import { EntityFilter } from './entity-filter.ts';
import { SavedTableConfigs } from './saved-table-configs.ts';

export class EntityFilters {
  entityFilters: EntityFilter[];
  constructor(data: any = null) {
    this.entityFilters = [];
    if (data) {
      if (Array.isArray(data)) {
        data.forEach((item) => {
          this.entityFilters.push(new EntityFilter(item));
        });
      } else if (Array.isArray(data.entityFilters)) {
        data.entityFilters.forEach((item) => {
          this.entityFilters.push(new EntityFilter(item));
        });
      }
    }
  }

  generateSavedTableConfigs() {
    const tableConfigData = [];
    this.entityFilters.forEach((entityFilter) => {
      const data = JSON.parse(entityFilter.criteria);
      if (data['id'] === '') {
        data['id'] = entityFilter.id;
      }
      data['userId'] = entityFilter.userId;
      tableConfigData.push(data);
    });

    return new SavedTableConfigs(tableConfigData);
  }
}
