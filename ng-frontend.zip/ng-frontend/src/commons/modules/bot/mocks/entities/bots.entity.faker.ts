import { generateWords } from '../../../../utils/faker.util';

export const generateBotsData = (count = 10) => {
  const res = [];
  for (let i = 1; i <= count; i++) {
    res.push({
      id: i,
      name: generateWords(3),
      tenantId: 10000,
    });
  }
  return res;
};
