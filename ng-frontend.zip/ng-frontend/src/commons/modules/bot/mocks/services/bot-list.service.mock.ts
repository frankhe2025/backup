import { Bots } from '../../bots.entity';
import { generateBotsData } from '../entities/bots.entity.faker';

export class BotListServiceMock {
  getBots(): Promise<Bots> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const data = generateBotsData(10);
        resolve(new Bots(data));
      });
    });
  }
}
