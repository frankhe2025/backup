import { Autocomplete, AutocompleteItem } from '@aisera-ui/react';
import { useBot } from './bot.hook';
import { Key, useContext, useEffect, useMemo, useCallback } from 'react';
import { AppContext } from '../../context/app-context.context';
import { Bot } from './bot.entity';

export const BotComponent = () => {
  const { bots, handler } = useBot();
  const { setSelectedBot, selectedBot } = useContext(AppContext);

  const botList = useMemo(() => bots?.getRows() || [], [bots]);

  const botSelected = useCallback(
    (key: Key | null) => {
      if (!key) return;
      const selectedBot = botList.find((b) => b.id == key);
      setSelectedBot(selectedBot);
    },
    [botList, setSelectedBot],
  );

  useEffect(() => {
    handler.list();
  }, [handler]);

  useEffect(() => {
    if (botList.length && !selectedBot?.id) {
      botSelected(botList[0].id);
    }
  }, [bots, selectedBot, botSelected, botList]);

  return (
    <Autocomplete
      selectedKey={`${selectedBot?.id}`}
      className='max-w-xs'
      label=''
      size='sm'
      onSelectionChange={botSelected}>
      {botList.map((bot: Bot) => (
        <AutocompleteItem key={bot.id}>{bot.name}</AutocompleteItem>
      ))}
    </Autocomplete>
  );
};
