import { Bot } from './bot.entity';

export class Bots {
  bots: Bot[] = [];
  constructor(items: any[]) {
    if (Array.isArray(items) && items.length > 0) {
      items.forEach((item) => {
        this.bots.push(new Bot(item));
      });
    }
  }
  getRows() {
    return this.bots;
  }
}
