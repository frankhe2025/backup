export class Bot {
  tenantId: string = '';
  createdAt: number | null = null;
  updatedAt: number | null = null;
  createdBy: string = '';
  id: number | null = null;
  name: string = '';
  description: string = '';
  userId: number | null = null;
  status: string = '';
  liveAgentSystemConfig: string = '';
  liveAgentSystemId: string = '';
  botGuid: string = '';
  config: string = '';
  numDataSources: number | null = null;
  numChannels: number | null = null;
  language: string = '';
  botType: string = '';
  compositionDefinition: string = '';
  contentUnitId: string = '';
  parentId: string = '';
  category: string = '';
  downloadContentPack: string = '';
  contentPackStatus: string = '';
  domainDisplayName: string = '';
  agentName: string = '';
  basicCompositionDefinition: string = '';

  constructor(data: any) {
    if (data) {
      Object.keys(data).forEach((key) => {
        if (key === 'createdAt' || key === 'updatedAt') {
          (this as any)[key] = new Date(data[key]).toString();
        } else {
          (this as any)[key] = data[key];
        }
      });
    }
  }
}
