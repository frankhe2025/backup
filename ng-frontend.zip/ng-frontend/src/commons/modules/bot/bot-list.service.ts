import getAuthService from '../auth/service/auth.service';
import callApi, { REQUEST_METHOD } from '../../utils/fetcher.util';
import { Bots } from './bots.entity';

export class BotListService {
  async getBots(): Promise<Bots> {
    const url = `tenant-server`;

    const obj = {
      columns: ['id', 'name'],
    };
    const data = await callApi({
      url: `${url}/v1/tenants/${getAuthService().getTenantId()}/bots/v2?query=${JSON.stringify(obj)}`,
      method: REQUEST_METHOD.GET,
    }).catch((e) => e);

    return new Bots(data.resp);
  }
}
