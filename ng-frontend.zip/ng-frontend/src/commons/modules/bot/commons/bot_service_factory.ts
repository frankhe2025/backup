import config from '../../../config/config';
import { BotListService } from '../bot-list.service';
import { BotListServiceMock } from '../mocks/services/bot-list.service.mock';

const SERVICE_REGISTRY: any = {};
export enum BOT_SERVICE_TYPES {
  BOT_LIST,
}

const getBotServiceInstance = (type: BOT_SERVICE_TYPES) => {
  if (!(type in SERVICE_REGISTRY)) {
    SERVICE_REGISTRY[type] = {};
  }
  const fkType = '' + config.usingMock;

  if (!(fkType in SERVICE_REGISTRY[type])) {
    switch (type) {
      case BOT_SERVICE_TYPES.BOT_LIST:
        SERVICE_REGISTRY[type][fkType] = config.usingMock ? new BotListServiceMock() : new BotListService();
    }
  }

  return SERVICE_REGISTRY[type][fkType];
};

export default getBotServiceInstance;
