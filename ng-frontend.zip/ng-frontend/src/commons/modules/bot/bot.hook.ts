import { useState, useCallback, useMemo } from 'react';
import getBotServiceInstance, { BOT_SERVICE_TYPES } from './commons/bot_service_factory';
import { Bots } from './bots.entity';

export const useBot = () => {
  const [bots, setBots] = useState<Bots | null>(null);
  const [hasLoaded, setHasLoaded] = useState(false);

  const list = useCallback(async () => {
    if (hasLoaded) return;

    try {
      const data: Bots = await getBotServiceInstance(BOT_SERVICE_TYPES.BOT_LIST).getBots();
      setBots(data);
      setHasLoaded(true);
    } catch (error) {
      console.error('Failed to load bots:', error);
    }
  }, [hasLoaded]);

  const handler = useMemo(
    () => ({
      list,
    }),
    [list],
  );

  return { bots, handler };
};
