import { createContext, ReactNode, useState } from 'react';
import { Bot } from '../modules/bot/bot.entity';

export interface IAppContext {
  setSelectedBot: (bot: Bot | undefined) => void;
  selectedBot?: Bot;
}

export const AppContext = createContext<IAppContext>({ selectedBot: undefined, setSelectedBot: () => {} });

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [selectedBot, setSelectedBot] = useState<Bot | undefined>(undefined);

  return <AppContext.Provider value={{ selectedBot, setSelectedBot }}>{children}</AppContext.Provider>;
};
