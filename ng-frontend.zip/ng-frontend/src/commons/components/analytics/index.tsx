import { Outlet } from 'react-router';
import useAnalytics from '../../hooks/use-analytics';

export const Analytics = () => {
  useAnalytics();

  return <Outlet />;
};
