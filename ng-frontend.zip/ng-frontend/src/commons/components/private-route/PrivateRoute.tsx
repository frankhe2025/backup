import { Outlet, useNavigate } from 'react-router';
import React, { useEffect } from 'react';
import getAuthService from '../../modules/auth/service/auth.service';
import { ROUTES } from '../../config/routes';
import getSocketService from '../../services/socket.service.ts';

export type PrivateRouteProps = {
  layout: React.ComponentType<any> | null;
  element: React.ReactNode;
};

export const PrivateRoute = () => {
  const navigate = useNavigate();
  const isAuthenticated = getAuthService().isUserSignedIn();
  useEffect(() => {
    if (!isAuthenticated) {
      // Redirect to login if not authenticated
      navigate(`${ROUTES.LOGIN}`, { replace: true });
    }
  }, [isAuthenticated, navigate]);
  console.log('insdie private route=====>');
  if (!isAuthenticated) {
    // Redirect to login if not authenticated
    return null;
  }

  if (isAuthenticated) {
    if (!getSocketService().subscribedToNotification()) {
      getSocketService()
        .subscribeNotification()
        .then((data: any) => {
          console.log('data: ', data);
        });
    }

    // Set the tenantId as a user property
    // This will be used to filter the data in Google Analytics
    // and to identify the tenant in the reports
    // This is a one-time setup, so we can set it here
    const userEmail = getAuthService().getUserName();
    const isAiseraUser = userEmail && userEmail.endsWith('@aisera.com');
    // const isAdmin = initData.sessionData.isAppAdmin; // TODO: Currently not available
    (window as any)._googleAnalyticsAdapter?.setUserProperties({
      tenantId: getAuthService().getTenantId(),
      isAiseraUser,
    });
  }

  return <Outlet />;
};

export default PrivateRoute;
