import React from 'react';
import * as Sentry from '@sentry/react';
import { useSentryTags } from '../../hooks/useSentryTags';

const { SENTRY_DSN, SENTRY_RELEASE } = process.env;
const ENABLE_SENTRY = process.env.ENABLE_SENTRY === 'true';

if (ENABLE_SENTRY) {
  Sentry.init({
    dsn:
      SENTRY_DSN || 'https://e3c6cf4195058d595a51761ec51e35b6@o4508245570748416.ingest.us.sentry.io/4509314981363712',
    release: SENTRY_RELEASE,
    environment: 'production',
    sendDefaultPii: true,
    integrations: [Sentry.browserTracingIntegration(), Sentry.replayIntegration()],
    tracesSampleRate: 1.0,
    tracePropagationTargets: [/^\/api\//],
    replaysSessionSampleRate: 0.5,
    replaysOnErrorSampleRate: 1.0,
  });
}

interface SentryBoundaryProps {
  children: React.ReactNode;
}

const SentryBoundary: React.FC<SentryBoundaryProps> = ({ children }) => {
  useSentryTags();

  return <Sentry.ErrorBoundary>{children}</Sentry.ErrorBoundary>;
};

export default SentryBoundary;
