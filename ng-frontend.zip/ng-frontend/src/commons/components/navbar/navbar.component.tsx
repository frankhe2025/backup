import { Navbar, NavbarBrand, NavbarContent, NavbarItem, Select, SelectItem } from '@aisera-ui/react';
import getAuthService from '../../modules/auth/service/auth.service';
import { BotComponent } from '../../modules/bot/bot.component';
import { useNgTransaltion } from '../../../i18n/hooks/translation.hook';

export const NavBar = () => {
  const { _t, i18n } = useNgTransaltion('translation');
  const user = getAuthService().getAuth();

  const languageChanged = (e: any) => {
    i18n.changeLanguage(e.target.value);
  };

  return (
    <Navbar
      position='static'
      height={'50px'}
      isBordered={true}
      maxWidth='full'
      className='sticky -top-4 z-20 bg-white shadow-sm'>
      <NavbarBrand>
        <p className='font-bold text-inherit'></p>

        <NavbarItem>
          <BotComponent />
        </NavbarItem>
      </NavbarBrand>

      <NavbarContent justify='end'>
        <NavbarItem>
          {user?.tenantId} - {user?.tenantName}
        </NavbarItem>
        <NavbarItem>{user?.userName}</NavbarItem>
        <NavbarItem>
          <Select
            className='min-w-[200px]'
            label={_t('LANGUAGE', { ns: 'translation', defaultValue: 'Language' })}
            labelPlacement='outside-left'
            defaultSelectedKeys={[i18n.language]}
            size='sm'
            onChange={languageChanged}>
            <SelectItem key={'en-US'}>English </SelectItem>
            <SelectItem key={'fr'}>French</SelectItem>
          </Select>
        </NavbarItem>
      </NavbarContent>
    </Navbar>
  );
};
