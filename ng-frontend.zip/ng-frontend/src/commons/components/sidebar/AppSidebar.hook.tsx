import { useState } from 'react';
import getRbacService from '../../modules/auth/service/rbac.service.ts';

// This hook will manage visibility for all the menu Items, just keep adding logic in the updateMenuItemVisibility function
export function useAppSidebar() {
  const [promptVisible, setPromptVisible] = useState(false);

  const handler = {
    updateMenuItemVisibility: async () => {
      setPromptVisible(await getRbacService().checkCurrentPageAccess('prompts'));
    },
  };

  return {
    promptVisible,
    handler,
  };
}
