import type { SidebarItem } from '@aisera-ui/sidebar';

export const items: SidebarItem[] = [
  {
    key: 'home',
    href: '/',
    icon: 'solar:home-2-linear',
    title: 'Home',
  },
  {
    key: 'prompt-studio',
    href: '/prompts',
    icon: 'solar:tuning-square-2-linear',
    title: 'Prompt Studio',
  },
  // {
  //   key: "tasks",
  //   href: "#",
  //   icon: "solar:checklist-minimalistic-outline",
  //   title: "Tasks",
  //   endContent: (
  //     <Icon className="text-default-400" icon="solar:add-circle-line-duotone" width={24} />
  //   ),
  // },
  // {
  //   key: "team",
  //   href: "#",
  //   icon: "solar:users-group-two-rounded-outline",
  //   title: "Team",
  // },
  // {
  //   key: "tracker",
  //   href: "#",
  //   icon: "solar:sort-by-time-linear",
  //   title: "Tracker",
  //   endContent: (
  //     <Chip size="sm" variant="flat">
  //       New
  //     </Chip>
  //   ),
  // },
  // {
  //   key: "analytics",
  //   href: "#",
  //   icon: "solar:chart-outline",
  //   title: "Analytics",
  // },
  // {
  //   key: "perks",
  //   href: "#",
  //   icon: "solar:gift-linear",
  //   title: "Perks",
  //   endContent: (
  //     <Chip size="sm" variant="flat">
  //       3
  //     </Chip>
  //   ),
  // },
  // {
  //   key: "expenses",
  //   href: "#",
  //   icon: "solar:bill-list-outline",
  //   title: "Expenses",
  // },
  // {
  //   key: "settings",
  //   href: "#",
  //   icon: "solar:settings-outline",
  //   title: "Settings",
  // },
];
