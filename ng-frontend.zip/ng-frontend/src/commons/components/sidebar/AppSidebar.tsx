import { useEffect } from 'react';
import { SidebarDrawer, Sidebar as AiSidebar } from '@aisera-ui/sidebar';
import { Spacer, Avatar, Tooltip, Button, cn } from '@aisera-ui/react';
import { Icon } from '@iconify/react';

import { items } from './items';
import { useAppShellContext } from '@aisera-ui/app-shell';
import getAuthService from '../../modules/auth/service/auth.service';
import { useNgTransaltion } from '../../../i18n/hooks/translation.hook';
import { ROUTES } from '../../config/routes';
import { useAppSidebar } from './AppSidebar.hook.tsx';
import { useNavigate, useLocation } from 'react-router';

export const Sidebar = () => {
  const {
    isSidebarOpen: isOpen,
    toggleSidebar: onOpenChange,
    isMobile,
    isCollapsed,
    toggleCollapsed: onToggle,
  } = useAppShellContext();
  const navigate = useNavigate();
  const location = useLocation();
  const { promptVisible, handler } = useAppSidebar();
  const user = getAuthService().getAuth();
  const { _t } = useNgTransaltion('translation');

  // Determine current active route key based on location.pathname
  const getCurrentActiveKey = () => {
    const path = location.pathname;
    // Find the matching item from the sidebar items
    const matchingItem = items.find((item) => {
      if (item.href === path) return true;
      // Check if path starts with item href for nested routes
      if (item.href && path.startsWith(item.href) && item.href !== '/') return true;
      return false;
    });

    return matchingItem?.key || 'home'; // Default to 'home' if no match
  };

  const logOut = () => {
    getAuthService().logout();
    navigate(ROUTES.LOGIN);
  };

  useEffect(() => {
    handler.updateMenuItemVisibility();
  }, [handler]);

  return (
    <SidebarDrawer
      className={cn('min-w-[288px] rounded-lg', { 'min-w-[76px]': isCollapsed })}
      hideCloseButton={true}
      isOpen={isOpen}
      onOpenChange={onOpenChange}>
      <div
        className={cn('will-change relative flex h-full w-72 flex-col bg-default-100 p-6 transition-width', {
          'w-[83px] items-center px-[6px] py-6': isCollapsed,
        })}>
        <div
          className={cn('flex items-center gap-3 pl-2', {
            'justify-center gap-0 pl-0': isCollapsed,
          })}>
          <div className='flex h-8 w-8 items-center justify-center rounded-full text-[#FF5D5F]'>
            {/* <AcmeIcon className="text-background" /> */}
            <Icon icon='@aisera:ai-brand:logo' fontSize={32} />
          </div>
          <span
            className={cn('w-full text-small font-bold uppercase opacity-100', {
              'w-0 opacity-0': isCollapsed,
            })}>
            Aisera
          </span>
          <div className={cn('flex-end flex', { hidden: isCollapsed })}>
            <Icon
              className='cursor-pointer dark:text-primary-foreground/60 [&>g]:stroke-[1px]'
              icon='solar:round-alt-arrow-left-line-duotone'
              width={24}
              onClick={isMobile ? onOpenChange : onToggle}
            />
          </div>
        </div>
        <Spacer y={6} />
        <div className='flex items-center gap-3 px-3'>
          <Tooltip content={user?.userName} isDisabled={!isCollapsed} placement='right'>
            <Avatar isBordered name={user?.initial} />
          </Tooltip>
          <div className={cn('flex max-w-full flex-col', { hidden: isCollapsed })}>
            <p className='text-small font-medium text-foreground break-all'>{user?.userName}</p>
            <p className='text-tiny font-medium text-default-400'></p>
          </div>
        </div>

        <Spacer y={6} />

        {promptVisible && (
          <AiSidebar
            defaultSelectedKey={getCurrentActiveKey()}
            iconClassName='group-data-[selected=true]:text-default-900 text-default-600'
            isCompact={isCollapsed}
            itemClasses={{
              base: 'px-3 rounded-large data-[selected=true]:!bg-default-200',
              title: 'group-data-[selected=true]:text-default-900 text-default-600',
            }}
            items={items}
          />
        )}

        <Spacer y={8} />

        <div
          className={cn('mt-auto flex flex-col', {
            'items-center': isCollapsed,
          })}>
          {isCollapsed && (
            <Button isIconOnly className='flex h-10 w-10 text-default-600' size='sm' variant='light'>
              <Icon
                className='cursor-pointer dark:text-primary-foreground/60 [&>g]:stroke-[1px]'
                height={24}
                icon='solar:round-alt-arrow-right-line-duotone'
                width={24}
                onClick={onToggle}
              />
            </Button>
          )}
          <Tooltip
            content={_t('SUPPORT', { ns: 'translation', defaultValue: 'Support' })}
            isDisabled={!isCollapsed}
            placement='right'>
            <Button
              fullWidth
              className={cn('justify-start truncate text-default-600 data-[hover=true]:text-foreground', {
                'justify-center': isCollapsed,
              })}
              isIconOnly={isCollapsed}
              startContent={
                isCollapsed ? null : (
                  <Icon className='flex-none text-default-600' icon='solar:info-circle-line-duotone' width={24} />
                )
              }
              variant='light'>
              {isCollapsed ? (
                <Icon className='text-default-500' icon='solar:info-circle-line-duotone' width={24} />
              ) : (
                _t('SUPPORT', { ns: 'translation', defaultValue: 'Support' })
              )}
            </Button>
          </Tooltip>
          <Tooltip
            content={_t('LOG-OUT', { ns: 'translation', defaultValue: 'Log Out' })}
            isDisabled={!isCollapsed}
            placement='right'>
            <Button
              onClick={logOut}
              className={cn('justify-start text-default-500 data-[hover=true]:text-foreground', {
                'justify-center': isCollapsed,
              })}
              isIconOnly={isCollapsed}
              startContent={
                isCollapsed ? null : (
                  <Icon
                    className='flex-none rotate-180 text-default-500'
                    icon='solar:minus-circle-line-duotone'
                    width={24}
                  />
                )
              }
              variant='light'>
              {isCollapsed ? (
                <Icon className='rotate-180 text-default-500' icon='solar:minus-circle-line-duotone' width={24} />
              ) : (
                _t('LOG-OUT', { ns: 'translation', defaultValue: 'Log Out' })
              )}
            </Button>
          </Tooltip>
        </div>
      </div>
    </SidebarDrawer>
  );
};
