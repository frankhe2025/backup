import { HeroUIProvider } from '@aisera-ui/react';
import { Outlet, useHref, useNavigate } from 'react-router';

export const Providers = () => {
  const navigate = useNavigate();

  return (
    <HeroUIProvider navigate={navigate} useHref={useHref}>
      <Outlet />
    </HeroUIProvider>
  );
};
