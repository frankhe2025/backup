import { io } from 'socket.io-client';
import getAuthService from '../modules/auth/service/auth.service';

export class SocketService {
  socket;
  subscriber;
  constructor() {
    this.subscriber = null;
    // The socket will be proxied to backend through vite, it is going to root /socket.io,
    // So here, we do not need to provide any URL
    this.socket = io('', {
      reconnectionAttempts: 5,
      timeout: 10000,
      auth: {
        token: getAuthService().getAuthToken(),
      },
      transports: ['websocket', 'polling'], // Explicitly specify transports
    });

    this.socket.on('connect', () => {
      // console.log('Socket Connected:', this.socket.connected);
      // console.log('Transport:', this.socket.io.engine.transport.name);
    });

    this.socket.on('connect_error', (error: any) => {
      console.error('Socket Connection Error:', error);
      console.error('Error Message:', error.message);
      console.error('Error Description:', error.description);
      console.error('Error Context:', error.context);
    });

    this.socket.on('disconnect', (reason: any) => {
      // console.log('Socket Disconnected:', reason);
      if (reason === 'io server disconnect') {
        // the disconnection was initiated by the server, you need to reconnect manually
        this.socket.connect();
      }
    });

    // Add error event listener
    this.socket.io.on('error', (error: any) => {
      console.error('Socket.IO Error:', error);
    });

    // Add reconnect event listener
    this.socket.io.on('reconnect', (attempt: number) => {
      // console.log('Socket Reconnected after', attempt, 'attempts');
    });

    // Add reconnect_attempt event listener
    this.socket.io.on('reconnect_attempt', (attempt: number) => {
      // console.log('Socket Reconnection Attempt:', attempt);
    });
  }

  subscribedToNotification() {
    return !!this.subscriber;
  }

  subscribeNotification() {
    if (!this.subscriber) {
      this.subscriber = new Promise((resolve) => {
        this.socket.on('notification', (data: any) => {
          console.log('Notification Received:', data);
          resolve(data);
        });
      });
    }
    return this.subscriber;
  }
}

let _sockerService: SocketService;
const getSocketService = () => {
  if (!_sockerService) {
    _sockerService = new SocketService();
  }
  return _sockerService;
};
export default getSocketService;
