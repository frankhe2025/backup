import { useEffect } from 'react';
import * as Sentry from '@sentry/react';
import getRegistrationService from '../modules/connector-server/services/registration.service';

const fetchTenantId = async (): Promise<string | undefined> => {
  return await getRegistrationService().getCurrentTenantId();
};

export const useSentryTags = () => {
  useEffect(() => {
    const ENABLE_SENTRY = process.env.ENABLE_SENTRY === 'true';

    if (!ENABLE_SENTRY) return;

    (async () => {
      const tenantId = await fetchTenantId();
      if (tenantId) Sentry.setTag('tenantId', tenantId);

      Sentry.setTag('cluster', process.env.CLUSTER);
      Sentry.setTag('namespace', process.env.NAMESPACE);
    })();
  }, []);
};
