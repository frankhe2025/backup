import { useEffect } from 'react';
import { useLocation, useMatches } from 'react-router';
import { useDebounceCallback } from 'usehooks-ts';

const useAnalytics = () => {
  const location = useLocation();
  const matches = useMatches();

  const trackPageView = useDebounceCallback((url: string) => {
    const pageName = matches[matches.length - 1].id || url;
    if ((window as any)._googleAnalyticsAdapter) {
      (window as any)._googleAnalyticsAdapter.trackPageView(pageName);
    }
  }, 100);

  useEffect(() => {
    trackPageView(location.pathname);
  }, [matches, location.pathname, trackPageView]);
};

export default useAnalytics;
