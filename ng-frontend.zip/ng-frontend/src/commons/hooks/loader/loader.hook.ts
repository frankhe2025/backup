import { useEffect, useRef, useState } from 'react';

export const useLoader = () => {
  const [loading, setLoading] = useState<'SHOW' | 'HIDE'>('HIDE');
  const div = useRef<any>(null);

  useEffect(() => {
    if (loading === 'SHOW') {
      div.current = document.createElement('div');
      div.current.id = 'custom-element';
      div.current.className = 'w-full h-screen left-0 top-0 absolute flex items-center justify-center bg-background';
      div.current.innerHTML = '<div class="animate-spin rounded-full h-24 w-24 border-b-2 border-blue-500"></div>';
      div.current.style.zIndex = 9999;

      document.body.appendChild(div.current);
    } else {
      if (document.body.contains(div.current)) document.body.removeChild(div.current);
    }
  }, [loading]);

  return { loading, setLoading };
};
