const config = {
  usingMock: false, // true,
  token: '',
  BACKEND_HOST_URL: process.env.PUBLIC_BACKEND_HOST_URL || '/api/', // This is the API URL for all services except those with custom URL
};
export default config;
