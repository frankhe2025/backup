export const ROUTES = {
  // Auth
  LOGIN: '/login',

  // Prompts
  PROMPTS: '/prompts',
  PROMPT_PLAYGROUND: '/prompts/playground',
};
