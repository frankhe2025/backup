class CachedItem {
  key: string;
  value: any;
  createdAt: number = 0;
  constructor() {
    this.key = '';
  }
  set(key: string, value: any) {
    this.key = key;
    this.value = value;
    this.createdAt = new Date().getTime();
  }

  isExpired(ttl: number) {
    return new Date().getTime() - this.createdAt > ttl * 1000;
  }

  refresh() {
    this.createdAt = new Date().getTime();
  }
}
class LRU {
  items: CachedItem[];
  max: number;
  ttl: number;
  constructor(ttl = 3600 * 1000, maxSize = 500) {
    this.ttl = ttl;
    this.max = maxSize;
    this.items = [];
  }
  setMax(max: number) {
    this.max = max;
    //splice the data
    if (this.items.length > this.max) {
      this.items.splice(0, this.items.length - this.max);
    }
  }
  setTtl(seconds: number) {
    this.ttl = seconds;
  }
  set(key: any, value: any) {
    const foundItem = this.findByKey(key);
    if (foundItem) {
      foundItem.value = value;
    } else {
      const item = new CachedItem();
      item.set('' + this.generateKey(key), value);
      if (this.items.length === this.max) {
        this.items.splice(0, 1);
      }
      this.items.push(item);
    }
  }

  get(key: any) {
    return this.findByKey(key);
  }

  findByKey(key: any) {
    const foundItem = this.items.find((item) => {
      return item.key === this.generateKey(key);
    });
    if (foundItem) {
      this.items.splice(this.items.indexOf(foundItem), 1);
      if (!foundItem.isExpired(this.ttl)) {
        foundItem.refresh();
        this.items.push(foundItem);
      }
      return foundItem;
    } else {
      return null;
    }
  }

  generateKey(key: any) {
    if (typeof key === 'string') {
      return key;
    } else {
      return JSON.stringify(key);
    }
  }
}

class CacheManager {
  cache: LRU;
  constructor(_config: any = null) {
    this.cache = new LRU();
  }
  set(key: any, value: any) {
    this.cache.set(key, value);
  }
  get(key: any) {
    return this.cache.get(key)?.value;
  }
  clear() {
    this.cache.items = [];
  }
}

let cacheManagerInstance: CacheManager | null = null;
const getCacheManager = (config: any = null) => {
  console.log('_intern cm: ', cacheManagerInstance);
  if (!cacheManagerInstance) {
    cacheManagerInstance = new CacheManager(config);
  }
  return cacheManagerInstance;
};
export default getCacheManager;
