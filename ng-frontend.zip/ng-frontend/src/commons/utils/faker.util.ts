const generateWords = (cnt: number = 10): string => {
  const words: string[] = [];
  for (let i = 0; i < cnt; i++) {
    words.push(generateWord());
  }
  return words.join(' ');
};
const generateWord = (min: number = 5, max: number = 10): string => {
  return faker.word.noun(min, max);
};

const generateBoolean = () => {
  return faker.number.int(0, 10) % 2 === 0;
};

const generateNumber = (min: number = 5, max: number = 10) => {
  return faker.number.int(min, max);
};

const faker = {
  word: {
    noun: (min: number, max: number): string => {
      return randomWord(randomNumber(min, max));
    },
  },
  number: {
    int: (min: number, max: number) => {
      return randomNumber(min, max);
    },
  },
};

const randomNumber = (min: number, max: number) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

const randomWord = (length: number): string => {
  const seedString =
    'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz';
  const chars: string[] = [];
  for (let i = 0; i < length; i++) {
    const randomPos = randomNumber(0, seedString.length - 2);
    chars.push(seedString.substring(randomPos, randomPos + 1));
  }
  return chars.join('');
};

export { generateWords, generateWord, generateBoolean, generateNumber, randomNumber };
