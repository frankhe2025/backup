const setCookie = (key: string, value: any, days = 7) => {
  const date = new Date();
  date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000); // Convert days to milliseconds
  const expires = `expires=${date.toUTCString()}`;
  document.cookie = `${key}=${value}; ${expires}; path=/`;
};

const deleteCookie = (key: string) => {
  const date = new Date();
  date.setTime(date.getTime() - 24 * 60 * 60 * 1000); // Convert days to milliseconds
  const expires = `expires=${date.toUTCString()}`;
  document.cookie = `${key}=; ${expires}; path=/`;
};

// Function to get a cookie value by key
const getCookie = (key: string) => {
  const cookies = document.cookie.split('; ');
  for (let i = 0; i < cookies.length; i++) {
    const [cookieKey, cookieValue] = cookies[i].split('=');
    if (cookieKey === key) {
      return decodeURIComponent(cookieValue);
    }
  }
  return null; // Return null if the cookie is not found
};

export { getCookie, setCookie, deleteCookie };
