import axios from 'axios';

import config from '../config/config';
import getCacheManager from './cache_manager.util';
import getAuthService from '../modules/auth/service/auth.service';

const getApiClient = (options = {}) => {
  return axios.create({
    headers: {
      'Content-Type': 'application/json',
      'get-over-post': 'true',
      'session-header': config.token || '',
    },
    ...(options || {}),
  });
};

export enum REQUEST_METHOD {
  GET = 1,
  POST,
  DELETE,
  PUT,
  PATCH,
}

export interface CallApiParams {
  url: string;
  data?: any | null;
  method: REQUEST_METHOD;
  headers?: any | null;
}

const callApi = async (props: CallApiParams, cached = true) => {
  if (cached) {
    const resp: any = getCacheManager().get(props);
    if (resp) {
      return resp;
    }
  }

  if (!props.url) throw new Error('No url was provided');
  if (!props.method) throw new Error('No method was provided, should be one of GET, POST, PUT, DELETE, PATCH');
  const jwt = props?.headers?.jwt || getAuthService().getAuthToken();

  const customBaseUrl = props.headers?.['x-custom-base-url'];

  const headers = { ...props.headers };
  if (headers && 'x-custom-base-url' in headers) {
    delete headers['x-custom-base-url'];
  }

  const mergedOptions = {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...props.headers,
      Authorization: `Bearer ${jwt}`,
    },
  };

  const isProxyUrl = props.url.startsWith('/llm-proxy/') || props.url.startsWith('/api/');

  const apiUrl = isProxyUrl ? props.url : (customBaseUrl || config.BACKEND_HOST_URL) + props.url;

  try {
    let response = null;
    switch (props.method) {
      case REQUEST_METHOD.POST: {
        response = await getApiClient().post(apiUrl, props.data, mergedOptions);
        break;
      }
      case REQUEST_METHOD.PUT: {
        response = await getApiClient().put(apiUrl, props.data, mergedOptions);
        break;
      }
      case REQUEST_METHOD.PATCH: {
        response = await getApiClient().patch(apiUrl, props.data, mergedOptions);
        break;
      }
      case REQUEST_METHOD.DELETE: {
        response = await getApiClient().delete(apiUrl, { ...mergedOptions, data: props.data });
        break;
      }
      default: {
        response = await getApiClient().get(apiUrl, { ...mergedOptions });
      }
    }
    const result = {
      resp: response.data,
      statusCode: response.status,
      err: null,
    };
    if (cached) getCacheManager().set(props, result);
    return result;
  } catch (error: any) {
    return {
      resp: error.response?.data,
      statusCode: error.response?.status,
      err: error,
      canceled: error.message.toLowerCase() === 'canceled',
    };
  }
};

export default callApi;
