import { formatDate, formatMilliSeconds, formatNumber, formatPercentage } from './formatter.util';

describe('Formatter Uti', () => {
  it('formatNumber()', () => {
    expect(formatNumber(123)).toEqual('123');
    expect(formatNumber(1234)).toEqual('1.2K');
    expect(formatNumber(1999)).toEqual('2.0K');
    expect(formatNumber(123456)).toEqual('123.5K');
    expect(formatNumber(1234567)).toEqual('1.2M');
    expect(formatNumber(1534567)).toEqual('1.5M');
    expect(formatNumber(1534567, 2)).toEqual('1.53M');
    expect(formatNumber(1534567, 0)).toEqual('2M');
    expect(formatNumber(200.123, 0)).toEqual('200');
  });

  it('formatMilliSeconds()', () => {
    // 1 hour
    let x = 60 * 60 * 1000;
    expect(formatMilliSeconds(x)).toEqual('1 Hrs');
    x = 2 * 60 * 60 * 1000;
    expect(formatMilliSeconds(x)).toEqual('2 Hrs');
    x = 2.5 * 60 * 60 * 1000;
    expect(formatMilliSeconds(x)).toEqual('2.5 Hrs');
  });

  it('formatPercentage()', () => {
    expect(formatPercentage(0.12)).toEqual('12%');
    expect(formatPercentage(0.123, 1)).toEqual('12.3%');
    expect(formatPercentage(0.123)).toEqual('12%');
  });

  it('formatDate()', () => {
    const testDate = new Date('2024-07-25T12:00:00.000Z');
    let result = formatDate(testDate, 'YYYY-MM-DD');
    expect(result).toMatch(/2024-07-2[45]/);
    result = formatDate(testDate, 'MM-DD-YYYY');
    expect(result).toMatch(/07-2[45]-2024/);
  });
});
