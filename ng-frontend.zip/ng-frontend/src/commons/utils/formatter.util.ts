const formatNumber = (value: number | null, decimal: number = 1) => {
  if (value === 0) return '0';
  if (value === null) return '';
  const result = value + '';
  if (value > 1000000000) {
    return (value / 1000000000).toFixed(decimal) + 'B';
  } else if (value > 1000000) {
    return (value / 1000000).toFixed(decimal) + 'M';
  } else if (value > 1000) {
    return (value / 1000).toFixed(decimal) + 'K';
  }
  if (decimal === 0) {
    return '' + value.toFixed(0);
  } else {
    return result;
  }
};

// value is a decimal, such as 0.1234
const formatPercentage = (value: number, decimal: number = 0) => {
  if (value === null) return '';
  const converted = value * 100;
  if (decimal === 0) {
    return Math.floor(converted) + '%';
  } else {
    return converted.toFixed(decimal) + '%';
  }
};

const formatMilliSeconds = (ms: number, fixed: number = 1) => {
  const minutes = Math.floor(ms / 1000 / 60);
  return (minutes % 60 === 0 ? minutes / 60 : (minutes / 60).toFixed(fixed)) + ' Hrs';
};

const formatDate = (dt: Date, pattern = 'YYYY-MM-DD HH:mm:ss') => {
  const YYYY = '' + dt.getFullYear();
  const MM = (dt.getMonth() < 9 ? '0' : '') + (dt.getMonth() + 1);
  const DD = (dt.getDate() < 10 ? '0' : '') + dt.getDate();
  const HH = (dt.getHours() < 10 ? '0' : '') + dt.getHours();
  const mm = (dt.getMinutes() < 10 ? '0' : '') + dt.getMinutes();
  const ss = (dt.getSeconds() < 10 ? '0' : '') + dt.getSeconds();

  const result = pattern
    .replace('YYYY', YYYY)
    .replace('MM', MM)
    .replace('DD', DD)
    .replace('HH', HH)
    .replace('mm', mm)
    .replace('ss', ss);
  return result;
};

export { formatNumber, formatMilliSeconds, formatPercentage, formatDate };
