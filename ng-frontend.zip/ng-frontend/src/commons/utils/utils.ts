import { ROUTES } from '../config/routes';

const debounce = <T extends (...args: any[]) => void>(
  func: T,
  wait: number = 500,
): ((...args: Parameters<T>) => void) => {
  let timeout: ReturnType<typeof setTimeout> | null;

  return (...args: Parameters<T>) => {
    if (timeout !== null) {
      clearTimeout(timeout);
    }

    timeout = setTimeout(() => {
      func(...args);
    }, wait);
  };
};

const isEmptyObject = (obj: any) => {
  if (obj === null) return true;
  if ('filters' in obj) {
    return obj === null || obj === undefined || Object.keys(obj).length === 0 || obj.filters === null;
  } else {
    return obj === null || obj === undefined || Object.keys(obj).length === 0;
  }
};

const isSSOCallback = () => document.location.search.indexOf('jwt=') !== -1;
const isLoginPage = () => document.location.pathname.indexOf(ROUTES.LOGIN) !== -1;

const getJwtToken = () => localStorage.getItem('JWT');
const formatDate = (date: string | Date | null): string => {
  if (!date) return '';
  const d = new Date(date);
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

export { debounce, isEmptyObject, getJwtToken, isSSOCallback, isLoginPage, formatDate };
