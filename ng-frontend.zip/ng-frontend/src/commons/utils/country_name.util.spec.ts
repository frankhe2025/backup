import CountryNameUtil from './country_name.util';

describe('CountryNameUtil', () => {
  it('getContryCode3()', () => {
    const util = new CountryNameUtil();
    expect(util.getContryCode3('Australia')).toBe('AUS');
    expect(util.getContryCode3('China')).toBe('CHN');
    expect(util.getContryCode3('Czech Republic')).toBe('CZE');
    expect(util.getContryCode3('Germany')).toBe('DEU');
  });
});
