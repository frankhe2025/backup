/** @type {import('ts-jest').JestConfigWithTsJest} */
export default {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['<rootDir>/jest.setup.ts'],
  collectCoverageFrom: [
    'src/**/*.{ts,tsx}',
    'src/*.{ts,tsx}',
    '!src/**/*.d.ts',
    '!src/**/*.spec.{ts,tsx}',
    '!src/mocks/**',
    '!src/**/mocks/**',
    '!src/env.d.ts',
  ],
  coverageReporters: ['lcov', 'text-summary'],
  coverageDirectory: 'reports',
  coveragePathIgnorePatterns: ['/node_modules/'],
};
