import { createFileRoute } from "@tanstack/react-router";
import About from "../modules/about/About";

export const Route = createFileRoute("/about")({
  component: About,
  beforeLoad: async ({ location, params, context }) => {
    // return await new Promise((resolve)=>{
    //   setTimeout(()=>{
    //     resolve(null)
    //   }, 5000);
    // });

    // This runs on both server and client before the route loads
    console.log("Route is about to load! ABOUT: ", location, params);
    // You can run your logic here
  },
});
