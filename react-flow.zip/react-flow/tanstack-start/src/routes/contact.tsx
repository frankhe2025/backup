import { createFileRoute } from "@tanstack/react-router";
import Contact from '../modules/contact/Contact';

export const Route = createFileRoute("/contact")({
  component: Contact,
  beforeLoad: async ({ location, params, context }) => {
    // This runs on both server and client before the route loads
    console.log('Route is about to load! CONTACT: ', location, params);
    // You can run your logic here
  },
});
