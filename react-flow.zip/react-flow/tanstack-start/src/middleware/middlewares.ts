// import {createMiddleware, registerGlobalMiddleware} from '@tanstack/react-start';
//
// const globalMiddleware1 = createMiddleware({ type: 'function' }).server(
//     async ({ next }) => {
//         console.log('globalMiddleware1')
//         return next()
//     },
// )
//
// const globalMiddleware2 = createMiddleware({ type: 'function' }).server(
//     async ({ next }) => {
//         console.log('globalMiddleware2')
//         return next()
//     },
// )
//
// registerGlobalMiddleware({
//     middleware: [globalMiddleware1, globalMiddleware2],
// })
