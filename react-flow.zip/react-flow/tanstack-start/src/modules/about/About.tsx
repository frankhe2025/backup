import React from "react";
import DataList from './data-list';

const companyInfo = {
  name: "Acme Innovations",
  description:
    "Acme Innovations is a leading provider of cutting-edge solutions in the tech industry, dedicated to delivering excellence and driving progress.",
  imageUrl: "https://via.placeholder.com/800x200?text=Acme+Innovations", // Replace with real image if available
  goals: [
    "Drive innovation in technology and services",
    "Empower clients to achieve their business objectives",
    "Foster a culture of continuous learning and growth",
  ],
  opportunities: [
    "Software Engineer",
    "Product Manager",
    "UX/UI Designer",
    "Sales & Marketing Specialist",
  ],
};

const About: React.FC = () => {
  return (
    <div style={{ maxWidth: 800, margin: "0 auto", padding: 24 }}>
      {/* Company Image */}
      <img
        src={companyInfo.imageUrl}
        alt={companyInfo.name}
        style={{ width: "100%", borderRadius: 12, marginBottom: 24 }}
      />

      {/* Company Information */}
      <h1>About {companyInfo.name}</h1>
      <p style={{ fontSize: 18, color: "#555", marginBottom: 32 }}>
        {companyInfo.description}
      </p>

      {/* Company Goals */}
      <h2>Our Goals</h2>
      <ul style={{ fontSize: 16, marginBottom: 32 }}>
        {companyInfo.goals.map((goal, idx) => (
          <li key={idx} style={{ marginBottom: 8 }}>
            {goal}
          </li>
        ))}
      </ul>

      {/* Open Opportunities */}
      <h2>Open Opportunities</h2>
      <ul style={{ fontSize: 16 }}>
        {companyInfo.opportunities.map((role, idx) => (
          <li key={idx} style={{ marginBottom: 8 }}>
            {role}
          </li>
        ))}
      </ul>
    <DataList></DataList>
    </div>
  );
};

export default About;
