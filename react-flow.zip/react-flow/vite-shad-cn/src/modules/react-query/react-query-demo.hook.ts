import {useMutation, useQuery, useQueryClient} from '@tanstack/react-query';
import getSvc from '@/modules/react-query/react-query-serivce.ts';
import {Todo, type Todos} from '@/modules/react-query/react-query-entitits.ts';


// queryClient.invalidateQueries(['todos']);
// queryClient.refetchQueries(['todos']);

export function useReactQueryDemoHook() {

    const queryClient = useQueryClient();
    const todos: Todos = useQuery<Todos>({
        queryKey: ['todos'],
        queryFn: getSvc().fetchTodos,
        refetchOnMount: true, // this is to trigger automatically
    }).data;

    const mutation = useMutation({
        mutationFn: getSvc().createTodo,
        onSuccess: (data) => {
            console.log('added ')
            console.log(data);
            queryClient.invalidateQueries({queryKey: ['todos']});
        }
    });

    const handler = {
        createNewTodo: ()=>{
            mutation.mutate(new Todo().faked() as never);
        }
    }

    return {todos, handler}
}
