
interface TodoData {
    userId: number;
    id: number;
    title: string;
    body: string;
}

export class Todo{
    userId: number;
    id: number;
    title: string;
    body: string;
    constructor(data: TodoData | null = null) {
        this.userId=data?.userId ?? 0;
        this.id = data?.userId ?? 0;
        this.title = data?.title??'';
        this.body = data?.body??'';
    }

    faked() {
        const obj = new Todo();
        obj.userId = this.userId;
        obj.title = this.title;
        obj.body = this.body;
        return obj;
    }
}



export class Todos {
    todos: Todo[];
    constructor(data: TodoData[]) {
        this.todos = [];
        if(data){
            data.map( (item)=>{
                this.todos.push(new Todo(item));
            })
        }
    }
}
