import {QueryClient, QueryClientProvider} from '@tanstack/react-query';
import {useReactQueryDemoHook} from '@/modules/react-query/react-query-demo.hook.ts';
import type {Todo} from '@/modules/react-query/react-query-entitits.ts';
import {Button} from '@/components/ui/button.tsx';
import {Link, useNavigate} from '@tanstack/react-router';

const Todos = ()=>{
    const {todos, handler} = useReactQueryDemoHook();
    const navigate = useNavigate();
    const goBack = () => {
        navigate({to:'/'});
    };

    return (
        <div>
            <Button onClick={handler.createNewTodo}>Add New</Button>
            <Button onClick={goBack}>Go Back</Button>
            {
                todos?.todos?.map((item:Todo)=>{
                    return <div><Link to={`/react-query/${item.id}`}>{item.userId} - {item.title}</Link></div>
                })
            }

        </div>
    )
}

const ReactQueryDemoComponent = () => {
    return <QueryClientProvider client={new QueryClient()}><Todos/>
    </QueryClientProvider>
}

export default ReactQueryDemoComponent
