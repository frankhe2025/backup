import { useParams } from "@tanstack/react-router";

const ReactQueryDemoDetailComponent = ()=>{
    const { postId } = useParams({ strict: false })
    return (<div>Hello, Detail ID: {postId}</div>);
}
export default ReactQueryDemoDetailComponent;
