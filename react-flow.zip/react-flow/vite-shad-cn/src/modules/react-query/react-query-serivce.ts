import {Todo, Todos} from '@/modules/react-query/react-query-entitits.ts';

export class ReactQuerySerivce{

    async fetchTodos(): Promise<Todos> {
        const response = await fetch(
            'https://jsonplaceholder.typicode.com/posts',
        )
        const jsonResp = await response.json();
        return new Todos(jsonResp);
    }

    async createTodo(): Promise<Todo>{
        const response = await fetch(
            'https://jsonplaceholder.typicode.com/posts',
            {
             method: 'POST',
                body: JSON.stringify(new Todo().faked())
            }
        );
        const resObj = await response.json();
        console.log('result: ', JSON.stringify(resObj));
        return new Todo(resObj)
    }
}

let _inst;

const getSvc = ()=>{
    if(!_inst){
        _inst = new ReactQuerySerivce()
    }
    return _inst;
}

export default getSvc;
