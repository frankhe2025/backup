import { createFileRoute } from '@tanstack/react-router'
import {ShadCNLib as UI} from '@frankhe/mf-lib';
// @ts-ignore
export const Route = createFileRoute('/')({
    component: Index,
})

function Index() {
    return (
        <div className="p-2">
            <UI.Button>Button</UI.Button>
            <UI.Button variant='default'>Gost Button</UI.Button>
            <h3>Welcome Home!</h3>
        </div>
    )
}
