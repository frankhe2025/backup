import { createFileRoute } from '@tanstack/react-router';
import ReactQueryDemoDetailComponent from '@/modules/react-query/react-query-demo-detail.component.tsx';

export const Route = createFileRoute('/react-query/$postId')({
  // loader: async ({ params }) => {
  //   return { postId: params.postId }; // Return data instead of JSX
  // },
  component: ReactQueryDemoDetailComponent,
});
