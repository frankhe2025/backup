import { createRootRoute, Link, Outlet } from '@tanstack/react-router'
import { TanStackRouterDevtools } from '@tanstack/react-router-devtools'
import {ModeToggle} from '@/components/mode-toggle.tsx';

export const Route = createRootRoute({
    component: () => (
        <>
            <div className="p-2 flex gap-2">
                <Link to="/" className="[&.active]:font-bold">
                    Home
                </Link>{' '}
                <Link to="/about" className="[&.active]:font-bold">
                    About
                </Link>
                <Link to="/react-query/listing" className="[&.active]:font-bold">
                    React Query
                </Link>
                <Link to="/react-query/1" className="[&.active]:font-bold">
                    Detail
                </Link>
                <ModeToggle />
            </div>
            <hr />
            <Outlet />
            <TanStackRouterDevtools />
        </>
    ),
})
