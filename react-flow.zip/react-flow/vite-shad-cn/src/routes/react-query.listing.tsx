import {createFileRoute, redirect} from '@tanstack/react-router'
import ReactQueryDemoComponent from '@/modules/react-query/react-query-demo.component.tsx';


const checker = ()=>{
  return new Promise(resolve=>{
    setTimeout(()=>{
      resolve(true);
    }, 500);
  });
}

export const Route = createFileRoute('/react-query/listing')({
 beforeLoad: async ()=>{
    const allowed = await checker()
   if(!allowed) {
     throw redirect({to: "/"});
   }
 },
  component: ReactQueryDemoComponent,
})
