
import './App.css'
import {Button} from '@/components/ui/button.tsx';
import ReactQueryDemoComponent from '@/modules/react-query/react-query-demo.component.tsx';

function App() {
  return <div className="App">
      <Button>Click Me </Button>
      <div className="bg-warning text-warning-foreground" >
        CSS Variables
      </div>
      <ReactQueryDemoComponent />
  </div>
}

export default App
