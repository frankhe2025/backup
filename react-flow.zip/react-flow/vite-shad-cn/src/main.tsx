// Option 1: No Router
// import { StrictMode } from 'react'
// import { createRoot } from 'react-dom/client'
// import './index.css'
// import App from './App.tsx'
//
// createRoot(document.getElementById('root')!).render(
//   <StrictMode>
//     <App />
//   </StrictMode>,
// )

// Option 2: Code definition

// import { StrictMode } from 'react'
// import ReactDOM from 'react-dom/client'
// import {
//     Outlet,
//     RouterProvider,
//     Link,
//     createRouter,
//     createRoute,
//     createRootRoute,
// } from '@tanstack/react-router'
// import { TanStackRouterDevtools } from '@tanstack/react-router-devtools'
// import './index.css'
// import {Button} from '@/components/ui/button.tsx';
// import ReactQueryDemoComponent from '@/modules/react-query/react-query-demo.component.tsx';
//
// const rootRoute = createRootRoute({
//     component: () => (
//         <>
//             <div className="p-2 flex gap-2">
//                 <Link to="/" className="[&.active]:font-bold">
//                     Home
//                 </Link>{' '}
//                 <Link to="/about" className="[&.active]:font-bold">
//                     About
//                 </Link>
//             </div>
//             <hr />
//             <Outlet />
//             <TanStackRouterDevtools />
//         </>
//     ),
// })
//
// const indexRoute = createRoute({
//     getParentRoute: () => rootRoute,
//     path: '/',
//     component: function Index() {
//         return (
//             <div className="p-2">
//                 <h3>Welcome Home!</h3>
//                 <Button>Click Me </Button>
//                 <div className="bg-warning text-warning-foreground" >
//                     CSS Variables
//                 </div>
//                 <ReactQueryDemoComponent />
//             </div>
//         )
//     },
// })
//
// const aboutRoute = createRoute({
//     getParentRoute: () => rootRoute,
//     path: '/about',
//     component: function About() {
//         return <div className="p-2">Hello from About!</div>
//     },
// })
//
// const routeTree = rootRoute.addChildren([indexRoute, aboutRoute])
//
// const router = createRouter({ routeTree })
//
// declare module '@tanstack/react-router' {
//     interface Register {
//         router: typeof router
//     }
// }
//
// const rootElement = document.getElementById('root')!
// if (!rootElement.innerHTML) {
//     const root = ReactDOM.createRoot(rootElement)
//     root.render(
//         <StrictMode>
//             <RouterProvider router={router} />
//         </StrictMode>,
//     )
// }


// Option 3: File based
import { StrictMode } from 'react'
import ReactDOM from 'react-dom/client'
import { RouterProvider, createRouter } from '@tanstack/react-router'
import './index.css'
// Import the generated route tree
import { routeTree } from './routeTree.gen'
import { ThemeProvider } from "@/components/theme-provider"


// Create a new router instance
const router = createRouter({ routeTree })

// Register the router instance for type safety
declare module '@tanstack/react-router' {
    interface Register {
        router: typeof router
    }
}

// Render the app
const rootElement = document.getElementById('root')!
if (!rootElement.innerHTML) {
    const root = ReactDOM.createRoot(rootElement)
    root.render(
        <StrictMode>
            <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
                <RouterProvider router={router} />
            </ThemeProvider>

        </StrictMode>,
    )
}
