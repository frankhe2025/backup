import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { HomeIcon } from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInput,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarRail,
  SidebarTrigger,
} from "./sidebar";

const meta: Meta<typeof Sidebar> = {
  title: "Components/Sidebar",
  component: Sidebar,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
  },
  args: {
    children: (
      <>
        <SidebarTrigger />
        <SidebarRail />
        <SidebarHeader>
          <SidebarInput placeholder="Search..." />
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Menu</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild tooltip="Home">
                    <a href="#">
                      <HomeIcon />
                      <span>Home</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton tooltip="About">
                    <HomeIcon />
                    <span>About</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton tooltip="Settings">
                <HomeIcon />
                <span>Settings</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarFooter>
      </>
    ),
  },
};

export default meta;

type Story = StoryObj<typeof Sidebar>;

export const Default: Story = {
  render: (args) => (
    <SidebarProvider>
      <Sidebar {...args} />
    </SidebarProvider>
  ),
};

export const Collapsed: Story = {
  render: (args) => (
    <SidebarProvider defaultOpen={false}>
      <Sidebar {...args} />
    </SidebarProvider>
  ),
};

export const Floating: Story = {
  args: {
    variant: "floating",
  },
  render: (args) => (
    <SidebarProvider>
      <Sidebar {...args} />
    </SidebarProvider>
  ),
};

export const Inset: Story = {
  args: {
    variant: "inset",
  },
  render: (args) => (
    <SidebarProvider>
      <Sidebar {...args} />
    </SidebarProvider>
  ),
};

export const Offcanvas: Story = {
  args: {
    collapsible: "offcanvas",
  },
  render: (args) => (
    <SidebarProvider>
      <Sidebar {...args} />
    </SidebarProvider>
  ),
};

export const WithoutToggle: Story = {
  args: {
    collapsible: "none",
  },
  render: (args) => (
    <SidebarProvider>
      <Sidebar {...args} />
    </SidebarProvider>
  ),
};
