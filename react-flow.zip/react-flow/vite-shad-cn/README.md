pnpm dlx shadcn@latest add https://registry.lloydrichards.dev/registry/accordion-story
pnpm dlx shadcn@latest add button
