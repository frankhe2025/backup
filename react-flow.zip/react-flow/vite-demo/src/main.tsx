import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import FlowDemoComponent from './flow-demo/flow-demo.component';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <FlowDemoComponent />
  </StrictMode>,
)
