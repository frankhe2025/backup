import {ReactFlow, ReactFlowProvider} from 'reactflow';
import {useRef} from 'react';
import {useFlowDemoHook} from './hook/use-flow-demo.hook.ts';
import nodesConfig from './config/site.ts';
import './flow-demo.component.css';
import '@xyflow/react/dist/style.css';

const FlowDemoComponent = ()=>{
    const reactFlowWrapper = useRef<any>(null);
    const {nodes, setNodes, selectedNode, edges, setEdges, onNodesChange, onEdgesChange, onConnect, updateNodeLabel, setSelectedNode} = useFlowDemoHook();

    return (
        <ReactFlowProvider>
            <main>
                <div
                    className="h-[calc(100vh_-_48px)] flex-grow wrapper"
                    ref={reactFlowWrapper}
                >
                    <p className={'font-bold text-red-500'}>This is a simple flow demo component.</p>
                    {/*<ReactFlow*/}
                    {/*    nodes={nodes}*/}
                    {/*    edges={edges}*/}
                    {/*    onNodesChange={onNodesChange}*/}
                    {/*    onEdgesChange={onEdgesChange}*/}
                    {/*    onConnect={onConnect}*/}
                    {/*    fitView*/}
                    {/*    nodeTypes={nodesConfig.nodeTypes}*/}
                    {/*></ReactFlow>*/}
                </div>
            </main>

        </ReactFlowProvider>
    );
}
export default FlowDemoComponent;
