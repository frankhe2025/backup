import {useCallback, useState} from 'react';
import {
    ReactFlow,
    addEdge,
    useEdgesState,
    useNodesState, SelectionMode, MiniMap, Controls, Background, Panel
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import { initialNodes } from './nodes';
import { initialEdges } from './edges';

const panOnDrag = [1, 2];

function Flow() {
    const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
    const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
    const [variant, setVariant] = useState('cross');

    const onConnect = useCallback(
        (connection) => setEdges((eds) => addEdge(connection, eds)),
        [setEdges],
    );

    const nodeColor = (node) => {
        switch (node.type) {
            case 'input':
                return '#6ede87';
            case 'output':
                return '#6865A5';
            default:
                return '#ff0072';
        }
    };

    return (
        <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            panOnScroll
            selectionOnDrag
            panOnDrag={panOnDrag}
            selectionMode={SelectionMode.Partial}
        >
            <MiniMap nodeColor={nodeColor} nodeStrokeWidth={3} zoomable pannable />
            <Controls />
            <Background color="#ccc" variant={variant} />
            <Panel>
                <div>variant:</div>
                <button onClick={() => setVariant('dots')}>dots</button>
                <button onClick={() => setVariant('lines')}>lines</button>
                <button onClick={() => setVariant('cross')}>cross</button>
            </Panel>
            <Panel position="top-left">top-left</Panel>
            <Panel position="top-center">top-center</Panel>
            <Panel position="top-right">top-right</Panel>
            <Panel position="bottom-left">bottom-left</Panel>
            <Panel position="bottom-center">bottom-center</Panel>
            <Panel position="bottom-right">bottom-right</Panel>
        </ReactFlow>
    );
}

export default Flow;
