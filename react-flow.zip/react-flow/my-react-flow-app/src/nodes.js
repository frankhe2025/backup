
export const initialNodes = [
    {
        id: '1',
        type: 'textUpdater', // Custom node type
        data: { label: 'Node 1' },
        position: { x: 150, y: 0 },
    },
    {
        id: '2',
        data: { label: 'Node 2' },
        position: { x: 0, y: 150 },
    },
    {
        id: '3',
        data: { label: 'Node 3' },
        position: { x: 300, y: 150 },
    },
];
