export const initialEdges = [
    { id: 'e1-2', source: '1', target: '2', label: 'to the', type: 'step' },
    { id: 'e1-3', source: '1', target: '3' },
];
