import {Position} from 'reactflow';
import {TextNode} from '@/flow-demo/components/nodes/text';
import {TextNewNode} from '@/flow-demo/components/nodes/textNew';


export type NodeTypes = 'textNode'

const nodesConfig = {
    initialNodes: [
        {
            id: '1',
            type: 'textNode',
            data: {
                label: 'hey Frank check this video out\nhttps://youtu.be/dQw4w9WgXcQ',
                isInitial: true,
            },
            position: { x: 300, y: 400 },
            sourcePosition: Position.Left,
        },
        {
            id: '2',
            type: 'textNode',
            data: {
                label: 'wow123, that was a great video\n😳',
            },
            position: { x: 600, y: 300 },
            targetPosition: Position.Left,
        },
    ],
    initialEdges: [{ id: 'e1-1', source: '1', target: '2' }],
    nodeTypes: {
        textNode: TextNode,
        textNodeNew:TextNewNode
    } as any
}
export default nodesConfig;
