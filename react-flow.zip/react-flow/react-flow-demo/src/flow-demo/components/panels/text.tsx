// import React from 'react';
// import {useFlowDemoHook} from '@/flow-demo/hook/use-flow-demo.hook';
// import {ArrowLeft} from 'lucide';


import {useFlowDemoContext} from '@/flow-demo/hook/use-flow-demo.context';

export const TextPanel = ()=> {
    // const { selectedNode, updateNodeLabel, setSelectedNode } = useFlowDemoContext();
    const flowDemoState: any = useFlowDemoContext();

    const handleChange = (value: string) => {
        flowDemoState.selectedNode && flowDemoState.updateNodeLabel(flowDemoState?.selectedNode.id, value)
    }

    return (
        <>
            <div className="p-2 font-semibold flex">
                <button
                    onClick={() => {
                        flowDemoState.setSelectedNode(null)
                    }}
                >
                   <div> -- Back</div>
                </button>
                <h2 className="flex-grow text-center">Message</h2>
            </div>
            <hr />

            <div className="p-2 mt-3">
                <label
                    className="block text-sm font-medium text-start text-gray-700"
                    htmlFor="message"
                >
                    Text
                </label>
                <div className="mt-1">
					<textarea
                        rows={4}
                        key={flowDemoState.selectedNode?.id}
                        defaultValue={flowDemoState.selectedNode?.data.label}
                        name="message"
                        id="message"
                        onChange={(e) => handleChange(e.target.value)}
                        className="border block w-full border-gray-300 rounded-md sm:text-sm p-2"
                    />
                </div>
            </div>
        </>
    )
}
