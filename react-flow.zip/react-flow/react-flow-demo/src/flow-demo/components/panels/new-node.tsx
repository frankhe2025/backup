// import React from 'react';
// import {MessagesSquare} from 'lucide';

export const AddNodePanel = ()=>{
    const onDragStart = (
        event: React.DragEvent<HTMLDivElement>,
        nodeType: 'textNode'
    ) => {
        event.dataTransfer.setData('application/reactflow', nodeType)
        event.dataTransfer.effectAllowed = 'move'
    }
    return (
        <aside>
            <div className="p-2 font-semibold">
                <h2>Add New Node Type1</h2>
            </div>

            <div className="p-2 mt-3 w-fit min-w-[200px]">
                <div
                    className="border border-primary bg-primary/5 text-primary-foreground hover:border-primary/90 hover:bg-primary/10 py-2 px-3 rounded-md cursor-pointer flex flex-col items-center gap-2 transition-colors"
                    draggable
                    onDragStart={(event) => onDragStart(event, 'textNode')}
                >
                    {/*<MessagesSquare color="hsl(222.2,47.4%,11.2%)" size="32" />*/}
                    <span className="font-semibold text-primary">Message</span>
                </div>
            </div>
        </aside>
    )
}
