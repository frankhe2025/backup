import {TextPanel, AddNodePanel} from './panels';
import {useEffect} from 'react';
import {useFlowDemoContext} from '@/flow-demo/hook/use-flow-demo.context';
import {AddNodePanel1} from '@/flow-demo/components/panels/new-node-1';
export const Panel = () => {

    const flowDemoStates: any = useFlowDemoContext();

    useEffect(() => {
        console.log('selected node updated:', flowDemoStates?.selectedNode);
    }, [flowDemoStates?.selectedNode]);
    const CurrentPanel =  getPanel(flowDemoStates?.selectedNode?.type || '');
    return (
        <div className=" bg-white h-full border-gray-200 border">
            <CurrentPanel />
        </div>
    )
}

const AddNodePanels = ()=>{
    return <div><AddNodePanel/><AddNodePanel1/></div>
}

const getPanel = (type: any) => {
    // when list of panels grows, use a switch statement or a map
    if (type === 'textNode' || type === 'textNodeNew') {
        return TextPanel
    }
    return AddNodePanels;
}
