import {ReactFlow, ReactFlowProvider, Node} from 'reactflow';

import nodesConfig from './config/site';
import '@xyflow/react/dist/style.css';
import {Panel} from './components/panel';
import {FlowDemoProvider, useFlowDemoContext} from '@/flow-demo/hook/use-flow-demo.context';
import {useCallback, useRef, useState} from 'react';
import {handleDragOver, handleOnDrop} from '@/flow-demo/lib/utils';
import {Background} from 'reactflow';

const FlowDemoContent = ({ reactFlowWrapper }) => {
    const flowDemoStates: any = useFlowDemoContext();
    const [reactFlowInstance, setReactFlowInstance] = useState<any>(null)

   const onDragOver=     (event: React.DragEvent<HTMLDivElement>) => {
            handleDragOver(event)
        }

    const onDrop = (event: any)=>{
        handleOnDrop(event, reactFlowWrapper, reactFlowInstance, flowDemoStates.setNodes)
    }



    return (
        <main className={"flex"}>
        <div
            className="h-[calc(100vh_-_48px)] flex-grow"
            ref={reactFlowWrapper}
        >
            <p className={'font-bold text-red-500'}>This is a simple flow demo component.</p>
            {flowDemoStates &&  <ReactFlow
                nodes={flowDemoStates.nodes}
                edges={flowDemoStates.edges}
                onNodesChange={flowDemoStates.onNodesChange}
                onEdgesChange={flowDemoStates.onEdgesChange}
                onConnect={flowDemoStates.onConnect}
                fitView
                nodeTypes={nodesConfig.nodeTypes}
                onNodeClick={(event: React.MouseEvent, node: Node)=>{
                    console.log('node', node);
                    flowDemoStates.setSelectedNode(node);
                }}
                onPaneClick={() => {
                    flowDemoStates.setSelectedNode(null);
                }}
                fitViewOptions={{ maxZoom: 1 }}
                snapToGrid={true}
                onDragOver={onDragOver}
                onDrop={onDrop}
                onInit={setReactFlowInstance}
            >
                <Background color="#ccc" variant="dots" />
            </ReactFlow>
            }
        </div>
        <div className={"basis-[300px] md:block lg:basis-[350px]"}>
            <Panel />
        </div>
    </main>

    );
};

const FlowDemoComponent = ()=>{
    const reactFlowWrapper = useRef<any>(null);
    return (
        <FlowDemoProvider>
            <ReactFlowProvider>
                <FlowDemoContent reactFlowWrapper={reactFlowWrapper} />
            </ReactFlowProvider>
        </FlowDemoProvider>


    );
}

export default FlowDemoComponent;
