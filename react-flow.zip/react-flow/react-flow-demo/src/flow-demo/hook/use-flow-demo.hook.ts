import {useState} from 'react';
import {
    addEdge,
    applyEdgeChanges,
    applyNodeChanges, type Connection,
    type Edge, type EdgeChange,
    type Node, type NodeChange,
} from 'reactflow';
import nodesConfig from '../config/site';

const useFlowDemoHook = (): any => {

    const [nodes, _setNodes] = useState<Node[]>(nodesConfig.initialNodes);
    const [edges, setEdges] = useState<Edge[]>(nodesConfig.initialEdges);
    const [selectedNode, _setSelectedNode] = useState<Node | null>(null);

    const setSelectedNode = (node: Node | null) => {
       console.log('selected ndoe: ', node);
        _setSelectedNode(node);

        // if the node is null, then we want to deselect the currently selected node
        if (node === null) {
            const selectedNode = nodes.find((n) => n.selected === true);
            if (selectedNode) {
                onNodesChange([{
                    type: 'select',
                    id: selectedNode.id,
                    selected: false,
                }])
            }
        }
    };
    const setNodes = (newNode: Node) => {
        _setNodes((prevState)=> [...prevState, newNode]);
    };
    const onNodesChange = (changes: NodeChange[]) => {
        _setNodes(applyNodeChanges(changes, nodes));
    };

    const onEdgesChange = (changes: EdgeChange[]) => {
        setEdges(applyEdgeChanges(changes, edges));
    };

    const onConnect = (connection: Connection) => {
        setEdges( addEdge(connection, edges) );
    };

    const updateNodeLabel = (nodeId: string, nodeVal: string) => {
        _setNodes(nodes.map((node) => {
            if (node.id === nodeId) {
                node.data = {
                    ...node.data,
                    label: nodeVal,
                };
            }
            return node;
        }));
    };

    return {nodes, setNodes, selectedNode, edges, setEdges, onNodesChange, onEdgesChange, onConnect, updateNodeLabel, setSelectedNode};
}
export default useFlowDemoHook;
