import {createContext, useContext} from 'react';
import useFlowDemoHook from '@/flow-demo/hook/use-flow-demo.hook';


const FlowDemoContext = createContext(null);

// @ts-ignore
const FlowDemoProvider = ({children}) => {
    const FlowDemoStates = useFlowDemoHook();
    return (
        <FlowDemoContext.Provider value={FlowDemoStates}>
            {children}
        </FlowDemoContext.Provider>
    )
}

const useFlowDemoContext = ()=>{
    return useContext(FlowDemoContext)
}

export {FlowDemoProvider, useFlowDemoContext}
