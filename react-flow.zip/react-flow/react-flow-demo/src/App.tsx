export default function App() {

	return (
		<div className={'text-red-500 font-bold text-2xl'}>Hello</div>
	)
}
