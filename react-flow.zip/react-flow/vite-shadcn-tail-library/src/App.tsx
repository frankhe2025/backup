import './App.css'

function App() {

  return (
    <>
      <div className={'font-bold text-red-500'}>
          Hello World
      </div>
    </>
  )
}

export default App
