npx shadcn@latest add button input


https://medium.com/@sonilamohanty26/how-to-build-a-scalable-react-component-library-with-shadcn-ui-tailwind-css-57ce33a296f1
