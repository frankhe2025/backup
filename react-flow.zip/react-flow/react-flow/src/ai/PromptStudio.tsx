import React, { useState } from 'react';
import './PromptStudio.css';

const PromptStudio = () => {
  const [selectedItems, setSelectedItems] = useState(new Set());
  const [searchQuery, setSearchQuery] = useState('');

  const dummyData = [
    {
      id: 1,
      name: "Intent Extraction From Conversation (Single & Multiple Intents)",
      source: "System",
      type: "Default",
      scope: "Global",
      model: "Microsoft Azure OpenAI - GPT-4",
      status: "Published",
      lastUpdated: "Jan 25th, 2025",
      updatedBy: "Tony Reichert",
      draft: "N/A",
      avatar: "TR"
    },
    {
      id: 2,
      name: "Context Management & Carry-Over",
      source: "User",
      type: "Custom",
      scope: "Application",
      model: "Microsoft Azure OpenAI - GPT-4",
      status: "Published",
      lastUpdated: "Dec 19th, 2024",
      updatedBy: "Zoey Lang",
      draft: "Yes",
      avatar: "ZL"
    },
    {
      id: 3,
      name: "Answer Generation For Actionable Request For Which No-Fulfillment Is Available",
      source: "System",
      type: "Tuned",
      scope: "Application",
      model: "Microsoft Azure OpenAI - GPT-4",
      status: "Inactive",
      lastUpdated: "Aug 31st, 2024",
      updatedBy: "Jane Fisher",
      draft: "Yes",
      avatar: "JF"
    },
    {
      id: 4,
      name: "Answer Extraction From Knowledge Articles",
      source: "User",
      type: "Custom",
      scope: "Tenant",
      model: "Microsoft Azure OpenAI - GPT-4",
      status: "Published",
      lastUpdated: "Jul 11th, 2024",
      updatedBy: "William Howard",
      draft: "No",
      avatar: "WH"
    }
  ];

  const handleSelectAll = (e) => {
    if (e.target.checked) {
      setSelectedItems(new Set(dummyData.map(item => item.id)));
    } else {
      setSelectedItems(new Set());
    }
  };

  const handleSelectItem = (id) => {
    const newSelected = new Set(selectedItems);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedItems(newSelected);
  };

  const getStatusClass = (status) => {
    return status === 'Published' ? 'status-published' : 'status-inactive';
  };

  const filteredData = dummyData.filter(item =>
      Object.values(item).some(value =>
          value.toString().toLowerCase().includes(searchQuery.toLowerCase())
      )
  );

  return (
      <div className="prompt-studio">
        {/* Header */}
        <div className="header">
          <div className="header-left">
            <div className="logo">
              <span className="logo-icon">AI</span>
              <h1>Prompt Studio</h1>
            </div>
          </div>
          <div className="header-right">
            <button className="new-prompt-btn">+ New Prompt</button>
          </div>
        </div>

        {/* Controls */}
        <div className="controls">
          <div className="search-section">
            <div className="search-box">
              <input
                  type="text"
                  placeholder="Search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
              />
              <span className="search-icon">🔍</span>
            </div>
            <button className="filter-btn">🔽 Filter</button>
            <button className="sort-btn">📊 Sort</button>
            <button className="columns-btn">📋 Columns</button>
            <span className="selected-count">{selectedItems.size} Selected</span>
          </div>
        </div>

        {/* Table */}
        <div className="table-container">
          <table className="data-table">
            <thead>
            <tr>
              <th>
                <input
                    type="checkbox"
                    onChange={handleSelectAll}
                    checked={selectedItems.size === dummyData.length}
                />
              </th>
              <th>Name</th>
              <th>Source</th>
              <th>Type</th>
              <th>Scope</th>
              <th>Model</th>
              <th>Status</th>
              <th>Last Updated</th>
              <th>Updated by</th>
              <th>Draft</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            {filteredData.map((item) => (
                <tr key={item.id}>
                  <td>
                    <input
                        type="checkbox"
                        checked={selectedItems.has(item.id)}
                        onChange={() => handleSelectItem(item.id)}
                    />
                  </td>
                  <td className="name-cell">{item.name}</td>
                  <td>{item.source}</td>
                  <td>{item.type}</td>
                  <td>{item.scope}</td>
                  <td>{item.model}</td>
                  <td>
                  <span className={`status ${getStatusClass(item.status)}`}>
                    ● {item.status}
                  </span>
                  </td>
                  <td>{item.lastUpdated}</td>
                  <td>
                    <div className="user-info">
                      <div className="avatar">{item.avatar}</div>
                      <span>{item.updatedBy}</span>
                    </div>
                  </td>
                  <td>{item.draft}</td>
                  <td>
                    <div className="actions">
                      <button className="action-btn">📝</button>
                      <button className="action-btn">🗑️</button>
                    </div>
                  </td>
                </tr>
            ))}
            </tbody>
          </table>
        </div>
      </div>
  );
};

export default PromptStudio;
