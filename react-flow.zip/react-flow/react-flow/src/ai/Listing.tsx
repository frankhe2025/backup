import React from 'react';
import './Listing.css';

const Listing: React.FC = () => {
    return (
        <div className="listing-container">
            <div className="listing-header">
                <h1>Listings</h1>
                <div className="listing-filters">
                    <input
                        type="text"
                        placeholder="Search listings..."
                        className="search-input"
                    />
                    <select className="filter-select">
                        <option value="">All Categories</option>
                        <option value="category1">Category 1</option>
                        <option value="category2">Category 2</option>
                    </select>
                </div>
            </div>

            <div className="listing-grid">
                {[1, 2, 3, 4, 5, 6].map((item: number) => (
                    <div key={item} className="listing-card">
                        <div className="listing-image">
                            <img
                                src={`https://picsum.photos/300/200?random=${item}`}
                                alt={`Listing ${item}`}
                            />
                        </div>
                        <div className="listing-content">
                            <h3>Listing Title {item}</h3>
                            <p className="listing-description">
                                This is a sample description for listing {item}. It provides a brief overview of the item.
                            </p>
                            <div className="listing-meta">
                                <span className="price">$299.99</span>
                                <span className="location">New York, NY</span>
                            </div>
                            <button className="view-details-btn">View Details</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Listing;
