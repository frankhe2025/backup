import {Button} from "@aisera-ui/button";
import {Meta} from "@storybook/react";
import React from "react";

import {FeaturesProvider, Has} from "../src";

import options from "./config";

const meta: Meta = {
  title: "Components/FeatureFlags/Has",
  component: FeaturesProvider,
  parameters: {
    controls: {expanded: true},
  },
  args: {},
  decorators: [
    (Story) => {
      return (
        <div>
          <FeaturesProvider
            value={{
              ...options,
              attr: {
                role: "admin",
              },
            }}
          >
            <Story />
          </FeaturesProvider>
        </div>
      );
    },
  ],
};

export default meta;

export const Default = () => {
  return (
    <Has feature="settings">
      <Button color="success">Settings Enabled</Button>
    </Has>
  );
};

export const WithFallback = () => {
  return (
    <Has fallback={<Button color="danger">Beta Feature Disabled</Button>} feature="beta-feature">
      <Button color="success">Beta Feature Enabled</Button>
    </Has>
  );
};

export const WithMultiplefeatures = () => {
  return (
    <Has
      fallback={<Button color="danger">Feature Disabled</Button>}
      feature={["settings", "enterprise-feature"]}
    >
      <Button color="success">Feature Enabled</Button>
    </Has>
  );
};

export const WithMultipleExactfeatures = () => {
  return (
    <Has
      exact={false}
      fallback={<Button color="danger">Feature Disabled</Button>}
      feature={["settings", "beta"]}
    >
      <Button color="success">Feature Enabled</Button>
    </Has>
  );
};

export const WithValue = () => {
  return (
    <Has feature="value-feature" value="enabled">
      <Button color="success">Feature Enabled</Button>
    </Has>
  );
};

export const WithNot = () => {
  return (
    <Has not feature="private-feature">
      <Button color="success">Feature Enabled</Button>
    </Has>
  );
};

export const WithRenderProps = () => {
  return (
    <Has feature={["settings"]}>
      {({flags}) => {
        const features = Object.keys(flags);

        return <Button color="success">Feature Enabled: {features[0]}</Button>;
      }}
    </Has>
  );
};

export const WithMultipleValues = () => {
  return (
    <Has
      fallback={<Button color="danger">Feature Disabled</Button>}
      feature={["settings", "value-feature"]}
      value="enabled"
    >
      <Button color="success">Feature Enabled</Button>
    </Has>
  );
};
