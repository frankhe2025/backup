import {Table, TableBody, TableCell, TableColumn, TableHeader, TableRow} from "@aisera-ui/table";
import {Card} from "@aisera-ui/card";
import {Meta} from "@storybook/react";

import {FeaturesProvider, useFlag} from "../src";

import options from "./config";

const meta: Meta = {
  title: "Components/FeatureFlags/useFlag",
  component: FeaturesProvider,
  parameters: {
    controls: {expanded: true},
  },
  args: {},
  decorators: [
    (Story) => {
      return (
        <div>
          <FeaturesProvider
            value={{
              ...options,
              attr: {
                role: "admin",
              },
            }}
          >
            <Story />
          </FeaturesProvider>
        </div>
      );
    },
  ],
};

export default meta;

export const Default = () => {
  const features = ["settings", "beta", "enterprice-feature", "value-feature"];

  return (
    <Card>
      <Table aria-label="Example static collection table">
        <TableHeader>
          <TableColumn>Feature</TableColumn>
          <TableColumn>Value</TableColumn>
        </TableHeader>
        <TableBody>
          <TableRow key={features[0]}>
            <TableCell>{features[0]}</TableCell>
            <TableCell>{useFlag(features[0])?.toString()}</TableCell>
          </TableRow>
          <TableRow key={features[1]}>
            <TableCell>{features[1]}</TableCell>
            <TableCell>{useFlag(features[1])?.toString()}</TableCell>
          </TableRow>
          <TableRow key={features[2]}>
            <TableCell>{features[2]}</TableCell>
            <TableCell>{useFlag(features[2])?.toString()}</TableCell>
          </TableRow>
          <TableRow key={features[3]}>
            <TableCell>{features[3]}</TableCell>
            <TableCell>{useFlag(features[3])?.toString()}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </Card>
  );
};
