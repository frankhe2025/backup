# @aisera-ui/feature-flags

Feature flags allow you to toggle functionality on/off during runtime and give people access to certain features based on their attributes, like their role or the current billing plan/License.

Please refer to the [documentation](https://aisera.com/docs/components/feature-flags) for more information.

## Installation

```sh
yarn add @aisera-ui/feature-flags
# or
npm i @aisera-ui/feature-flags
```

## Contribution

Yes please! See the
[contributing guidelines](https://github.com/Aisera/ng-uicomponent/blob/master/CONTRIBUTING.md)
for details.
