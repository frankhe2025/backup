import React from "react";

import {Segment, UserAttributes, Flags} from "./types";

export interface FeaturesOptions {
  segments: Segment[];
  attr?: UserAttributes;
}

interface FeaturesState {
  isReady: boolean;
  attr?: UserAttributes;
  segments: Segment[];
  flags: Flags;
  identify: (attr: UserAttributes) => void;
  hasFeatures: (ids: string[], value: any) => Record<string, any>;
}

const FeaturesContext = React.createContext<FeaturesState | null>(null);

export interface FeaturesProviderProps {
  value?: FeaturesOptions;
  children: React.ReactNode;
}

type FeaturesAction =
  | {type: "INITIALIZE"; payload: {segments: Segment[]; attr?: UserAttributes}}
  | {type: "IDENTIFY"; payload: {attr: UserAttributes; segments: Segment[]}};
const featuresReducer = (
  state: Omit<FeaturesState, "identify" | "hasFeatures">,
  action: FeaturesAction,
): Omit<FeaturesState, "identify" | "hasFeatures"> => {
  switch (action.type) {
    case "INITIALIZE":
      const initSegments = matchSegments(action.payload.segments, action.payload.attr || {});
      const initFlags = action.payload.attr ? flagsFromSegments(initSegments) : state.flags;

      return {
        ...state,
        segments: [...state.segments, ...action.payload.segments],
        attr: {...state.attr, ...action.payload.attr},
        flags: initFlags,
        isReady: true,
      };
    case "IDENTIFY":
      const segments = matchSegments([...state.segments, ...action.payload.segments], {
        ...state.attr,
        ...action.payload.attr,
      });

      const flags = flagsFromSegments(segments);

      return {
        ...state,
        attr: {...state.attr, ...action.payload.attr},
        flags,
      };
    default:
      return state;
  }
};

export const FeaturesProvider: React.FC<FeaturesProviderProps> = (props) => {
  const {children, value} = props;

  const [state, dispatch] = React.useReducer(featuresReducer, {
    isReady: false,
    attr: {},
    flags: [],
    segments: [],
  });

  const identify = (attr) => {
    dispatch({type: "IDENTIFY", payload: {attr, segments: state.segments}});
  };

  const hasFeatures = (ids, value) => {
    return ids?.reduce((memo, id) => {
      if ((typeof value === "undefined" && state.flags[id]) || state.flags[id] === value) {
        memo[id] = state.flags[id];
      }

      return memo;
    }, {}) as Record<string, any>;
  };

  React.useEffect(() => {
    if (value) {
      dispatch({
        type: "INITIALIZE",
        payload: {
          segments: value.segments,
          attr: value.attr,
        },
      });
    }
  }, [value]);

  return (
    <FeaturesContext.Provider value={{...state, identify, hasFeatures}}>
      {children}
    </FeaturesContext.Provider>
  );
};

export const useFeatures = () => {
  const context = React.useContext(FeaturesContext);

  if (!context) {
    throw new Error("Features context missing, did you wrap your app with FeaturesProvider?");
  }

  return context;
};

/**
 * Check if the current identified user has one or more features.
 */
export const useHasFeature = (feature: string | string[] = [], value = true) => {
  const ids = typeof feature === "string" ? [feature] : feature;
  const {hasFeatures, flags} = useFeatures();

  return React.useMemo(() => {
    return hasFeatures(ids, value);
  }, [flags, ids, value, hasFeatures]);
};

/**
 *
 * @param id The feature id
 * @returns The feature value
 */
export const useFlag = (id: string) => {
  const {flags} = useFeatures();

  return flags[id];
};

const matchSegments = (segments: Segment[], attr: UserAttributes) => {
  return segments.filter((segment) => {
    return segment.attr.every(({key, value}) => {
      if (Array.isArray(attr[key])) {
        return attr[key].includes(value);
      }

      return attr[key] === value;
    });
  });
};

const flagsFromSegments = (segments: Segment[]) => {
  return segments.reduce<Flags>((memo, {features}) => {
    features.forEach((feature) => {
      if (typeof feature === "string") {
        memo[feature] = true;
      } else {
        memo[feature.id] = feature.value;
      }
    });

    return memo;
  }, {});
};
