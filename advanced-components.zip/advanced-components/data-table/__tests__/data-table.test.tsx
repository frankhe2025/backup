import React from "react";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {DataTable} from "../src";
import {DataTableColumn, DataTableConfiguration} from "../src/types";

// Mock the Table component from @aisera-ui/table
jest.mock("@aisera-ui/table", () => ({
  Table: jest.fn(({children, selectedKeys, selectionMode, onSelectionChange}) => (
    <div data-testid="table">
      <div data-testid="selection-mode">{selectionMode}</div>
      <div data-testid="selected-keys">
        {selectedKeys instanceof Set ? Array.from(selectedKeys).join(",") : "none"}
      </div>
      {children}
    </div>
  )),
  TableHeader: jest.fn(({children}) => <div data-testid="table-header">{children}</div>),
  TableBody: jest.fn(({children}) => <div data-testid="table-body">{children}</div>),
  TableColumn: jest.fn(({children, key}) => (
    <div key={key} data-testid={`table-column-${key}`}>
      {children}
    </div>
  )),
  TableRow: jest.fn(({children, key}) => (
    <div key={key} data-testid={`table-row-${key}`}>
      {children}
    </div>
  )),
  TableCell: jest.fn(({children, key}) => (
    <div key={key} data-testid={`table-cell-${key}`}>
      {children}
    </div>
  )),
}));

describe("DataTable", () => {
  const mockData = [
    {
      id: "1",
      name: "Amar Patel",
      email: "amar.patel@cortex.dev",
      role: "Developer",
    },
    {
      id: "2",
      name: "Keisha Williams",
      email: "keisha.w@cortex.dev",
      role: "Designer",
    },
  ];

  const defaultColumns: DataTableColumn[] = [
    {key: "name", title: "Name", sortable: true},
    {key: "email", title: "Email", sortable: true},
    {key: "role", title: "Role", sortable: true},
  ];

  const defaultConfiguration: DataTableConfiguration = {
    columns: defaultColumns,
    selectionMode: "multiple",
  };

  it("renders without crashing", () => {
    render(<DataTable configuration={defaultConfiguration} data={mockData} />);

    expect(screen.getByTestId("table")).toBeInTheDocument();
    expect(screen.getByTestId("table-header")).toBeInTheDocument();
    expect(screen.getByTestId("table-body")).toBeInTheDocument();
  });


 
  it("sets selection mode correctly", () => {
    render(
      <DataTable
        configuration={{
          ...defaultConfiguration,
          selectionMode: "single",
        }}
        data={mockData}
      />,
    );

    expect(screen.getByTestId("selection-mode").textContent).toBe("single");
  });


});
