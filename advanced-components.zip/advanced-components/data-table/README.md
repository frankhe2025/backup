# @aisera-ui/data-table

A Quick description of the component

> This is an internal utility, not intended for public usage.

## Installation

```sh
yarn add @aisera-ui/data-table
# or
npm i @aisera-ui/data-table
```

## Contribution

Yes please! See the
[contributing guidelines](https://github.com/Aisera/ng-uicomponent/blob/master/CONTRIBUTING.md)
for details.
