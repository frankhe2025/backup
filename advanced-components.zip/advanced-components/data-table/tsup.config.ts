import {defineConfig} from "tsup";

export default defineConfig({
  entry: ["src/index.ts"],
  clean: true,
  dts: false,
  target: "es2019",
  format: ["cjs", "esm"],
  banner: {js: '"use client";'},
  
  loader: {
    ".css": "copy",
  },
  
  external: ["*.css"],
});
