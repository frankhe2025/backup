import React from "react";
import {Meta, StoryObj} from "@storybook/react";

import {DataTable, DataTableProps} from "../src";
import {DataTableColumn} from "../src/types";

const meta: Meta<typeof DataTable> = {
  title: "Components/DataTable",
  component: DataTable,
  argTypes: {
    data: {control: {type: "object"}},
    configuration: {control: {type: "object"}},
  },
};

export default meta;
type Story = StoryObj<typeof DataTable>;

const mockData = [
  {
    id: "1",
    name: "Amar Patel",
    email: "amar.patel@cortex.dev",
    role: "Developer",
    status: "Active",
    createdAt: "2023-01-15T08:00:00.000Z",
  },
  {
    id: "2",
    name: "Keisha Williams",
    email: "keisha.w@cortex.dev",
    role: "Designer",
    status: "Inactive",
    createdAt: "2023-02-20T10:30:00.000Z",
  },
  {
    id: "3",
    name: "Tariq Hassan",
    email: "tariq.h@cortex.dev",
    role: "Manager",
    status: "Active",
    createdAt: "2023-03-10T14:15:00.000Z",
  },
  {
    id: "4",
    name: "Zoe Chen",
    email: "zoe.chen@cortex.dev",
    role: "Developer",
    status: "Active",
    createdAt: "2023-04-05T09:45:00.000Z",
  },
  {
    id: "5",
    name: "Mateo Rodriguez",
    email: "mateo.r@cortex.dev",
    role: "Designer",
    status: "Inactive",
    createdAt: "2023-05-12T16:20:00.000Z",
  },
];

const defaultColumns: DataTableColumn[] = [
  {key: "name", title: "Name", sortable: true},
  {key: "email", title: "Email", sortable: true},
  {key: "role", title: "Role", sortable: true},
  {key: "status", title: "Status", sortable: true},
  {key: "createdAt", title: "Created At", type: "date", sortable: true},
];

const Template = (args: DataTableProps) => <DataTable {...args} />;

export const Default: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: {
      columns: defaultColumns,
    },
  },
};

export const WithActions: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: {
      columns: defaultColumns,
      actions: {
        edit: {
          handler: (id) => console.log(`Edit ${id}`),
          icon: <span>✏️</span>,
          label: "Edit",
        },
        delete: {
          handler: (id) => console.log(`Delete ${id}`),
          icon: <span>🗑️</span>,
          label: "Delete",
        },
      },
    },
  },
};

export const WithSelection: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: {
      columns: defaultColumns,
      selectionMode: "multiple",
      onSelectionChange: (selectedKeys) => console.log("Selected:", selectedKeys),
    },
  },
};

export const WithSingleSelection: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: {
      columns: defaultColumns,
      selectionMode: "single",
      onSelectionChange: (selectedKeys) => console.log("Selected:", selectedKeys),
    },
  },
};

export const WithCustomStyling: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: {
      columns: defaultColumns,
      classNames: {
        base: "border-collapse",
        thead: "bg-blue-50",
        th: "bg-blue-100 text-blue-900 border-b border-blue-200 font-semibold text-xs uppercase",
        td: "px-4 py-3 border-b border-blue-100",
      },
    },
  },
};
