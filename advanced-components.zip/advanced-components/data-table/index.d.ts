
import React from "react";
import { Selection } from "@aisera-ui/table";

export type DataTableColumnType = "text" | "number" | "date" | "boolean" | "action";
export type SortDirection = "asc" | "desc" | "none";

export interface DataTableActionConfig {
  handler: (id: string) => void;
  icon?: React.ReactNode;
  label?: string;
}

export interface DataTableActionCollection {
  [key: string]: DataTableActionConfig | ((id: string) => void) | undefined;
}

export type CellRenderer = (
  value: any,
  rowData: any,
  columnKey: string,
  columnType?: DataTableColumnType
) => React.ReactNode;

export type ActionRenderer = (rowData: any, actions: DataTableActionCollection) => React.ReactNode;

export interface TableClassNames {
  base?: string;
  thead?: string;
  th?: string;
  td?: string;
  tr?: string;
  actionButton?: string;
  sortIndicator?: string;
  pagination?: string;
  spinner?: string;
  loadingContent?: string;
}

export interface DataTableColumn {
  key: string;
  title: string;
  type?: DataTableColumnType;
  cellRenderer?: CellRenderer;
  sortable?: boolean;
  reorderable?: boolean;
  resizable?: boolean;
  width?: number | string;
  minWidth?: number;
}

export interface PaginationRenderProps {
  page: number;
  rowsPerPage: number;
  totalItems: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  onRowsPerPageChange: (rowsPerPage: number) => void;
}

export interface PaginationOptions {
  page?: number;
  rowsPerPage?: number;
  totalItems?: number;
  totalPages?: number;
  onPageChange?: (page: number) => void;
  onRowsPerPageChange?: (rowsPerPage: number) => void;
  showControls?: boolean;
  showRowsPerPageSelector?: boolean;
  rowsPerPageOptions?: number[];
  customPagination?: (props: PaginationRenderProps) => React.ReactNode;
  variant?: "flat" | "bordered" | "light" | "faded";
  size?: "sm" | "md" | "lg";
  color?: "default" | "primary" | "secondary" | "success" | "warning" | "danger";
  radius?: "none" | "sm" | "md" | "lg" | "full";
  applyPagination?: boolean;
}

export interface InfiniteScrollOptions {
  hasMore?: boolean;
  isLoading?: boolean;
  onLoadMore?: () => void;
  maxHeight?: string | number;
  loadingContent?: React.ReactNode;
}

export interface DataTableConfiguration {
  columns: DataTableColumn[];
  selectionMode?: "single" | "multiple" | "none";
  onSelectionChange?: (selectedKeys: Selection) => void;
  actions?: DataTableActionCollection;
  defaultCellRenderer?: CellRenderer;
  actionRenderer?: ActionRenderer;
  classNames?: TableClassNames;
  ariaLabel?: string;
  onSortChange?: (column: string, direction: SortDirection) => void;
  sortColumn?: string;
  sortDirection?: SortDirection;
  onColumnResize?: (columnKey: string, width: number) => void;
  onColumnHeaderClick?: (columnKey: string) => void;
  onSort?: (columnKey: string) => void;
  pagination?: PaginationOptions;
  infiniteScroll?: InfiniteScrollOptions;
  isLoading?: boolean;
  loadingContent?: React.ReactNode;
  emptyContent?: React.ReactNode;
  isHeaderSticky?: boolean;
  columnOrder?: string[];
  onColumnOrderChange?: (columnOrder: string[]) => void;
}

export interface DataTableProps {
  data: any[];
  configuration: DataTableConfiguration;
}

export declare const DataTable: React.FC<DataTableProps>;
export declare const DataTableV2: React.FC<DataTableProps>;