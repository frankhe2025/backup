/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import {
  Table,
  TableHeader,
  TableBody,
  TableColumn,
  TableRow,
  TableCell,
  Selection,
} from "@aisera-ui/table";
import {useState, useCallback, useMemo} from "react";

import {DataTableProps, SortDirection} from "./types";

export const DataTable = ({data, configuration}: DataTableProps) => {
  const [selectedKeys, setSelectedKeys] = useState<Selection>(new Set());
  const [sortColumn, setSortColumn] = useState<string>("");
  const [sortDirection, setSortDirection] = useState<SortDirection>("none");

  const {columns} = configuration;
  const selectionMode = configuration.selectionMode ?? "multiple";
  const onSelectionChange = configuration.onSelectionChange;
  const actions = configuration.actions;
  const defaultCellRenderer = configuration.defaultCellRenderer ?? null;

  const classNames = configuration.classNames ?? {
    base: "border-collapse",
    thead: "bg-gray-50",
    th: "bg-default-100 text-default-900 border-b border-divider font-semibold text-xs uppercase",
    td: "px-4 py-3 border-b border-divider",
    actionButton: "text-gray-600 hover:text-gray-900",
    sortIndicator: "ml-2 text-blue-600 font-bold",
  };

  const handleSelectionChange = useCallback(
    (keys: Selection) => {
      setSelectedKeys(keys);
      if (onSelectionChange) {
        onSelectionChange(keys instanceof Set ? keys : new Set([keys]));
      }
    },
    [onSelectionChange],
  );

  const handleSort = useCallback(
    (columnKey: string, e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();

      const column = columns.find((col) => col.key === columnKey);

      if (!column?.sortable) return;

      if (sortColumn !== columnKey) {
        setSortColumn(columnKey);
        setSortDirection("asc");
      } else {
        if (sortDirection === "asc") {
          setSortDirection("desc");
        } else if (sortDirection === "desc") {
          setSortDirection("none");
          setSortColumn("");
        } else {
          setSortDirection("asc");
        }
      }
    },
    [sortColumn, sortDirection, columns],
  );

  const sortedData = useMemo(() => {
    if (!sortColumn || sortDirection === "none" || !data || data.length === 0) {
      return [...data];
    }

    const columnConfig = columns.find((col) => col.key === sortColumn);

    return [...data].sort((a, b) => {
      const valueA = a[sortColumn];
      const valueB = b[sortColumn];

      if (valueA === null || valueA === undefined) return sortDirection === "asc" ? 1 : -1;
      if (valueB === null || valueB === undefined) return sortDirection === "asc" ? -1 : 1;

      if (
        (typeof valueA === "object" && valueA?.name) ||
        (typeof valueB === "object" && valueB?.name)
      ) {
        const nameA = typeof valueA === "object" ? valueA?.name || "" : valueA;
        const nameB = typeof valueB === "object" ? valueB?.name || "" : valueB;

        return sortDirection === "asc"
          ? String(nameA).localeCompare(String(nameB))
          : String(nameB).localeCompare(String(nameA));
      }

      if (columnConfig?.type === "number") {
        return sortDirection === "asc"
          ? Number(valueA) - Number(valueB)
          : Number(valueB) - Number(valueA);
      } else if (columnConfig?.type === "date") {
        const dateA = valueA instanceof Date ? valueA : new Date(valueA);
        const dateB = valueB instanceof Date ? valueB : new Date(valueB);

        return sortDirection === "asc"
          ? dateA.getTime() - dateB.getTime()
          : dateB.getTime() - dateA.getTime();
      } else if (columnConfig?.type === "boolean") {
        const boolA = Boolean(valueA);
        const boolB = Boolean(valueB);

        return sortDirection === "asc"
          ? boolA === boolB
            ? 0
            : boolA
            ? 1
            : -1
          : boolA === boolB
          ? 0
          : boolA
          ? -1
          : 1;
      } else {
        return sortDirection === "asc"
          ? String(valueA).localeCompare(String(valueB))
          : String(valueB).localeCompare(String(valueA));
      }
    });
  }, [data, sortColumn, sortDirection, columns]);

  const allColumns = [...columns];

  if (actions && !columns.some((col) => col.key === "actions")) {
    allColumns.push({key: "actions", title: "Actions"});
  }

  const renderCellContent = (item: any, column: any) => {
    const value = item[column.key];

    if (column.cellRenderer) {
      return column.cellRenderer(value, item, column.key, column.type);
    }

    if (column.key === "actions" && actions) {
      if (configuration.actionRenderer) {
        return configuration.actionRenderer(item, actions);
      }

      return (
        <div className="flex gap-2 justify-center">
          {Object.entries(actions).map(([key, action]) => {
            if (!action) return null;
            if (typeof action === "function") return null;
            if (!action.icon) return null;

            return (
              <button
                key={key}
                aria-label={action.label || key}
                className={classNames.actionButton}
                onClick={() => action.handler(item.id)}
              >
                {action.icon}
              </button>
            );
          })}
        </div>
      );
    }

    if (defaultCellRenderer) {
      return defaultCellRenderer(value, item, column.key, column.type);
    }

    return value != null ? String(value) : "";
  };

  const renderSortIndicator = (columnKey: string) => {
    const column = columns.find((col) => col.key === columnKey);

    if (!column?.sortable) return null;

    if (sortColumn !== columnKey || sortDirection === "none") return null;

    return (
      <span className={classNames.sortIndicator ?? "ml-2 text-blue-600 font-bold"}>
        {sortDirection === "asc" ? "↑" : "↓"}
      </span>
    );
  };

  return (
    <Table
      aria-label={configuration.ariaLabel || "Data table"}
      classNames={classNames}
      selectedKeys={selectedKeys}
      selectionMode={selectionMode}
      onSelectionChange={handleSelectionChange}
    >
      <TableHeader>
        {allColumns.map((column) => (
          <TableColumn key={column.key}>
            <div
              className={`flex items-center ${
                column.sortable ? "cursor-pointer hover:text-blue-600" : ""
              }`}
              onClick={(e) => column.sortable && handleSort(column.key, e)}
            >
              {column.title}
              {renderSortIndicator(column.key)}
            </div>
          </TableColumn>
        ))}
      </TableHeader>
      <TableBody>
        {sortedData.map((item, index) => (
          <TableRow key={item.id || `row-${index}`}>
            {allColumns.map((column) => (
              <TableCell key={`${item.id || index}-${column.key}`}>
                {renderCellContent(item, column)}
              </TableCell>
            ))}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};
