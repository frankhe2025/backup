# @aisera-ui/data-table-v2

## 2.2.2

### Patch Changes

- Table Header Fix

## 2.2.1

### Patch Changes

- Action Column Fix
