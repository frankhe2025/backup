import React, { useMemo } from 'react';
import { Meta, StoryObj } from '@storybook/react';
import { Icon } from '@iconify/react';
import { DataTableV2 } from '../src/DataTableV2';
import { DataTableColumnType } from '../src/types';

export default {
  title: 'Components/DataTableV2',
  component: DataTableV2,
  parameters: {
    layout: 'centered',
  },
} as Meta<typeof DataTableV2>;

type Story = StoryObj<typeof DataTableV2>;

const sampleData = [
  { id: 1, name: 'Amar P', email: 'amar@example.com', role: 'Developer', status: 'Active' },
  { id: 2, name: 'Keisha', email: 'keisha@example.com', role: 'Designer', status: 'Inactive' },
  { id: 3, name: 'Tariq H', email: 'tariq@example.com', role: 'Manager', status: 'Active' },
  { id: 4, name: 'Sarah J', email: 'sarah@example.com', role: 'Developer', status: 'Active' },
  { id: 5, name: 'Michael B', email: 'michael@example.com', role: 'Analyst', status: 'Inactive' },
];

export const BasicTable: Story = {
  args: {
    data: sampleData,
    configuration: {
      columns: [
        {
          key: 'name',
          title: 'Name',
          type: 'text' as DataTableColumnType,
        },
        {
          key: 'email',
          title: 'Email',
          type: 'text' as DataTableColumnType,
        },
        {
          key: 'role',
          title: 'Role',
          type: 'text' as DataTableColumnType,
        },
        {
          key: 'status',
          title: 'Status',
          type: 'text' as DataTableColumnType,
        },
      ],
    },
  },
};

export const WithActions: Story = {
  args: {
    data: sampleData,
    configuration: {
      columns: [
        {
          key: 'name',
          title: 'Name',
          type: 'text' as DataTableColumnType,
        },
        {
          key: 'email',
          title: 'Email',
          type: 'text' as DataTableColumnType,
        },
        {
          key: 'role',
          title: 'Role',
          type: 'text' as DataTableColumnType,
        },
        {
          key: 'status',
          title: 'Status',
          type: 'text' as DataTableColumnType,
        },
      ],
      actions: {
        copy: {
          handler: (id: string) => {
            navigator.clipboard.writeText(`Copied item ${id}`);
            alert(`Copied item ${id}`);
          },
          label: 'Copy',
          icon: <Icon icon="lucide:copy" width="16" height="16" />,
        },
        delete: {
          handler: (id: string) => {
            if (confirm(`Delete item ${id}?`)) {
              alert(`Deleted item ${id}`);
            }
          },
          label: 'Delete', 
          icon: <Icon icon="lucide:trash-2" width="16" height="16" />,
        },
      },
    },
  },
};

