/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React, {useEffect, useRef} from "react";
import {
  useReactTable,
  getCoreRowModel,
  flexRender,
  getSortedRowModel,
  getPaginationRowModel,
} from "@tanstack/react-table";

import {DataTableProps} from "./types";
import {dataTableStyles} from "./styles";
import {useDataTable, useInfiniteScroll} from "./DataTableCore";

const StylesInjector = () => {
  return <style dangerouslySetInnerHTML={{__html: dataTableStyles}} />;
};

export const DataTableV2 = (props: DataTableProps) => {
  const {data, configuration} = props;
  const tableContainerRef = useRef<HTMLDivElement>(null);

  const {
    paginatedData,
    columnDefs,
    sorting,
    pagination,
    rowSelection,
    columnSizing,
    columnOrder,
    columnResizeMode,
    draggingColumnId,
    dragOverColumnId,
    isResizing,
    totalPages,
    setSorting,
    setPagination,
    setRowSelection,
    setColumnSizing,
    setColumnOrder,
    setDraggingColumnId,
    setDragOverColumnId,
    setIsResizing,
    reorderColumn,
    calculateInitialColumnSizing,
  } = useDataTable(data, configuration);

  const infiniteScrollOptions = configuration.infiniteScroll;
  const isLoadingMore = infiniteScrollOptions?.isLoading || false;
  const isLoading = configuration.isLoading || false;
  const loadingContent = configuration.loadingContent || "Loading...";
  const emptyContent = configuration.emptyContent || "No data available";

  const {scrollerRef, loaderRef} = infiniteScrollOptions
    ? useInfiniteScroll({
        onLoadMore: infiniteScrollOptions.onLoadMore || (() => {}),
        hasMore: infiniteScrollOptions.hasMore || false,
        isLoading: isLoading || infiniteScrollOptions?.isLoading || false,
      })
    : {scrollerRef: useRef<HTMLDivElement>(null), loaderRef: useRef<HTMLDivElement>(null)};

  const table = useReactTable({
    data: paginatedData,
    columns: columnDefs,
    state: {
      sorting,
      pagination,
      rowSelection,
      columnSizing,
      columnOrder,
    },
    enableRowSelection: configuration.selectionMode !== "none",
    enableMultiRowSelection: configuration.selectionMode === "multiple",
    onRowSelectionChange: setRowSelection,
    onSortingChange: setSorting,
    onPaginationChange: setPagination,
    onColumnSizingChange: setColumnSizing,
    onColumnOrderChange: setColumnOrder,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    columnResizeMode,
    manualSorting: false,
    manualPagination: true,
    pageCount: totalPages,
  });

  useEffect(() => {
    console.log(
      "Table columns with sort status:",
      table.getAllColumns().map((col) => ({
        id: col.id,
        canSort: col.getCanSort(),
        isSorted: col.getIsSorted(),
      })),
    );
  }, [table]);

  useEffect(() => {
    if (Object.keys(columnSizing).length === 0) {
      const containerWidth =
        tableContainerRef.current?.querySelector(".data-table")?.clientWidth || 0;

      calculateInitialColumnSizing(containerWidth);
    }
  }, [columnSizing, calculateInitialColumnSizing]);

  const renderPagination = () => {
    const paginationOptions = configuration.pagination;

    if (!paginationOptions) return null;

    const showPagination = paginationOptions.showControls !== false;

    if (!showPagination) return null;

    if (paginationOptions.customPagination) {
      return paginationOptions.customPagination({
        page: pagination.pageIndex + 1,
        rowsPerPage: pagination.pageSize,
        totalItems: paginationOptions.totalItems || data.length,
        totalPages,
        onPageChange: (page) => table.setPageIndex(page - 1),
        onRowsPerPageChange: (size) => table.setPageSize(size),
      });
    }

    return (
      <div
        className={`data-table-pagination ${
          paginationOptions.variant === "bordered" ? "data-table-pagination-bordered" : ""
        }`}
      >
        <div className="data-table-pagination-per-page">
          {paginationOptions.showRowsPerPageSelector && (
            <>
              <span className="data-table-pagination-label">Rows per page:</span>
              <select
                className="data-table-pagination-select"
                value={pagination.pageSize}
                onChange={(e) => {
                  table.setPageSize(Number(e.target.value));
                }}
              >
                {(paginationOptions.rowsPerPageOptions || [10, 25, 50, 100]).map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </>
          )}
        </div>

        <div className="data-table-pagination-controls">
          <span className="data-table-pagination-info">
            Page {pagination.pageIndex + 1} of {totalPages}
          </span>

          <button
            className="data-table-pagination-button"
            disabled={!table.getCanPreviousPage()}
            onClick={() => table.setPageIndex(0)}
          >
            {"<<"}
          </button>

          <button
            className="data-table-pagination-button"
            disabled={!table.getCanPreviousPage()}
            onClick={() => table.previousPage()}
          >
            {"<"}
          </button>

          {Array.from({length: Math.min(5, totalPages)}, (_, i) => {
            let pageNumber;
            const currentPage = pagination.pageIndex + 1;

            if (totalPages <= 5) {
              pageNumber = i + 1;
            } else {
              if (currentPage <= 3) {
                pageNumber = i + 1;
              } else if (currentPage >= totalPages - 2) {
                pageNumber = totalPages - 4 + i;
              } else {
                pageNumber = currentPage - 2 + i;
              }
            }

            return (
              <button
                key={pageNumber}
                className={`data-table-pagination-button ${
                  pageNumber === currentPage ? "data-table-pagination-button-active" : ""
                }`}
                style={{margin: "0 2px"}}
                onClick={() => {
                  table.setPageIndex(pageNumber - 1);
                }}
              >
                {pageNumber}
              </button>
            );
          })}

          <button
            className="data-table-pagination-button"
            disabled={!table.getCanNextPage()}
            onClick={() => table.nextPage()}
          >
            {">"}
          </button>

          <button
            className="data-table-pagination-button"
            disabled={!table.getCanNextPage()}
            onClick={() => table.setPageIndex(table.getPageCount() - 1)}
          >
            {">>"}
          </button>
        </div>
      </div>
    );
  };

  return (
    <div ref={tableContainerRef} className="data-table-wrapper">
      <StylesInjector />
      <div
        ref={scrollerRef as React.RefObject<HTMLDivElement>}
        className="data-table-container"
        style={{
          maxHeight: infiniteScrollOptions?.maxHeight,
          overflowY: "auto",
        }}
      >
        <div
          className={`data-table data-table-sticky-header`}
          style={{
            width: "100%",
            minWidth: table.getTotalSize(),
            tableLayout: "fixed",
          }}
        >
          <div className="data-table-header">
            {table.getHeaderGroups().map((headerGroup) => (
              <div key={headerGroup.id} className="data-table-header-row">
                {headerGroup.headers.map((header) => (
                  <div
                    key={header.id}
                    className={`data-table-header-cell ${
                      header.column.getCanSort()
                        ? "data-table-header-cell-sortable"
                        : "data-table-header-cell-not-sortable"
                    } ${header.column.getIsSorted() ? "data-table-header-cell-sorted" : ""} ${
                      draggingColumnId === header.column.id ? "data-table-header-cell-dragging" : ""
                    } ${
                      dragOverColumnId === header.column.id
                        ? "data-table-header-cell-drag-over"
                        : ""
                    }`}
                    draggable={!isResizing}
                    style={{
                      width: `${header.getSize()}px`,
                      minWidth: `${header.getSize()}px`,
                      maxWidth: `${header.getSize()}px`,
                      position: "relative",
                      cursor: "move",
                    }}
                    onDragEnd={() => {
                      setDraggingColumnId(null);
                      setDragOverColumnId(null);
                    }}
                    onDragEnter={(e) => e.preventDefault()}
                    onDragLeave={() => setDragOverColumnId(null)}
                    onDragOver={(e) => {
                      e.preventDefault();
                      setDragOverColumnId(header.column.id);
                    }}
                    onDragStart={(e) => {
                      if (isResizing || header.column.getIsResizing()) {
                        e.preventDefault();
                        e.stopPropagation();

                        return;
                      }

                      const target = e.target as HTMLElement;

                      if (target.classList.contains("data-table-resizer")) {
                        e.preventDefault();
                        e.stopPropagation();

                        return;
                      }

                      e.dataTransfer.setData("columnId", header.column.id);
                      setDraggingColumnId(header.column.id);
                    }}
                    onDrop={(e) => {
                      e.preventDefault();
                      const draggedColumnId = e.dataTransfer.getData("columnId");

                      if (draggedColumnId && draggedColumnId !== header.column.id) {
                        reorderColumn(draggedColumnId, header.column.id);

                        table.setColumnOrder((prevColumnOrder) => {
                          const updatedOrder = [...prevColumnOrder];
                          const draggedIndex = updatedOrder.indexOf(draggedColumnId);
                          const targetIndex = updatedOrder.indexOf(header.column.id);

                          if (draggedIndex >= 0 && targetIndex >= 0) {
                            updatedOrder.splice(draggedIndex, 1);
                            updatedOrder.splice(targetIndex, 0, draggedColumnId);
                          }

                          return updatedOrder;
                        });
                      }
                      setDraggingColumnId(null);
                      setDragOverColumnId(null);
                    }}
                  >
                    <div
                      className="data-table-header-cell-content"
                      onClick={() => {
                        console.log(
                          `Clicked column: ${
                            header.column.id
                          }, canSort: ${header.column.getCanSort()}`,
                        );

                        if (header.column.getCanSort()) {
                          const currentSort = header.column.getIsSorted();

                          if (!currentSort) {
                            header.column.toggleSorting(false);

                            if (configuration.onSortChange) {
                              configuration.onSortChange(header.column.id, "asc");
                            }
                          } else if (currentSort === "asc") {
                            header.column.toggleSorting(true);

                            if (configuration.onSortChange) {
                              configuration.onSortChange(header.column.id, "desc");
                            }
                          } else {
                            setSorting([]);

                            if (configuration.onSortChange) {
                              configuration.onSortChange(header.column.id, "none");
                            }
                          }
                        }
                      }}
                    >
                      {flexRender(header.column.columnDef.header, header.getContext())}
                      {header.column.getCanSort() && (
                        <span className="data-table-sort-indicator">
                          {
                            {
                              asc: "↑",
                              desc: "↓",
                              false: "",
                            }[(header.column.getIsSorted() as string) || "false"]
                          }
                        </span>
                      )}
                    </div>
                    {header.column.getCanResize() && (
                      <div
                        className={`data-table-resizer ${
                          header.column.getIsResizing() ? "data-table-resizing" : ""
                        }`}
                        draggable={false}
                        onClick={(e) => {
                          e.stopPropagation();
                        }}
                        onDragStart={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                        }}
                        onMouseDown={(e) => {
                          e.stopPropagation();
                          setDraggingColumnId(null);
                          setIsResizing(true);

                          const onMouseUp = () => {
                            setIsResizing(false);
                            document.removeEventListener("mouseup", onMouseUp);
                          };

                          document.addEventListener("mouseup", onMouseUp);

                          header.getResizeHandler()(e);
                        }}
                        onTouchStart={(e) => {
                          e.stopPropagation();
                          setDraggingColumnId(null);
                          setIsResizing(true);

                          const onTouchEnd = () => {
                            setIsResizing(false);
                            document.removeEventListener("touchend", onTouchEnd);
                          };

                          document.addEventListener("touchend", onTouchEnd);

                          header.getResizeHandler()(e);
                        }}
                      />
                    )}
                  </div>
                ))}
              </div>
            ))}
          </div>

          <div className="data-table-body" style={{maxHeight: "100%", overflow: "visible"}}>
            {isLoading ? (
              <div className="data-table-loading">{loadingContent}</div>
            ) : table.getRowModel().rows.length === 0 ? (
              <div className="data-table-empty">{emptyContent}</div>
            ) : (
              table.getRowModel().rows.map((row) => (
                <div
                  key={row.id}
                  className={`data-table-row ${
                    row.getIsSelected() ? "data-table-row-selected" : ""
                  }`}
                  onClick={() => {
                    if (configuration.selectionMode !== "none") {
                      row.toggleSelected();
                    }
                  }}
                >
                  {row.getVisibleCells().map((cell) => (
                    <div
                      key={cell.id}
                      className="data-table-cell"
                      style={{
                        width: `${cell.column.getSize()}px`,
                        minWidth: `${cell.column.getSize()}px`,
                        maxWidth: `${cell.column.getSize()}px`,
                      }}
                    >
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </div>
                  ))}
                </div>
              ))
            )}
          </div>
        </div>

        {infiniteScrollOptions?.hasMore && (
          <div ref={loaderRef as React.RefObject<HTMLDivElement>} className="data-table-loader">
            {infiniteScrollOptions.isLoading || isLoadingMore ? (
              infiniteScrollOptions.loadingContent || <div className="data-table-spinner" />
            ) : (
              <div className="data-table-load-more">Scroll to load more</div>
            )}
          </div>
        )}
      </div>

      {!isLoading && renderPagination()}
    </div>
  );
};
