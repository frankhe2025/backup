export const dataTableStyles = `
  .data-table-wrapper {
    width: 100%;
    font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 14px;
    color: #333;
  }

  .data-table-container {
    position: relative;
    width: 100%;
    overflow-x: auto;
    overflow-y: auto;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    background-color: #fff;
    max-height: 900px;
  }

  .data-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    table-layout: fixed;
    display: inline-block;
    min-width: min-content;
  }

  .data-table-header {
    background-color: #f7fafc;
    position: sticky;
    top: 0;
    z-index: 10;
    border-bottom: 1px solid #e2e8f0;
  }

  .data-table-sticky-header .data-table-header {
    position: sticky !important;
    top: 0 !important;
    z-index: 10 !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    background-color: #f7fafc;
  }

  .data-table-header-row {
    display: flex;
    border-bottom: 1px solid #e2e8f0;
    width: 100%;
  }

  .data-table-header-cell {
    padding: 10px 16px;
    font-weight: 600;
    text-align: left;
    color: #4a5568;
    position: relative;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    border-right: 1px solid #e2e8f0;
    flex: 1 1 0;
    box-sizing: border-box;
    max-width: none !important;
  }

  .data-table-header-cell:last-child {
    border-right: none;
  }

  .data-table-header-cell-sortable {
    cursor: pointer;
  }

  .data-table-header-cell-sortable:hover {
    background-color: #edf2f7;
  }

  .data-table-header-cell-not-sortable {
    cursor: default;
    position: relative;
  }

  .data-table-header-cell-not-sortable:after {
    content: '';
    display: block;
  }

  .data-table-header-cell-sorted {
    background-color: #ebf8ff;
  }

  .data-table-header-cell-sorted:hover {
    background-color: #e6fffa;
  }

  /* Column reordering styles */
  .data-table-header-cell-dragging {
    opacity: 0.7;
    background-color: #ebf8ff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  .data-table-header-cell-drag-over {
    position: relative;
  }

  .data-table-header-cell-drag-over::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 3px;
    background-color: #4299e1;
  }

  .data-table-header-cell-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .data-table-sort-indicator {
    margin-left: 8px;
    color: #4299e1;
    font-weight: bold;
  }

  /* Resizer */
  .data-table-resizer {
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    width: 8px;
    background: rgba(0, 0, 0, 0.05);
    cursor: col-resize;
    user-select: none;
    touch-action: none;
    opacity: 0;
    transition: opacity 0.2s ease;
    z-index: 10;
  }

  .data-table-header-cell:hover .data-table-resizer {
    opacity: 1;
  }

  .data-table-resizing {
    background: rgba(66, 153, 225, 0.4);
    opacity: 1 !important;
    width: 8px;
  }

  .data-table-body {
    position: relative;
  }

  .data-table-row {
    display: flex;
    border-bottom: 1px solid #e2e8f0;
    transition: background-color 0.2s ease;
    width: 100%;
  }

  .data-table-row:last-child {
    border-bottom: none;
  }

  .data-table-row:hover {
    background-color: #f7fafc;
  }

  .data-table-row-selected {
    background-color: #ebf8ff;
  }

  .data-table-row-selected:hover {
    background-color: #e6fffa;
  }

  .data-table-cell {
    padding: 12px 16px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    border-right: 1px solid #e2e8f0;
    flex: 1 1 0;
    box-sizing: border-box;
    max-width: none !important;
  }

  .data-table-cell:last-child {
    border-right: none;
  }

  .data-table-action-button {
    padding: 6px;
    border: none;
    background: none;
    cursor: pointer;
    border-radius: 4px;
    color: #718096;
    transition: color 0.2s ease, background-color 0.2s ease;
  }

  .data-table-action-button:hover {
    color: #2d3748;
    background-color: #edf2f7;
  }

  .data-table-loading,
  .data-table-empty {
    padding: 32px;
    text-align: center;
    color: #718096;
  }

  .data-table-loader {
    display: flex;
    justify-content: center;
    padding: 16px;
    border-top: 1px solid #e2e8f0;
  }

  .data-table-spinner {
    width: 32px;
    height: 32px;
    border: 2px solid #e2e8f0;
    border-top-color: #4299e1;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }

  .data-table-load-more {
    color: #718096;
    font-size: 14px;
  }

  .data-table-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px;
    background-color: #fff;
    border: 1px solid #e2e8f0;
    border-top: none;
    border-radius: 0 0 6px 6px;
  }

  .data-table-pagination-bordered {
    border-top: 1px solid #e2e8f0;
  }

  .data-table-pagination-per-page {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .data-table-pagination-label {
    font-size: 14px;
    color: #718096;
  }

  .data-table-pagination-select {
    padding: 6px 8px;
    border: 1px solid #e2e8f0;
    border-radius: 4px;
    font-size: 14px;
    color: #4a5568;
    background-color: #fff;
    cursor: pointer;
  }

  .data-table-pagination-controls {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .data-table-pagination-info {
    font-size: 14px;
    color: #718096;
    margin-right: 16px;
  }

  .data-table-pagination-button {
    padding: 6px 12px;
    border: 1px solid #e2e8f0;
    border-radius: 4px;
    background-color: #fff;
    font-size: 14px;
    color: #4a5568;
    cursor: pointer;
    transition: background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;
  }

  .data-table-pagination-button:hover:not(:disabled) {
    background-color: #f7fafc;
    border-color: #cbd5e0;
  }

  .data-table-pagination-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .data-table-pagination-button-active {
    background-color: #ebf8ff;
    border-color: #90cdf4;
    color: #3182ce;
  }

  .data-table-pagination-button-active:hover {
    background-color: #e6fffa;
    border-color: #81e6d9;
  }

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }

  .data-table-header-cell[style*="width"] {
    flex: 0 0 auto !important;
  }

  .data-table-cell[style*="width"] {
    flex: 0 0 auto !important;
  }

  .data-table-header-cell:not([style*="width"]) {
    flex: 1 1 0;
  }

  .data-table-cell:not([style*="width"]) {
    flex: 1 1 0;
  }

  .data-table-row {
    table-layout: fixed;
    width: 100%;
  }
  
  .data-table-header-row {
    table-layout: fixed;
    width: 100%;
  }
`;
