import {DataTableState, DataTableService} from "../DataTableCore";
import {DataTableConfiguration} from "../types";

describe("DataTableState", () => {
  it("should create a default state", () => {
    const state = new DataTableState();

    expect(state.sorting).toEqual([]);
    expect(state.pagination).toEqual({pageIndex: 0, pageSize: 10});
    expect(state.rowSelection).toEqual({});
    expect(state.columnOrder).toEqual([]);
    expect(state.draggingColumnId).toBeNull();
    expect(state.isResizing).toBe(false);
  });

  it("should create state from configuration", () => {
    const config: DataTableConfiguration = {
      columns: [
        {key: "name", title: "Name"},
        {key: "age", title: "Age"},
      ],
      sortColumn: "name",
      sortDirection: "asc",
      pagination: {page: 2, rowsPerPage: 20},
    };

    const state = DataTableState.fromConfiguration(config);

    expect(state.sorting).toEqual([{id: "name", desc: false}]);
    expect(state.pagination).toEqual({pageIndex: 1, pageSize: 20});
    expect(state.columnOrder).toEqual(["name", "age"]);
  });

  it("should create state with actions column from configuration", () => {
    const config: DataTableConfiguration = {
      columns: [
        {key: "name", title: "Name"},
        {key: "age", title: "Age"},
      ],
      actions: {
        edit: {handler: () => {}},
      },
    };

    const state = DataTableState.fromConfiguration(config);

    expect(state.columnOrder).toEqual(["name", "age", "actions"]);
  });

  it("should create state with actions column from configuration", () => {
    const config: DataTableConfiguration = {
      columns: [
        {key: "name", title: "Name"},
        {key: "age", title: "Age"},
      ],
      actions: {
        edit: {handler: () => {}},
      },
    };

    const state = DataTableState.fromConfiguration(config);

    expect(state.columnOrder).toEqual(["name", "age", "actions"]);
  });

  it("should handle custom column order from configuration", () => {
    const config: DataTableConfiguration = {
      columns: [
        {key: "name", title: "Name"},
        {key: "age", title: "Age"},
        {key: "email", title: "Email"},
      ],
      columnOrder: ["age", "name", "email"],
    };

    const state = DataTableState.fromConfiguration(config);

    expect(state.columnOrder).toEqual(["age", "name", "email"]);
  });

  it("should update state immutably", () => {
    const state = new DataTableState();

    const newSorting = [{id: "name", desc: false}];
    const stateWithSorting = new DataTableState(
      newSorting,
      state.pagination,
      state.rowSelection,
      state.columnVisibility,
      state.columnOrder,
      state.columnSizing,
      state.expanded,
      state.draggingColumnId,
      state.dragOverColumnId,
      state.isResizing,
    );

    expect(state.sorting).toEqual([]);
    expect(stateWithSorting.sorting).toEqual(newSorting);
    expect(stateWithSorting.pagination).toEqual(state.pagination);
  });

  it("should reorder columns", () => {
    const state = new DataTableState([], {pageIndex: 0, pageSize: 10}, {}, {}, [
      "name",
      "age",
      "email",
    ]);

    const newState = state.reorderColumn("email", "name");

    expect(newState.columnOrder).toEqual(["email", "name", "age"]);
  });
});

describe("DataTableService", () => {
  const mockData = [
    {id: "1", name: "John", age: 30},
    {id: "2", name: "Jane", age: 25},
    {id: "3", name: "Bob", age: 40},
  ];

  const mockConfig: DataTableConfiguration = {
    columns: [
      {key: "name", title: "Name"},
      {key: "age", title: "Age"},
    ],
  };

  it("should create a service from configuration", () => {
    const service = DataTableService.fromConfiguration(mockConfig, mockData);

    expect(service.getState().columnOrder).toEqual(["name", "age"]);
  });

  it("should get paginated data", () => {
    const state = new DataTableState([], {pageIndex: 0, pageSize: 2}, {}, {}, ["name", "age"]);

    const service = new DataTableService(state, mockData, {
      ...mockConfig,
      pagination: {
        page: 1,
        rowsPerPage: 2,
        applyPagination: true,
      },
    });

    const paginatedData = service.getPaginatedData();

    expect(paginatedData.length).toBe(2);
    expect(paginatedData[0].id).toBe("1");
    expect(paginatedData[1].id).toBe("2");
  });

  it("should calculate total pages", () => {
    const state = new DataTableState([], {pageIndex: 0, pageSize: 2}, {}, {}, ["name", "age"]);

    const service = new DataTableService(state, mockData, {
      ...mockConfig,
      pagination: {rowsPerPage: 2},
    });

    expect(service.getTotalPages()).toBe(2);
  });

  it("should get selected ids", () => {
    const state = new DataTableState([], {pageIndex: 0, pageSize: 10}, {"0": true, "2": true}, {}, [
      "name",
      "age",
    ]);

    const service = new DataTableService(state, mockData, mockConfig);
    const selectedIds = service.getSelectedIds();

    expect(selectedIds.size).toBe(2);
    expect(selectedIds.has("1")).toBe(true);
    expect(selectedIds.has("3")).toBe(true);
  });

  it("should get column definitions", () => {
    const service = DataTableService.fromConfiguration(mockConfig, mockData);
    const columnDefs = service.getColumnDefs();

    expect(columnDefs.length).toBe(2);
    expect(columnDefs[0].id).toBe("name");
    expect(columnDefs[1].id).toBe("age");
  });

  it("should add actions column when no saved order exists", () => {
    const config: DataTableConfiguration = {
      columns: [
        {key: "name", title: "Name"},
        {key: "email", title: "Email"},
      ],
      actions: {
        copy: {handler: () => {}, icon: "📋"},
        delete: {handler: () => {}, icon: "🗑️"},
      },
    };

    const service = DataTableService.fromConfiguration(config, []);
    const columns = service.getAllColumns();

    expect(columns).toHaveLength(3);
    expect(columns.map(col => col.key)).toEqual(["name", "email", "actions"]);
  });

  it("should NOT add actions column when saved order includes actions", () => {
    const config: DataTableConfiguration = {
      columns: [
        {key: "name", title: "Name"},
        {key: "email", title: "Email"},
      ],
      actions: {
        copy: {handler: () => {}, icon: "📋"},
        delete: {handler: () => {}, icon: "🗑️"},
      },
      columnOrder: ["email", "actions", "name"], 
    };

    const service = DataTableService.fromConfiguration(config, []);
    const columns = service.getAllColumns();

    expect(columns).toHaveLength(2); 
    expect(columns.map(col => col.key)).toEqual(["name", "email"]);
  });

  it("should add actions column when saved order exists but doesn't include actions", () => {
    const config: DataTableConfiguration = {
      columns: [
        {key: "name", title: "Name"},
        {key: "email", title: "Email"},
      ],
      actions: {
        copy: {handler: () => {}, icon: "📋"},
        delete: {handler: () => {}, icon: "🗑️"},
      },
      columnOrder: ["email", "name"], 
    };

    const service = DataTableService.fromConfiguration(config, []);
    const columns = service.getAllColumns();

    expect(columns).toHaveLength(3);
    expect(columns.map(col => col.key)).toEqual(["name", "email", "actions"]);
  });

  it("should not add actions column when actions already in base columns", () => {
    const config: DataTableConfiguration = {
      columns: [
        {key: "name", title: "Name"},
        {key: "actions", title: "Actions"}, 
        {key: "email", title: "Email"},
      ],
      actions: {
        copy: {handler: () => {}, icon: "📋"},
        delete: {handler: () => {}, icon: "🗑️"},
      },
    };

    const service = DataTableService.fromConfiguration(config, []);
    const columns = service.getAllColumns();

    expect(columns).toHaveLength(3);
    expect(columns.map(col => col.key)).toEqual(["name", "actions", "email"]);
  });
});
