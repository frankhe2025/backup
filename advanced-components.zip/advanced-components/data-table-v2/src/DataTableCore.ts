import React, {ReactNode, useEffect, useMemo, useRef, useState} from "react";
import {
  SortingState,
  PaginationState,
  RowSelectionState,
  ColumnSizingState,
  ColumnResizeMode,
  ColumnDef,
  OnChangeFn,
} from "@tanstack/react-table";

import {DataTableConfiguration, DataTableColumn} from "./types";

export class DataTableState {
  constructor(
    public readonly sorting: SortingState = [],
    public readonly pagination: PaginationState = {pageIndex: 0, pageSize: 10},
    public readonly rowSelection: RowSelectionState = {},
    public readonly columnVisibility: Record<string, boolean> = {},
    public readonly columnOrder: string[] = [],
    public readonly columnSizing: ColumnSizingState = {},
    public readonly expanded: Record<string, boolean> = {},
    public readonly draggingColumnId: string | null = null,
    public readonly dragOverColumnId: string | null = null,
    public readonly isResizing: boolean = false,
  ) {}

  static fromConfiguration(config: DataTableConfiguration): DataTableState {
    const sortingState: SortingState =
      config.sortColumn && config.sortDirection !== "none"
        ? [{id: config.sortColumn, desc: config.sortDirection === "desc"}]
        : [];

    const paginationState: PaginationState = {
      pageIndex: (config.pagination?.page || 1) - 1,
      pageSize: config.pagination?.rowsPerPage || 10,
    };

    const columnOrderState = config.columnOrder || config.columns.map((col) => col.key);

    return new DataTableState(sortingState, paginationState, {}, {}, columnOrderState);
  }

  withColumnOrder(columnOrder: string[]): DataTableState {
    return new DataTableState(
      this.sorting,
      this.pagination,
      this.rowSelection,
      this.columnVisibility,
      columnOrder,
      this.columnSizing,
      this.expanded,
      this.draggingColumnId,
      this.dragOverColumnId,
      this.isResizing,
    );
  }

  reorderColumn(draggedColumnId: string, targetColumnId: string): DataTableState {
    if (draggedColumnId === targetColumnId) return this;

    const newColumnOrder = [...this.columnOrder];
    const draggedIndex = newColumnOrder.indexOf(draggedColumnId);
    const targetIndex = newColumnOrder.indexOf(targetColumnId);

    if (draggedIndex < 0 || targetIndex < 0) return this;

    newColumnOrder.splice(draggedIndex, 1);
    newColumnOrder.splice(targetIndex, 0, draggedColumnId);

    return this.withColumnOrder(newColumnOrder);
  }

  syncColumnOrder(allColumns: DataTableColumn[], hasActions: boolean): DataTableState {
    let newColumnOrder = [...this.columnOrder];
    const allColumnKeys = allColumns.map((col) => col.key);

    if (hasActions && !newColumnOrder.includes("actions")) {
      newColumnOrder.push("actions");
    }

    for (const colKey of allColumnKeys) {
      if (!newColumnOrder.includes(colKey)) {
        newColumnOrder.push(colKey);
      }
    }

    newColumnOrder = newColumnOrder.filter(
      (colKey) => (colKey === "actions" && hasActions) || allColumnKeys.includes(colKey),
    );

    if (
      newColumnOrder.length !== this.columnOrder.length ||
      !newColumnOrder.every((col, i) => col === this.columnOrder[i])
    ) {
      return this.withColumnOrder(newColumnOrder);
    }

    return this;
  }
}

export class DataTableService {
  constructor(
    private readonly state: DataTableState,
    private readonly data: any[],
    private readonly configuration: DataTableConfiguration,
  ) {}

  static fromConfiguration(config: DataTableConfiguration, data: any[]): DataTableService {
    const configWithDefaults = {
      ...config,
      isHeaderSticky: true,
    };

    const state = DataTableState.fromConfiguration(configWithDefaults);

    return new DataTableService(state, data, configWithDefaults);
  }

  getState(): DataTableState {
    return this.state;
  }

  getData(): any[] {
    return this.data;
  }

  getConfiguration(): DataTableConfiguration {
    return this.configuration;
  }

  getColumnDefs(): ColumnDef<any>[] {
    const allColumns = this.getAllColumns();

    return allColumns.map((col) => ({
      accessorKey: col.key,
      id: col.key,
      header: col.title,
      enableSorting: col.sortable !== false,
      enableResizing: col.resizable !== false,
      minSize: col.minWidth || 50,
      size: col.width ? (typeof col.width === "string" ? parseInt(col.width) : col.width) : 150,
      cell: (info) => this.renderCell(info, col),
    }));
  }

  getAllColumns(): DataTableColumn[] {
    let columns = [...this.configuration.columns];

    const hasSavedOrder = this.configuration.columnOrder && this.configuration.columnOrder.length > 0;
    const actionsInSavedOrder = hasSavedOrder && this.configuration.columnOrder!.includes("actions");
    const actionsAlreadyInColumns = columns.some((col) => col.key === "actions");

    if (this.configuration.actions && 
        !actionsAlreadyInColumns && 
        (!hasSavedOrder || !actionsInSavedOrder)) {
      const actionsColumn = {key: "actions", title: "Actions"};
      columns.push(actionsColumn);
    }

    return columns;
  }

  private renderCell(info: any, col: DataTableColumn): ReactNode {
    const item = info.row.original;
    const value = item[col.key];

    if (col.cellRenderer) {
      return col.cellRenderer(value, item, col.key, col.type);
    }

    if (col.key === "actions" && this.configuration.actions) {
      if (this.configuration.actionRenderer) {
        return this.configuration.actionRenderer(item, this.configuration.actions);
      }

      const actionButtons = Object.entries(this.configuration.actions)
        .filter(([_, action]) => action && typeof action === "object" && "handler" in action && action.icon)
        .map(([key, action]) => {
          const actionConfig = action as { handler: (id: string) => void; label?: string; icon: ReactNode };
          return React.createElement('button', {
            key: key,
            onClick: () => actionConfig.handler(item.id),
            title: actionConfig.label || key,
            style: { marginRight: '4px', background: 'none', border: 'none', cursor: 'pointer' }
          }, actionConfig.icon);
        });

      return React.createElement('div', { style: { textAlign: 'center' } }, ...actionButtons);
    }

    if (this.configuration.defaultCellRenderer) {
      return this.configuration.defaultCellRenderer(value, item, col.key, col.type);
    }

    return value != null ? String(value) : "";
  }

  getPaginatedData(): any[] {
    if (!this.configuration.pagination || this.configuration.pagination.applyPagination === false) {
      return this.data;
    }

    const {pageIndex, pageSize} = this.state.pagination;
    const start = pageIndex * pageSize;
    const end = start + pageSize;

    return this.data.slice(start, end);
  }

  getTotalPages(): number {
    const totalItems = this.configuration.pagination?.totalItems || this.data.length;
    const pageSize = this.state.pagination.pageSize;

    return Math.max(1, Math.ceil(totalItems / pageSize));
  }

  getSelectedIds(): Set<string | number> {
    const selectedKeys = new Set<string | number>();

    Object.keys(this.state.rowSelection).forEach((key) => {
      const item = this.data[parseInt(key, 10)];

      if (item?.id) {
        selectedKeys.add(item.id);
      } else {
        selectedKeys.add(key);
      }
    });

    return selectedKeys;
  }

  calculateInitialColumnSizing(containerWidth: number): ColumnSizingState {
    const allColumns = this.getAllColumns();
    const initialSizing: Record<string, number> = {};

    if (containerWidth > 0 && allColumns.length > 0) {
      let usedWidth = 0;
      let columnsWithoutWidth = 0;

      allColumns.forEach((column) => {
        if (column.width) {
          const width = typeof column.width === "string" ? parseInt(column.width) : column.width;

          initialSizing[column.key] = width;
          usedWidth += width;
        } else {
          columnsWithoutWidth++;
        }
      });

      const remainingWidth = Math.max(0, containerWidth - usedWidth);
      const defaultWidth =
        columnsWithoutWidth > 0
          ? Math.max(150, Math.floor(remainingWidth / columnsWithoutWidth))
          : 150;

      allColumns.forEach((column) => {
        if (!initialSizing[column.key]) {
          initialSizing[column.key] = defaultWidth;
        }
      });
    }

    return initialSizing;
  }
}

export function useInfiniteScroll(options: {
  onLoadMore: () => void;
  hasMore: boolean;
  isLoading: boolean;
}) {
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const loaderRef = useRef<HTMLDivElement | null>(null);
  const {onLoadMore, hasMore, isLoading} = options;

  useEffect(() => {
    const loader = loaderRef.current;
    const scroller = scrollerRef.current;

    if (!loader || !scroller || !hasMore || isLoading) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoading) {
          onLoadMore();
        }
      },
      {root: scroller, threshold: 0.1},
    );

    observer.observe(loader);

    return () => {
      observer.disconnect();
    };
  }, [hasMore, isLoading, onLoadMore]);

  return {scrollerRef, loaderRef};
}

export function useDataTable(data: any[], configuration: DataTableConfiguration) {
  const [service, setService] = useState(() =>
    DataTableService.fromConfiguration(configuration, data),
  );

  const state = service.getState();

  const [sorting, setSorting] = useState<SortingState>(state.sorting);
  const [pagination, setPagination] = useState<PaginationState>(state.pagination);
  const [rowSelection, setRowSelection] = useState<RowSelectionState>(state.rowSelection);
  const [columnSizing, setColumnSizing] = useState<ColumnSizingState>(state.columnSizing);
  const [columnOrder, setColumnOrder] = useState<string[]>(state.columnOrder);
  const [draggingColumnId, setDraggingColumnId] = useState<string | null>(state.draggingColumnId);
  const [dragOverColumnId, setDragOverColumnId] = useState<string | null>(state.dragOverColumnId);
  const [isResizing, setIsResizing] = useState<boolean>(state.isResizing);
  const [columnResizeMode] = useState<ColumnResizeMode>("onChange");

  useEffect(() => {
    setService((prev) => new DataTableService(prev.getState(), data, configuration));
  }, [data, configuration]);

  useEffect(() => {
    if (configuration.sortColumn && configuration.sortDirection !== "none") {
      setSorting([{id: configuration.sortColumn, desc: configuration.sortDirection === "desc"}]);
    } else {
      setSorting([]);
    }
  }, [configuration.sortColumn, configuration.sortDirection]);

  useEffect(() => {
    setPagination({
      pageIndex: (configuration.pagination?.page || 1) - 1,
      pageSize: configuration.pagination?.rowsPerPage || 10,
    });
  }, [configuration.pagination?.page, configuration.pagination?.rowsPerPage]);

  useEffect(() => {
    if (configuration.columnOrder && configuration.columnOrder.length) {
      let newOrder = [...configuration.columnOrder];

      if (configuration.actions && !newOrder.includes("actions")) {
        newOrder.push("actions");
      }
      setColumnOrder(newOrder);
    } else {
      const allColumns = service.getAllColumns();
      const defaultOrder = allColumns.map((col) => col.key);

      setColumnOrder(defaultOrder);
    }
  }, [configuration.columnOrder, configuration.actions, service]);

  useEffect(() => {
    const allColumns = service.getAllColumns();
    const hasActions = !!configuration.actions;

    const newState = state.syncColumnOrder(allColumns, hasActions);

    if (newState !== state) {
      setColumnOrder(newState.columnOrder);
    }
  }, [service, state, configuration.actions]);

  useEffect(() => {
    if (configuration.onSelectionChange) {
      const selectedKeys = service.getSelectedIds();

      configuration.onSelectionChange(selectedKeys);
    }
  }, [rowSelection, configuration, service]);

  useEffect(() => {
    if (configuration.onSort && sorting.length > 0) {
      const sortColumn = sorting[0].id;

      if (configuration.onColumnHeaderClick) {
        configuration.onColumnHeaderClick(sortColumn);
      }

      if (configuration.onSort) {
        configuration.onSort(sortColumn);
      }
    }
  }, [sorting, configuration]);

  useEffect(() => {
    if (
      configuration.pagination?.onPageChange &&
      pagination.pageIndex + 1 !== configuration.pagination.page
    ) {
      configuration.pagination.onPageChange(pagination.pageIndex + 1);
    }

    if (
      configuration.pagination?.onRowsPerPageChange &&
      pagination.pageSize !== configuration.pagination.rowsPerPage
    ) {
      configuration.pagination.onRowsPerPageChange(pagination.pageSize);
    }
  }, [pagination, configuration.pagination]);

  const paginatedData = useMemo(() => {
    return service.getPaginatedData();
  }, [service]);

  const columnDefs = useMemo(() => {
    return service.getColumnDefs();
  }, [service]);

  const totalPages = service.getTotalPages();

  const reorderColumn = (draggedColumnId: string, targetColumnId: string): void => {
    if (draggedColumnId === targetColumnId) return;

    const newState = state.reorderColumn(draggedColumnId, targetColumnId);

    setColumnOrder(newState.columnOrder);

    setService((prev) => new DataTableService(newState, prev.getData(), prev.getConfiguration()));

    if (configuration.onColumnOrderChange) {
      configuration.onColumnOrderChange(newState.columnOrder);
    }
  };

  const calculateInitialColumnSizing = (containerWidth: number) => {
    if (Object.keys(columnSizing).length === 0 && containerWidth > 0) {
      const initialSizing = service.calculateInitialColumnSizing(containerWidth);

      setColumnSizing(initialSizing);
    }
  };

  const handleSortingChange: OnChangeFn<SortingState> = (updater) => {
    setSorting(updater);

    if (typeof updater === "function") {
      const newSorting = updater(sorting);

      if (newSorting.length > 0) {
        const column = newSorting[0].id;
        const direction = newSorting[0].desc ? "desc" : "asc";

        configuration.onSortChange?.(column, direction);
      } else if (sorting.length > 0) {
        configuration.onSortChange?.(sorting[0].id, "none");
      }
    } else if (updater.length > 0) {
      const column = updater[0].id;
      const direction = updater[0].desc ? "desc" : "asc";

      configuration.onSortChange?.(column, direction);
    } else if (sorting.length > 0) {
      configuration.onSortChange?.(sorting[0].id, "none");
    }
  };

  return {
    service,
    state,
    paginatedData,
    columnDefs,
    sorting,
    pagination,
    rowSelection,
    columnSizing,
    columnOrder,
    columnResizeMode,
    draggingColumnId,
    dragOverColumnId,
    isResizing,
    totalPages,
    setSorting: handleSortingChange,
    setPagination,
    setRowSelection,
    setColumnSizing,
    setColumnOrder,
    setDraggingColumnId,
    setDragOverColumnId,
    setIsResizing,
    reorderColumn,
    calculateInitialColumnSizing,
  };
}
