# @aisera-ui/data-table-v2

this is a v2 table component

Please refer to the [documentation](https://aisera.com/docs/components/data-table-v2) for more information.

## Installation

```sh
yarn add @aisera-ui/data-table-v2
# or
npm i @aisera-ui/data-table-v2
```

## Contribution

Yes please! See the
[contributing guidelines](https://github.com/Aisera/ng-uicomponent/blob/master/CONTRIBUTING.md)
for details.
