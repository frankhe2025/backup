# @aisera-ui/icons

Aisera icons for iconify project

Please refer to the [documentation](https://aisera.com/docs/components/icons) for more information.

## Installation

```sh
yarn add @aisera-ui/icons
# or
npm i @aisera-ui/icons
```

## Contribution

Yes please! See the
[contributing guidelines](https://github.com/Aisera/ng-uicomponent/blob/master/CONTRIBUTING.md)
for details.
