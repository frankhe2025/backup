import aiBaseJson from "../output/json/ai-base.json";
import aiBrandJson from "../output/json/ai-brand.json";

export {aiBaseJson, aiBrandJson};
