/* eslint-disable-file no-console */
import type {IconifyInfo} from "@iconify/types";

import {promises as fs} from "fs";

import {importDirectory, cleanupSVG, parseColors, isEmptyColor, runSVGO} from "@iconify/tools";

// Directory for svg files
const sourceDirectory = "assets/svgs";

// Themes to parse
const themes = ["base", "brand"];

// Directory to export icon sets to
const targetDirectory = "output/json";

// Information
const baseInfo: IconifyInfo = {
  name: "Aisera Icons",
  author: {
    name: "Aisera",
  },
  license: {
    title: "Private",
  },
  height: 32, // It can be arrary as well. Depending on svg height.
};

// Base prefix without theme
const basePrefix = "ai-";

// Do stuff
(async function () {
  // Create directory for output if missing
  try {
    await fs.mkdir(targetDirectory, {
      recursive: true,
    });
  } catch (err) {
    //
  }

  // Parse all configured themes
  for (let i = 0; i < themes.length; i++) {
    const theme = themes[i];
    const source = sourceDirectory + "/" + theme;
    const prefix = basePrefix + theme;

    // Import icons
    const iconSet = await importDirectory(source, {
      prefix,
    });

    // Set info
    const info: IconifyInfo = JSON.parse(JSON.stringify(baseInfo));
    const themeName = theme.toUpperCase().slice(0, 1) + theme.slice(1);

    info.name += " " + themeName;
    iconSet.info = info;

    // Validate, clean up, fix palette and optimise
    iconSet.forEachSync((name, type) => {
      if (type !== "icon") {
        return;
      }

      // Get SVG instance for parsing
      const svg = iconSet.toSVG(name);

      if (!svg) {
        // Invalid icon
        iconSet.remove(name);

        return;
      }

      // Clean up and optimise icons
      try {
        // Clean up icon code
        cleanupSVG(svg);

        // Replace color with currentColor, add if missing
        parseColors(svg, {
          defaultColor: "currentColor",
          callback: (attr, colorStr, color) => {
            return !color || isEmptyColor(color) ? colorStr : "currentColor";
          },
        });

        // Optimise
        runSVGO(svg);
      } catch (err) {
        // Invalid icon
        // console.error(`Error parsing ${name}:`, err);
        iconSet.remove(name);

        return;
      }

      // Update icon from SVG instance
      iconSet.fromSVG(name, svg);
    });
    // console.log(`Imported ${iconSet.count()} icons for ${info.name}`);

    // Export to IconifyJSON, convert to string
    const output = JSON.stringify(iconSet.export(), null, "\t");

    // Save to file
    const target = targetDirectory + "/" + prefix + ".json";

    await fs.writeFile(target, output, "utf8");

    // console.log(`Saved ${target} (${output.length} bytes)`);
  }
})().catch((_err) => {
  // console.error(_err);
});
