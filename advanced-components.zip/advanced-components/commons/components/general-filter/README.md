# @aisera-ui/general-filter

Please refer to the [documentation](https://aisera.com/docs/components/feature-flags) for more
information.

## Installation

```sh
yarn add @aisera-ui/general-filter
# or
npm i @aisera-ui/general-filter
```

## Contribution

Yes please! See the
[contributing guidelines](https://github.com/Aisera/ng-uicomponent/blob/master/CONTRIBUTING.md)
for details.
