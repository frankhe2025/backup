import {render, screen} from "@testing-library/react";

import FilterItem from "../../../src/entities/filter_item";
import getFilterConfigMock from "../../../src/mock/entities/filter_config.mock";
import DateSelectComponent from "../../../src/components/date-component/date-select.component";
import FinalFilters from "../../../src/entities/final_filters";

const config = {
  filterItem: new FilterItem(getFilterConfigMock().filterItems[2]),
  finalFilters: new FinalFilters(),
  setFinalFilters: () => {},
};

describe("DateSelectComponent", () => {
  it("should rende date selector", async () => {
    render(<DateSelectComponent {...config} />);
    const btnTrigger = await screen.findByTestId("dateselector-trigger-btn", {}, {timeout: 5000});

    expect(btnTrigger).toBeInTheDocument();
    btnTrigger.click();
    const options = await screen.findAllByTestId("dateselector-option-item", {}, {timeout: 5000});

    expect(options.length).toEqual(config.filterItem.options?.length);
    const customItem = await screen.findByTestId(
      "dateselector-option-custom-item",
      {},
      {timeout: 5000},
    );

    expect(customItem).toBeInTheDocument();
    // now trigger model
    customItem.click();
    const customModelHeader = await screen.findByTestId(
      "dateselector-custom-model-header",
      {},
      {timeout: 5000},
    );

    expect(customModelHeader).toBeInTheDocument();
    expect(customModelHeader).toHaveTextContent("Select custom range");
  });

  it("will update the title when option selected", async () => {
    render(<DateSelectComponent {...config} />);
    const btnTrigger = await screen.findByTestId("dateselector-trigger-btn", {}, {timeout: 5000});

    expect(btnTrigger.textContent).toEqual("Label 3: ");
    expect(btnTrigger).toBeInTheDocument();
    btnTrigger.click();
    const options = await screen.findAllByTestId("dateselector-option-item", {}, {timeout: 5000});

    options[1].click();
  });
});
