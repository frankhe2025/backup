import {render, screen} from "@testing-library/react";

import FilterItem from "../../../src/entities/filter_item";
import getFilterConfigMock from "../../../src/mock/entities/filter_config.mock";
import FinalFilters from "../../../src/entities/final_filters";
import TextComponent from "../../../src/components/text-component/text.component";

const config = {
  filterItem: new FilterItem(getFilterConfigMock().filterItems[3]),
  finalFilters: new FinalFilters(),
  setFinalFilters: () => {},
};

describe("TextComponent", () => {
  it("should rende TextComponent", async () => {
    render(<TextComponent {...config} />);
    const input = await screen.findByTestId("text-component-input", {}, {timeout: 5000});

    expect(input).toBeInTheDocument();
  });
});
