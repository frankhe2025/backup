import {render, screen} from "@testing-library/react";

import GeneralFilterComponent from "../src/general-filter.component";
import FilterConfig from "../src/entities/filter_config";
import FinalFilters from "../src/entities/final_filters";

import getFilterConfigMock from "../src/mock/entities/filter_config.mock";

describe("GeneralFilterComponent", () => {
  it("Should render correctly", async () => {
    const generalFilterAtt = {
      filterConfig: new FilterConfig(getFilterConfigMock()),
      setFilterConfig: () => {},
      finalFilters: new FinalFilters(),
      setFinalFilters: () => {},
      saveable: false,
    };
    const wrapper = render(<GeneralFilterComponent {...generalFilterAtt} />);
    const filterIems = await screen.findAllByTestId("general-filter-item-close");

    expect(filterIems.length).toEqual(2);
    expect(() => wrapper.unmount()).not.toThrow();
  });
});
