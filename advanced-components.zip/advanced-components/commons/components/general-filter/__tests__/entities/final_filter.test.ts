import {FilterOperand, FinalFilter} from "../../src/entities/final_filters";

describe("FinalFilter", () => {
  it("constructor", () => {
    const finalFilter = new FinalFilter({
      key: "key1",
      operand: FilterOperand.LIKE,
      value: "abc",
    });

    expect(finalFilter.key).toEqual("key1");
    expect(finalFilter.operand).toEqual("Like");
    expect(finalFilter.value).toEqual("abc");

    const finalFilter1 = new FinalFilter({
      key: "key1",
      operand: FilterOperand.Include,
      value: ["a", "b"],
    });

    expect(finalFilter1.key).toEqual("key1");
    expect(finalFilter1.operand).toEqual("Include");
    expect(finalFilter1.value).toEqual(["a", "b"]);

    const finalFilter3 = new FinalFilter({
      key: "key1",
      operand: FilterOperand.Within,
      value: 12345,
    });

    expect(finalFilter3.key).toEqual("key1");
    expect(finalFilter3.operand).toEqual("Within");
    expect(finalFilter3.value).toEqual(12345);
  });

  it("isEmpty()", () => {
    let finalFilter = new FinalFilter({
      key: "key1",
      operand: FilterOperand.LIKE,
      value: "",
    });

    expect(finalFilter.isEmpty).toBeTruthy();
    finalFilter.value = null;
    expect(finalFilter.isEmpty).toBeTruthy();
    finalFilter.value = [];
    expect(finalFilter.isEmpty).toBeTruthy();
  });

  it("getDisplayedTitle()", () => {
    let filter = new FinalFilter({
      operand: FilterOperand.Between,
      value: [new Date("2023-01-01 12:00:00").getTime(), new Date("2023-01-10 12:00:00").getTime()],
    });

    expect(filter.getDisplayedTitle()).toEqual("Between 1/1/23 and 1/10/23");

    filter = new FinalFilter({
      operand: FilterOperand.Within,
      value: "1d",
    });
    expect(filter.getDisplayedTitle()).toEqual("Within 1 Day");

    filter = new FinalFilter({
      operand: FilterOperand.Within,
      value: "2m",
    });
    expect(filter.getDisplayedTitle()).toEqual("Within 2 Months");

    filter = new FinalFilter({
      operand: FilterOperand.Within,
      value: "2h",
    });
    expect(filter.getDisplayedTitle()).toEqual("Within 2 Hours");

    filter = new FinalFilter({
      operand: FilterOperand.Include,
      value: ["a", "b"],
    });
    expect(filter.getDisplayedTitle()).toEqual("Include [a, b]");

    filter = new FinalFilter({
      operand: FilterOperand.LIKE,
      value: "a",
    });
    expect(filter.getDisplayedTitle()).toEqual("a");
  });

  it("updateArrayTypeValue()", () => {
    let filter = new FinalFilter({
      value: [],
    });

    filter.updateArrayTypeValue("a");
    expect(filter.value).toEqual(["a"]);

    filter.updateArrayTypeValue("a");
    expect(filter.value).toEqual([]);

    filter.updateArrayTypeValue("a");
    filter.updateArrayTypeValue("b");
    expect(filter.value).toEqual(["a", "b"]);

    filter.updateValue(["c"]);
    expect(filter.value).toEqual(["c"]);
  });
});
