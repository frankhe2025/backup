import FilterConfig, {GLOBAL_SEARCH_KEY} from "../../src/entities/filter_config";
import getFilterConfigMock from "../../src/mock/entities/filter_config.mock";
import FilterItem from "../../src/entities/filter_item";
import {SavedFilter} from "../../src/entities/saved-filter";

describe("FilterConfig", () => {
  let filterConfig = null;

  beforeEach(() => {
    filterConfig = new FilterConfig(getFilterConfigMock());
  });
  it("setGlobalSearch", () => {
    expect(filterConfig.globalSearchable).toBeTruthy();
    const cfg = getFilterConfigMock();

    cfg["globalSearchable"] = true;
    expect(new FilterConfig(cfg).globalSearchable).toBeTruthy();
    cfg["globalSearchable"] = false;
    expect(new FilterConfig(cfg).globalSearchable).toBeFalsy();
  });
  it("Initialized", () => {
    expect(filterConfig).toBeTruthy();
    expect(filterConfig.filterItems.length > 0).toBe(true);
    expect(filterConfig.filterItems[0].key).toBe("key1");
    expect(filterConfig.defaultFilters.length).toBe(2);
  });

  it("filterItemsInUse", () => {
    let inUsedItems = filterConfig.filterItemsInUse;

    expect(inUsedItems.length).toEqual(3);
    expect(inUsedItems[0].key).toEqual(GLOBAL_SEARCH_KEY);

    let cfg = getFilterConfigMock();

    cfg["globalSearchable"] = true;
    inUsedItems = new FilterConfig(cfg).filterItemsInUse;

    expect(inUsedItems.length).toEqual(3);
    expect(inUsedItems[0].key).toEqual(GLOBAL_SEARCH_KEY);

    cfg = getFilterConfigMock();
    cfg["globalSearchable"] = false;
    inUsedItems = new FilterConfig(cfg).filterItemsInUse;

    expect(inUsedItems.length).toEqual(2);
  });

  it("clone", () => {
    const clonedItem = filterConfig.clone;

    expect(clonedItem.filterItems.length).toEqual(filterConfig.filterItems.length);
  });

  it("isFilterItemInUse", () => {
    expect(
      filterConfig.isFilterItemInUse(
        new FilterItem({
          key: "key2",
          label: "Label 2",
          type: "MULTI_SELECT",
          options: [
            {value: "option1", label: "Option 1"},
            {value: "option2", label: "Option 2"},
            {value: "option3", label: "Option 3"},
            {value: "option4", label: "Option 4"},
          ],
        }),
      ),
    ).toBeTruthy();
    expect(
      filterConfig.isFilterItemInUse(
        new FilterItem({
          key: "key1",
          label: "Label 1",
          type: "SINGLE_SELECT",
          options: [
            {value: "option1", label: "Option 1"},
            {value: "option2", label: "Option 2"},
            {value: "option3", label: "Option 3"},
            {value: "option4", label: "Option 4"},
          ],
        }),
      ),
    ).toBeFalsy();
  });

  it("toggleDefaultFilters(filterItem: FilterItem) ", () => {
    expect(filterConfig.defaultFilters).toEqual(["key2", "key5"]);
    filterConfig.toggleDefaultFilters(
      new FilterItem({
        key: "key1",
        label: "Label 1",
        type: "SINGLE_SELECT",
        options: [
          {value: "option1", label: "Option 1"},
          {value: "option2", label: "Option 2"},
          {value: "option3", label: "Option 3"},
          {value: "option4", label: "Option 4"},
        ],
      }),
    );
    expect(filterConfig.defaultFilters).toEqual(["key2", "key5", "key1"]);
    filterConfig.toggleDefaultFilters(
      new FilterItem({
        key: "key1",
        label: "Label 1",
        type: "SINGLE_SELECT",
        options: [
          {value: "option1", label: "Option 1"},
          {value: "option2", label: "Option 2"},
          {value: "option3", label: "Option 3"},
          {value: "option4", label: "Option 4"},
        ],
      }),
    );
    expect(filterConfig.defaultFilters).toEqual(["key2", "key5"]);
  });

  it("getAllFiltersInUseWithSaveFilterConfig()", () => {
    expect(filterConfig.defaultFilters).toEqual(["key2", "key5"]);
    filterConfig.globalSearchable = false;
    filterConfig.getAllFiltersInUseWithSaveFilterConfig();
    expect(filterConfig.getAllFiltersInUseWithSaveFilterConfig().map((f) => f.key)).toEqual([
      "key2",
      "key5",
    ]);
    filterConfig.globalSearchable = true;
    filterConfig.getAllFiltersInUseWithSaveFilterConfig();
    expect(filterConfig.getAllFiltersInUseWithSaveFilterConfig().map((f) => f.key)).toEqual([
      "GLOBAL_SEARCH_KEY",
      "key2",
      "key5",
    ]);

    let savedFilter = new SavedFilter({
      finalFilters: [{key: "key2"}],
    });

    expect(
      filterConfig.getAllFiltersInUseWithSaveFilterConfig(savedFilter).map((f) => f.key),
    ).toEqual(["GLOBAL_SEARCH_KEY", "key2"]);

    filterConfig.globalSearchable = false;
    savedFilter = new SavedFilter({
      finalFilters: [{key: "key2123"}],
    });
    expect(filterConfig.getAllFiltersInUseWithSaveFilterConfig().map((f) => f.key)).toEqual([
      "key2",
      "key5",
    ]);
  });
});
