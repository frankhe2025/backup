import FilterItem, {FilterType} from "../../src/entities/filter_item";

describe("FilterItem class", () => {
  it("should initialize with default values when no data is provided", () => {
    const filter = new FilterItem({});

    expect(filter.key).toBe("");
    expect(filter.label).toBe("");
    expect(filter.type).toBeUndefined();
    expect(filter.options).toEqual([]);
    expect(filter.optionsFn).toBeNull();
  });

  it("should initialize with provided values", () => {
    const data = {
      key: "category",
      label: "Category",
      type: FilterType.SINGLE_SELECT,
      options: [
        {value: "1", label: "Option 1"},
        {value: "2", label: "Option 2"},
      ],
    };
    const filter = new FilterItem(data);

    expect(filter.key).toBe("category");
    expect(filter.label).toBe("Category");
    expect(filter.type).toBe(FilterType.SINGLE_SELECT);
    expect(filter.options).toEqual(data.options);
  });

  it("should handle missing options array gracefully", () => {
    const filter = new FilterItem({key: "test", label: "Test", type: FilterType.TEXT});

    expect(filter.options).toEqual([]);
  });

  it("should set optionsFn to null by default", () => {
    const filter = new FilterItem({key: "test"});

    expect(filter.optionsFn).toBeNull();
  });
});
