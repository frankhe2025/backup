import {SavedFilter, SavedFilterScope} from "../../src/entities/saved-filter";
import {FilterItem, FinalFilters} from "../../src";
describe("SavedFilter", () => {
  it("should initialize with default values when no data is provided", () => {
    const filter = new SavedFilter();

    expect(filter.name).toBe("");
    expect(filter.scope).toBe(SavedFilterScope.private);
    expect(filter.finalFilters).toBeNull();
  });

  it("should initialize with provided name, scope, and finalFilters", () => {
    const mockData = {
      name: "Sample Filter",
      scope: SavedFilterScope.public,
      finalFilters: {filterType: "date", value: "2024-01-01"},
    };

    const filter = new SavedFilter(mockData);

    expect(filter.name).toBe(mockData.name);
    expect(filter.scope).toBe(mockData.scope);
    expect(FinalFilters == null).toBeFalsy();
  });

  it("should set finalFilters to null when finalFilters is not provided", () => {
    const filter = new SavedFilter({name: "No Filters", scope: SavedFilterScope.public});

    expect(filter.name).toBe("No Filters");
    expect(filter.scope).toBe(SavedFilterScope.public);
    expect(filter.finalFilters).toBeNull();
  });

  it("should default scope to Private when not provided", () => {
    const filter = new SavedFilter({name: "Private Filter"});

    expect(filter.scope).toBe(SavedFilterScope.private);
  });

  it("isFilterItemSelected()", () => {
    const finalFiltersData = [{key: "key1"}, {key: "key2"}, {key: "key3"}];
    const savedFilter = new SavedFilter({
      finalFilters: finalFiltersData,
    });
    let filterItem = new FilterItem({
      key: "key1",
    });

    savedFilter.isFilterItemSelected(filterItem);
    expect(savedFilter.isFilterItemSelected(filterItem)).toBeTruthy();
    filterItem = new FilterItem({
      key: "key4",
    });
    expect(savedFilter.isFilterItemSelected(filterItem)).toBeFalsy();
  });

  it("toggleFinalFiltersWithFilterItem", () => {
    const finalFiltersData = [{key: "key1"}, {key: "key2"}, {key: "key3"}];
    const savedFilter = new SavedFilter({
      finalFilters: finalFiltersData,
    });
    let filterItem = new FilterItem({key: "key1"});

    savedFilter.toggleFinalFiltersWithFilterItem(filterItem);
    expect(savedFilter.finalFilters?.finalFilters.length).toEqual(2);
    expect(savedFilter.finalFilters?.finalFilters.map((f) => f.key)).toEqual(["key2", "key3"]);
    filterItem = new FilterItem({key: "key4"});
    savedFilter.toggleFinalFiltersWithFilterItem(filterItem);
    expect(savedFilter.finalFilters?.finalFilters.length).toEqual(3);
    expect(savedFilter.finalFilters?.finalFilters.map((f) => f.key)).toEqual([
      "key2",
      "key3",
      "key4",
    ]);
  });
});
