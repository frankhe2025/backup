# @aisera-ui/general-filter

## 2.2.1

### Patch Changes

- [#17](https://github.com/Aisera/ng-uicomponent/pull/17) [`ded0b14`](https://github.com/Aisera/ng-uicomponent/commit/ded0b143c9bde5d54f1506a2e7bd654666a975cf) Thanks [@frankhe-aisera](https://github.com/frankhe-aisera)! - test
