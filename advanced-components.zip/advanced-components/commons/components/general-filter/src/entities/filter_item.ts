enum FilterType {
  SINGLE_SELECT = "SINGLE_SELECT",
  MULTI_SELECT = "MULTI_SELECT",
  DATE = "DATE",
  DATETIME = "DATETIME",
  TEXT = "TEXT",
  NUMERIC = "NUMERIC",
}

interface OptionItem {
  value: string;
  label: string;
}

export class FilterItem {
  key: string;
  label?: string;
  type?: FilterType | string;
  options?: OptionItem[];
  optionsFn?: any;

  constructor(data: Partial<FilterItem>) {
    this.key = data.key ?? "";
    this.label = data.label ?? "";
    this.type = data.type as FilterType;
    this.options = (data.options as OptionItem[]) || [];
    this.optionsFn = null;
  }
}

export {FilterType};
export type {OptionItem};
export default FilterItem;
