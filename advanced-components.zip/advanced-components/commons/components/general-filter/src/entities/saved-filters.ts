import {SavedFilter} from "./saved-filter";

export class SavedFilters {
  savedFilters: SavedFilter[];
  constructor(items) {
    this.savedFilters = [];
    items.forEach((item) => {
      this.savedFilters.push(new SavedFilter(item));
    });
  }

  removeSavedFilter(savedFilter: SavedFilter) {
    this.savedFilters = this.savedFilters.filter((f) => {
      return f !== savedFilter;
    });

    return this;
  }
}
