const NumericComponent = () => {
  return <div>NumericComponent</div>;
};

export default NumericComponent;
