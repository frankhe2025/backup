import React, {useEffect, useState} from "react";
import {Popover, PopoverContent, PopoverTrigger} from "@aisera-ui/popover";
import {Button} from "@aisera-ui/button";
import {Input} from "@aisera-ui/input";
import {Select, SelectItem} from "@aisera-ui/select";
import {Checkbox} from "@aisera-ui/checkbox";
import {Radio, RadioGroup} from "@aisera-ui/radio";
import {Icon} from "@iconify-icon/react";

import FilterComponentInputType from "../../../entities/fiter-component-input-type";
import {FilterOperand} from "../../../entities/final_filters";
import {FilterType, OptionItem} from "../../../entities/filter_item";
const SelectorComponent = (props: FilterComponentInputType) => {
  const FilterOperandIncExc: FilterOperand[] = [FilterOperand.Exclude, FilterOperand.Include];
  const [searchTerm, setSearchTerm] = useState("");
  const [popOpen, setPopOpen] = useState<boolean>(false);
  const [label, setLabel] = useState<string>("");
  let filteredItems: OptionItem[] = [];

  useEffect(() => {
    //we need to set up label based on passed in savedFilter
    if (props.savedFilter) {
      const newLable: any = props.savedFilter.finalFilters
        ?.findFilterItemByKey(props.filterItem.key)
        ?.getDisplayedTitle();

      setLabel(newLable);
    }
  }, []);

  if (props.filterItem.options && Array.isArray(props.filterItem.options)) {
    filteredItems = props.filterItem.options.filter((item) =>
      item.label.toLowerCase().includes(searchTerm.toLowerCase()),
    );
  }

  const toggleSelection = (item) => {
    props.setFinalFilters(props.finalFilters.upsertFinalFilterValue(props.filterItem, item).clone);
    updateLabel();
  };

  const changeSelectedOperantValue = (event) => {
    props.setFinalFilters(
      props.finalFilters.upsertFinalFilterOperand(props.filterItem, event.target.value).clone,
    );
    updateLabel();
  };

  const updateLabel = () => {
    const newLabel: any = props.finalFilters
      ?.findFilterItemByKey(props.filterItem.key)
      ?.getDisplayedTitle();

    setLabel(newLabel);
  };

  let COMP;

  if (props.filterItem.type === FilterType.MULTI_SELECT) {
    COMP = (
      <div>
        <Popover onOpenChange={(prev) => setPopOpen(!prev)}>
          <PopoverTrigger>
            <Button
              endContent={
                <Icon icon={popOpen ? "mdi-light:chevron-down" : "mdi-light:chevron-up"} />
              }
            >
              {props.filterItem.label}: {label}
            </Button>
          </PopoverTrigger>
          <PopoverContent className={"items-start"}>
            <Input
              className={"mb-2"}
              data-testid={"searchingInput"}
              placeholder={"Searching.."}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Select
              className="mb-2"
              data-testid="operand-selector"
              defaultSelectedKeys={[
                props.finalFilters.findFilterItemByKey(props.filterItem.key)?.operand ??
                  FilterOperand.Include,
              ]}
              items={FilterOperandIncExc as any}
              onChange={changeSelectedOperantValue}
            >
              {FilterOperandIncExc.map((item: any) => {
                return <SelectItem key={item}>{item}</SelectItem>;
              })}
            </Select>

            {filteredItems.map((option: OptionItem) => {
              return (
                <Checkbox
                  key={option.value}
                  data-testid="selector-option-item"
                  defaultSelected={props.finalFilters
                    .getFilterValue(props.filterItem)
                    .includes(option.value)}
                  onChange={() => toggleSelection(option.value)}
                >
                  {option.label}
                </Checkbox>
              );
            })}
          </PopoverContent>
        </Popover>
      </div>
    );
  } else {
    COMP = (
      <div>
        <Popover>
          <PopoverTrigger>
            <Button>
              {props.filterItem.label}:
              {props.finalFilters?.findFilterItemByKey(props.filterItem.key)?.getDisplayedTitle()}
            </Button>
          </PopoverTrigger>
          <PopoverContent className={"items-start"}>
            <RadioGroup
              value={props.finalFilters.getFilterValue(props.filterItem)}
              onChange={(event) => toggleSelection(event.target.value)}
            >
              {filteredItems.map((option: OptionItem) => {
                return (
                  <Radio
                    key={option.value}
                    data-testid="selector-option-item-single"
                    value={option.value}
                  >
                    {option.label}
                  </Radio>
                );
              })}
            </RadioGroup>
          </PopoverContent>
        </Popover>
      </div>
    );
  }

  return COMP;
};

export default SelectorComponent;
