import {Select, SelectItem} from "@aisera-ui/select";
import {
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  useDisclosure,
} from "@aisera-ui/modal";
import {Button} from "@aisera-ui/button";
import {DateRangePicker} from "@aisera-ui/date-picker";
import {useEffect, useState} from "react";
import {RangeValue} from "@react-types/shared";
import {CalendarDate} from "@internationalized/date";

import {OptionItem} from "../../entities/filter_item";
import FilterComponentInputType from "../../entities/fiter-component-input-type";
import {DateRangeValue, FilterOperand} from "../../entities/final_filters";

// Define the correct type manually

const DateSelectComponent = (props: FilterComponentInputType) => {
  const {isOpen, onOpen, onOpenChange} = useDisclosure();
  const [label, setLabel] = useState<string>("");
  const [dateRangeValue, setDateRangeValue] = useState<DateRangeValue | null>(
    props.finalFilters.getFilterValueAsDateRange(props.filterItem),
  );

  useEffect(() => {
    //we need to set up label based on passed in savedFilter
    if (props.savedFilter) {
      const newLable: any = props.savedFilter.finalFilters
        ?.findFilterItemByKey(props.filterItem.key)
        ?.getDisplayedTitle();

      setLabel(newLable);
    }
  }, []);
  const updateLabel = () => {
    const newLabel: any = props.finalFilters
      ?.findFilterItemByKey(props.filterItem.key)
      ?.getDisplayedTitle();

    setLabel(newLabel);
  };

  const onConfirm = (cb) => {
    props.setFinalFilters(
      props.finalFilters.upsertFinalFilterOperandAndValueForDateRangeValue(
        props.filterItem,
        dateRangeValue,
      ).clone,
    );
    cb();
  };

  const selectionChanged = (e) => {
    if (e.currentKey === "-1") {
      onOpen();
    } else {
      if (props.filterItem.options) {
        props.setFinalFilters(
          props.finalFilters.upsertFinalFilterOperandAndValue(
            props.filterItem,
            FilterOperand.Within,
            props.filterItem.options[Number(e.currentKey)].value,
          ).clone,
        );
        updateLabel();
      }
    }
  };

  const renderValue = (items) => {
    const selectedItem = items[0];

    if (!selectedItem) return props.filterItem.label;

    return props.filterItem.label + ": " + label;
  };

  return (
    <div className={"flex w-[280px] flex-wrap md:flex-nowrap gap-4"}>
      <Select
        className="max-w-xs"
        data-testid={"dateselector-trigger-btn"}
        placeholder={props.filterItem.label + ": " + label}
        renderValue={renderValue}
        onSelectionChange={selectionChanged}
      >
        {
          props.filterItem.options?.map((option: OptionItem, key: number) => {
            return (
              <SelectItem key={key} data-testid={"dateselector-option-item"}>
                {option.label}
              </SelectItem>
            );
          }) as any
        }

        <SelectItem
          key={"-1"}
          className={"border-t-1"}
          data-testid={"dateselector-option-custom-item"}
        >
          Custom Range
        </SelectItem>
      </Select>
      <Modal isOpen={isOpen} onOpenChange={onOpenChange}>
        <ModalContent>
          {(onClose) => (
            <>
              <ModalHeader
                className="flex flex-col gap-1"
                data-testid={"dateselector-custom-model-header"}
              >
                Select custom range
              </ModalHeader>
              <ModalBody>
                <div className="w-full flex flex-col gap-y-2">
                  <DateRangePicker
                    label="Date range (controlled)"
                    value={dateRangeValue}
                    onChange={(range: RangeValue<CalendarDate> | null) => {
                      setDateRangeValue(range);
                    }}
                  />
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="danger" variant="light" onPress={onClose}>
                  Cancel
                </Button>
                <Button color="primary" onPress={() => onConfirm(onClose)}>
                  Confirm
                </Button>
              </ModalFooter>
            </>
          )}
        </ModalContent>
      </Modal>
    </div>
  );
};

export default DateSelectComponent;
