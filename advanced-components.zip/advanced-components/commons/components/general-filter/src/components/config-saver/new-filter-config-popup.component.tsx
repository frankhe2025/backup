import {ModalBody, ModalFooter, ModalHeader} from "@aisera-ui/modal";
import {Input} from "@aisera-ui/input";
import {Select, SelectItem} from "@aisera-ui/select";
import {Button} from "@aisera-ui/button";
import React, {useState} from "react";

const NewFilterConfigPopupComponent = ({onClose, onConfirm}) => {
  const [name, setName] = useState<string>("");
  const [scope, setScope] = useState<string>("private");
  const confirm = () => {
    onConfirm({name, scope});
    onClose();
  };

  return (
    <>
      <ModalHeader className="flex flex-col gap-1" data-testid={"new-filter-model-header"}>
        New Filter
      </ModalHeader>
      <ModalBody>
        <div className="w-full flex flex-col gap-y-2">
          <div>
            This will save the current values into a new filter. Please enter the filter name.
          </div>
          <div className={"gap-y-2"}>
            <div className={"flex items-center gap-2 mb-2"}>
              Name{" "}
              <Input
                className={"w-[100px]"}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className={"flex items-center gap-2"}>
              Scope
              <Select
                className="max-w-xs w-full"
                defaultSelectedKeys={new Set([scope])}
                onSelectionChange={(e: any) => setScope(e.currentKey)}
              >
                <SelectItem key={"private"}>Private</SelectItem>
                <SelectItem key={"public"}>Public</SelectItem>
              </Select>
            </div>
          </div>
        </div>
      </ModalBody>
      <ModalFooter>
        <Button color="danger" variant="light" onPress={onClose}>
          Cancel
        </Button>
        <Button color="primary" onPress={confirm}>
          Confirm
        </Button>
      </ModalFooter>
    </>
  );
};

export default NewFilterConfigPopupComponent;
