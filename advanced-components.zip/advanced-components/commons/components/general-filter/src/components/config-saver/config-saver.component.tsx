import React, {useEffect, useState} from "react";
import {Popover, PopoverContent, PopoverTrigger} from "@aisera-ui/popover";
import {Icon} from "@iconify-icon/react";
import {Button} from "@aisera-ui/button";
import {Input} from "@aisera-ui/input";
import {Modal, ModalContent, useDisclosure} from "@aisera-ui/modal";

import {SavedFilter} from "../../entities/saved-filter";

import NewFilterConfigPopupComponent from "./new-filter-config-popup.component";
import FilterManagerPopupComponent from "./filter-manager-popup.component";

export interface ConfigSaverProp {
  savedFilters?: SavedFilter[];
  onNewFilterSaved;
  onFilterUpdated;
  onFilterSelected;
  currentUserId?:any
}

const ConfigSaverComponent = ({
  savedFilters = [],
  onNewFilterSaved,
  onFilterUpdated,
  onFilterSelected,
  currentUserId=''
}: ConfigSaverProp) => {
  const [popOpen, setPopOpen] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [filteredSavedFilters, setFilteredSavedFilters] = useState(savedFilters);
  const [selectedSavedFilter, setSelectedSavedFilter] = useState<SavedFilter | null>(null);
  const {
    isOpen: isNewFilerOpen,
    onOpen: openNewFilter,
    onOpenChange: onNewFitlerOpenChange,
  } = useDisclosure();
  const {
    isOpen: isManagerOpen,
    onOpen: openManager,
    onOpenChange: onManagerOpenChange,
  } = useDisclosure();

  useEffect(() => {
    setFilteredSavedFilters(() => {
      if (searchTerm.trim() === "") {
        return savedFilters;
      } else {
        if (Array.isArray(savedFilters)) {
          const foundFilters = savedFilters?.filter((savedFilter: SavedFilter) =>
            savedFilter.name.toLowerCase().includes(searchTerm.toLowerCase()),
          );

          return foundFilters;
        } else {
          return [];
        }
      }
    });
  }, [searchTerm, savedFilters]);

  const onOpenNewFilter = () => {
    openNewFilter();
    closeMe();
  };
  const onOpenManager = () => {
    openManager();
    closeMe();
  };
  const selectFilter = (filter: SavedFilter) => {
    onFilterSelected(filter);
    setSelectedSavedFilter(filter);
    closeMe();
  };

  const closeMe = () => setPopOpen(false);

  return (
    <div>
      <Popover isOpen={popOpen} onOpenChange={setPopOpen}>
        <PopoverTrigger>
          <Button
            endContent={<Icon icon={popOpen ? "mdi-light:chevron-down" : "mdi-light:chevron-up"} />}
          >
            <Icon height="24" icon="akar-icons:sort" width="24" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className={"items-start z-10"}>
          <Input
            className={"mb-2"}
            data-testid={"searchingInput"}
            placeholder={"Search"}
            startContent={<Icon icon="mdi-light:magnify" />}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {filteredSavedFilters?.length > 0 && (
            <div className={"w-full"}>
              <div className={"mb-1 font-bold"}>CUSTOM FILTERS</div>
              {filteredSavedFilters?.map((savedFilter, key) => {
                return (
                  <div
                    key={savedFilter.id || key}
                    className={`p-1 hover:bg-red-500 cursor-pointer ${
                      selectedSavedFilter === savedFilter ? " bg-gray-200" : ""
                    }`}
                    role={"button"}
                    tabIndex={0}
                    onClick={() => selectFilter(savedFilter)}
                    onKeyDown={() => selectFilter(savedFilter)}
                  >
                    {savedFilter.name}
                  </div>
                );
              })}
            </div>
          )}

          <div className={"mb-1 font-bold"}>MANAGE</div>
          <div
            className={"flex gap-x-2 cursor-pointer mb-1"}
            role={"button"}
            tabIndex={0}
            onClick={onOpenNewFilter}
            onKeyDown={onOpenNewFilter}
          >
            <Icon height="24" icon="stash:filter-light" width="24" />
            Save as New Filter
          </div>

          {savedFilters?.length > 0 && (
            <div
              className={"flex gap-x-2 cursor-pointer"}
              role={"button"}
              tabIndex={0}
              onClick={onOpenManager}
              onKeyDown={onOpenManager}
            >
              <Icon height="24" icon="mdi:gear-outline" width="24" /> Manage Filters
            </div>
          )}
        </PopoverContent>
      </Popover>
      <Modal isOpen={isNewFilerOpen} onOpenChange={onNewFitlerOpenChange}>
        <ModalContent>
          {(onClose) => (
            <NewFilterConfigPopupComponent onClose={onClose} onConfirm={onNewFilterSaved} />
          )}
        </ModalContent>
      </Modal>
      <Modal isOpen={isManagerOpen} onOpenChange={onManagerOpenChange}>
        <ModalContent>
          {(onClose) => (
            <FilterManagerPopupComponent
              savedFilters={savedFilters}
              onClose={onClose}
              onConfirm={onFilterUpdated}
              currentUserId={currentUserId}
            />
          )}
        </ModalContent>
      </Modal>
    </div>
  );
};

export default ConfigSaverComponent;
