import {ModalBody, ModalFooter, ModalHeader} from "@aisera-ui/modal";
import {Input} from "@aisera-ui/input";
import {Select, SelectItem} from "@aisera-ui/select";
import {Button} from "@aisera-ui/button";
import {Icon} from "@iconify-icon/react";
import {Fragment, useState} from "react";

import {SavedFilter} from "../../entities/saved-filter";
import {SavedFilters} from "../../entities/saved-filters";

const FilterManagerPopupComponent = ({onClose, onConfirm, savedFilters, currentUserId}) => {
  const [selfSavedFilters, setSelfSavedFilters] = useState<SavedFilters>(
    new SavedFilters(savedFilters),
  );
  const confirm = () => {
    onConfirm(selfSavedFilters);
    onClose();
  };
  const removeRow = (savedFilter) => {
    setSelfSavedFilters(new SavedFilters([]));
    setTimeout(() => {
      setSelfSavedFilters(selfSavedFilters.removeSavedFilter(savedFilter));
    });
  };

  return (
    <>
      <ModalHeader className="flex flex-col gap-1" data-testid={"filter-manager-model-header"}>
        Manage Filters
      </ModalHeader>
      <ModalBody>
        <div
          className="grid border-1 solid items-center gap-y-0"
          style={{gridTemplateColumns: "1fr 1fr 50px"}}
        >
          {/* Header Row */}
          <div className="bg-amber-100 p-2 border-r-1 solid" style={{backgroundColor: "#eee"}}>
            Name
          </div>
          <div className="bg-gray-100 p-2" style={{backgroundColor: "#eee"}}>
            Scope
          </div>
          <div className="bg-gray-100 p-2 h-full" style={{backgroundColor: "#eee"}} />
          {selfSavedFilters?.savedFilters.map((savedFilter: SavedFilter, index) => {
            return (
              <Fragment key={index}>
                <div
                  className={`p-2 ${
                    currentUserId && savedFilter.userId && currentUserId != savedFilter.userId
                      ? "pointer-events-none opacity-50"
                      : ""
                  }`}
                >
                  <Input
                    fullWidth
                    defaultValue={savedFilter.name}
                    onChange={(e) => (savedFilter.name = e.target.value)}
                  />
                </div>
                <div
                  className={`p-2 ${
                    currentUserId && savedFilter.userId && currentUserId != savedFilter.userId
                      ? "pointer-events-none opacity-50"
                      : ""
                  }`}
                >
                  <Select
                    className="max-w-xs w-full"
                    defaultSelectedKeys={new Set([savedFilter.scope])}
                    onSelectionChange={(e: any) => (savedFilter.scope = e.currentKey)}
                  >
                    <SelectItem key={"private"}>Private</SelectItem>
                    <SelectItem key={"public"}>Public</SelectItem>
                  </Select>
                </div>
                <div
                  className={`p-2 flex justify-center cursor-pointer  ${
                    currentUserId && savedFilter.userId && currentUserId != savedFilter.userId
                      ? "pointer-events-none opacity-50"
                      : ""
                  }`}
                >
                  <Icon
                    height="36"
                    icon="basil:cross-outline"
                    width="36"
                    onClick={() => removeRow(savedFilter)}
                  />
                </div>
              </Fragment>
            );
          })}
        </div>
      </ModalBody>
      <ModalFooter>
        <Button color="danger" variant="light" onPress={onClose}>
          Cancel
        </Button>
        <Button color="primary" onPress={confirm}>
          Confirm
        </Button>
      </ModalFooter>
    </>
  );
};

export default FilterManagerPopupComponent;
