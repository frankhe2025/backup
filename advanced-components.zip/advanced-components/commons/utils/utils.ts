let __debounceTimer;
const debounce = (fn, timeDelay = 500) => {
  return () => {
    clearTimeout(__debounceTimer);
    __debounceTimer = setTimeout(() => fn(), timeDelay);
  };
};

function wait(seconds) {
  return new Promise((resolve) => setTimeout(resolve, seconds * 1000));
}

export {debounce, wait};
