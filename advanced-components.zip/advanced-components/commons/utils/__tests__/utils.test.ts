import {debounce} from "../utils";

jest.useFakeTimers();

describe("debounce function", () => {
  let mockFn;

  beforeEach(() => {
    mockFn = jest.fn();
  });

  it("should call the function after the specified delay", () => {
    const debouncedFn = debounce(mockFn, 500);

    debouncedFn();

    expect(mockFn).not.toBeCalled();
    jest.advanceTimersByTime(500);
    expect(mockFn).toBeCalledTimes(1);
  });

  it("should reset the timer if called again within the delay", () => {
    const debouncedFn = debounce(mockFn, 500);

    debouncedFn();
    jest.advanceTimersByTime(300);
    debouncedFn();
    jest.advanceTimersByTime(300);
    expect(mockFn).not.toBeCalled();
    jest.advanceTimersByTime(200);
    expect(mockFn).toBeCalledTimes(1);
  });

  it("should only call the function once even if called multiple times rapidly", () => {
    const debouncedFn = debounce(mockFn, 500);

    debouncedFn();
    debouncedFn();
    debouncedFn();
    jest.advanceTimersByTime(500);
    expect(mockFn).toBeCalledTimes(1);
  });
});
