import TableControllerComponent from "../src/table-controller.component";
import getFilterConfigMock from "../../commons/components/general-filter/src/mock/entities/filter_config.mock";
import {SavedTableConfig} from "../src/entities/saved-table-config";

const meta = {
  title: "advanced-components/table-controller",
  component: TableControllerComponent,
  tags: ["autodocs"],
};

export default meta;
// type Story = StoryObj<typeof meta>;

const columns = [
  {key: "key1", title: "title1"},
  {key: "key2", title: "title2 Check"},
  {key: "key3", title: "title3"},
  {key: "key4", title: "title4"},
  {key: "key5", title: "title5"},
  {key: "key6", title: "title6"},
];

// @ts-ignore
const tableControllerConfig = {
  filterConfig: getFilterConfigMock(),
  columns: columns,
  defaultColumns: ["key1", "key2", "key3"],
  onSearch: (_cfg) => {
     console.log(_cfg);
  },
  onColumnChange: (_columns) => {
      console.log(_columns);
  },
  onSaveNewTableConfig: (_savedTableConfig: SavedTableConfig) => {
      console.log("save new config: ", _savedTableConfig);
  },
  onSavedTableConfigUpdated: (_cfg) => {
      console.log("Save table config updates: ", _cfg);
  },
  saveable: true,
  selfSaveable: true,
};

export const Primary = {
  args: tableControllerConfig,
};
