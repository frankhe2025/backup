import {SavedTableConfig} from "../entities/saved-table-config";
import {SavedTableConfigs} from "../entities/saved-table-configs";

class TableControllerService {
  keyPrefix = "";
  constructor(tableName: string = "") {
    this.keyPrefix = tableName;
  }
  saveNewTableConfig(cfg: SavedTableConfig) {
    const existingCfgs = this.getSavedTableConfigs();

    existingCfgs.savedTableConfigs.push(cfg);
    setTableConfigsToLocalStorage(this.keyPrefix, existingCfgs);
  }

  getSavedTableConfigs() {
    return new SavedTableConfigs(getTableConfigFromLocalStorage(this.keyPrefix));
  }

  saveUpdatedTableConfigs(updatedTableConfigs: SavedTableConfigs) {
    setTableConfigsToLocalStorage(this.keyPrefix, updatedTableConfigs);
  }

}

let tableServicesMapper = {};

const tableConfigKey = "NG-TABLE-CONFIG";
const getTableConfigFromLocalStorage = (prefix: string) => {
  const res = localStorage.getItem(prefix + "_" + tableConfigKey);

  if (res) {
    return JSON.parse(res);
  } else {
    return [];
  }
};
const setTableConfigsToLocalStorage = (keyPrefix, value) => {
  localStorage.setItem(keyPrefix + "_" + tableConfigKey, JSON.stringify(value));
};

const getTableControllerService = (tableName: string = "") => {
  if (!(tableName in tableServicesMapper)) {
    tableServicesMapper[tableName] = new TableControllerService(tableName);
  }

  return tableServicesMapper[tableName];
};

export default getTableControllerService;
