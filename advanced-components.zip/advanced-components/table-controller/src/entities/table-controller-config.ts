import FilterConfig from "../../../commons/components/general-filter/src/entities/filter_config";
import {SavedFilter} from "../../../commons/components/general-filter/src/entities/saved-filter";

interface TableColumnConfig {
  key: string;
  title: string;
}

interface TableControllerConfig {
  filterConfig: FilterConfig;
  columns: TableColumnConfig[];
  defaultColumns: string[];
  onSearch: any;
  onColumnChange: any;
  onColumnOrderChange?: (columnOrder: string[]) => void; // this is for column ordering
  onSortOrderChange?: (sortOrder: {column: string; direction: "asc" | "desc" | "none"}[]) => void; // this is for sort order
  saveable?: boolean; // this is to restrict if table is saveable or not
  savedTableConfigs?: any; // this is saved table configurations
  savedFilters?: SavedFilter[];
  onSaveNewTableConfig?: any; // will fire only when the user create a brand new table config
  onSavedTableConfigUpdated?: any; // will fire when the user update a table config
  // below is only for situation that there is no API support, so all go to localStorage
  selfSaveable?: boolean; //default False, used to control if table will be saving in localStorage or not
  tableName?: string; // defaultEmpty, used to identify the self-saved type,
  initialColumnOrder?: string[];
  initialSortOrder?: {column: string; direction: "asc" | "desc" | "none"}[]; // Initial sort order
  currentUserId?: any; // used to decide if we can show update or delete option for the saved config
}

export type {TableColumnConfig, TableControllerConfig};
