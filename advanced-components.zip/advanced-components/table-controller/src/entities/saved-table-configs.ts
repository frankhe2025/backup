import {SavedFilter} from "../../../commons/components/general-filter/src/entities/saved-filter";

import {SavedTableConfig} from "./saved-table-config";

// DB saving is multiple rows, not a whole object, so we must distinguish it
// if data is a list, that comes from DB result directly,
// Otherwise, ths is from localStory, we saved the whole object into localStorage
export class SavedTableConfigs {
  savedTableConfigs: SavedTableConfig[];
  constructor(data: any = null) {
    this.savedTableConfigs = [];
    if (data) {
      if (Array.isArray(data)) {
        data.forEach((item) => {
          this.savedTableConfigs.push(new SavedTableConfig(item));
        });
      } else if (data.hasOwnProperty("savedTableConfigs")) {
        data.savedTableConfigs.forEach((item) => {
          this.savedTableConfigs.push(new SavedTableConfig(item));
        });
      }
    }
  }

  get
  savedFilters(): (SavedFilter | null)[] {
    const tmp: any[] = [];

    this.savedTableConfigs.forEach((savedTableConfig) => tmp.push(savedTableConfig.savedFilter));

    return tmp;
  }

  addSavedTableConfig(cfg: SavedTableConfig) {
    this.savedTableConfigs.push(cfg);

    return this;
  }

  mergeSavedFilterConfigs(savedFitlers: SavedFilter[]) {
    for (let i = this.savedTableConfigs.length - 1; i >= 0; i--) {
      //1. We remove it
      let bExist = false;

      savedFitlers.forEach((savedFilter: SavedFilter) => {
        if (savedFilter.id === this.savedTableConfigs[i]?.id) {
          //found it and replace here
          this.savedTableConfigs[i].savedFilter = savedFilter;
          bExist = true;
        }
      });
      if (!bExist) {
        // if not exist, let's remove it
        this.savedTableConfigs.splice(i, 1);
      }
    }

    return this;
  }
}
