import {useEffect, useState} from "react";

import GeneralFilterComponent from "../../commons/components/general-filter/src/general-filter.component";
import FinalFilters from "../../commons/components/general-filter/src/entities/final_filters";
import FilterConfig from "../../commons/components/general-filter/src/entities/filter_config";
import {debounce} from "../../commons/utils/utils";
import {SavedFilter} from "../../commons/components/general-filter/src/entities/saved-filter";

import {TableControllerConfig} from "./entities/table-controller-config";
import ColumnSelectorComponent from "./components/column-selector/column-selector.component";
import {SavedTableConfig} from "./entities/saved-table-config";
import getTableControllerService from "./services/table-controller.service";
import {SavedTableConfigs} from "./entities/saved-table-configs";

const TableControllerComponent = ({
  filterConfig,
  columns,
  defaultColumns = [],
  onSearch,
  onColumnChange,
  onColumnOrderChange,
  onSortOrderChange,
  saveable = true,
  savedTableConfigs = null,
  selfSaveable = false,
  tableName = "",
  onSaveNewTableConfig = null,
  onSavedTableConfigUpdated = null,
  initialColumnOrder = [],
  initialSortOrder = [],
  currentUserId = null
}: TableControllerConfig) => {
  const [finalFilters, setFinalFilters] = useState<FinalFilters>(new FinalFilters());
  const [selfFilterConfig, setSelfFilterConfig] = useState<FilterConfig>(
    new FilterConfig(filterConfig),
  );
  const [selfSavedTableConfigs, setSelfSavedTableConfigs] = useState<SavedTableConfigs>(
    new SavedTableConfigs(savedTableConfigs),
  );
  const [selfSavedFilters, setSelfSavedFilters] = useState<any>(
    savedTableConfigs ? new SavedTableConfigs(savedTableConfigs).savedFilters : [],
  );
  const [selfColumns, setSelfColumns] = useState<string[]>([]);

  const [columnOrder, setColumnOrder] = useState<string[]>(
    initialColumnOrder && initialColumnOrder.length > 0 ? initialColumnOrder : [],
  );

  const [sortOrder, setSortOrder] = useState<
    {column: string; direction: "asc" | "desc" | "none"}[]
  >(initialSortOrder && initialSortOrder.length > 0 ? initialSortOrder : []);

  useEffect(() => {
    if (initialColumnOrder && initialColumnOrder.length > 0) {
      setColumnOrder(initialColumnOrder);
    }
  }, [initialColumnOrder]);

  useEffect(() => {
    if (initialSortOrder && initialSortOrder.length > 0) {
      setSortOrder(initialSortOrder);
    }
  }, [initialSortOrder]);

  useEffect(() => {
    debounce(() => {
      onSearch(finalFilters.getStandardOutput());
    }, 500)();
  }, [finalFilters]);

  useEffect(() => {
    if (selfSaveable && savedTableConfigs === null) {
      const savedConfigs = getTableControllerService(tableName).getSavedTableConfigs();

      setSelfSavedTableConfigs(new SavedTableConfigs(savedConfigs));
      setSelfSavedFilters(new SavedTableConfigs(savedConfigs).savedFilters);

      if (savedConfigs?.savedTableConfigs?.length > 0) {
        const lastConfig =
          savedConfigs.savedTableConfigs[savedConfigs.savedTableConfigs.length - 1];

        if (lastConfig.columnOrder?.length > 0) {
          setColumnOrder(lastConfig.columnOrder);
          onColumnOrderChange?.(lastConfig.columnOrder);
        }
        if (lastConfig.sortOrder?.length > 0) {
          setSortOrder(lastConfig.sortOrder);
          onSortOrderChange?.(lastConfig.sortOrder);
        }
      }
    }
  }, []);

  const _onColumnChange = (_columns: string[]) => {
    setSelfColumns(_columns);
    onColumnChange(_columns);
  };

  const onSaveNewFilter = (savedFilter: SavedFilter) => {
    const savedTableConfig = new SavedTableConfig({
      savedFilter,
      columns: selfColumns,
      columnOrder,
      sortOrder,
    });

    selfSavedTableConfigs.addSavedTableConfig(savedTableConfig);
    setSelfSavedFilters(selfSavedTableConfigs.savedFilters);

    if (onSaveNewTableConfig) onSaveNewTableConfig(savedTableConfig.removeId());
    if (selfSaveable) {
      getTableControllerService(tableName).saveNewTableConfig(savedTableConfig);
    }
  };

  const savedFilterUpdated = (savedFilters: SavedFilter[]) => {
    const savedTableConfigs: SavedTableConfig[] = [];
    savedFilters.forEach((savedFilter:SavedFilter)=>{
      savedTableConfigs.push(new SavedTableConfig({
        savedFilter
      }))
    });

    selfSavedTableConfigs.mergeSavedFilterConfigs(savedFilters);
    setSelfSavedFilters(selfSavedTableConfigs.savedFilters);

    if (onSavedTableConfigUpdated) {
      onSavedTableConfigUpdated(savedTableConfigs);
    }
    if (selfSaveable) {
      getTableControllerService(tableName).saveUpdatedTableConfigs(selfSavedTableConfigs);
    }
  };

  const onSavedfilterSelected = (savedFilter: SavedFilter) => {
    onSearch(savedFilter.finalFilters?.getStandardOutput());

    const tableConfig = selfSavedTableConfigs.savedTableConfigs.find(
      (config) => config.savedFilter?.id === savedFilter.id,
    );

    if (tableConfig) {
      if (tableConfig.columnOrder?.length > 0) {
        setColumnOrder(tableConfig.columnOrder);
        onColumnOrderChange?.(tableConfig.columnOrder);
      }

      if (tableConfig.sortOrder?.length > 0) {
        setSortOrder(tableConfig.sortOrder);
        onSortOrderChange?.(tableConfig.sortOrder);
      } else if (tableConfig.sortBy) {
        const legacySortOrder = [
          {
            column: tableConfig.sortBy,
            direction: tableConfig.asc ? "asc" : ("desc" as "asc" | "desc"),
          },
        ];

        setSortOrder(legacySortOrder);
        onSortOrderChange?.(legacySortOrder);
      }

      if (tableConfig.columns?.length > 0) {
        setSelfColumns(tableConfig.columns);
        onColumnChange(tableConfig.columns);
      }
    } else {
      console.warn("No matching table config found for filter ID:", savedFilter.id);
    }
  };

  return (
    <div className={"flex gap-1"}>
      <GeneralFilterComponent
        filterConfig={selfFilterConfig}
        finalFilters={finalFilters}
        saveable={saveable}
        savedFilters={selfSavedFilters}
        setFilterConfig={setSelfFilterConfig}
        setFinalFilters={setFinalFilters}
        onSaveNewFilter={onSaveNewFilter}
        onSavedFilterUpdated={savedFilterUpdated}
        onSavedfilterSelected={onSavedfilterSelected}
        currentUserId = {currentUserId}
      />
      <ColumnSelectorComponent
        columns={columns}
        defaultColumns={defaultColumns}
        onColumnChange={_onColumnChange}
      />
    </div>
  );
};

export default TableControllerComponent;
