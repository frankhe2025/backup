import {Popover, PopoverContent, PopoverTrigger} from "@aisera-ui/popover";
import {Button} from "@aisera-ui/button";
import {Checkbox} from "@aisera-ui/checkbox";
import {useEffect} from "react";

import {TableColumnConfig} from "../../entities/table-controller-config";

import {useCustomSelectorHook} from "./custom-selector.hook";

export interface ColumnSelectorParam {
  columns: TableColumnConfig[];
  defaultColumns: string[];
  onColumnChange: any;
}

const ColumnSelectorComponent = (props: ColumnSelectorParam) => {
  const {selectedColumns, handler} = useCustomSelectorHook(props.defaultColumns);
  const toggleSelection = (columnKey: string) => {
    handler.toggleColumn(columnKey);
  };

  useEffect(() => {
    props.onColumnChange(selectedColumns);
  }, [selectedColumns]);

  return (
    <div>
      <Popover>
        <PopoverTrigger>
          <Button>Columns</Button>
        </PopoverTrigger>

        <PopoverContent className="items-start">
          {props.columns.map((column: TableColumnConfig) => {
            return (
              <Checkbox
                key={column.key}
                data-testid={"column-selector-items"}
                defaultSelected={selectedColumns.includes(column.key)}
                onChange={() => toggleSelection(column.key)}
              >
                {column.title}
              </Checkbox>
            );
          })}
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default ColumnSelectorComponent;
