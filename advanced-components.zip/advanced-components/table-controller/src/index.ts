import TableControllerComponent from "./table-controller.component";

export default TableControllerComponent;
export type {TableColumnConfig, TableControllerConfig} from "./entities/table-controller-config";
export {SavedTableConfig} from "./entities/saved-table-config";
export {SavedTableConfigs} from "./entities/saved-table-configs";
