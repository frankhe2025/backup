# @aisera-ui/table-filter

Please refer to the [documentation](https://aisera.com/docs/components/feature-flags) for more
information.

## Installation

```sh
yarn add @aisera-ui/table-controller
# or
npm i @aisera-ui/table-controller
```

## Contribution

Yes please! See the
[contributing guidelines](https://github.com/Aisera/ng-uicomponent/blob/master/CONTRIBUTING.md)
for details.
