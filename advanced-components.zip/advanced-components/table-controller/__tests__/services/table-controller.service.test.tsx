import getTableControllerService from "../../src/services/table-controller.service";
import {SavedTableConfigs} from "../../src/entities/saved-table-configs";

jest.mock("../../src/entities/saved-table-configs", () => {
  return {
    SavedTableConfigs: jest.fn().mockImplementation((data) => ({
      savedTableConfigs: [...(data || [])],
    })),
  };
});

describe("TableControllerService", () => {
  const tableName = "MyTable";
  const keyPrefix = `${tableName}_NG-TABLE-CONFIG`;
  let service;

  beforeEach(() => {
    localStorage.clear();
    jest.clearAllMocks();
    service = getTableControllerService(tableName);
  });

  it("should initialize with correct keyPrefix", () => {
    expect(service.keyPrefix).toBe(tableName);
  });

  it("getSavedTableConfigs should return instance of SavedTableConfigs with parsed data", () => {
    const mockData = [{id: 1, name: "Initial Config"}];

    localStorage.setItem(keyPrefix, JSON.stringify(mockData));

    const result = service.getSavedTableConfigs();

    expect(SavedTableConfigs).toHaveBeenCalledWith(mockData);
    expect(result.savedTableConfigs).toEqual(mockData);
  });

  it("getTableControllerService should return same instance for same table", () => {
    const secondCall = getTableControllerService(tableName);

    expect(secondCall).toBe(service);
  });

  it("getTableControllerService should return different instances for different tables", () => {
    const anotherService = getTableControllerService("AnotherTable");

    expect(anotherService).not.toBe(service);
    expect(anotherService.keyPrefix).toBe("AnotherTable");
  });
});
