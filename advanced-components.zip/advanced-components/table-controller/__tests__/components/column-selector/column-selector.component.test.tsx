import {render, screen} from "@testing-library/react";

import ColumnSelectorComponent from "../../../src/components/column-selector/column-selector.component";

describe("ColumnSelectorComponent", () => {
  const props = {
    columns: [
      {key: "key1", title: "title1"},
      {key: "key2", title: "title2"},
    ],
    defaultColumns: ["key1"],
    onColumnChange: () => {},
  };

  it("Should Render ColumnSelector", async () => {
    render(<ColumnSelectorComponent {...props} />);
    const btn = await screen.getByRole("button");

    expect(btn).toBeInTheDocument();
    btn.click();
    const selectorItems = await screen.findAllByTestId("column-selector-items");

    expect(selectorItems).toHaveLength(2);
  });
});
