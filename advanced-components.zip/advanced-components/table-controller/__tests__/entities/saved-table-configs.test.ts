// Mocking SavedTableConfig and SavedFilter
import {SavedTableConfig} from "../../src/entities/saved-table-config";
import {SavedTableConfigs} from "../../src/entities/saved-table-configs";
import {SavedFilter} from "../../../commons/components/general-filter/src/entities/saved-filter";

jest.mock("../../src/entities/saved-table-config", () => {
  return {
    SavedTableConfig: jest.fn().mockImplementation((data) => ({
      ...data,
      savedFilter: data.savedFilter || null,
      __isMock: true,
    })),
  };
});

describe("SavedTableConfigs", () => {
  beforeEach(() => {
    (SavedTableConfig as jest.Mock).mockClear();
  });

  it("should initialize with an empty array when no data is provided", () => {
    const instance = new SavedTableConfigs();

    expect(instance.savedTableConfigs).toEqual([]);
  });

  it("should initialize from an array of raw data", () => {
    const mockData = [
      {id: 1, savedFilter: {name: "Filter A"}},
      {id: 2, savedFilter: {name: "Filter B"}},
    ];

    const instance = new SavedTableConfigs(mockData);

    expect(SavedTableConfig).toHaveBeenCalledTimes(2);
    expect(instance.savedTableConfigs.length).toBe(2);
    expect(instance.savedFilters).toEqual([{name: "Filter A"}, {name: "Filter B"}]);
  });

  it("should initialize from object with savedTableConfigs property", () => {
    const mockData = {
      savedTableConfigs: [
        {id: 1, savedFilter: {name: "FromObject A"}},
        {id: 2, savedFilter: {name: "FromObject B"}},
      ],
    };

    const instance = new SavedTableConfigs(mockData);

    expect(SavedTableConfig).toHaveBeenCalledTimes(2);
    expect(instance.savedTableConfigs.length).toBe(2);
    expect(instance.savedFilters).toEqual([{name: "FromObject A"}, {name: "FromObject B"}]);
  });

  it("should add a new SavedTableConfig via addSavedTableConfig()", () => {
    const instance = new SavedTableConfigs();

    const newConfig = new SavedTableConfig({id: 3, savedFilter: {name: "NewFilter"}});

    instance.addSavedTableConfig(newConfig);

    expect(instance.savedTableConfigs.length).toBe(1);
    expect(instance.savedFilters).toEqual([{name: "NewFilter"}]);
  });

  it("savedFilters should return array of null if savedFilter is not set", () => {
    const mockData = [{id: 1}, {id: 2}];
    const instance = new SavedTableConfigs(mockData);

    expect(instance.savedFilters).toEqual([null, null]);
  });

  it("should merge saved filters into table config", () => {
    const savedTableConfigs = new SavedTableConfigs([
      {
        id: 1,
        savedFilter: {name: "n1"},
      },
      {
        id: 2,
        savedFilter: {name: "n2"},
      },
      {
        id: 3,
        savedFilter: {name: "n3"},
      },
    ]);

    expect(savedTableConfigs != null).toBeTruthy();
    let savedFitlers = [
      new SavedFilter({id: 1, name: "n11"}),
      new SavedFilter({id: 2, name: "n22"}),
      new SavedFilter({id: 3, name: "n33"}),
    ];

    savedTableConfigs.mergeSavedFilterConfigs(savedFitlers);
    expect(savedTableConfigs.savedTableConfigs.length).toBe(3);
    expect(savedTableConfigs.savedTableConfigs[0].savedFilter?.name).toBe("n11");
    expect(savedTableConfigs.savedTableConfigs[1].savedFilter?.name).toBe("n22");
    expect(savedTableConfigs.savedTableConfigs[2].savedFilter?.name).toBe("n33");
    savedFitlers = [new SavedFilter({id: 1, name: "n11"})];
    savedTableConfigs.mergeSavedFilterConfigs(savedFitlers);
    expect(savedTableConfigs.savedTableConfigs.length).toBe(1);
  });
});
