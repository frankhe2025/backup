import {useDisclosure} from "@aisera-ui/use-disclosure";
import {useMediaQuery} from "usehooks-ts";
import {createContext} from "@aisera-ui/react-utils";

export const [AppShellProvider, useAppShellContext] = createContext<ReturnType<typeof useAppShell>>(
  {
    strict: false,
    errorMessage: "AppShell context not available.",
  },
);

export const useAppShell = () => {
  const disclosure = useDisclosure();

  const isMobile = useMediaQuery("(max-width: 768px)");

  const compactDisclosure = useDisclosure();

  return {
    isSidebarOpen: disclosure.isOpen,
    closeSidebar: disclosure.onClose,
    openSidebar: disclosure.onOpen,
    toggleSidebar: disclosure.onOpenChange,
    isMobile,
    isCollapsed: compactDisclosure.isOpen,
    collapseSidebar: compactDisclosure.onClose,
    expandSidebar: compactDisclosure.onOpen,
    toggleCollapsed: compactDisclosure.onOpenChange,
  };
};
