import {forwardRef} from "@aisera-ui/system";
import React from "react";
import {cn, SlotsToClasses} from "@aisera-ui/theme";
import {ReactRef, useDOMRef} from "@aisera-ui/react-utils";
import {clsx} from "@aisera-ui/shared-utils";

import {AppShellProvider, useAppShell} from "./app-shell-context";

export type AppShellSlots = "main";

export interface AppShellProps {
  /**
   * The top header navigation
   */
  navbar?: React.ReactNode;
  /**
   * Main sidebar, positioned on the left
   */
  sidebar?: React.ReactNode;
  /**
   * Secondary sidebar, positioned on the right
   */
  aside?: React.ReactNode;
  /**
   * The footer
   */
  footer?: React.ReactNode;
  /**
   * The main content
   */
  children: React.ReactNode;
  mainRef?: React.RefObject<HTMLDivElement>;
  /**
   * Ref to the DOM node.
   */
  ref?: ReactRef<HTMLElement | null>;

  classNames?: SlotsToClasses<AppShellSlots>;
}

const AppShell = forwardRef<"div", AppShellProps>((props, ref) => {
  const {
    navbar,
    sidebar,
    aside,
    footer,
    children,
    mainRef,
    className,
    classNames,
    ...containerProps
  } = props;

  const context = useAppShell();

  const domRef = useDOMRef(ref);

  return (
    <AppShellProvider value={context}>
      <div ref={domRef} className={cn("flex flex-col h-dvh w-full", className)} {...containerProps}>
        {/* Navbar */}
        {navbar}
        <div className="flex h-full w-full gap-4">
          {/* Sidebar */}
          {sidebar}

          {/*  Main Content */}
          <div ref={mainRef} className={clsx("w-full flex-1 p-4", classNames?.main)}>
            {children}
          </div>
          {/* Aside */}
          {aside}
        </div>
        {/* Footer */}
        {footer}
      </div>
    </AppShellProvider>
  );
});

AppShell.displayName = "AppShell";

export default AppShell;
