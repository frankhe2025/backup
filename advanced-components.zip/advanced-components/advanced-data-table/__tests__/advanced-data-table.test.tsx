import React from "react";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {DataTableWithControls} from "../src";
import FilterItem from "../../../advanced-components/commons/components/general-filter/src/entities/filter_item";
import {DataTableConfiguration} from "../src/types";

// Mock the dependencies
jest.mock("../../../advanced-components/table-controller/src/table-controller.component", () => ({
  __esModule: true,
  default: jest.fn(({onSearch, onColumnChange, filterConfig}) => (
    <div data-testid="table-controller">
      <button
        data-testid="filter-button"
        onClick={() => onSearch([{key: "name", value: "Amar", operand: "Like"}])}
      >
        Apply Filter
      </button>
      <button data-testid="column-button" onClick={() => onColumnChange(["name", "email"])}>
        Change Columns
      </button>
    </div>
  )),
}));

// Mock the data-table component
jest.mock("../../data-table/src/DataTable", () => ({
  __esModule: true,
  DataTable: jest.fn(({data, configuration}) => (
    <div data-testid="data-table">
      <div data-testid="row-count">{data.length}</div>
      <div data-testid="columns">{configuration.columns.map((col) => col.key).join(",")}</div>
    </div>
  )),
}));

describe("DataTableWithControls", () => {
  const mockData = [
    {
      id: "1",
      name: "Amar Patel",
      email: "amar.patel@cortex.dev",
      role: "Developer",
    },
    {
      id: "2",
      name: "Keisha Williams",
      email: "keisha.w@cortex.dev",
      role: "Designer",
    },
  ];

  const defaultColumns = [
    {key: "name", title: "Name", sortable: true},
    {key: "email", title: "Email", sortable: true},
    {key: "role", title: "Role", sortable: true},
  ];

  const defaultConfiguration: DataTableConfiguration = {
    columns: defaultColumns,
    selectionMode: "multiple",
  };

  const filterItems = [
    new FilterItem({key: "name", label: "Name", type: "TEXT"}),
    new FilterItem({key: "email", label: "Email", type: "TEXT"}),
    new FilterItem({key: "role", label: "Role", type: "TEXT"}),
  ];

  it("filters data when a filter is applied", async () => {
    const user = userEvent.setup();
    const onFilterChangeMock = jest.fn();

    render(
      <DataTableWithControls
        configuration={defaultConfiguration}
        data={mockData}
        filterItems={filterItems}
        onFilterChange={onFilterChangeMock}
      />,
    );

    await user.click(screen.getByTestId("filter-button"));

    // The mocked filter should only return rows with "Amar" in the name
    expect(onFilterChangeMock).toHaveBeenCalled();
  });
});
