import {ReactNode} from "react";
import {Selection} from "@aisera-ui/table";

import FilterItem from "../../../advanced-components/commons/components/general-filter/src/entities/filter_item";

export type DataTableColumnType = "text" | "number" | "date" | "boolean" | "action";

export type SortDirection = "asc" | "desc" | "none";

export interface DataTableActionConfig {
  handler: (id: string) => void;
  icon?: ReactNode;
  label?: string;
}

export interface DataTableActionCollection {
  [key: string]: DataTableActionConfig | ((id: string) => void) | undefined;
}

export type CellRenderer = (
  value: any,
  rowData: any,
  columnKey: string,
  columnType?: DataTableColumnType,
) => ReactNode;

export type ActionRenderer = (rowData: any, actions: DataTableActionCollection) => ReactNode;

export interface TableClassNames {
  base?: string;
  thead?: string;
  th?: string;
  td?: string;
  tr?: string;
  actionButton?: string;
  sortIndicator?: string;
}

export interface DataTableColumn {
  key: string;
  title: string;
  type?: DataTableColumnType;
  cellRenderer?: CellRenderer;
  sortable?: boolean;
  reorderable?: boolean;
}

export interface FilterData {
  key: string;
  value: string | number | boolean | Date | Array<any>;
  operand?: "Like" | "Equal" | "Include" | "Exclude" | "Between" | "Within";
}

export interface DataTableWithControlsProps extends DataTableProps {
  filterItems?: FilterItem[];
  defaultVisibleColumns?: string[];
  onFilterChange?: (filters: {finalFilters?: FilterData[]} | FilterData[]) => void;
  onColumnOrderChange?: (columnOrder: string[]) => void;
  onSortOrderChange?: (sortOrder: {column: string; direction: 'asc' | 'desc' | 'none'}[]) => void;
  tableName?: string;
  selfSaveable?: boolean;
  savedFilters?: any[];
  onSaveNewFilter?: (filter: any) => void;
  onSavedFilterUpdated?: (filters: any[]) => void;
  onSaveNewTableConfig?: (config: any) => void;
  onSavedTableConfigUpdated?: (configs: any) => void;
  savedTableConfigs?: any[];
  currentUserId?: any;
}

export interface DataTableConfiguration {
  columns: DataTableColumn[];
  selectionMode?: "single" | "multiple" | "none";
  onSelectionChange?: (selectedKeys: Selection) => void;
  actions?: DataTableActionCollection;
  defaultCellRenderer?: CellRenderer;
  actionRenderer?: ActionRenderer;
  classNames?: TableClassNames;
  ariaLabel?: string;
  sortColumn?: string;
  sortDirection?: SortDirection;
  onColumnHeaderClick?: (columnKey: string) => void;
  onSort?: (columnKey: string) => void;
  columnOrder?: string[];
  onColumnOrderChange?: (columnOrder: string[]) => void;
  onSortChange?: (column: string, direction: SortDirection) => void;
}

export interface DataTableProps {
  data: any[];
  configuration: DataTableConfiguration;
}
