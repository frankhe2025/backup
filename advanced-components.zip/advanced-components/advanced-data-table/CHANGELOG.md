# @aisera-ui/advanced-data-table

## 2.2.2

### Patch Changes

- Updated dependencies []:
  - @aisera-ui/data-table-v2@2.2.2

## 2.2.1

### Patch Changes

- Action Column Fix

- Updated dependencies [[`ded0b14`](https://github.com/Aisera/ng-uicomponent/commit/ded0b143c9bde5d54f1506a2e7bd654666a975cf)]:
  - @aisera-ui/data-table-v2@2.2.1
  - @aisera-ui/table-controller@2.3.0
  - @aisera-ui/general-filter@2.2.1
