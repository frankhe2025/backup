Backend Service for Next Gen

To start it:

1. npm install
2. copy .env.example to .env and .env.test
3. adding credential into .env and .env.test
4. Go to ticket-ui and start proxy first
5. start this repo with npm start

Now,

1. You can go to swagger at
   http://localhost:9000/api-doc#/Auth/AuthController_login
   and generate token
   You can also go to postman and send POST request to generate token

2. Once you have token, you must put the token into all the following apis header with name as 'jwt'

3. call other demo APIs
