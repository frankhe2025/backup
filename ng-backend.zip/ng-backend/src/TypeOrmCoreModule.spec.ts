import { DataSource, DataSourceOptions } from 'typeorm';
import { TypeOrmCoreModule } from '@nestjs/typeorm/dist/typeorm-core.module';
import { getDataSourceName, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { EntitiesMetadataStorage } from '@nestjs/typeorm/dist/entities-metadata.storage';

describe('TypeOrmCoreModule', () => {
  let createDataSourceFactory: any;

  beforeAll(() => {
    createDataSourceFactory = (TypeOrmCoreModule as any).createDataSourceFactory;
  });

  it('should create a data source factory with autoLoadEntities disabled', async () => {
    const mockOptions: TypeOrmModuleOptions = {
      type: 'mysql',
      autoLoadEntities: false,
      retryAttempts: 1,
      retryDelay: 1000,
    } as TypeOrmModuleOptions;

    const mockDataSource = {
      initialize: jest.fn().mockResolvedValue(true),
      isInitialized: false,
    };

    const mockDataSourceFactory = jest.fn().mockResolvedValue(mockDataSource);

    const result = await createDataSourceFactory(mockOptions, mockDataSourceFactory);

    expect(mockDataSourceFactory).toHaveBeenCalledWith(mockOptions);
    expect(mockDataSource.initialize).toHaveBeenCalled();
  });

  it('should create a data source factory with autoLoadEntities enabled', async () => {
    const mockOptions: TypeOrmModuleOptions = {
      type: 'mysql',
      autoLoadEntities: true,
      retryAttempts: 1,
      retryDelay: 1000,
    } as TypeOrmModuleOptions;

    // Mock entities as classes to match EntityClassOrSchema type
    class TestEntity {}
    const mockEntities = [TestEntity];

    const mockDataSource = {
      initialize: jest.fn().mockResolvedValue(true),
      isInitialized: false,
    };

    jest.spyOn(EntitiesMetadataStorage, 'getEntitiesByDataSource').mockReturnValue(mockEntities);
    const mockDataSourceFactory = jest.fn().mockResolvedValue(mockDataSource);

    // Mock the createDataSourceFactory to return the mockDataSource
    jest.spyOn(TypeOrmCoreModule as any, 'createDataSourceFactory').mockImplementation(async () => mockDataSource);

    const result = await createDataSourceFactory(mockOptions, mockDataSourceFactory);

    expect(mockDataSourceFactory).toHaveBeenCalledWith({
      ...mockOptions,
      entities: mockEntities,
    });
    expect(mockDataSource.initialize).toHaveBeenCalled();
  });
});
