import { Test, TestingModule } from '@nestjs/testing';
import { Logger } from 'nestjs-pino';

import { LoggerService } from './logger.service';

describe('LoggerService', () => {
  let service: LoggerService;
  let mockLogger: any;

  beforeEach(async () => {
    mockLogger = {
      log: jest.fn(),
      warn: jest.fn(),
      error: jest.fn(),
      debug: jest.fn(),
      verbose: jest.fn(),
      fatal: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        LoggerService,
        {
          provide: Logger,
          useValue: mockLogger,
        },
      ],
    }).compile();

    service = module.get<LoggerService>(LoggerService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call log', () => {
    service.log('log message');
    expect(mockLogger.log).toHaveBeenCalledWith({}, 'log message');
  });

  it('should call warn with meta', () => {
    const meta = { context: 'warn-test' };
    service.warn('warn msg', meta);
    expect(mockLogger.warn).toHaveBeenCalledWith(meta, 'warn msg');
  });

  it('should call error', () => {
    service.error('error msg');
    expect(mockLogger.error).toHaveBeenCalledWith({}, 'error msg');
  });

  it('should call debug', () => {
    service.debug('debug msg');
    expect(mockLogger.debug).toHaveBeenCalledWith({}, 'debug msg');
  });

  it('should call verbose', () => {
    const meta = { detail: 'extra' };
    service.verbose('verbose msg', meta);
    expect(mockLogger.verbose).toHaveBeenCalledWith(meta, 'verbose msg');
  });

  it('should call fatal', () => {
    service.fatal('fatal error!');
    expect(mockLogger.fatal).toHaveBeenCalledWith({}, 'fatal error!');
  });
});
