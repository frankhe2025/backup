import { maskSensitiveData } from './logger.entity';

describe('maskSensitiveData Utility', () => {
  it('should mask sensitive keys at the root level', () => {
    const input = {
      token: 'abcdef12345',
      authorization: 'Bearer abcde',
      email: 'user@example.com',
      password: 'mypassword',
      normalKey: 'normalValue',
    };
    const output = maskSensitiveData(input);

    expect(output.token).toMatch(/^xxxxxx/);
    expect(output.authorization).toMatch(/^xxxxxx/);
    expect(output.email).toMatch(/^xxxxxx/);
    expect(output.password).toMatch(/^xxxxxx/);
    expect(output.normalKey).toEqual('normalValue');
  });

  it('should mask sensitive keys inside nested objects', () => {
    const input = {
      user: {
        jwt: 'jwt-token-abc',
        secret: 'super-secret',
      },
    };
    const output = maskSensitiveData(input);

    expect(output.user.jwt).toMatch(/^xxxxxx/);
    expect(output.user.secret).toMatch(/^xxxxxx/);
  });

  it('should mask sensitive keys inside arrays', () => {
    const input = [{ apiKey: 'test-api-key' }, { key: 'test-key' }, { nonSensitive: 'value' }];
    const output = maskSensitiveData(input);

    expect(output[0].apiKey).toMatch(/^xxxxxx/);
    expect(output[1].key).toMatch(/^xxxxxx/);
    expect(output[2].nonSensitive).toEqual('value');
  });

  it('should handle plain strings with sensitive data patterns', () => {
    const input = 'Authorization: Bearer abcdefghijklmnop';
    const output = maskSensitiveData(input);

    expect(output).toContain('Authorization: xxxxxx');
  });

  it('should handle sensitive data with spaces, colons, equals', () => {
    const inputs = ['token abcde expired', 'token:abcdef expired', 'apiKey=abcde123', 'key abcde-1234 used'];

    inputs.forEach((text) => {
      const output = maskSensitiveData(text);
      expect(output).toContain('xxxxxx');
    });
  });

  it('should not mask when no sensitive data is found', () => {
    const input = {
      message: 'Hello world',
      randomKey: 'justSomeText',
    };
    const output = maskSensitiveData(input);

    expect(output).toEqual(input);
  });

  it('should return input as-is for null, undefined, or non-objects', () => {
    expect(maskSensitiveData(null)).toBe(null);
    expect(maskSensitiveData(undefined)).toBe(undefined);
    expect(maskSensitiveData(1234)).toBe(1234);
    expect(maskSensitiveData(true)).toBe(true);
  });

  it('should mask even inside error message field', () => {
    const input = {
      error: 'Token abcdedfe is expired',
    };
    const output = maskSensitiveData(input);

    expect(output.error).toContain('Token xxxxxx');
  });

  it('should only mask values longer than 4 characters', () => {
    const input = {
      token: 'abc',
      email: 'a@b.c',
      password: 'longpassword',
    };
    const output = maskSensitiveData(input);

    expect(output.token).toEqual('xxxxxx');
    expect(output.email).toEqual('xxxxxx@b.c');
    expect(output.password).toMatch(/^xxxxxx/);
  });
});
