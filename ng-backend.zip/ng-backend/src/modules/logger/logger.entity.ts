const RAW_SENSITIVE_KEYS = [
  'authorization',
  'token',
  'jwt',
  'accessToken',
  'refreshToken',
  'apiKey',
  'key',
  'secret',
  'password',
  'email',
];

const SENSITIVE_KEYS = RAW_SENSITIVE_KEYS.map((k: string) => k.toLowerCase());

const SENSITIVE_PATTERN = new RegExp(
  `\\b(${SENSITIVE_KEYS.join('|')})\\b([\\s:=]*)\\s*(?:Bearer\\s+)?([\\w@.\\-]+)`,
  'gi'
);

export const maskSensitiveData = (data: any): any => {
  if (data == null) return data;

  if (typeof data === 'string') {
    return maskSensitiveString(data);
  }

  if (Array.isArray(data)) {
    return data.map((item) => {
      if (typeof item === 'object' && item !== null) {
        return maskSensitiveData(item);
      }
      return item;
    });
  }

  if (typeof data === 'object') {
    return Object.entries(data).reduce(
      (acc, [key, value]) => {
        const lowerKey = key.toLowerCase();
        if (SENSITIVE_KEYS.includes(lowerKey)) {
          acc[key] = maskValue(value);
        } else {
          acc[key] = maskSensitiveData(value);
        }
        return acc;
      },
      {} as Record<string, any>
    );
  }

  return data;
};

const maskSensitiveString = (text: string) => {
  return text.replace(SENSITIVE_PATTERN, (match, key, separator, value) => {
    if (value && value.length > 4) {
      const lastFour = value.slice(-4);
      return `${key}${separator}xxxxxx${lastFour}`;
    }
    return `${key}${separator}xxxxxx`;
  });
};

const maskValue = (value: any) => {
  if (typeof value === 'string' && value.length > 4) {
    const lastFour = value.slice(-4);
    return `xxxxxx${lastFour}`;
  }
  return 'xxxxxx';
};
