import { Injectable } from '@nestjs/common';
import { Logger } from 'nestjs-pino';

@Injectable()
export class LoggerService {
  constructor(private readonly logger: Logger) {}

  log(message: string, meta?: any) {
    this.logger.log(meta ?? {}, message);
  }

  warn(message: string, meta?: any) {
    this.logger.warn(meta ?? {}, message);
  }

  error(message: string, meta?: any) {
    this.logger.error(meta ?? {}, message);
  }

  debug(message: string, meta?: any) {
    this.logger.debug(meta ?? {}, message);
  }

  verbose(message: string, meta?: any) {
    this.logger.verbose(meta ?? {}, message);
  }

  fatal(message: string, meta?: any) {
    this.logger.fatal(meta ?? {}, message);
  }
}
