import { Global, Module } from '@nestjs/common';
import { LoggerModule as PinoLoggerModule } from 'nestjs-pino';

import { loggerConfig } from '../../config/logger.config';
import { LoggerService } from './logger.service';

@Global()
@Module({
  imports: [PinoLoggerModule.forRootAsync(loggerConfig)],
  providers: [LoggerService],
  exports: [LoggerService],
})
export class LoggerModule {}
