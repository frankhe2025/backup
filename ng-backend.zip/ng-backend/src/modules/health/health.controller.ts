import { Controller, Get } from '@nestjs/common';
import { HealthService } from './health.service';

@Controller('ng-backend/v1/health-check')
export class HealthController {
  constructor(private readonly healthService: HealthService) {}

  @Get()
  getHealth() {
    return this.healthService.getHealth();
  }
}
