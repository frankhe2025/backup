import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
import { EntityFilterDto } from '../dto/entity-filter.dto';

const enum EntityType {
  NG_PROMPT = 'NG_PROMPT',
}

@Entity('entity_filters')
export class EntityFilter {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  entityType: EntityType | string;

  @Column()
  criteria: string;

  // DB is using BigInt to save userId, but Javascript can not handle that, so if we do not transfer
  // the value will get changed, so we ahve to use string, and then convert to number before saving
  @Column({
    type: 'bigint',
    transformer: {
      from: (value: string) => value, // Keep as string
      to: (value: string | number) => value.toString(), // Convert number to string before saving
    },
  })
  userId: string;

  @Column({ name: 'sys_updated_at', type: 'timestamp' })
  sysUpdatedAt: Date;

  @Column({ name: 'is_public', type: 'boolean' })
  isPublic: boolean;

  updateWithDto(dto: EntityFilterDto) {
    this.name = dto.name;
    this.criteria = dto.criteria;
    this.isPublic = dto.isPublic;
  }
}
