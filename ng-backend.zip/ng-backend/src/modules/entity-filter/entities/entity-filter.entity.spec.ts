import { EntityFilter } from './entity-filter.entity';
import { EntityFilterDto } from '../dto/entity-filter.dto';
import { getMetadataArgsStorage } from 'typeorm';

describe('EntityFilter', () => {
  it('updateWithDto()', () => {
    const entity = new EntityFilter();
    entity.id = 1;
    entity.entityType = 'TEST';
    entity.userId = '123';
    entity.name = 'Old Name';
    entity.criteria = 'Old Criteria';
    entity.isPublic = false;

    const dto = new EntityFilterDto();
    dto.id = 2;
    dto.name = 'TEST NEW';
    dto.criteria = 'New Criteria';
    dto.isPublic = true;

    entity.updateWithDto(dto);
    expect(entity.entityType).toEqual('TEST');
    expect(entity.id).toEqual(1);
    expect(entity.name).toEqual(dto.name);
    expect(entity.isPublic).toEqual(dto.isPublic);
    expect(entity.criteria).toEqual(dto.criteria);
  });

  describe('userId transformer', () => {
    const getUserIdTransformer = (): any => {
      const column = getMetadataArgsStorage().columns.find(
        (col) => col.target === EntityFilter && col.propertyName === 'userId'
      );
      return column?.options?.transformer;
    };

    it('should transform DB value (string) to entity (string)', () => {
      expect(getUserIdTransformer().from('12345678901234567890')).toBe('12345678901234567890');
    });
    it('should transform entity value (number) to DB (string)', () => {
      expect(getUserIdTransformer().to(123)).toBe('123');
    });

    it('should transform entity value (string) to DB (string)', () => {
      expect(getUserIdTransformer().to('98765432109876543210')).toBe('98765432109876543210');
    });
  });
});
