import { IsBoolean, IsNumber, IsOptional, IsString } from 'class-validator';
import { EntityFilter } from '../entities/entity-filter.entity';
import { ApiProperty } from '@nestjs/swagger';

export class EntityFilterDto {
  @IsNumber()
  @IsOptional()
  @ApiProperty({ description: 'Id for passed filter', example: 1 })
  id?: number;

  @IsString()
  @ApiProperty({ description: 'Name for the entity filter', example: 'Filter 1' })
  name?: string;

  @IsString()
  @IsOptional()
  @ApiProperty({ description: 'Entity Type', example: 'NG-PROMPT' })
  entityType?: string;

  @IsString()
  @ApiProperty({ description: 'Entity Filter Criteria', example: '' })
  criteria?: string;

  @IsOptional()
  @ApiProperty({ description: 'UserId for the creator', example: '12345' })
  userId?: string;

  @IsBoolean()
  @ApiProperty({ description: 'Is this entity filter public or not', example: true })
  isPublic?: boolean;

  toEntityFilterObject(): EntityFilter {
    const obj = new EntityFilter();
    if (this.id) obj.id = this.id;
    if (this.name) obj.name = this.name;
    if (this.entityType) obj.entityType = this.entityType;
    if (this.criteria) obj.criteria = this.criteria;
    if (this.userId) obj.userId = this.userId;

    obj.isPublic = this.isPublic;
    return obj;
  }

  updateEntityFilterObject(entity: EntityFilter) {
    if (this.name) entity.name = this.name;
    if (this.criteria) entity.criteria = this.criteria;
    if (this.isPublic === true || this.isPublic === false) {
      entity.isPublic = this.isPublic;
    }
    return entity;
  }
}
