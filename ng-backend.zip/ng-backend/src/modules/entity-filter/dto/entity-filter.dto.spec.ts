import { EntityFilterDto } from './entity-filter.dto';
import { EntityFilter } from '../entities/entity-filter.entity';

describe('EntityFilterDto', () => {
  describe('toEntityFilterObject', () => {
    it('should convert DTO to EntityFilter object correctly', () => {
      const dto = new EntityFilterDto();
      dto.id = 1;
      dto.name = 'Test Filter';
      dto.entityType = 'PROMPT';
      dto.criteria = '{"field": "value"}';
      dto.userId = '123';
      dto.isPublic = true;

      const entity = dto.toEntityFilterObject();

      expect(entity.id).toBe(1);
      expect(entity.name).toBe('Test Filter');
      expect(entity.entityType).toBe('PROMPT');
      expect(entity.criteria).toBe('{"field": "value"}');
      expect(entity.userId).toBe('123');
      expect(entity.isPublic).toBe(true);
    });

    it('should handle missing optional fields correctly', () => {
      const dto = new EntityFilterDto();
      dto.name = 'Name Only';
      dto.criteria = 'some-criteria';
      dto.isPublic = false;

      const entity = dto.toEntityFilterObject();

      expect(entity.name).toBe('Name Only');
      expect(entity.criteria).toBe('some-criteria');
      expect(entity.isPublic).toBe(false);
      expect(entity.id).toBeUndefined();
      expect(entity.entityType).toBeUndefined();
      expect(entity.userId).toBeUndefined();
    });
  });

  describe('updateEntityFilterObject', () => {
    it('should update an existing EntityFilter with DTO values', () => {
      const dto = new EntityFilterDto();
      dto.name = 'Updated Name';
      dto.criteria = 'updated-criteria';
      dto.isPublic = true;

      const entity: EntityFilter = {
        id: 1,
        name: 'Old Name',
        entityType: 'PROMPT',
        criteria: 'old-criteria',
        userId: '123',
        sysUpdatedAt: new Date(),
        isPublic: false,
        updateWithDto: () => {},
      };

      const updatedEntity = dto.updateEntityFilterObject(entity);

      expect(updatedEntity.name).toBe('Updated Name');
      expect(updatedEntity.criteria).toBe('updated-criteria');
      expect(updatedEntity.isPublic).toBe(true);
    });

    it('should not overwrite isPublic if undefined in DTO', () => {
      const dto = new EntityFilterDto();
      dto.name = 'Only Name Updated';

      const entity: EntityFilter = {
        id: 2,
        name: 'Initial Name',
        entityType: 'PROMPT',
        criteria: 'criteria',
        userId: '456',
        sysUpdatedAt: new Date(),
        isPublic: false,
        updateWithDto: () => {},
      };

      const updatedEntity = dto.updateEntityFilterObject(entity);

      expect(updatedEntity.name).toBe('Only Name Updated');
      expect(updatedEntity.isPublic).toBe(false); // unchanged
    });
  });
});
