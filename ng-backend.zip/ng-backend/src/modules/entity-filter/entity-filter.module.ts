import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EntityFilter } from './entities/entity-filter.entity';
import { TENANT_DB_CONNECTION } from '../../common/constants';
import { EntityFilterService } from './services/entity-filter.service';
import { EntityFilterController } from './controllers/entity-filter.controller';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [TypeOrmModule.forFeature([EntityFilter], TENANT_DB_CONNECTION), AuthModule],
  providers: [EntityFilterService],
  controllers: [EntityFilterController],
})
export class EntityFilterModule {}
