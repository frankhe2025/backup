import { EntityFilterService } from './entity-filter.service';
import { In, Repository } from 'typeorm';
import { EntityFilter } from '../entities/entity-filter.entity';
import { EntityFilterDto } from '../dto/entity-filter.dto';

jest.mock('../../auth/auth.service');

const mockRepository = () => ({
  find: jest.fn(),
  findOne: jest.fn(),
  save: jest.fn(),
  delete: jest.fn(),
});

const mockAuthService = {
  authUser: {
    userId: '123',
  },
};

describe('EntityFilterService', () => {
  let service: EntityFilterService;
  let repository: jest.Mocked<Repository<EntityFilter>>;

  beforeEach(() => {
    repository = mockRepository() as any;
    service = new EntityFilterService(repository, mockAuthService as any);
  });

  describe('getAllMyEntityFilters', () => {
    it('should return filters where entityType matches and isPublic OR userId matches', async () => {
      const filters = [{ id: 1 }, { id: 2 }];
      repository.find.mockResolvedValue(filters as any);

      const result = await service.getAllMyEntityFilters('PROMPT');
      expect(repository.find).toHaveBeenCalledWith({
        where: [
          { entityType: 'PROMPT', isPublic: true },
          { entityType: 'PROMPT', userId: '123' },
        ],
      });
      expect(result).toEqual(filters);
    });
  });

  describe('getFilterEntityById', () => {
    it('should return filter by id and entityType with isPublic or userId', async () => {
      const filter = { id: 1 };
      repository.findOne.mockResolvedValue(filter as any);

      const result = await service.getFilterEntityById('PROMPT', 1);
      expect(repository.findOne).toHaveBeenCalledWith({
        where: [
          { id: 1, entityType: 'PROMPT', isPublic: true },
          { id: 1, entityType: 'PROMPT', userId: '123' },
        ],
      });
      expect(result).toEqual(filter);
    });
  });

  describe('createFilterEntity', () => {
    it('should create and save a new filter entity', async () => {
      const dto: EntityFilterDto = {
        id: null,
        name: 'test',
        criteria: 'criteria',
        isPublic: false,
        toEntityFilterObject: () => {
          return new EntityFilter();
        },
        updateEntityFilterObject: (entity: EntityFilter) => {
          return this;
        },
      };

      const savedEntity = { id: 1 };
      repository.save.mockResolvedValue(savedEntity as any);

      const result = await service.createFilterEntity('PROMPT', dto);
      expect(repository.save).toHaveBeenCalled();
      expect(result).toEqual(savedEntity);
    });
  });

  describe('deleteFilterEntities', () => {
    it('should delete entities with matching ids and userId', async () => {
      await service.deleteFilterEntities('PROMPT', ['1', '2']);
      expect(repository.delete).toHaveBeenCalledWith({
        id: In(['1', '2']),
        entityType: 'PROMPT',
        userId: '123',
      });
    });
  });

  describe('updateFilterEntity', () => {
    it('should update an existing filter', async () => {
      const existing = {
        id: 1,
        name: 'old',
        updateWithDto: jest.fn(),
      };

      const dto: EntityFilterDto = {
        id: 1,
        name: 'updated',
        criteria: 'new',
        isPublic: true,
        toEntityFilterObject: () => {
          return new EntityFilter();
        },
        updateEntityFilterObject: (entity: EntityFilter) => {
          return this;
        },
      };

      repository.findOne.mockResolvedValue(existing as any);
      repository.save.mockResolvedValue({ ...existing, name: 'updated' } as any);

      const result = await service.updateFilterEntity('PROMPT', 1, dto);
      expect(repository.save).toHaveBeenCalled();
      expect(result.name).toBe('updated');
    });
  });

  describe('updateFilterEntities', () => {
    it('should batch update filter entities', async () => {
      const dtos: EntityFilterDto[] = [
        {
          id: 1,
          name: 'Filter1',
          criteria: 'criteria1',
          isPublic: false,
          toEntityFilterObject: () => {
            return new EntityFilter();
          },
          updateEntityFilterObject: (entity: EntityFilter) => {
            return this;
          },
        },
        {
          id: 2,
          name: 'Filter2',
          criteria: 'criteria2',
          isPublic: true,
          toEntityFilterObject: () => {
            return new EntityFilter();
          },
          updateEntityFilterObject: (entity: EntityFilter) => {
            return this;
          },
        },
      ];

      const existingEntities = [
        {
          id: 1,
          updateWithDto: jest.fn(),
        },
        {
          id: 2,
          updateWithDto: jest.fn(),
        },
      ];

      repository.find.mockResolvedValue(existingEntities as any);
      repository.save.mockResolvedValue(existingEntities as any);

      await service.updateFilterEntities('PROMPT', dtos);

      expect(repository.find).toHaveBeenCalledWith({
        where: {
          id: In([1, 2]),
          userId: '123',
          entityType: 'PROMPT',
        },
      });
      expect(repository.save).toHaveBeenCalledWith(existingEntities);
    });
  });
});
