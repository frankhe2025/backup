import { Repository, In } from 'typeorm';
import { EntityFilter } from '../entities/entity-filter.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { TENANT_DB_CONNECTION } from '../../../common/constants';
import { Injectable } from '@nestjs/common';
import { AuthService } from '../../auth/auth.service';
import { EntityFilterDto } from '../dto/entity-filter.dto';

@Injectable()
export class EntityFilterService {
  constructor(
    @InjectRepository(EntityFilter, TENANT_DB_CONNECTION)
    private readonly entityFilterRepository: Repository<EntityFilter>,
    private readonly authServivce: AuthService
  ) {}

  getAllMyEntityFilters(entityType: string): Promise<EntityFilter[]> {
    return this.entityFilterRepository.find({
      // this  entityType='abc' and ( either isPublic or current user created)
      // [{}, {}]
      where: [
        {
          entityType,
          isPublic: true,
        },
        {
          entityType,
          // type is string, entity class will automatically convert it
          userId: this.authServivce.authUser.userId.toString(),
        },
      ],
    });
  }

  getFilterEntityById(entityType: string, id: number) {
    return this.entityFilterRepository.findOne({
      // this must be AND, entityType, id AND ( userId = current user OR isPublic = true)
      // in where clause, we do {entityType, id and ispubic} or {entityType, id and currentUser}
      where: [
        {
          id,
          entityType,
          isPublic: true,
        },
        {
          id,
          entityType,
          // type is string, entity class will automatically convert it
          userId: this.authServivce.authUser.userId.toString(),
        },
      ],
    });
  }

  createFilterEntity(entityType: string, entityFilter: EntityFilterDto) {
    const entityFilterObj = entityFilter.toEntityFilterObject();
    entityFilterObj.entityType = entityType;
    this.updateEntityCommonField(entityFilterObj);
    return this.entityFilterRepository.save(entityFilterObj);
  }

  deleteFilterEntities(entityType: string, ids: string[]) {
    return this.entityFilterRepository.delete({
      id: In(ids),
      entityType,
      userId: this.authServivce.authUser.userId.toString(),
    });
  }

  async updateFilterEntity(entityType: string, id: number, entityFilter: EntityFilterDto) {
    const entityFilterObj = await this.getFilterEntityById(entityType, id);
    const udpatedEntityObj = entityFilter.updateEntityFilterObject(entityFilterObj);
    this.updateEntityCommonField(udpatedEntityObj);
    return this.entityFilterRepository.save(udpatedEntityObj);
  }

  async updateFilterEntities(entityType: string, entityFilterDtos: EntityFilterDto[]) {
    const entityFilterObjects: EntityFilter[] = [];
    // get all My created entityFitler with same type
    const entityIds = entityFilterDtos.map((dto) => dto.id);

    // For batch updates
    // We loop every passed in entityFilter, if editable, we edit (self created filter)
    const existingEntities: EntityFilter[] = await this.entityFilterRepository.find({
      where: {
        userId: this.authServivce.authUser.userId.toString(),
        entityType,
        id: In(entityIds),
      },
    });
    existingEntities.forEach((entity: EntityFilter) => {
      entity.updateWithDto(entityFilterDtos.find((dto) => dto.id === entity.id));
      this.updateEntityCommonField(entity);
    });
    // now update them
    await this.entityFilterRepository.save(existingEntities);
  }

  updateEntityCommonField(entityFilter: EntityFilter) {
    entityFilter.userId = this.authServivce.authUser.userId.toString();
    entityFilter.sysUpdatedAt = new Date();
    return entityFilter;
  }
}
