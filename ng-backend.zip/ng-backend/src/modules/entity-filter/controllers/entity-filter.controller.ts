import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';
import { EntityFilterService } from '../services/entity-filter.service';
import { EntityFilter } from '../entities/entity-filter.entity';
import { ApiBody, ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger';
import { EntityFilterDto } from '../dto/entity-filter.dto';
import { AuthLoginDto, AuthResponse } from '../../auth/auth.dto';

@Controller('/entity-filter')
@ApiTags('Entity Filter')
export class EntityFilterController {
  constructor(private readonly entityFilterService: EntityFilterService) {}

  @Get('/:entityType')
  @ApiOperation({
    summary: 'Get All Entity Filters',
    description: 'Return all the entity filters created by current logged in user as well as all the public filters',
  })
  @ApiParam({
    name: 'entityType',
    type: String,
    description: 'Entity type for the search, this can be anything that passed by UI requirement',
  })
  @ApiResponse({
    status: 200,
    description: 'List of Filters for the passed Entity Type',
  })
  getAllMyEntityFilters(@Param('entityType') entityType: string): Promise<EntityFilter[]> {
    return this.entityFilterService.getAllMyEntityFilters(entityType);
  }

  @Get('/:entityType/:id')
  @ApiOperation({
    summary: 'Get Entity Filter',
    description: 'Return Entity Fitler for the passed in filerId',
  })
  @ApiParam({
    name: 'entityType',
    type: String,
    description: 'Entity type for the search, this can be anything that passed by UI requirement',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'Entity Filter Id used to search the filter configuration',
  })
  @ApiResponse({
    status: 200,
    description: 'Filter Configuration',
  })
  getFilterEntityById(@Param('id') id: number, @Param('entityType') entityType: string): Promise<EntityFilter> {
    return this.entityFilterService.getFilterEntityById(entityType, id);
  }

  @Post('/:entityType')
  @ApiOperation({
    summary: 'Create Entity Filter',
    description: 'Create Entity Filter For the Passed In Entity Type',
  })
  @ApiParam({
    name: 'entityType',
    type: String,
    description: 'Entity type for the search, this can be anything that passed by UI requirement',
  })
  @ApiBody({
    description: 'Entity Filter Configuration',
    type: EntityFilterDto,
    required: true,
  })
  @ApiResponse({
    status: 200,
    description: 'Created Entity Filter',
  })
  postCreateEntityType(
    @Param('entityType') entityType: string,
    @Body() entityFilter: EntityFilterDto
  ): Promise<EntityFilter> {
    return this.entityFilterService.createFilterEntity(entityType, entityFilter);
  }

  // can delete multiple filters by 1,2,3,4,5
  @Delete('/:entityType/:ids')
  @ApiOperation({
    summary: 'Delete Entity Filters',
    description: 'Delete one or more Entity Filters',
  })
  @ApiParam({
    name: 'entityType',
    type: String,
    description: 'Entity type for the search, this can be anything that passed by UI requirement',
  })
  @ApiParam({
    name: 'ids',
    type: String,
    description: 'list of Ids for the entity filters to be deleted, seperated by comma, such as 1,2,3,4',
  })
  deleteFilterEntities(@Param('entityType') entityType: string, @Param('ids') ids: string) {
    return this.entityFilterService.deleteFilterEntities(entityType, ids.split(','));
  }

  @Put('/:entityType')
  @ApiOperation({
    summary: 'Batch update entity filters',
    description: 'Update all the entity filters using passed in objects',
  })
  @ApiParam({
    name: 'entityType',
    type: String,
    description: 'Entity type for the search, this can be anything that passed by UI requirement',
  })
  @ApiBody({
    description: 'List of updated entity filters',
    type: EntityFilterDto,
    isArray: true,
    required: true,
  })
  updateFilterEntities(@Param('entityType') entityType: string, @Body() entityFilters: EntityFilterDto[]) {
    this.entityFilterService.updateFilterEntities(entityType, entityFilters);
  }
  @Put('/:entityType/:id')
  @ApiOperation({
    summary: 'Update entity filter',
    description: 'Update single entity filter for the passed in Id',
  })
  @ApiParam({
    name: 'entityType',
    type: String,
    description: 'Entity type for the search, this can be anything that passed by UI requirement',
  })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'Entity Filter Id used to find out the record to be updated',
  })
  updateFilterEntity(
    @Param('entityType') entityType: string,
    @Param('id') id: number,
    @Body() entityFilter: EntityFilterDto
  ) {
    return this.entityFilterService.updateFilterEntity(entityType, id, entityFilter);
  }
}
