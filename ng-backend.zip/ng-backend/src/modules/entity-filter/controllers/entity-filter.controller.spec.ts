import { EntityFilterController } from './entity-filter.controller';
import { EntityFilterService } from '../services/entity-filter.service';
import { Test, TestingModule } from '@nestjs/testing';
import { AuthModule } from '../../auth/auth.module';

import { TENANT_DB_CONNECTION } from '../../../common/constants';
import { getRepositoryToken } from '@nestjs/typeorm';
import { EntityFilter } from '../entities/entity-filter.entity';
import { AuthService } from '../../auth/auth.service';
import { EntityFilterDto } from '../dto/entity-filter.dto';
const mockRepository = {
  find: jest.fn(),
  findOne: jest.fn(),
  save: jest.fn(),
  delete: jest.fn(),
};

const mockAuthService = {
  authUser: { userId: 'test-user' },
};

const mockService = {
  getAllMyEntityFilters: jest.fn(),
  getFilterEntityById: jest.fn(),
  createFilterEntity: jest.fn(),
  deleteFilterEntities: jest.fn(),
  updateFilterEntity: jest.fn(),
  updateFilterEntities: jest.fn(),
};
describe('EntityFitlerController', () => {
  let controller: EntityFilterController;
  let service: EntityFilterService;

  beforeEach(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({
      controllers: [EntityFilterController],
      providers: [
        {
          provide: EntityFilterService,
          useValue: mockService,
        },
        {
          provide: getRepositoryToken(EntityFilter, TENANT_DB_CONNECTION),
          useValue: mockRepository,
        },
        {
          provide: AuthService,
          useValue: mockAuthService,
        },
      ],
    }).compile();

    controller = moduleRef.get<EntityFilterController>(EntityFilterController);
    service = moduleRef.get<EntityFilterService>(EntityFilterService);
  });

  describe('getFilterEntityById', () => {
    it('should return the entity filter with given id and entityType', async () => {
      const mockEntity: EntityFilter = { id: 1, entityType: 'test', isPublic: true } as EntityFilter;
      mockService.getFilterEntityById.mockResolvedValue(mockEntity);

      const result = await controller.getFilterEntityById(1, 'test');
      expect(result).toEqual(mockEntity);
      expect(service.getFilterEntityById).toHaveBeenCalledWith('test', 1);
    });
  });

  describe('postCreateEntityType', () => {
    it('should create and return the new entity filter', async () => {
      const dto: EntityFilterDto = {
        toEntityFilterObject: jest.fn().mockReturnValue({ name: 'test-filter' }),
      } as any;

      const createdEntity = { id: 2, name: 'test-filter', entityType: 'test' } as EntityFilter;
      mockService.createFilterEntity.mockResolvedValue(createdEntity);

      const result = await controller.postCreateEntityType('test', dto);
      expect(result).toEqual(createdEntity);
      expect(service.createFilterEntity).toHaveBeenCalledWith('test', dto);
    });
  });

  describe('deleteFilterEntities', () => {
    it('should call service to delete entity filters', async () => {
      mockService.deleteFilterEntities.mockResolvedValue({ affected: 1 });

      const result = await controller.deleteFilterEntities('test', '1');
      expect(result).toEqual({ affected: 1 });
      expect(service.deleteFilterEntities).toHaveBeenCalledWith('test', ['1']);
    });
  });

  describe('updateFilterEntity', () => {
    it('should update and return the entity filter', async () => {
      const dto: EntityFilterDto = {
        updateEntityFilterObject: jest.fn().mockReturnValue({ id: 1, name: 'updated-filter' }),
      } as any;

      const updatedEntity = { id: 1, name: 'updated-filter', entityType: 'test' } as EntityFilter;
      mockService.updateFilterEntity.mockResolvedValue(updatedEntity);

      const result = await controller.updateFilterEntity('test', 1, dto);
      expect(result).toEqual(updatedEntity);
      expect(service.updateFilterEntity).toHaveBeenCalledWith('test', 1, dto);
    });
  });

  it('should update only user-owned filters', async () => {
    const entityType = 'PROMPT';

    const dto1: EntityFilterDto = { id: 1, name: 'Filter A' } as any;
    const dto2: EntityFilterDto = { id: 2, name: 'Filter B' } as any;
    const entityDtoList = [dto1, dto2];

    const entity1 = new EntityFilter();
    entity1.id = 1;
    entity1.updateWithDto = jest.fn();

    const entity2 = new EntityFilter();
    entity2.id = 2;
    entity2.updateWithDto = jest.fn();

    await service.updateFilterEntities(entityType, entityDtoList);
  });
});
