import { Test, TestingModule } from '@nestjs/testing';
import { PrometheusController } from './prometheus.controller';
import { PrometheusService } from './prometheus.service';
import { Response } from 'express';
import { PrometheusMetricName } from './prometheus.metric_name.enum';

describe('PrometheusController', () => {
  let controller: PrometheusController;
  let service: PrometheusService;

  const mockPrometheusService = {
    getMetrics: jest.fn(),
    count: jest.fn(),
    gauge: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PrometheusController],
      providers: [
        {
          provide: PrometheusService,
          useValue: mockPrometheusService,
        },
      ],
    }).compile();

    controller = module.get<PrometheusController>(PrometheusController);
    service = module.get<PrometheusService>(PrometheusService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('getMetrics', () => {
    it('should return metrics', async () => {
      const mockResponse = {
        setHeader: jest.fn(),
        send: jest.fn(),
      } as unknown as Response;

      mockPrometheusService.getMetrics.mockResolvedValue('mock-metrics');

      await controller.getMetrics(mockResponse);

      expect(mockResponse.setHeader).toHaveBeenCalledWith('Content-Type', 'text/plain');
      expect(mockResponse.send).toHaveBeenCalledWith('mock-metrics');
    });
  });

  describe('testCounter', () => {
    it('should call PrometheusService.count with correct arguments', () => {
      controller.testCounter();

      expect(service.count).toHaveBeenCalledWith(
        PrometheusMetricName.TEST_COUNTER,
        { label1: 'a', label2: 'b', tenantId: '10000' },
        2
      );
    });
  });

  describe('testGauge', () => {
    it('should call PrometheusService.gauge with correct arguments', () => {
      controller.testGauge();

      expect(service.gauge).toHaveBeenCalledWith(
        PrometheusMetricName.TEST_GAUGE,
        { label1: 'a', label2: 'b', tenantId: 'onTrac' },
        expect.any(Number)
      );
    });
  });
});
