import { Injectable } from '@nestjs/common';
import * as client from 'prom-client';
import { Counter, Gauge, Histogram } from 'prom-client';

@Injectable()
export class PrometheusService {
  private readonly register: client.Registry;
  private readonly countersMap;
  private readonly gaugesMap;
  private readonly histogramsMap;
  constructor() {
    this.register = new client.Registry();
    this.register.setDefaultLabels({ app: 'ng-backend' });
    client.collectDefaultMetrics({
      register: this.register,
      // prefix: 'ng_backend_',
    });
    this.countersMap = {};
    this.gaugesMap = {};
    this.histogramsMap = {};
  }

  getMetrics(): Promise<string> {
    return this.register.metrics();
  }

  private _getCounter(counterName: string, labelNames: string[] = []): Counter {
    if (!(counterName in this.countersMap)) {
      this.countersMap[counterName] = new client.Counter({
        name: counterName,
        help: counterName,
        labelNames: labelNames,
      });
      this.register.registerMetric(this.countersMap[counterName]);
    }
    return this.countersMap[counterName];
  }
  private _getGauge(gaugeName: string, labelNames: string[] = []): Gauge {
    if (!(gaugeName in this.gaugesMap)) {
      this.gaugesMap[gaugeName] = new client.Gauge({
        name: gaugeName,
        help: gaugeName,
        labelNames: labelNames,
      });
      this.register.registerMetric(this.gaugesMap[gaugeName]);
    }
    return this.gaugesMap[gaugeName];
  }

  private _getHistogram(histogramName: string): Histogram {
    if (!(histogramName in this.histogramsMap)) {
      this.histogramsMap[histogramName] = new client.Histogram({
        name: histogramName,
        help: histogramName,
      });
    }
    return this.histogramsMap[histogramName];
  }

  count(counterName: string, labels: any = {}, value: number) {
    const counter = this._getCounter(counterName, Object.keys(labels));
    counter.labels(labels).inc(value);
  }

  gauge(gaugeName: string, labels: any = {}, incDecValue: number) {
    const gauge = this._getGauge(gaugeName, Object.keys(labels));
    if (incDecValue > 0) {
      gauge.labels(labels).inc(incDecValue);
    } else {
      gauge.labels(labels).dec(Math.abs(incDecValue));
    }
  }
}
