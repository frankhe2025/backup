import { Test, TestingModule } from '@nestjs/testing';
import { PrometheusService } from './prometheus.service';
import * as client from 'prom-client';

describe('PrometheusService', () => {
  let service: PrometheusService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PrometheusService],
    }).compile();

    service = module.get<PrometheusService>(PrometheusService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getMetrics', () => {
    it('should return metrics as a string', async () => {
      const metricsSpy = jest.spyOn(client.Registry.prototype, 'metrics').mockResolvedValue('mock_metrics');
      const result = await service.getMetrics();
      expect(result).toBe('mock_metrics');
      expect(metricsSpy).toHaveBeenCalled();
    });
  });

  describe('count', () => {
    it('should increment the counter with the given value and labels', () => {
      const counterName = 'test_counter';
      const labels = { label1: 'a', label2: 'b' };
      const value = 2;

      const counterSpy = jest.spyOn(client, 'Counter').mockImplementation(
        () =>
          ({
            labels: jest.fn().mockReturnValue({ inc: jest.fn() }),
          }) as any
      );

      service.count(counterName, labels, value);

      expect(counterSpy).toHaveBeenCalledWith({
        name: counterName,
        help: counterName,
        labelNames: Object.keys(labels),
      });
    });
  });

  describe('gauge', () => {
    it('should increment the gauge when value is positive', () => {
      const gaugeName = 'test_gauge';
      const labels = { label1: 'a' };
      const value = 5;

      const gaugeSpy = jest.spyOn(client, 'Gauge').mockImplementation(
        () =>
          ({
            labels: jest.fn().mockReturnValue({ inc: jest.fn(), dec: jest.fn() }),
          }) as any
      );

      service.gauge(gaugeName, labels, value);

      expect(gaugeSpy).toHaveBeenCalledWith({
        name: gaugeName,
        help: gaugeName,
        labelNames: Object.keys(labels),
      });
    });

    it('should decrement the gauge when value is negative', () => {
      const gaugeName = 'test_gauge';
      const labels = { label1: 'a' };
      const value = -3;

      const gaugeSpy = jest.spyOn(client, 'Gauge').mockImplementation(
        () =>
          ({
            labels: jest.fn().mockReturnValue({ inc: jest.fn(), dec: jest.fn() }),
          }) as any
      );

      service.gauge(gaugeName, labels, value);

      expect(gaugeSpy).toHaveBeenCalledWith({
        name: gaugeName,
        help: gaugeName,
        labelNames: Object.keys(labels),
      });
    });
  });
});
