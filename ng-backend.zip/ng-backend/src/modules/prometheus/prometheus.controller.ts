import { Controller, Get, Res } from '@nestjs/common';
import { Response } from 'express';
import { PrometheusService } from './prometheus.service';
import { PrometheusMetricName } from './prometheus.metric_name.enum';

@Controller('metrics')
export class PrometheusController {
  constructor(private readonly prometheusService: PrometheusService) {}

  @Get()
  async getMetrics(@Res() res: Response) {
    const metrics = await this.prometheusService.getMetrics();
    res.setHeader('Content-Type', 'text/plain');
    res.send(metrics);
  }

  @Get('/test_counter')
  testCounter() {
    this.prometheusService.count(PrometheusMetricName.TEST_COUNTER, { label1: 'a', label2: 'b', tenantId: '10000' }, 2);
  }

  @Get('/test_gauge')
  testGauge() {
    for (let i = 0; i < 10; i++) {
      this.prometheusService.gauge(
        PrometheusMetricName.TEST_GAUGE,
        { label1: 'a', label2: 'b', tenantId: 'onTrac' },
        i
      );
    }

    for (let i = 10; i >= 0; i--) {
      this.prometheusService.gauge(PrometheusMetricName.TEST_GAUGE, { label1: 'a', label2: 'b' }, i * -1);
    }
  }
}
