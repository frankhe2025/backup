import { Controller, Get, Param } from '@nestjs/common';
import { BotService } from '../services/bot.service';
import { TenantService } from '../services/tenant.service';
import { AiTicketService } from '../services/ai_ticket.service';
import { AiIntentService } from '../services/ai_intent.service';

@Controller('/demo')
export class DemoController {
  constructor(
    private botService: BotService,
    private tenantService: TenantService,
    private aiTicketService: AiTicketService,
    private aiIntentService: AiIntentService
  ) {}

  @Get('/bots/total')
  async getAllBotsCount() {
    return await this.botService.count();
  }
  @Get('/bots/:offset?/:pageSize?')
  async getAllBots(@Param('offset') offset = 0, @Param('pageSize') pageSize = 20) {
    return await this.botService.get(offset, pageSize);
  }

  @Get('/tenants/total')
  async getAllTenantsCount() {
    return await this.tenantService.count();
  }
  @Get('/tenants/:offset?/:pageSize?')
  async getAllTenants(@Param('offset') offset = 0, @Param('pageSize') pageSize = 20) {
    return await this.tenantService.get(offset, pageSize);
  }

  @Get('/ai_tickets/total')
  async getAiTicketsCount() {
    return await this.aiTicketService.count();
  }
  @Get('/ai_tickets/:offset?/:pageSize?')
  async getAiTickets(@Param('offset') offset = 0, @Param('pageSize') pageSize = 20) {
    return await this.aiTicketService.get(offset, pageSize);
  }

  @Get('/ai_intents/total')
  async getAiIntentsCount() {
    return await this.aiIntentService.count();
  }
  @Get('/ai_intents/:offset?/:pageSize?')
  async getAiIntents(@Param('offset') offset = 0, @Param('pageSize') pageSize = 20) {
    return await this.aiIntentService.get(offset, pageSize);
  }
}
