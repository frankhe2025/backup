import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Tenant } from './entities/tenant.entity';
import { Bot } from './entities/bot.entity';
import { TENANT_DB_CONNECTION } from '../../common/constants';
import { BotService } from './services/bot.service';
import { TenantService } from './services/tenant.service';
import { DemoController } from './controllers/demo.controller';
import { ClickhouseService } from './services/common/clickhouse.service';
import { AiTicketService } from './services/ai_ticket.service';
import { AiTicket } from './entities/ai_ticket.entity';
import { AiIntent } from './entities/ai_intent.entity';
import { AiIntentService } from './services/ai_intent.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Tenant]),
    TypeOrmModule.forFeature([Bot, AiTicket, AiIntent], TENANT_DB_CONNECTION),
  ],
  providers: [ClickhouseService, BotService, TenantService, AiTicketService, AiIntentService],
  controllers: [DemoController],
})
export class DemoModule {}
