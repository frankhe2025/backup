import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Tenant } from '../entities/tenant.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { ClickhouseService } from './common/clickhouse.service';
import { EntityBaseService } from './common/entity_base.service';
@Injectable()
export class TenantService extends EntityBaseService {
  tenants: Tenant[] = [];
  constructor(
    @InjectRepository(Tenant)
    private tenantRepository: Repository<Tenant>,
    private ckService: ClickhouseService
  ) {
    super(tenantRepository, ckService);
  }
}
