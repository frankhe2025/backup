import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Bot } from '../entities/bot.entity';
import { TENANT_DB_CONNECTION } from '../../../common/constants';
import { InjectRepository } from '@nestjs/typeorm';
import { ClickhouseService } from './common/clickhouse.service';
import { EntityBaseService } from './common/entity_base.service';

@Injectable()
export class BotService extends EntityBaseService {
  constructor(
    @InjectRepository(Bot, TENANT_DB_CONNECTION)
    private botRepository: Repository<Bot>,
    private ckService: ClickhouseService
  ) {
    super(botRepository, ckService);
  }
}
