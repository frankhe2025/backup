import { Repository } from 'typeorm';
import { ClickhouseService } from './clickhouse.service';

export class EntityBaseService {
  repository: Repository<any>;
  clickhouseService: ClickhouseService;
  constructor(repo, chServie) {
    this.repository = repo;
    this.clickhouseService = chServie;
  }

  async get(offset = 0, pageSize = 20) {
    const qb = this.repository.createQueryBuilder().offset(offset).limit(pageSize);
    return await this.clickhouseService.query(qb);
  }

  async count() {
    const qb = this.repository.createQueryBuilder();
    return await this.clickhouseService.getTotal(qb);
  }
}
