import { createClient } from '@clickhouse/client';
import { Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { AppConfig } from '../../../../config/app.config';

/*
 *  For clickhouse, we need to do,
 * 1. generate the Raw Query from ORM
 * 2. The generated RowQuery has someething like this in the kye
 *   {
 *    'AiTicket_id':
 * }
 *  so we need to replace className from all the Key, this will make sure
 *  clickhouse response and MariaDB returned data are the same
 *  3. Make sure all the Entity Class attribute should be the same as the DB column
 *
 * */

@Injectable()
export class ClickhouseService {
  clickHouseClient = null;

  constructor() {
    this.clickHouseClient = createClient({
      host: AppConfig.aisera_clickhousedb_host,
      username: AppConfig.aisera_clickhousedb_user,
      password: AppConfig.aisera_clickhousedb_password,
      database: 'aisera_10000',
    });
  }

  async query(queryBuilder: any) {
    // read CH for the data
    try {
      const queryStr = queryBuilder.printSql().getQuery();
      const resultSet = await this.clickHouseClient.query({
        query: queryStr,
        format: 'JSONEachRow',
      });
      const dataset = await resultSet.json();
      if (Array.isArray(dataset) && dataset.length > 0) {
        const obj = dataset[0];
        const key = Object.keys(obj)[0];
        const className = key.split('_')[0];

        let datasetJsonStr = JSON.stringify(dataset);
        datasetJsonStr = datasetJsonStr.replace(new RegExp(className + '_', 'g'), '');
        return JSON.parse(datasetJsonStr);
      }
    } catch (e) {
      // console.log('Error: ', e);
      // If error, then run queryBuilder
      return queryBuilder.getMany();
    }
  }

  async getTotal(queryBuilder: any) {
    // Construct a count query without executing it
    const countQueryBuilder = queryBuilder.clone().select('COUNT(*)', 'total');
    // Get the raw SQL query and parameters
    const [countQuery, parameters] = countQueryBuilder.getQueryAndParameters();
    try {
      // const queryStr = countQueryBuilder.printSql().getQuery();
      const resultSet = await this.clickHouseClient.query({
        query: countQuery,
        format: 'JSONEachRow',
      });
      const dataset = await resultSet.json();
      return { total: parseInt(dataset[0]['total']) };
    } catch (e) {
      // Execute the query to get the actual count
      const total = await countQueryBuilder.getRawOne();
      return { total: total.total };
    }
  }
}
