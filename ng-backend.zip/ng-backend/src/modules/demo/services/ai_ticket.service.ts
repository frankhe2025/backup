import { Repository } from 'typeorm';
import { AiTicket } from '../entities/ai_ticket.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { TENANT_DB_CONNECTION } from '../../../common/constants';
import { ClickhouseService } from './common/clickhouse.service';
import { Injectable } from '@nestjs/common';
import { EntityBaseService } from './common/entity_base.service';

@Injectable()
export class AiTicketService extends EntityBaseService {
  constructor(
    @InjectRepository(AiTicket, TENANT_DB_CONNECTION)
    private aiTicketRepository: Repository<AiTicket>,
    private ckService: ClickhouseService
  ) {
    super(aiTicketRepository, ckService);
  }
}
