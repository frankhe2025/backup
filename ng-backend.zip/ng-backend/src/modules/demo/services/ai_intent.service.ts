import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TENANT_DB_CONNECTION } from '../../../common/constants';
import { Repository } from 'typeorm';
import { ClickhouseService } from './common/clickhouse.service';
import { AiIntent } from '../entities/ai_intent.entity';
import { EntityBaseService } from './common/entity_base.service';

@Injectable()
export class AiIntentService extends EntityBaseService {
  constructor(
    @InjectRepository(AiIntent, TENANT_DB_CONNECTION)
    private aiIntentRepository: Repository<AiIntent>,
    private ckService: ClickhouseService
  ) {
    super(aiIntentRepository, ckService);
  }
}
