import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity('ai_intents_view')
export class AiIntent {
  @PrimaryColumn()
  id: number;
  @Column()
  name: string;
  @Column()
  review_status: string;
  @Column()
  status: string;
  @Column()
  created_at: Date;
  @Column()
  source_type: string;
}
