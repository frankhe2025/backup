import { Column, Entity, PrimaryColumn } from 'typeorm';
@Entity('bots')
export class Bot {
  @PrimaryColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  status: string;

  @Column()
  description: string;

  @Column()
  bot_type: string;

  @Column()
  config: string;
}
