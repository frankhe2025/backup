import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity('ai_tickets')
export class AiTicket {
  @PrimaryColumn()
  id: number;
  @Column()
  ticket_type: string;
  @Column()
  status: string;
  @Column()
  resolution_status: string;
  @Column({ name: 'resolved_at' })
  resolved_at: Date;
}
