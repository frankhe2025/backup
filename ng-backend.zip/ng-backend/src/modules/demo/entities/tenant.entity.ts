import { Column, Entity, PrimaryColumn } from 'typeorm';
@Entity('tenants')
export class Tenant {
  @PrimaryColumn()
  tenant_id: string;

  @Column()
  tenant_name: string;

  @Column()
  status: string;

  @Column({ name: 'is_public' })
  is_public: boolean;
}
