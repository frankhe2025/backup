import { ExecutionContext, Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class SamlAuthGuard extends AuthGuard('saml') {
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest();

    if (req.query?.tenantId) {
      const referer = req.headers?.['referer'];
      req.body.RelayState = JSON.stringify({ tenantId: req.query?.tenantId, referer: new URL(referer).origin });
    }

    return (await super.canActivate(context)) as boolean;
  }
}
