import { AuthLoginDto, AuthResponse } from './auth.dto';
import { Body, Controller, Get, Post, Request, Response, UnauthorizedException, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { SamlAuthGuard } from '../guards/saml_auth.guard';
import { AppConfig } from '../../config/app.config';
import { CommonService } from '../common/common.service';
import { LoggerService } from '../logger/logger.service';

@Controller('auth')
@ApiTags('Auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly commonService: CommonService,
    private readonly loggerService: LoggerService
  ) {}

  @Post('/login')
  @ApiOperation({ summary: 'Login API', description: 'Login API Through username and password' })
  @ApiBody({
    description: 'Login request payload',
    type: AuthLoginDto,
    required: true,
  })
  @ApiResponse({
    status: 200,
    description: 'Successful login',
    type: AuthResponse,
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request – Invalid credentials or missing fields',
  })
  @ApiResponse({
    status: 401,
    description: 'Unauthorized – Incorrect username or password',
  })
  @ApiResponse({
    status: 500,
    description: 'Internal Server Error',
  })
  async login(@Body() authLoginDto: AuthLoginDto, @Request() req): Promise<AuthResponse> {
    this.loggerService.debug('login: ' + JSON.stringify(authLoginDto));
    if (
      (typeof AppConfig.EZLOGIN_DEV_ENABLED === 'string' && AppConfig.EZLOGIN_DEV_ENABLED.toLowerCase() === 'true') ||
      (typeof AppConfig.EZLOGIN_DEV_ENABLED === 'boolean' && AppConfig.EZLOGIN_DEV_ENABLED === true)
    ) {
      const token = await this.authService.generateToken({
        email: AppConfig.EZLOGIN_DEV_USERNAME,
        firstName: '',
        lastName: '',
        issuer: '',
        tenantId: AppConfig.EZLOGIN_DEV_TENANT_ID,
        userId: AppConfig.EZLOGIN_DEV_ID,
      });

      const resp: AuthResponse = {
        token,
        email: AppConfig.EZLOGIN_DEV_USERNAME,
        tenantName: 'Acme',
        userId: AppConfig.EZLOGIN_DEV_ID,
      };

      this.loggerService.debug('Eazy Login Succeeded: ' + JSON.stringify(resp));
      return resp;
    }

    const user = await this.authService.login(authLoginDto);
    this.loggerService.debug('Login Response: ' + JSON.stringify(user));

    if (!user?.email) {
      this.loggerService.error('User Not Found, throw Error');
      throw new UnauthorizedException();
    }

    const token = await this.authService.generateToken(user);
    this.loggerService.debug('Token Generated: ' + token);
    const tenant = await this.commonService.getTenantDetails(authLoginDto.tenantId, ['tenantName'], {
      ...req,
      headers: { Authorization: `Bearer ${token}` },
    });
    this.loggerService.debug('Tenant Response: ' + JSON.stringify(tenant));
    const resp: AuthResponse = { token, email: user?.email, tenantName: tenant.tenantName, userId: user?.userId };

    return resp;
  }

  @Get('/sso/login')
  @UseGuards(SamlAuthGuard)
  async samlLogin() {
    return;
  }

  @Post('/sso/callback')
  @UseGuards(SamlAuthGuard)
  async samlCallback(@Request() req, @Response() res) {
    const token = await this.authService.generateToken(req.user);
    const referer = JSON.parse(req.body.RelayState)?.referer;

    res.redirect(`${referer}/?jwt=${token}`);
  }

  @Get('profile')
  async getUserProfile(@Request() req) {
    const user = await this.authService.getUserProfile(req);
    const tenantName = await this.commonService.getTenantDetails(user.tenantId, ['tenantName'], req);
    return { ...tenantName, ...user };
  }
}
