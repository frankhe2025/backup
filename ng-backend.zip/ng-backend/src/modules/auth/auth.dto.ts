import { IsOptional, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
export class AuthLoginDto {
  @ApiProperty({ description: 'Email of the login user', example: 'user1' })
  @IsString()
  email: string;

  @ApiProperty({ description: 'Password of the login user', example: 'password1' })
  @IsString()
  password: string;

  @ApiProperty({ description: 'Tenant ID of the login user', example: 'tenant_id' })
  @IsString()
  tenantId: string;
}

export interface AuthToken {
  userName: string;
  tenantId?: number;
}

export class AuthResponse {
  @ApiProperty({ description: 'JWT for the logged in user' })
  token: string;

  @ApiProperty({ description: 'Email of the login user' })
  @IsString()
  email: string;

  @ApiProperty({ description: 'Name of the tenant' })
  @IsString()
  tenantName: string;

  @ApiProperty({ description: 'userId of the current user' })
  @IsString()
  @IsOptional()
  userId: string;
}
