import { forwardRef, Inject, Injectable, Scope } from '@nestjs/common';
import { Request } from 'express';
import * as jwt from 'jsonwebtoken';
import { AppConfig, getJWTKey } from '../../config/app.config';
import { AuthLoginDto } from './auth.dto';
import { AuthUser } from './auth-user.entity';
import { FetcherService } from '../common/services/fetcher.service';
import { SERVICE_NAME } from '../common/enums/service-name.enum';
import { TenantUserService } from '../tenant-user/tenant-user.service';
import { TenantUser } from '../tenant-user/tenant-user.entity';
import { LoggerService } from '../logger/logger.service';

const REQUEST_AUTH_HEADER_TOKEN_NAME = 'Authorization';
// Since we are saving the authUser in this service and reuse it in the db factory, we need this to be request scope
@Injectable({ scope: Scope.REQUEST })
export class AuthService {
  public static _authUser: AuthUser; // This is only used by tenant-db-option.factory.ts
  public authUser: AuthUser;
  private static _tenantUserService: TenantUserService;

  constructor(
    private readonly fetcherService: FetcherService,
    private tenantUserService: TenantUserService,
    private loggerService: LoggerService
  ) {
    if (!AuthService._tenantUserService) {
      AuthService._tenantUserService = tenantUserService;
    }
  }

  extractBearerToken(req: Request) {
    return req.header(REQUEST_AUTH_HEADER_TOKEN_NAME)?.replace('Bearer', '')?.trim();
  }

  async authenticated(req: Request): Promise<any> {
    const jwtTokenInHeader = this.extractBearerToken(req);

    if (!jwtTokenInHeader) {
      // not authenticated
      return false;
    } else {
      const verifiedResult = this.verify(jwtTokenInHeader);
      if (verifiedResult) {
        this.setAuthUser(await this.getUserProfile(req));
      }
      return verifiedResult;
    }
  }

  setAuthUser(user: AuthUser) {
    this.authUser = user;
    AuthService._authUser = user;
  }

  async getUserProfile(req: Request): Promise<AuthUser> {
    const jwtTokenInHeader = this.extractBearerToken(req);
    const authUser = this.decode(jwtTokenInHeader);

    try {
      if (AuthService._tenantUserService) {
        const tenantUser: TenantUser = await AuthService._tenantUserService.findByEmailAndTenantId(
          authUser.email,
          authUser.tenantId
        );
        if (tenantUser) {
          authUser.userId = tenantUser.tenantUserId;
        }
      } else {
        console.warn('Static UserService is not available in getUserProfile');
      }
    } catch (error) {
      console.error('Error looking up user:', error);
    }

    return authUser;
  }

  async generateToken(data: any) {
    return await this.sign(data);
  }

  // JWT methods directly in AuthService
  public async sign(data: any): Promise<string> {
    const signingData = { ...data, roles: [1, 4] };
    if (!data.userId) {
      if (AuthService._tenantUserService) {
        const tenantUser: TenantUser = await AuthService._tenantUserService.findByEmailAndTenantId(
          data.email,
          data.tenantId
        );
        if (tenantUser) {
          signingData['userId'] = tenantUser.tenantUserId;
        }
      } else {
        console.warn('Static UserService is not available in getUserProfile');
      }
    }

    return jwt.sign(signingData, AppConfig.aisera_jwt_key, {
      algorithm: 'HS256',
      expiresIn: AppConfig.JWT_DURATION,
      issuer: AppConfig.aiseraJwtIssuer,
      subject: AppConfig.aiseraJwtSubject,
    });
  }

  public decode(token: string) {
    return jwt.decode(token);
  }

  public verify(token: string): boolean {
    let result = false;
    try {
      const key = getJWTKey();
      result = jwt.verify(token, key);
    } catch (e) {
      result = false;
    }
    return result;
  }

  async login(authLoginDto: AuthLoginDto): Promise<AuthUser> {
    const response = await this.fetcherService.request(
      SERVICE_NAME.CONNECTOR_SERVER,
      '/v1/tenant-users/tenantLogin',
      'POST',
      authLoginDto
    );

    return {
      email: response?.data?.tenantEmail,
      firstName: response?.data?.name,
      lastName: '',
      issuer: '',
      tenantId: response?.data?.tenantId,
      userId: response?.data?.tenantUserId,
    };
  }
}
