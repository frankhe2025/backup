import { PassportStrategy } from '@nestjs/passport';
import { ForbiddenException, Injectable } from '@nestjs/common';
import { AppConfig } from '../../config/app.config';
import { AuthUser } from './auth-user.entity';
import { Profile, Strategy } from '@node-saml/passport-saml';

@Injectable()
export class SamlStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      issuer: AppConfig.aisera_sso_issuer,
      callbackUrl: AppConfig.SAML_CALLBACK_URL,
      idpCert: AppConfig.aisera_sso_x509_certificate,
      entryPoint: AppConfig.aisera_sso_login_url,
      wantAssertionsSigned: true,
      disableRequestedAuthnContext: true,
      passReqToCallback: true,
    });
  }

  async validate(req, profile: Profile): Promise<AuthUser> {
    let tenantId = '';
    try {
      if (req.body.RelayState) {
        tenantId = JSON.parse(req.body.RelayState)?.tenantId;
      }
      const user: AuthUser = {
        email: profile?.email as string,
        issuer: profile?.issuer as string,
        firstName: profile?.firstName as string,
        lastName: profile?.lastName as string,
        tenantId,
      };
      return user;
    } catch (e) {
      throw new ForbiddenException('invalid user attributes');
    }
  }
}
