import { EntityAccessesEntity } from './entity-accesses.entity';
import { EntityAccess } from './entity-access.entity';

describe('EntityAccessesEntity', () => {
  const mockEntityAccess = (overrides = {}) =>
    new EntityAccess({
      entityType: 'TestType',
      entityTypeLabel: 'Test Type',
      privileges: ['read', 'readwrite'],
      defaultPrivilege: 'READ',
      description: 'desc',
      ...overrides,
    });

  it('should initialize with default values when no data is provided', () => {
    const entityAccesses = new EntityAccessesEntity();
    expect(entityAccesses.entityAccesses).toEqual([]);
    expect(entityAccesses.admin).toBe(false);
  });

  it('should set admin flag if provided in data', () => {
    const entityAccesses = new EntityAccessesEntity({ admin: true, privileges: [] });
    expect(entityAccesses.admin).toBe(true);
  });

  it('should populate entityAccesses from privileges', () => {
    const data = {
      privileges: [
        { entityType: 'TypeA', privileges: ['read'] },
        { entityType: 'TypeB', privileges: ['readwrite'] },
      ],
    };
    const entityAccesses = new EntityAccessesEntity(data);
    expect(entityAccesses.entityAccesses.length).toBe(2);
    expect(entityAccesses.entityAccesses[0]).toBeInstanceOf(EntityAccess);
    expect(entityAccesses.entityAccesses[0].entityType).toBe('TypeA');
    expect(entityAccesses.entityAccesses[1].entityType).toBe('TypeB');
  });

  it('should populate entityAccesses from entityAccesses if privileges not present', () => {
    const data = {
      entityAccesses: [{ entityType: 'TypeC', privileges: ['read'] }],
    };
    const entityAccesses = new EntityAccessesEntity(data);
    expect(entityAccesses.entityAccesses.length).toBe(1);
    expect(entityAccesses.entityAccesses[0].entityType).toBe('TypeC');
  });

  describe('isEntityReadable', () => {
    it('should return true if entity is readable', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'TestType', privileges: ['read'] })];
      expect(entityAccesses.isEntityReadable('TestType')).toBe(true);
    });
    it('should return false if entity is not readable', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'TestType', privileges: ['none'] })];
      expect(entityAccesses.isEntityReadable('TestType')).toBe(false);
    });
    it('should return false if entity type not found', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'OtherType', privileges: ['read'] })];
      expect(entityAccesses.isEntityReadable('TestType')).toBe(false);
    });
  });

  describe('isEntityWritable', () => {
    it('should return true if entity is writable', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'TestType', privileges: ['readwrite'] })];
      expect(entityAccesses.isEntityWritable('TestType')).toBe(true);
    });
    it('should return false if entity is not writable', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'TestType', privileges: ['read'] })];
      expect(entityAccesses.isEntityWritable('TestType')).toBe(false);
    });
    it('should return false if entity type not found', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'OtherType', privileges: ['readwrite'] })];
      expect(entityAccesses.isEntityWritable('TestType')).toBe(false);
    });
  });

  describe('isEntityAccessible', () => {
    it('should return true if entity is accessible', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'TestType', privileges: ['read'] })];
      expect(entityAccesses.isEntityAccessible('TestType')).toBe(true);
    });
    it('should return false if entity is not accessible', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'TestType', privileges: ['none'] })];
      expect(entityAccesses.isEntityAccessible('TestType')).toBe(false);
    });
    it('should return false if entity type not found', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'OtherType', privileges: ['read'] })];
      expect(entityAccesses.isEntityAccessible('TestType')).toBe(false);
    });
  });

  describe('isPriviledgeAllowed', () => {
    const { Priviledge, PrivilegeType } = require('./path_rbac.entities');

    it('should return true if privilege is allowed for the entity type', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'TestType', privileges: ['read', 'readwrite'] })];
      const priv = new Priviledge({ entityType: 'TestType', priviledge: PrivilegeType.Read });
      expect(entityAccesses.isPriviledgeAllowed(priv)).toBe(true);
    });

    it('should return false if privilege is not allowed for the entity type', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [mockEntityAccess({ entityType: 'TestType', privileges: ['read'] })];
      const priv = new Priviledge({ entityType: 'TestType', priviledge: PrivilegeType.ReadWrite });
      expect(entityAccesses.isPriviledgeAllowed(priv)).toBe(false);
    });

    it('should return false if entity type is not found', () => {
      const entityAccesses = new EntityAccessesEntity();
      entityAccesses.entityAccesses = [
        mockEntityAccess({ entityType: 'OtherType', privileges: ['read', 'readwrite'] }),
      ];
      const priv = new Priviledge({ entityType: 'TestType', priviledge: PrivilegeType.Read });
      expect(entityAccesses.isPriviledgeAllowed(priv)).toBe(false);
    });
  });
});
