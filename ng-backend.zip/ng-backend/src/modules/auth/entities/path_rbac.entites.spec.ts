import { PathRbacMap, PathRbacMaps, Priviledge, PrivilegeType, RequestMethod } from './path_rbac.entities';

const config = [
  {
    url: '/v1/tenants/{s}/version/llm-prompts',
    method: 'GET',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'Read',
      },
    ],
  },

  {
    url: '/v1/tenants/{s}/version/llm-prompts/{d}',
    method: 'GET',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'Read',
      },
    ],
  },

  {
    url: '/v1/tenants/{s}/version/llm-prompts',
    method: 'POST',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'ReadWrite',
      },
    ],
  },

  {
    url: '/v1/tenants/{s}/version/llm-prompts/{d}',
    method: 'DELETE',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'ReadWrite',
      },
    ],
  },

  {
    url: '/v1/tenants/{s}/version/llm-prompts/{d}',
    method: 'PUT',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'ReadWrite',
      },
    ],
  },
];

const pathRbacIgnore = [
  {
    url: '/access-control-service/v1/tenants/{s}/users/{d}',
    method: 'GET',
  },
  {
    url: '/access-control-service/v1/tenants/{s}/users/{d}/filter/{s}',
    method: 'POST',
  },
  {
    url: '/entity-filter/{s}',
    method: 'GET',
  },
];

describe('PathRbacMap', () => {
  it('should initialize with default values', () => {
    const pathRbacMap = new PathRbacMap();
    expect(pathRbacMap.url).toBe('');
    expect(pathRbacMap.method).toBe(RequestMethod.GET);
    expect(pathRbacMap.priviledges).toEqual([]);
  });

  it('matchesUrl should true with URL parameters', () => {
    const pathRbacMap = new PathRbacMap({
      url: '/v1/tenants/{s}/version/llm-prompts',
      method: RequestMethod.GET,
    });
    expect(
      pathRbacMap.matchesUrl('http://localhost:3001/api/llm-gateway/v1/tenants/10000/version/llm-prompts?botId=70')
    ).toBe(true);
  });

  it('should initialize with provided values', () => {
    const data = {
      url: '/v1/tenants/{s}/version/llm-prompts',
      method: RequestMethod.POST,
      priviledges: [{ entityType: 'promptStudio', priviledge: PrivilegeType.ReadWrite }],
    };
    const pathRbacMap = new PathRbacMap(data);
    expect(pathRbacMap.url).toBe(data.url);
    expect(pathRbacMap.method).toBe(data.method);
    expect(pathRbacMap.priviledges.length).toBe(1);
    expect(pathRbacMap.priviledges[0].entityType).toBe('promptStudio');
    expect(pathRbacMap.priviledges[0].priviledge).toBe(PrivilegeType.ReadWrite);
  });

  it('convertUrlToRegexStr should handle complex URLs', () => {
    const pathRbacMap = new PathRbacMap({
      url: '/v1/tenants/{s}/version/llm-prompts/{d}/details',
    });
    const regexStr = pathRbacMap.convertUrlToRegexStr(pathRbacMap.url);
    expect(regexStr).toBe('/v1/tenants/[a-zA-Z0-9_]+/version/llm-prompts/-?[0-9]+/details');
  });

  it('matchesUrl should return false for non-matching URLs', () => {
    const pathRbacMap = new PathRbacMap({
      url: '/v1/tenants/{s}/version/llm-prompts/{d}',
      method: RequestMethod.GET,
    });
    expect(pathRbacMap.matchesUrl('/v1/tenants/10000/version/llm-prompts')).toBe(false);
  });

  it('matchesUrl should handle edge cases', () => {
    const pathRbacMap = new PathRbacMap({
      url: '/v1/tenants/{s}/version/llm-prompts/{d}',
      method: RequestMethod.GET,
    });
    expect(pathRbacMap.matchesUrl('/v1/tenants/10000/version/llm-prompts/')).toBe(false);
    expect(pathRbacMap.matchesUrl('/v1/tenants/10000/version/llm-prompts/123')).toBe(true);
  });
});

describe('PathRbacMaps', () => {
  it('should initialize with default values', () => {
    const pathRbacMaps = new PathRbacMaps();
    expect(pathRbacMaps.pathRbacMaps).toEqual([]);
  });

  it('should initialize with provided values', () => {
    const data = {
      pathRbacMaps: [
        {
          url: '/v1/tenants/{s}/version/llm-prompts',
          method: RequestMethod.GET,
          priviledges: [{ entityType: 'promptStudio', priviledge: PrivilegeType.Read }],
        },
      ],
    };
    const pathRbacMaps = new PathRbacMaps(data);
    expect(pathRbacMaps.pathRbacMaps.length).toBe(1);
    expect(pathRbacMaps.pathRbacMaps[0].url).toBe('/v1/tenants/{s}/version/llm-prompts');
    expect(pathRbacMaps.pathRbacMaps[0].method).toBe(RequestMethod.GET);
    expect(pathRbacMaps.pathRbacMaps[0].priviledges[0].entityType).toBe('promptStudio');
    expect(pathRbacMaps.pathRbacMaps[0].priviledges[0].priviledge).toBe(PrivilegeType.Read);
  });
});

describe('Priviledge', () => {
  it('should initialize with default values', () => {
    const priviledge = new Priviledge();
    expect(priviledge.entityType).toBe('');
    expect(priviledge.priviledge).toBe(PrivilegeType.None);
  });

  it('should initialize with provided values', () => {
    const data = { entityType: 'promptStudio', priviledge: PrivilegeType.ReadWrite };
    const priviledge = new Priviledge(data);
    expect(priviledge.entityType).toBe(data.entityType);
    expect(priviledge.priviledge).toBe(data.priviledge);
  });
});

describe('PathRbacMaps', () => {
  it('constructor', () => {
    const pathRbacMaps = new PathRbacMaps({ pathRbacMaps: config });
    expect(pathRbacMaps).toBeInstanceOf(PathRbacMaps);
    expect(pathRbacMaps.pathRbacMaps.length).toBe(5);
    expect(pathRbacMaps.pathRbacMaps[0]).toBeInstanceOf(PathRbacMap);
    expect(pathRbacMaps.pathRbacMaps[0].url).toBe('/v1/tenants/{s}/version/llm-prompts');
    expect(pathRbacMaps.pathRbacMaps[0].method).toBe('GET');
    expect(pathRbacMaps.pathRbacMaps[0].priviledges.length).toBe(1);
    expect(pathRbacMaps.pathRbacMaps[0].priviledges[0].entityType).toBe('promptStudio');
    expect(pathRbacMaps.pathRbacMaps[0].priviledges[0].priviledge).toBe('Read');
  });

  it('convertUrlToRegexStr', () => {
    const pathRbacMap = new PathRbacMap({
      url: '/v1/tenants/{s}/version/llm-prompts/{d}',
      method: 'GET',
    });
    const regexStr = pathRbacMap.convertUrlToRegexStr(pathRbacMap.url);
    expect(regexStr).toBe('/v1/tenants/[a-zA-Z0-9_]+/version/llm-prompts/-?[0-9]+');
  });
  it('matchesUrl', () => {
    const pathRbacMap = new PathRbacMap({
      url: '/v1/tenants/{s}/version/llm-prompts/{d}',
      method: 'GET',
    });
    expect(pathRbacMap.matchesUrl('http://localhost:8080/v1/tenants/10000/version/llm-prompts/123')).toBe(true);
    expect(pathRbacMap.matchesUrl('https://localhost:8080/v1/tenants/testTenant/version/llm-prompts')).toBe(false);
    expect(pathRbacMap.matchesUrl('https://localhost:8080/v1/tenants/testTenant/anyotherurl')).toBe(false);
  });
  it('matchesUrl with different methods', () => {
    const pathRbacMaps: PathRbacMaps = new PathRbacMaps(config);
    expect(pathRbacMaps.isUrlMatched('http://localhost:8080/v1/tenants/abc/version/llm-prompts', 'GET')).toBeTruthy();
    expect(pathRbacMaps.isUrlMatched('http://localhost:8080/v1/tenants/abc/version/llm-prompts', 'POST')).toBeTruthy();
    expect(pathRbacMaps.isUrlMatched('http://anyURL:8088/abc', 'POST')).toBeFalsy();
  });

  it('isIgnoredURL Mapped', () => {
    const pathRbacMaps: PathRbacMaps = new PathRbacMaps(config, pathRbacIgnore);
    expect(
      pathRbacMaps.isIgnoredUrlMatched(
        'http://localhost:8080/access-control-service/v1/tenants/10000/users/-12345',
        'GET'
      )
    ).toBeTruthy();
    expect(
      pathRbacMaps.isIgnoredUrlMatched(
        'http://localhost:8080/access-control-service/v1/tenants/amgen/users/12345/filter/filtername',
        'POST'
      )
    ).toBeTruthy();
    expect(pathRbacMaps.isUrlMatched('http://anyURL:8088/abc', 'POST')).toBeFalsy();
  });

  it('isUrlAllowed', () => {
    const pathRbacMaps: PathRbacMaps = new PathRbacMaps(config, pathRbacIgnore);
    expect(
      pathRbacMaps.isUrlAllowed('http://localhost:8080/access-control-service/v1/tenants/10000/users/-12345', 'GET')
    ).toBeTruthy();
    expect(
      pathRbacMaps.isUrlAllowed(
        'http://localhost:8080/access-control-service/v1/tenants/amgen/users/12345/filter/filtername',
        'POST'
      )
    ).toBeTruthy();
    expect(pathRbacMaps.isUrlAllowed('http://localhost:8080/v1/tenants/abc/version/llm-prompts', 'GET')).toBeTruthy();
    expect(pathRbacMaps.isUrlMatched('http://anyURL:8088/abc', 'POST')).toBeFalsy();
  });

  it('isIgnoredURL Mapped with Capitalized URL', () => {
    const pathRbacMaps: PathRbacMaps = new PathRbacMaps(config, pathRbacIgnore);
    expect(
      pathRbacMaps.isIgnoredUrlMatched('http://localhost:3001/api/entity-filter/NG_PROMPT_LIST', 'GET')
    ).toBeTruthy();
  });
});
