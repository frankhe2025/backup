import { EntityAccess, EntityAccessPrivileges } from './entity-access.entity';
import { Priviledge, PrivilegeType } from './path_rbac.entities';

describe('EntityAccessPrivileges', () => {
  it('should have correct enum values', () => {
    expect(EntityAccessPrivileges.Read).toBe('Read');
    expect(EntityAccessPrivileges.ReadWrite).toBe('ReadWrite');
    expect(EntityAccessPrivileges.None).toBe('None');
  });
});

describe('EntityAccess', () => {
  it('should initialize with default values when no data is provided', () => {
    const entityAccess = new EntityAccess();
    expect(entityAccess.entityType).toBe('');
    expect(entityAccess.entityTypeLabel).toBe('');
    expect(entityAccess.privileges).toEqual([]);
    expect(entityAccess.defaultPrivilege).toBe(EntityAccessPrivileges.Read);
    expect(entityAccess.description).toBe('');
  });

  it('should initialize with provided data and normalize privileges', () => {
    const data = {
      entityType: 'testType',
      entityTypeLabel: 'Test Type',
      privileges: ['read', 'readwrite', 'none', 'READ', 'READWRITE', 'NONE', 'invalid'],
      defaultPrivilege: 'Read',
      description: 'Test description',
    };
    const entityAccess = new EntityAccess(data);
    expect(entityAccess.entityType).toBe('testType');
    expect(entityAccess.entityTypeLabel).toBe('Test Type');
    expect(entityAccess.privileges).toEqual([
      EntityAccessPrivileges.Read,
      EntityAccessPrivileges.ReadWrite,
      EntityAccessPrivileges.None,
      EntityAccessPrivileges.Read,
      EntityAccessPrivileges.ReadWrite,
      EntityAccessPrivileges.None,
    ]);
    expect(entityAccess.defaultPrivilege).toBe('Read');
    expect(entityAccess.description).toBe('Test description');
  });

  it('normalizePrivileges should handle empty privileges', () => {
    const entityAccess = new EntityAccess({ privileges: [] });
    entityAccess.normalize();
    expect(entityAccess.privileges).toEqual([]);
  });

  it('isReadable should return true if privileges include READ or READWRITE', () => {
    const entityAccess = new EntityAccess({ privileges: ['read'] });
    expect(entityAccess.isReadable()).toBe(true);
    const entityAccessRW = new EntityAccess({ privileges: ['readwrite'] });
    expect(entityAccessRW.isReadable()).toBe(true);
  });

  it('isReadable should return false if privileges do not include READ or READWRITE', () => {
    const entityAccess = new EntityAccess({ privileges: ['none'] });
    expect(entityAccess.isReadable()).toBe(false);
    const entityAccessEmpty = new EntityAccess({ privileges: [] });
    expect(entityAccessEmpty.isReadable()).toBe(false);
  });

  it('isWritable should return true if privileges include READWRITE', () => {
    const entityAccess = new EntityAccess({ privileges: ['readwrite'] });
    expect(entityAccess.isWritable()).toBe(true);
  });

  it('isWritable should return false if privileges do not include READWRITE', () => {
    const entityAccess = new EntityAccess({ privileges: ['read'] });
    expect(entityAccess.isWritable()).toBe(false);
    const entityAccessNone = new EntityAccess({ privileges: ['none'] });
    expect(entityAccessNone.isWritable()).toBe(false);
  });

  it('isAccessible should return true if isReadable or isWritable is true', () => {
    const entityAccessRead = new EntityAccess({ privileges: ['read'] });
    expect(entityAccessRead.isAccessible()).toBe(true);
    const entityAccessRW = new EntityAccess({ privileges: ['readwrite'] });
    expect(entityAccessRW.isAccessible()).toBe(true);
  });

  it('isAccessible should return false if neither isReadable nor isWritable is true', () => {
    const entityAccess = new EntityAccess({ privileges: ['none'] });
    expect(entityAccess.isAccessible()).toBe(false);
    const entityAccessEmpty = new EntityAccess({ privileges: [] });
    expect(entityAccessEmpty.isAccessible()).toBe(false);
  });

  describe('isPriviledgeAccessible', () => {
    it('should return false if privileges are empty', () => {
      const entityAccess = new EntityAccess({ privileges: [] });
      const priv = new Priviledge({ priviledge: PrivilegeType.Read });
      expect(entityAccess.isPriviledgeAccessible(priv)).toBe(false);
    });

    it('should return false if privileges are [None]', () => {
      const entityAccess = new EntityAccess({ privileges: ['none'] });
      const priv = new Priviledge({ priviledge: PrivilegeType.Read });
      expect(entityAccess.isPriviledgeAccessible(priv)).toBe(false);
    });

    it('should return false if privileges contain the requested privilege as string (method expects object)', () => {
      const entityAccess = new EntityAccess({ privileges: ['read'] });
      const priv = new Priviledge({ priviledge: PrivilegeType.Read });
      expect(entityAccess.isPriviledgeAccessible(priv)).toBe(true);
    });

    it('should return true if privileges contain the requested privilege as object', () => {
      const entityAccess = new EntityAccess({ privileges: [] });
      // Directly assign an array of objects to simulate the expected structure for the method
      entityAccess.privileges = [PrivilegeType.Read];
      const priv = new Priviledge({ priviledge: PrivilegeType.Read });
      expect(entityAccess.isPriviledgeAccessible(priv)).toBe(true);
    });

    it('should return false if privileges do not contain the requested privilege as object', () => {
      const entityAccess = new EntityAccess({ privileges: [] });
      entityAccess.privileges = [PrivilegeType.Read];
      const priv = new Priviledge({ priviledge: PrivilegeType.ReadWrite });
      expect(entityAccess.isPriviledgeAccessible(priv)).toBe(false);
    });
  });
});
