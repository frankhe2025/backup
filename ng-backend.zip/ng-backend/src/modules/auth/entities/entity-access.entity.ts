import { Priviledge, PrivilegeType } from './path_rbac.entities';

export enum EntityAccessPrivileges {
  Read = 'Read',
  ReadWrite = 'ReadWrite',
  None = 'None',
}
export class EntityAccess {
  entityType: string;
  entityTypeLabel: string;
  privileges: string[];
  defaultPrivilege: any;
  description: string;
  constructor(data: any = null) {
    this.entityType = data?.entityType ?? '';
    this.entityTypeLabel = data?.entityTypeLabel ?? '';
    this.privileges = data?.privileges || [];
    this.defaultPrivilege = data?.defaultPrivilege ?? EntityAccessPrivileges.Read;
    this.description = data?.description ?? '';
    this.normalize();
  }
  normalize(): void {
    if (this.privileges.length > 0) {
      this.privileges = this.normalizePriviledges(this.privileges);
    }
    if (this.defaultPrivilege.toLowerCase() === 'read') {
      this.defaultPrivilege = EntityAccessPrivileges.Read;
    } else if (this.defaultPrivilege.toLowerCase() === 'none') {
      this.defaultPrivilege = EntityAccessPrivileges.None;
    } else if (this.defaultPrivilege.toLowerCase() === 'readwrite') {
      this.defaultPrivilege = EntityAccessPrivileges.ReadWrite;
    }
  }

  normalizePriviledges(priviledges) {
    const _privileges: string[] = [];
    this.privileges.forEach((privilege) => {
      if (privilege.toLowerCase() === 'read') {
        _privileges.push(EntityAccessPrivileges.Read);
      } else if (privilege.toLowerCase() === 'none') {
        _privileges.push(EntityAccessPrivileges.None);
      } else if (privilege.toLowerCase() === 'readwrite') {
        _privileges.push(EntityAccessPrivileges.ReadWrite);
      }
    });
    return _privileges;
  }

  isReadable(): boolean {
    return (
      this.normalizePriviledges(this.privileges).includes(EntityAccessPrivileges.Read) ||
      this.normalizePriviledges(this.privileges).includes(EntityAccessPrivileges.ReadWrite)
    );
  }
  isWritable(): boolean {
    return this.normalizePriviledges(this.privileges).includes(EntityAccessPrivileges.ReadWrite);
  }
  isAccessible(): boolean {
    return this.isReadable() || this.isWritable();
  }

  // Current user priviledge can be Read, ReadWrite, None
  // Passed in can be Read or ReadWrite
  // we need to compare and make sure having access
  isPriviledgeAccessible(privledge: Priviledge) {
    if (this.privileges.length === 0 || this.privileges[0].toLowerCase() === PrivilegeType.None.toLowerCase()) {
      return false;
    } else {
      const foundPriviledges = this.privileges.filter((entity: any) => {
        return entity.toLowerCase() === privledge.priviledge.toLowerCase();
      });
      return foundPriviledges.length > 0;
    }
  }
}
