import { EntityAccess } from './entity-access.entity';
import { Priviledge, PrivilegeType } from './path_rbac.entities';

export enum EntityAccessPrivilege {
  Read = 'READ',
  ReadWrite = 'ReadWrite',
  None = 'None',
}

export class EntityAccessesEntity {
  entityAccesses: EntityAccess[];
  admin: boolean;
  constructor(data: any = null) {
    this.entityAccesses = [];
    this.admin = false;
    if (data) {
      if ('admin' in data) {
        this.admin = data.admin;
      }
      const dataList = data.privileges || data.entityAccesses;

      dataList.forEach((entityAccesse: any) => {
        this.entityAccesses.push(new EntityAccess(entityAccesse));
      });
    }
  }

  isPriviledgeAllowed(priviledge: Priviledge) {
    const foundEntityAccess = this.findByEntityType(priviledge.entityType);
    if (!foundEntityAccess) {
      return false; //not found, decline it
    } else {
      return foundEntityAccess.isPriviledgeAccessible(priviledge);
    }
  }

  findByEntityType(entityType: any) {
    return this.entityAccesses.find((entityAccess) => {
      return entityAccess.entityType.toLowerCase() === entityType.toLowerCase();
    });
  }

  isEntityReadable(entityType: string): boolean {
    const entityAccess = this.entityAccesses.find((access) => access.entityType === entityType);
    return entityAccess ? entityAccess.isReadable() : false;
  }
  isEntityWritable(entityType: string): boolean {
    const entityAccess = this.entityAccesses.find((access) => access.entityType === entityType);
    return entityAccess ? entityAccess.isWritable() : false;
  }
  isEntityAccessible(entityType: string): boolean {
    const entityAccess = this.entityAccesses.find((access) => access.entityType === entityType);
    return entityAccess ? entityAccess.isAccessible() : false;
  }
}
