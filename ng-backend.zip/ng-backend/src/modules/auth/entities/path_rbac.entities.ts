import { EntityAccessesEntity } from './entity-accesses.entity';

export enum RequestMethod {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  DELETE = 'DELETE',
}
export enum PrivilegeType {
  Read = 'Read',
  ReadWrite = 'ReadWrite',
  None = 'None',
}
export class Priviledge {
  entityType: string;
  priviledge: PrivilegeType;
  constructor(data: any = null) {
    this.entityType = '';
    this.priviledge = PrivilegeType.None;
    if (data) {
      if ('entityType' in data) {
        this.entityType = data.entityType;
      }
      if ('priviledge' in data) {
        this.priviledge = data.priviledge;
      }
    }
  }
}
export class PathRbacMap {
  url: string;
  method: RequestMethod;
  priviledges: Priviledge[];
  constructor(data: any = null) {
    this.url = '';
    this.method = RequestMethod.GET;
    this.priviledges = [];
    if (data) {
      if ('url' in data) {
        this.url = data.url;
      }
      if ('method' in data) {
        this.method = typeof data.method === 'string' ? data.method.toUpperCase() : data.method;
      }
      if ('priviledges' in data) {
        this.priviledges = data.priviledges.map((p: any) => new Priviledge(p));
      }
    }
  }
  // URL has {s} as string, and {d} as digit, so we need to convert it to regex string
  convertUrlToRegexStr(url: string): string {
    const regexStr = url
      .replace(/{s}/g, '[a-zA-Z0-9_]+') // Allow underscore for {s} segments
      .replace(/{d}/g, '-?[0-9]+'); // Allow negative numbers for {d}
    return regexStr; // Add start and end anchors for exact match
  }

  matchesUrl(url: string): boolean {
    // Extract the path from the input URL (ignore protocol, host, query, etc.)
    let inputPath = url;
    try {
      // If it's a full URL, extract the pathname
      if (url.startsWith('http://') || url.startsWith('https://')) {
        inputPath = new URL(url).pathname;
      }
    } catch (e) {
      // If URL parsing fails, fallback to original string
      inputPath = url;
    }
    const regexStr = this.convertUrlToRegexStr(this.url);
    const regex = new RegExp(regexStr, 'i'); // 'i' for case-insensitive
    return regex.test(inputPath);
  }
}

export class PathRbacMaps {
  pathRbacMaps: PathRbacMap[];
  pathRbacToBeIgnoredMaps: PathRbacMap[];
  constructor(data: any = null, ignoredData: any = null) {
    this.pathRbacMaps = [];
    this.pathRbacToBeIgnoredMaps = [];
    if (data) {
      if (Array.isArray(data)) {
        this.pathRbacMaps = data.map((p: any) => new PathRbacMap(p));
      } else if ('pathRbacMaps' in data) {
        this.pathRbacMaps = data.pathRbacMaps.map((p: any) => new PathRbacMap(p));
      }
    }
    if (ignoredData) {
      if (Array.isArray(ignoredData)) {
        this.pathRbacToBeIgnoredMaps = ignoredData.map((p: any) => new PathRbacMap(p));
      } else if ('pathRbacToBeIgnoredMaps' in ignoredData) {
        this.pathRbacToBeIgnoredMaps = ignoredData.pathRbacMaps.map((p: any) => new PathRbacMap(p));
      }
    }
  }

  isUrlAllowed(url: string, method: string) {
    return this.isIgnoredUrlMatched(url, method) || this.isUrlMatched(url, method);
  }

  isUrlMatched(url: string, method: string) {
    // this api is to check if URL matches any of the path rbac maps
    return this.pathRbacMaps.some((map) => {
      return map.matchesUrl(url) && map.method.toLowerCase().trim() === method.toLowerCase().trim().toLowerCase();
    });
  }

  isIgnoredUrlMatched(url: string, method: string) {
    // this api is to check if URL matches any of the path rbac maps
    return this.pathRbacToBeIgnoredMaps.some((map) => {
      return map.matchesUrl(url) && map.method.toLowerCase().trim() === method.toLowerCase().trim().toLowerCase();
    });
  }

  checkRbacPermission(url: string, method: string, entityAccesses: EntityAccessesEntity) {
    // Step 1, we find out what priviledges are required for this URL / Method
    const pathRbacMap = this.pathRbacMaps.find((map) => {
      return map.matchesUrl(url) && map.method.toLowerCase().trim() === method.toLowerCase().trim().toLowerCase();
    });
    if (!pathRbacMap) {
      return false;
    }
    const priviledges = pathRbacMap.priviledges;

    //step2, now we have priviledges, we now need to check user's priviledge and see if we can proceed
    let accessible = true;
    priviledges.forEach((priviledge) => {
      accessible = accessible && entityAccesses.isPriviledgeAllowed(priviledge);
    });
    return accessible;
  }
}
