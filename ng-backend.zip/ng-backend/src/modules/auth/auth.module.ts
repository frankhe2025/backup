import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AppConfigModule } from '../../config/app.config';
import { AuthController } from './auth.controller';
import { SamlStrategy } from './saml_okta.strategy';
import { CommonModule } from '../common/common.module';
import { TenantUserModule } from '../tenant-user/tenant-user.module';
import { RbacService } from './rbac.service';
import { CacheManager } from '../common/services/cache_manager.util';
import { LoggerModule } from '../logger/logger.module';
import { JwtUtilService } from './jwt_util.service';

@Module({
  imports: [AppConfigModule, CommonModule, TenantUserModule, LoggerModule],
  controllers: [AuthController],
  providers: [AuthService, RbacService, SamlStrategy, JwtUtilService],
  exports: [AuthService, RbacService, JwtUtilService],
})
export class AuthModule {}
