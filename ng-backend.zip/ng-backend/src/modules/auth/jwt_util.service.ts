import { Injectable } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';
import { AppConfig } from '../../config/app.config';
@Injectable()
export class JwtUtilService {
  public sign(data: any): string {
    return jwt.sign({ ...data, roles: [1, 4] }, AppConfig.aisera_jwt_key, {
      algorithm: 'HS256',
      expiresIn: AppConfig.JWT_DURATION,
      issuer: AppConfig.aiseraJwtIssuer,
      subject: AppConfig.aiseraJwtSubject,
    });
  }

  public decode(token: string) {
    return jwt.decode(token);
  }

  public verify(token: string): boolean {
    let result = false;
    try {
      result = jwt.verify(token, AppConfig.aisera_jwt_key);
    } catch (e) {
      result = false;
    }
    return result;
  }
}
