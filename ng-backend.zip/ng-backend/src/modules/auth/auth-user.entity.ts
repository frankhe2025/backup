export class AuthUser {
  email: string;
  issuer: string;
  firstName?: string;
  lastName?: string;
  tenantId?: string;
  userId?: string;
}
