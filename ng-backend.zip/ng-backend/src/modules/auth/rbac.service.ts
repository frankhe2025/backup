import { Injectable } from '@nestjs/common';
import { Request } from 'express';
import { AuthService } from './auth.service';
import { FetcherService } from '../common/services/fetcher.service';
import { SERVICE_NAME } from '../common/enums/service-name.enum';
import { PathRbacMaps } from './entities/path_rbac.entities';
import pathRbacMapperConfig, { pathRbacMapperToIgnore } from './path_rbac.mapper';
import { EntityAccessesEntity } from './entities/entity-accesses.entity';
import getCacheManager, { CacheManager } from '../common/services/cache_manager.util';
import { LoggerService } from '../logger/logger.service';

const UserPriviledgeCacheKey = 'USER_PRIVILEGE_';

@Injectable()
export class RbacService {
  pathRbacMappers: PathRbacMaps;
  constructor(
    private readonly authService: AuthService,
    private readonly fetcherService: FetcherService,
    private loggerService: LoggerService
  ) {
    this.pathRbacMappers = new PathRbacMaps(pathRbacMapperConfig, pathRbacMapperToIgnore);
  }

  // This method is going to fetch current user's privileges
  async authorized(req: Request) {
    // Step 1: making sure the URL is inside our configuration
    const url = req.originalUrl;
    const method = req.method;
    this.loggerService.debug('Authorized checking: ' + url + ', method: ' + method);
    // if this URL is ignored for checking,we just pass through
    if (this.pathRbacMappers.isIgnoredUrlMatched(url, method)) {
      this.loggerService.debug('URL and Method is Ignored, go to next step');
      return true;
    }
    // if there is NO match, means no permission allowed
    if (!this.pathRbacMappers.isUrlMatched(url, method)) {
      this.loggerService.debug('URL and Method does not match, declined for Rbac checking');
      return false;
    }

    let cachedPriviledges: EntityAccessesEntity = getCacheManager().get(
      UserPriviledgeCacheKey + this.authService.authUser.userId
    );

    if (!cachedPriviledges) {
      this.loggerService.debug('No cached priviledges found for user id: ' + this.authService.authUser.userId);
      // step 1: fetch the user's priviledges
      const authUser = this.authService.authUser;
      const resp = await this.fetcherService.request(
        SERVICE_NAME.ACCESS_CONTROL,
        `/v1/tenants/${this.authService.authUser.tenantId}/users/${this.authService.authUser.userId}`,
        'GET',
        {},
        {}
      );
      this.loggerService.debug('Retrieved user priviledges');
      // step 2: we save this into LRU cache
      cachedPriviledges = new EntityAccessesEntity(resp.data);
      getCacheManager().set(UserPriviledgeCacheKey + this.authService.authUser.userId, cachedPriviledges);
    }

    return this.pathRbacMappers.checkRbacPermission(url, method, cachedPriviledges);
  }
}
