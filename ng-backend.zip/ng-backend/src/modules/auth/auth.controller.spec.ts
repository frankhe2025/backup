import { Test, TestingModule } from '@nestjs/testing';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { UnauthorizedException } from '@nestjs/common';
import { CommonService } from '../common/common.service';
import { AppConfig } from '../../config/app.config';
import { LoggerService } from '../logger/logger.service';

describe('AuthController', () => {
  let controller: AuthController;
  let authService: AuthService;
  let commonService: CommonService;

  const mockAuthService = {
    login: jest.fn(),
    generateToken: jest.fn(),
    getUserProfile: jest.fn(),
  };

  const mockCommonService = {
    getTenantDetails: jest.fn(),
  };

  const mockLoggerService = {
    log: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    debug: jest.fn(),
    verbose: jest.fn(),
    fatal: jest.fn(),
  };

  const mockRequest = {
    user: { email: 'test@example.com', tenantId: 'tenant-123', userId: 'user-123' },
  };

  const mockResponse = {
    redirect: jest.fn(),
  };

  const mockLoginDto = {
    email: 'test@example.com',
    password: 'password123',
    tenantId: 'tenant-123', // Added tenantId to match AuthLoginDto
  };

  const mockAuthUser = {
    email: 'test@example.com',
    tenantId: 'tenant-123',
    userId: 'user-123',
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AuthController],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: CommonService, useValue: mockCommonService },
        { provide: LoggerService, useValue: mockLoggerService },
      ],
    }).compile();

    controller = module.get<AuthController>(AuthController);
    authService = module.get<AuthService>(AuthService);
    commonService = module.get<CommonService>(CommonService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('login', () => {
    it('should return dev login response when EZLOGIN_DEV_ENABLED is true', async () => {
      // Mock AppConfig values
      (AppConfig as any).EZLOGIN_DEV_ENABLED = 'true';
      (AppConfig as any).EZLOGIN_DEV_USERNAME = 'dev@example.com';
      (AppConfig as any).EZLOGIN_DEV_TENANT_ID = 'dev-tenant';
      (AppConfig as any).EZLOGIN_DEV_ID = 'dev-user-id';

      mockAuthService.generateToken.mockResolvedValue('dev-token');

      const result = await controller.login(mockLoginDto, mockRequest);

      expect(result).toEqual({
        token: 'dev-token',
        email: 'dev@example.com',
        tenantName: 'Acme',
        userId: 'dev-user-id',
      });
    });

    it('should return a valid token on successful login', async () => {
      // now setting Easy loing to false
      // Mock AppConfig values
      (AppConfig as any).EZLOGIN_DEV_ENABLED = false;

      const mockToken = 'valid-token';
      mockAuthService.login.mockResolvedValue(mockAuthUser);
      mockAuthService.generateToken.mockResolvedValue(mockToken);
      mockCommonService.getTenantDetails.mockResolvedValue({
        tenantName: 'Acme',
      });

      const result = await controller.login(mockLoginDto, mockRequest);

      expect(result).toEqual({
        token: mockToken,
        email: mockAuthUser.email,
        tenantName: 'Acme',
        userId: mockAuthUser.userId,
      });
    });
  });

  describe('samlCallback', () => {
    it('should redirect to the correct URL with a token', async () => {
      const mockToken = 'saml-token';
      const mockRequest = {
        user: mockAuthUser,
        body: {
          RelayState: JSON.stringify({ redirectUrl: '/dashboard' }),
        },
      };

      mockAuthService.generateToken.mockResolvedValue(mockToken);

      await controller.samlCallback(mockRequest, mockResponse);

      expect(mockAuthService.generateToken).toHaveBeenCalledWith(mockAuthUser);
    });
  });

  describe('getUserProfile', () => {
    it('should return user profile with tenant details', async () => {
      const mockTenantDetails = { tenantName: 'Acme Corp' };
      mockAuthService.getUserProfile.mockResolvedValue(mockAuthUser);
      mockCommonService.getTenantDetails.mockResolvedValue(mockTenantDetails);

      const result = await controller.getUserProfile(mockRequest);

      expect(result).toEqual({
        ...mockAuthUser,
        tenantName: 'Acme Corp',
      });
    });
  });
});
