import { Test, TestingModule } from '@nestjs/testing';
import { JwtUtilService } from './jwt_util.service';
import * as jwt from 'jsonwebtoken';
import { AppConfig } from '../../config/app.config';

jest.mock('jsonwebtoken');

describe('JwtUtilService', () => {
  let service: JwtUtilService;

  const mockData = {
    email: 'test@example.com',
    userId: '12345',
    tenantId: 'tenant123',
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [JwtUtilService],
    }).compile();

    service = module.get<JwtUtilService>(JwtUtilService);

    // Reset mocks
    jest.clearAllMocks();
    (jwt.sign as jest.Mock).mockReset();
    (jwt.verify as jest.Mock).mockReset();
    (jwt.decode as jest.Mock).mockReset();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('sign', () => {
    it('should sign data with JWT and add roles', () => {
      const expectedToken = 'signed-token';
      (jwt.sign as jest.Mock).mockReturnValue(expectedToken);

      const result = service.sign(mockData);

      expect(result).toBe(expectedToken);
      expect(jwt.sign).toHaveBeenCalledWith({ ...mockData, roles: [1, 4] }, AppConfig.aisera_jwt_key, {
        algorithm: 'HS256',
        expiresIn: AppConfig.JWT_DURATION,
        issuer: AppConfig.aiseraJwtIssuer,
        subject: AppConfig.aiseraJwtSubject,
      });
    });

    it('should handle empty data object', () => {
      const expectedToken = 'signed-token';
      (jwt.sign as jest.Mock).mockReturnValue(expectedToken);

      const result = service.sign({});

      expect(result).toBe(expectedToken);
      expect(jwt.sign).toHaveBeenCalledWith({ roles: [1, 4] }, AppConfig.aisera_jwt_key, expect.any(Object));
    });
  });

  describe('decode', () => {
    it('should decode JWT token', () => {
      const token = 'test-token';
      const decodedData = { ...mockData, roles: [1, 4] };
      (jwt.decode as jest.Mock).mockReturnValue(decodedData);

      const result = service.decode(token);

      expect(result).toEqual(decodedData);
      expect(jwt.decode).toHaveBeenCalledWith(token);
    });

    it('should handle invalid token', () => {
      const token = 'invalid-token';
      (jwt.decode as jest.Mock).mockReturnValue(null);

      const result = service.decode(token);

      expect(result).toBeNull();
      expect(jwt.decode).toHaveBeenCalledWith(token);
    });
  });

  describe('verify', () => {
    it('should return true for valid token', () => {
      const token = 'valid-token';
      (jwt.verify as jest.Mock).mockReturnValue(true);

      const result = service.verify(token);

      expect(result).toBe(true);
      expect(jwt.verify).toHaveBeenCalledWith(token, AppConfig.aisera_jwt_key);
    });

    it('should return false for invalid token', () => {
      const token = 'invalid-token';
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new Error('Invalid token');
      });

      const result = service.verify(token);

      expect(result).toBe(false);
      expect(jwt.verify).toHaveBeenCalledWith(token, AppConfig.aisera_jwt_key);
    });

    it('should handle expired token', () => {
      const token = 'expired-token';
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new Error('TokenExpiredError');
      });

      const result = service.verify(token);

      expect(result).toBe(false);
      expect(jwt.verify).toHaveBeenCalledWith(token, AppConfig.aisera_jwt_key);
    });
  });
});
