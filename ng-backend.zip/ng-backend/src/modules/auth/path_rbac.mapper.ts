const pathRbacMapperConfig = [
  {
    url: '/v1/tenants/{s}/version/llm-prompts',
    method: 'GET',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'Read',
      },
    ],
  },
  {
    url: '/llm-gateway/v1/tenants/{s}/llm/prompts/categories',
    method: 'GET',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'Read',
      },
    ],
  },
  {
    url: '/llm-gateway/v1/tenants/{s}/version/llm-prompts',
    method: 'POST',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'Read', //'ReadWrite', // This is error from backend, it needs to be ReadWrite
      },
    ],
  },
  {
    url: '/llm-gateway/v1/tenants/{s}/llm/prompts/models',
    method: 'GET',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'Read',
      },
    ],
  },

  {
    url: 'llm-gateway/v1/tenants/{s}/version/llm-prompts/{promptId}',
    method: 'POST',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'Read',
      },
    ],
  },
  {
    url: '/llm-gateway/v1/tenants/{s}/version/llm-prompts/{s}',
    method: 'DELETE',
    priviledges: [
      {
        entityType: 'llmPromptsUser',
        priviledge: 'ReadWrite',
      },
    ],
  },
  {
    url: '/llm-gateway/v1/tenants/{s}/llm/prompts/execute',
    method: 'POST',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'Read',
      },
    ],
  },

  {
    url: '/llm-gateway/v1/tenants/{s}/version/llm-prompts/publish',
    method: 'POST',
    priviledges: [
      {
        entityType: 'promptStudio',
        priviledge: 'ReadWrite',
      },
    ],
  },
  {
    url: '/llm-gateway/v1/tenants/{s}/version/llm-prompts/{s}',
    method: 'PUT',
    priviledges: [
      {
        entityType: 'llmPromptsUser',
        priviledge: 'ReadWrite',
      },
    ],
  },
  {
    url: '/llm-gateway/v1/tenants/{s}/llm/prompts',
    method: 'POST',
    priviledges: [
      {
        entityType: 'llmPromptsSystem',
        priviledge: 'ReadWrite',
      },
    ],
  },
];

const pathRbacMapperToIgnore = [
  {
    url: '/access-control-service/v1/tenants/{s}/users/{d}',
    method: 'GET',
  },
  {
    url: '/tenant-server/v1/tenants/{s}/bots',
    method: 'GET',
  },
  {
    url: '/entity-filter/{s}',
    method: 'GET',
  },
  {
    url: '/entity-filter/{s}',
    method: 'POST',
  },
  {
    url: '/entity-filter/{s}',
    method: 'DELETE',
  },
  {
    url: '/entity-filter/{s}',
    method: 'PUT',
  },
];
export { pathRbacMapperToIgnore };
export default pathRbacMapperConfig;
