import { AuthUser } from './auth-user.entity';

describe('AuthUserEntity', () => {
  it('should construct auth entity with required fields', () => {
    const authUser: AuthUser = {
      email: 'a@a',
      issuer: 'iss',
      firstName: 'firstName',
    };
    expect(authUser.email).toEqual('a@a');
    expect(authUser.issuer).toEqual('iss');
    expect(authUser.firstName).toEqual('firstName');
  });

  it('should allow optional fields to be undefined', () => {
    const authUser: AuthUser = {
      email: 'b@b',
      issuer: 'iss',
      firstName: 'John',
    };
    expect(authUser.lastName).toBeUndefined();
    expect(authUser.tenantId).toBeUndefined();
  });

  it('should construct auth entity with all fields', () => {
    const authUser: AuthUser = {
      email: 'c@c',
      issuer: 'iss',
      firstName: 'Jane',
      lastName: 'Doe',
      tenantId: 'tenant-123',
    };
    expect(authUser.email).toEqual('c@c');
    expect(authUser.issuer).toEqual('iss');
    expect(authUser.firstName).toEqual('Jane');
    expect(authUser.lastName).toEqual('Doe');
    expect(authUser.tenantId).toEqual('tenant-123');
  });

  it('should handle empty strings for optional fields', () => {
    const authUser: AuthUser = {
      email: 'd@d',
      issuer: 'iss',
      firstName: 'Alice',
      lastName: '',
      tenantId: '',
    };
    expect(authUser.lastName).toEqual('');
    expect(authUser.tenantId).toEqual('');
  });
});
