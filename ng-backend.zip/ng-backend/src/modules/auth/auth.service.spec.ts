import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from './auth.service';
import { FetcherService } from '../common/services/fetcher.service';
import { TenantUserService } from '../tenant-user/tenant-user.service';
import { Request } from 'express';
import * as jwt from 'jsonwebtoken';
import { AppConfig } from '../../config/app.config';
import { AuthLoginDto } from './auth.dto';
import { AuthUser } from './auth-user.entity';
import { TenantUser } from '../tenant-user/tenant-user.entity';
import { INestApplication } from '@nestjs/common';
import { LoggerService } from '../logger/logger.service';

jest.mock('jsonwebtoken');

describe('AuthService', () => {
  let app: INestApplication;
  let service: AuthService;
  let fetcherService: FetcherService;
  let tenantUserService: TenantUserService;
  let loggerService: LoggerService;

  const mockFetcherService = {
    request: jest.fn(),
  };

  const mockTenantUserService = {
    findByEmailAndTenantId: jest.fn(),
  };

  const mockLoggerService = {
    log: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    debug: jest.fn(),
    verbose: jest.fn(),
    fatal: jest.fn(),
  };

  const mockHeader = jest.fn().mockImplementation((name: string) => {
    if (name === 'Authorization') {
      return 'Bearer test-token';
    }
    return undefined;
  });

  const mockRequest = {
    header: mockHeader,
  } as unknown as Request;

  const mockAuthUser: AuthUser = {
    email: 'test@example.com',
    firstName: 'Test',
    lastName: 'User',
    issuer: 'test-issuer',
    tenantId: 'tenant123',
    userId: '12345',
  };

  const mockTenantUser: TenantUser = {
    tenantUserId: 12345,
    tenantId: 'tenant123',
    tenantUserName: 'Test User',
    tenantUserEmail: 'test@example.com',
  };

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      providers: [
        AuthService,
        {
          provide: FetcherService,
          useValue: mockFetcherService,
        },
        {
          provide: TenantUserService,
          useValue: mockTenantUserService,
        },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    app = moduleRef.createNestApplication();
    await app.init();
  });

  beforeEach(async () => {
    // Get a new instance of AuthService for each test
    service = await app.resolve(AuthService);
    fetcherService = app.get(FetcherService);
    tenantUserService = app.get(TenantUserService);

    // Reset mocks
    jest.clearAllMocks();
    (jwt.sign as jest.Mock).mockReset();
    (jwt.verify as jest.Mock).mockReset();
    (jwt.decode as jest.Mock).mockReset();
  });

  afterAll(async () => {
    await app.close();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('extractBearerToken', () => {
    it('should extract token from Authorization header', () => {
      const result = service.extractBearerToken(mockRequest);
      expect(result).toBe('test-token');
    });

    it('should return undefined if no Authorization header', () => {
      mockHeader.mockImplementationOnce(() => undefined);
      const result = service.extractBearerToken(mockRequest);
      expect(result).toBeUndefined();
    });
  });

  describe('authenticated', () => {
    it('should return false if no token in header', async () => {
      mockHeader.mockImplementationOnce(() => undefined);
      const result = await service.authenticated(mockRequest);
      expect(result).toBe(false);
    });

    it('should return false if token verification fails', async () => {
      (jwt.verify as jest.Mock).mockReturnValue(false);
      const result = await service.authenticated(mockRequest);
      expect(result).toBe(false);
    });

    it('should return true and set authUser if token is valid', async () => {
      (jwt.verify as jest.Mock).mockReturnValue(true);
      (jwt.decode as jest.Mock).mockReturnValue(mockAuthUser);
      mockTenantUserService.findByEmailAndTenantId.mockResolvedValue(mockTenantUser);

      const result = await service.authenticated(mockRequest);
      expect(result).toBe(true);
      expect(service.authUser).toBeDefined();
    });
  });

  describe('getUserProfile', () => {
    it('should return decoded token with user ID if tenant user found', async () => {
      (jwt.decode as jest.Mock).mockReturnValue(mockAuthUser);
      mockTenantUserService.findByEmailAndTenantId.mockResolvedValue(mockTenantUser);

      const result = await service.getUserProfile(mockRequest);
      expect(result).toEqual(
        expect.objectContaining({
          ...mockAuthUser,
          userId: mockTenantUser.tenantUserId,
        })
      );
    });

    it('should return decoded token without modification if no tenant user found', async () => {
      (jwt.decode as jest.Mock).mockReturnValue(mockAuthUser);
      mockTenantUserService.findByEmailAndTenantId.mockResolvedValue(null);

      const result = await service.getUserProfile(mockRequest);
      expect(result).toEqual(mockAuthUser);
    });
  });

  describe('generateToken and sign', () => {
    it('should generate token with user ID if available', async () => {
      const data = { ...mockAuthUser };
      (jwt.sign as jest.Mock).mockReturnValue('generated-token');

      const result = await service.generateToken(data);
      expect(result).toBe('generated-token');
      expect(jwt.sign).toHaveBeenCalledWith(
        expect.objectContaining({
          ...data,
          roles: [1, 4],
          userId: data.userId,
        }),
        AppConfig.aisera_jwt_key,
        expect.any(Object)
      );
    });

    it('should fetch and include user ID if not provided', async () => {
      const data = { ...mockAuthUser, userId: undefined };
      (jwt.sign as jest.Mock).mockReturnValue('generated-token');
      mockTenantUserService.findByEmailAndTenantId.mockResolvedValue(mockTenantUser);

      const result = await service.generateToken(data);
      expect(result).toBe('generated-token');
      expect(jwt.sign).toHaveBeenCalledWith(
        expect.objectContaining({
          ...data,
          roles: [1, 4],
          userId: mockTenantUser.tenantUserId,
        }),
        AppConfig.aisera_jwt_key,
        expect.any(Object)
      );
    });
  });

  describe('verify', () => {
    it('should return true for valid token', () => {
      (jwt.verify as jest.Mock).mockReturnValue(true);
      const result = service.verify('valid-token');
      expect(result).toBe(true);
    });

    it('should return false for invalid token', () => {
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new Error('Invalid token');
      });
      const result = service.verify('invalid-token');
      expect(result).toBe(false);
    });
  });

  describe('login', () => {
    it('should return auth user from login response', async () => {
      const loginDto: AuthLoginDto = {
        tenantId: 'tenant123',
        email: 'test@example.com',
        password: 'password',
      };

      const mockResponse = {
        data: {
          tenantEmail: 'test@example.com',
          name: 'Test User',
          tenantId: 'tenant123',
          tenantUserId: 12345,
        },
      };

      mockFetcherService.request.mockResolvedValue(mockResponse);

      const result = await service.login(loginDto);
      expect(result).toEqual({
        email: mockResponse.data.tenantEmail,
        firstName: mockResponse.data.name,
        lastName: '',
        issuer: '',
        tenantId: mockResponse.data.tenantId,
        userId: mockResponse.data.tenantUserId,
      });
    });
  });
});
