import { Module } from '@nestjs/common';
import { ConfigController } from './config.controller';
import { ConfigService } from './config.service';
import { LoggerModule } from '../logger/logger.module';

@Module({
  imports: [LoggerModule],
  controllers: [ConfigController],
  providers: [ConfigService],
  exports: [ConfigService], // Export ConfigService for use in other modules
})
export class ConfigModule {}
