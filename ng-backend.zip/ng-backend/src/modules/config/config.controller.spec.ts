import { Test, TestingModule } from '@nestjs/testing';
import { ConfigController } from './config.controller';
import { ConfigService } from './config.service';
import { HttpException, Logger } from '@nestjs/common';
import { LoggerModule } from '../logger/logger.module';

describe('ConfigController', () => {
  let controller: ConfigController;
  let service: ConfigService;

  beforeEach(async () => {
    // Create a mock ConfigService
    const mockConfigService = {
      getEnvVariables: jest.fn().mockReturnValue({
        googleAnalyticsId: 'UA-12345678-1',
      }),
      clearCache: jest.fn().mockReturnValue(undefined),
    };

    // Create a testing module with our components
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ConfigController],
      providers: [
        {
          provide: ConfigService,
          useValue: mockConfigService,
        },
      ],
      imports: [LoggerModule],
    }).compile();

    controller = module.get<ConfigController>(ConfigController);
    service = module.get<ConfigService>(ConfigService);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('getEnvVariables', () => {
    it('should return environment variables from the service', () => {
      const result = controller.getEnvVariables();

      expect(service.getEnvVariables).toHaveBeenCalled();
      expect(result).toEqual({
        googleAnalyticsId: 'UA-12345678-1',
      });
    });

    it('should handle errors properly', () => {
      // Mock service to throw an error
      jest.spyOn(service, 'getEnvVariables').mockImplementation(() => {
        throw new Error('Test error');
      });

      // Expect controller to throw HttpException
      expect(() => controller.getEnvVariables()).toThrow(HttpException);
      expect(() => controller.getEnvVariables()).toThrow('Failed to retrieve configuration');
    });
  });

  describe('refreshCache', () => {
    it('should call clearCache on the service', () => {
      const result = controller.refreshCache();

      expect(service.clearCache).toHaveBeenCalled();
      expect(result).toEqual({
        success: true,
        message: 'Configuration cache refreshed',
      });
    });

    it('should handle errors when refreshing cache', () => {
      // Mock service to throw an error
      jest.spyOn(service, 'clearCache').mockImplementation(() => {
        throw new Error('Test error');
      });

      // Since the controller doesn't have explicit error handling for refreshCache yet,
      // we should expect the error to propagate
      expect(() => controller.refreshCache()).toThrow();
    });
  });
});
