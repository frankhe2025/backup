import { Test, TestingModule } from '@nestjs/testing';
import { ConfigService } from './config.service';
import { LoggerModule } from '../logger/logger.module';

describe('ConfigService', () => {
  let service: ConfigService;
  const originalEnv = process.env;

  beforeEach(async () => {
    // Create a clean testing module before each test
    const module: TestingModule = await Test.createTestingModule({
      providers: [ConfigService],
      imports: [LoggerModule],
    }).compile();

    service = module.get<ConfigService>(ConfigService);

    // Mock environment variables
    process.env = {
      ...originalEnv,
      PUBLIC_NG_GA_MEASUREMENT_ID: 'UA-12345678-1',
    };
  });

  afterEach(() => {
    // Restore original environment variables after each test
    process.env = originalEnv;
    jest.restoreAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getEnvVariables', () => {
    it('should return environment variables with display keys', () => {
      const result = service.getEnvVariables();

      expect(result).toEqual({
        googleAnalyticsId: 'UA-12345678-1',
      });
    });

    it('should return undefined for missing environment variables', () => {
      // Remove the environment variable
      delete process.env.PUBLIC_NG_GA_MEASUREMENT_ID;
      service.clearCache(); // Clear cache to ensure fresh retrieval

      const result = service.getEnvVariables();

      expect(result).toEqual({
        googleAnalyticsId: undefined,
      });
    });

    it('should use cached values on subsequent calls', () => {
      // First call to populate cache
      const result1 = service.getEnvVariables();

      // Change environment variable
      process.env.PUBLIC_NG_GA_MEASUREMENT_ID = 'UA-87654321-1';

      // Second call should return cached values
      const result2 = service.getEnvVariables();

      expect(result1).toEqual(result2);
    });
  });

  describe('clearCache', () => {
    it('should clear the cached values', () => {
      // First call to populate cache
      const result1 = service.getEnvVariables();

      // Change environment variable
      process.env.PUBLIC_NG_GA_MEASUREMENT_ID = 'UA-87654321-1';

      // Clear cache
      service.clearCache();

      // Should get new values
      const result2 = service.getEnvVariables();

      expect(result1).not.toEqual(result2);
      expect(result2).toEqual({
        googleAnalyticsId: 'UA-87654321-1',
      });
    });
  });
});
