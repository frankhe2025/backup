import { Controller, Get, HttpException, HttpStatus } from '@nestjs/common';
import { ConfigService, EnvVarResponse } from './config.service';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { LoggerService } from '../logger/logger.service';

@ApiTags('Configuration')
@Controller('config')
export class ConfigController {
  constructor(
    private readonly configService: ConfigService,
    private readonly loggerService: LoggerService
  ) {}

  @Get()
  @ApiOperation({
    summary: 'Get configuration variables',
    description: 'Returns a list of configuration variables',
  })
  @ApiResponse({
    status: 200,
    description: 'Configuration variables retrieved successfully',
    schema: {
      type: 'object',
      example: {
        googleAnalyticsId: 'UA-12345678-1',
      },
      additionalProperties: {
        type: 'string',
      },
    },
  })
  @ApiResponse({
    status: 500,
    description: 'Internal server error',
  })
  getEnvVariables(): EnvVarResponse {
    try {
      return this.configService.getEnvVariables();
    } catch (error) {
      this.loggerService.error('Failed to retrieve environment variables', error);
      throw new HttpException('Failed to retrieve configuration', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Get('refresh')
  @ApiOperation({
    summary: 'Refresh configuration cache',
    description: 'Clears the configuration cache to reload values from environment variables',
  })
  @ApiResponse({
    status: 200,
    description: 'Cache refreshed successfully',
  })
  refreshCache() {
    this.configService.clearCache();
    return { success: true, message: 'Configuration cache refreshed' };
  }
}
