import { Injectable, OnModuleInit } from '@nestjs/common';
import { LoggerService } from '../logger/logger.service';
import getCacheManager from '../common/services/cache_manager.util';

// Interface for environment variable configuration
interface EnvVarConfig {
  key: string; // Original environment variable name
  displayKey: string; // display key to hide the original name
  required?: boolean; // Whether this env var is required
  sensitive?: boolean; // Whether this env var contains sensitive data
}

// Interface for the response structure
export interface EnvVarResponse {
  [displayKey: string]: string | undefined;
}

@Injectable()
export class ConfigService implements OnModuleInit {
  constructor(private readonly loggerService: LoggerService) {}

  // Define mapping between env variable names and their display keys
  private readonly envVarConfigs: EnvVarConfig[] = [
    { key: 'PUBLIC_NG_GA_MEASUREMENT_ID', displayKey: 'googleAnalyticsId', required: true },
    // Add more environment variables with appropriate settings
  ];

  /**
   * Validate required environment variables on module initialization
   */
  onModuleInit() {
    const missingVars = this.envVarConfigs
      .filter((config) => config.required && !process.env[config.key])
      .map((config) => config.key);

    if (missingVars.length > 0) {
      this.loggerService.warn(`Missing required environment variables: ${missingVars.join(', ')}`);
    }
  }

  /**
   * Retrieves the specified environment variables.
   * @returns An object containing the environment variables and their values.
   */
  getEnvVariables(): EnvVarResponse {
    // Return cached values if available
    const cachedEnvVars = getCacheManager().get('configVarsCache');
    if (cachedEnvVars) {
      return cachedEnvVars;
    }

    const result: EnvVarResponse = {};

    for (const config of this.envVarConfigs) {
      let value = process.env[config.key];

      // Handle sensitive values by masking them
      if (config.sensitive && value) {
        value = this.maskSensitiveValue(value);
      }

      result[config.displayKey] = value;
    }

    // Cache the result
    getCacheManager().set('configVarsCache', result);
    return result;
  }

  /**
   * Clears the environment variables cache
   */
  clearCache(): void {
    getCacheManager().set('configVarsCache', null);
  }

  /**
   * Masks sensitive values (e.g., showing only the last 4 characters)
   * @param value The sensitive value to mask
   * @returns The masked value
   */
  private maskSensitiveValue(value: string): string {
    if (value.length <= 4) {
      return '****';
    }
    return '*'.repeat(value.length - 4) + value.slice(-4);
  }
}
