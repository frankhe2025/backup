import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity('tenant_users')
export class TenantUser {
  @PrimaryColumn({
    name: 'tenant_user_id',
    type: 'bigint',
    transformer: {
      from: (value: string) => value, // Keep as string
      to: (value: string | number) => value.toString(), // Convert number to string before saving
    },
  })
  //@PrimaryGeneratedColumn()
  tenantUserId: number;
  @Column({ name: 'tenant_id' })
  tenantId: string;
  @Column({ name: 'tenant_user_name' })
  tenantUserName: string;
  @Column({ name: 'tenant_user_email' })
  tenantUserEmail: string;
}
