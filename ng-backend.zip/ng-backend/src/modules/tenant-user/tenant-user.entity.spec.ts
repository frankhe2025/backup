import { TenantUser } from './tenant-user.entity';
import { getMetadataArgsStorage } from 'typeorm';
import { ValueTransformer } from 'typeorm';

describe('TenantUser Entity', () => {
  let tenantUser: TenantUser;

  beforeEach(() => {
    tenantUser = new TenantUser();
  });

  it('should be defined', () => {
    expect(tenantUser).toBeDefined();
  });

  it('should have the correct table name', () => {
    const metadata = getMetadataArgsStorage();
    const entityMetadata = metadata.tables.find((table) => table.target === TenantUser);
    expect(entityMetadata.name).toBe('tenant_users');
  });

  it('should have the correct columns', () => {
    const metadata = getMetadataArgsStorage();
    const columns = metadata.columns.filter((column) => column.target === TenantUser);

    // Check tenantUserId column
    const tenantUserIdColumn = columns.find((col) => col.propertyName === 'tenantUserId');
    expect(tenantUserIdColumn).toBeDefined();
    expect(tenantUserIdColumn.options.name).toBe('tenant_user_id');
    expect(tenantUserIdColumn.options.type).toBe('bigint');
    expect(tenantUserIdColumn.options.primary).toBe(true);

    // Check tenantId column
    const tenantIdColumn = columns.find((col) => col.propertyName === 'tenantId');
    expect(tenantIdColumn).toBeDefined();
    expect(tenantIdColumn.options.name).toBe('tenant_id');

    // Check tenantUserName column
    const tenantUserNameColumn = columns.find((col) => col.propertyName === 'tenantUserName');
    expect(tenantUserNameColumn).toBeDefined();
    expect(tenantUserNameColumn.options.name).toBe('tenant_user_name');

    // Check tenantUserEmail column
    const tenantUserEmailColumn = columns.find((col) => col.propertyName === 'tenantUserEmail');
    expect(tenantUserEmailColumn).toBeDefined();
    expect(tenantUserEmailColumn.options.name).toBe('tenant_user_email');
  });

  describe('tenantUserId transformer', () => {
    it('should keep string value as is when transforming from database', () => {
      const transformer = getMetadataArgsStorage().columns.find((col) => col.propertyName === 'tenantUserId').options
        .transformer as ValueTransformer;

      const result = transformer.from('12345');
      expect(result).toBe('12345');
    });

    it('should convert number to string when transforming to database', () => {
      const transformer = getMetadataArgsStorage().columns.find((col) => col.propertyName === 'tenantUserId').options
        .transformer as ValueTransformer;

      const result = transformer.to(12345);
      expect(result).toBe('12345');
    });

    it('should keep string value as is when transforming to database', () => {
      const transformer = getMetadataArgsStorage().columns.find((col) => col.propertyName === 'tenantUserId').options
        .transformer as ValueTransformer;

      const result = transformer.to('12345');
      expect(result).toBe('12345');
    });
  });

  describe('entity instantiation', () => {
    it('should create an instance with all properties', () => {
      const user = new TenantUser();
      user.tenantUserId = 12345;
      user.tenantId = 'tenant123';
      user.tenantUserName = 'John Doe';
      user.tenantUserEmail = 'john@example.com';

      expect(user.tenantUserId).toBe(12345);
      expect(user.tenantId).toBe('tenant123');
      expect(user.tenantUserName).toBe('John Doe');
      expect(user.tenantUserEmail).toBe('john@example.com');
    });
  });
});
