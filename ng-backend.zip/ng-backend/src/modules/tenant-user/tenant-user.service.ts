import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TenantUser } from './tenant-user.entity';
import { Repository } from 'typeorm';

@Injectable()
export class TenantUserService {
  constructor(@InjectRepository(TenantUser) private tenantUserRepository: Repository<TenantUser>) {}

  async findByEmailAndTenantId(tenantUserEmail: string, tenantId: string) {
    const foundTenantUsers = await this.tenantUserRepository.find({
      where: {
        tenantId,
        tenantUserEmail,
      },
    });
    if (foundTenantUsers.length > 0) {
      return foundTenantUsers[0];
    } else {
      return null;
    }
  }
}
