import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TenantUser } from './tenant-user.entity';
import { TenantUserService } from './tenant-user.service';

@Module({
  imports: [TypeOrmModule.forFeature([TenantUser])],
  providers: [TenantUserService],
  exports: [TenantUserService],
})
export class TenantUserModule {}
