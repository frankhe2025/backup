import { Test, TestingModule } from '@nestjs/testing';
import { TenantUserService } from './tenant-user.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { TenantUser } from './tenant-user.entity';
import { Repository } from 'typeorm';

describe('TenantUserService', () => {
  let service: TenantUserService;
  let repository: Repository<TenantUser>;

  const mockTenantUser: TenantUser = {
    tenantUserId: 12345,
    tenantId: 'tenant123',
    tenantUserName: 'John Doe',
    tenantUserEmail: 'john@example.com',
  };

  const mockRepository = {
    find: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TenantUserService,
        {
          provide: getRepositoryToken(TenantUser),
          useValue: mockRepository,
        },
      ],
    }).compile();

    service = module.get<TenantUserService>(TenantUserService);
    repository = module.get<Repository<TenantUser>>(getRepositoryToken(TenantUser));
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('findByEmailAndTenantId', () => {
    it('should return a tenant user when found', async () => {
      // Arrange
      const email = 'john@example.com';
      const tenantId = 'tenant123';
      mockRepository.find.mockResolvedValue([mockTenantUser]);

      // Act
      const result = await service.findByEmailAndTenantId(email, tenantId);

      // Assert
      expect(result).toEqual(mockTenantUser);
      expect(repository.find).toHaveBeenCalledWith({
        where: {
          tenantId,
          tenantUserEmail: email,
        },
      });
      expect(repository.find).toHaveBeenCalledTimes(1);
    });

    it('should return null when no tenant user is found', async () => {
      // Arrange
      const email = 'nonexistent@example.com';
      const tenantId = 'tenant123';
      mockRepository.find.mockResolvedValue([]);

      // Act
      const result = await service.findByEmailAndTenantId(email, tenantId);

      // Assert
      expect(result).toBeNull();
      expect(repository.find).toHaveBeenCalledWith({
        where: {
          tenantId,
          tenantUserEmail: email,
        },
      });
      expect(repository.find).toHaveBeenCalledTimes(1);
    });

    it('should handle repository errors gracefully', async () => {
      // Arrange
      const email = 'john@example.com';
      const tenantId = 'tenant123';
      const error = new Error('Database error');
      mockRepository.find.mockRejectedValue(error);

      // Act & Assert
      await expect(service.findByEmailAndTenantId(email, tenantId)).rejects.toThrow('Database error');
      expect(repository.find).toHaveBeenCalledWith({
        where: {
          tenantId,
          tenantUserEmail: email,
        },
      });
      expect(repository.find).toHaveBeenCalledTimes(1);
    });

    it('should handle empty email and tenantId parameters', async () => {
      // Arrange
      const email = '';
      const tenantId = '';
      mockRepository.find.mockResolvedValue([]);

      // Act
      const result = await service.findByEmailAndTenantId(email, tenantId);

      // Assert
      expect(result).toBeNull();
      expect(repository.find).toHaveBeenCalledWith({
        where: {
          tenantId: '',
          tenantUserEmail: '',
        },
      });
      expect(repository.find).toHaveBeenCalledTimes(1);
    });

    it('should handle case sensitivity in email search', async () => {
      // Arrange
      const email = 'JOHN@EXAMPLE.COM';
      const tenantId = 'tenant123';
      mockRepository.find.mockResolvedValue([mockTenantUser]);

      // Act
      const result = await service.findByEmailAndTenantId(email, tenantId);

      // Assert
      expect(result).toEqual(mockTenantUser);
      expect(repository.find).toHaveBeenCalledWith({
        where: {
          tenantId,
          tenantUserEmail: email,
        },
      });
      expect(repository.find).toHaveBeenCalledTimes(1);
    });
  });
});
