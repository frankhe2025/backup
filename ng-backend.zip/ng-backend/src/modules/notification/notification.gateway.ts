import {
  MessageBody,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
  WsResponse,
} from '@nestjs/websockets';
import { Server } from 'socket.io';
import { from, map, Observable } from 'rxjs';
import { JwtUtilService } from '../auth/jwt_util.service';
import { RedisRecord } from '../redis/redis-record.interface';
import { LoggerService } from '../logger/logger.service';

@WebSocketGateway({
  //namespace: '/websocket', // Add this line
  // cors: {
  //   origin: '*',
  // },
})
export class NotificationGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  constructor(
    private readonly jwtUtilService: JwtUtilService,
    private readonly loggerService: LoggerService
  ) {}

  @SubscribeMessage('eventlist')
  findAll(@MessageBody() data: any): Observable<WsResponse<number>> {
    return from([1, 2, 3]).pipe(map((item) => ({ event: 'eventlist', data: item })));
  }

  handleDisconnect(client: any) {
    const authToken = client.handshake.auth.token;
    if (authToken) {
      const { tenantId } = this._getRequestDetailFromClient(client);
      client.leave(tenantId);
    }
    this.loggerService.debug('Client Disconnected:', client.id);
  }

  async handleConnection(client: any, ...args: any[]) {
    this.loggerService.debug('Client attempting to connect:', client.id);

    const authToken = client.handshake.auth.token;
    if (authToken) {
      const { tenantId } = this._getRequestDetailFromClient(client);
      client.join(tenantId);
    }
    this.loggerService.debug('Client connected:', client.id);
  }

  broadcastNotification(payload: any) {
    const msgObj: RedisRecord = JSON.parse(payload);
    // if there is tenantId inside the payload, we will ONLY broadcast to that specific room
    if (msgObj.tenantId) {
      const room = this.server.sockets.adapter.rooms.get(msgObj.tenantId);
      if (room && room.size > 0) {
        this.server.to(msgObj.tenantId).emit('notification', msgObj.message);
      } else {
        this.loggerService.debug(`No clients in room ${msgObj.tenantId}. Message not sent.`);
      }
    } else {
      // otherwise, we emit to all the connected clients
      this.server.emit('notification', msgObj.message);
    }
  }

  _getRequestDetailFromClient(client: any) {
    const authToken = client.handshake.auth.token;
    const res = this.jwtUtilService.decode(authToken);
    const tenantId = res['tenantId'];
    const userId = res['userId'];
    const email = res['email'];
    return { tenantId, userId, email };
  }
}
