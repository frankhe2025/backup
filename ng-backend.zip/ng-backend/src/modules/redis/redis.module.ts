import { Module, Global } from '@nestjs/common';
import Redis from 'ioredis';
import { AppConfig } from '../../config/app.config';
import { RedisService } from './redis.service';
import { RedisController } from './redis.controller';

@Global()
@Module({
  controllers: [RedisController],
  providers: [
    {
      provide: 'REDIS_PUBLISHER',
      useFactory: () =>
        new Redis({
          host: AppConfig.aisera_memstore_host,
          port: Number(AppConfig.aisera_memstore_port),
          username: AppConfig.aisera_memstore_username,
          password: AppConfig.aisera_memstore_password,
        }),
    },
    {
      provide: 'REDIS_SUBSCRIBER',
      useFactory: () =>
        new Redis({
          host: AppConfig.aisera_memstore_host,
          port: Number(AppConfig.aisera_memstore_port),
          username: AppConfig.aisera_memstore_username,
          password: AppConfig.aisera_memstore_password,
        }),
    },
    RedisService,
  ],
  exports: ['REDIS_PUBLISHER', 'REDIS_SUBSCRIBER'],
})
export class RedisModule {}
