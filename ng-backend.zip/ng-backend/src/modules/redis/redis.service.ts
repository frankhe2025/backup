import { Inject, Injectable, OnModuleInit } from '@nestjs/common';
import Redis from 'ioredis';
import { LoggerService } from '../logger/logger.service';
import { AppConfig } from '../../config/app.config';
import { NotificationService } from '../notification/notification.service';
import { RedisRecord } from './redis-record.interface';

@Injectable()
export class RedisService implements OnModuleInit {
  constructor(
    @Inject('REDIS_SUBSCRIBER') private readonly subscriber: Redis,
    @Inject('REDIS_PUBLISHER') private readonly publisher: Redis,
    private readonly loggerService: LoggerService,
    private readonly notificationService: NotificationService
  ) {}

  async onModuleInit() {
    await this.subscriber.subscribe(AppConfig.ng_notification_channel_name);
    this.subscriber.on('message', (channel, message) => {
      this.loggerService.log(`[Redis] Received on Channel ${channel}: ${message}`);
      this.notificationService.sendGlobalNotification(message);
    });
  }

  // message must include tenantId, userId, message as attribute
  publish(message: RedisRecord) {
    this.publisher.publish(AppConfig.ng_notification_channel_name, JSON.stringify(message));
  }
}
