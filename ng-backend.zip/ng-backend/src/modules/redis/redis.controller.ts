import { Controller, Get } from '@nestjs/common';
import { RedisService } from './redis.service';

@Controller('/redis')
export class RedisController {
  constructor(private redisService: RedisService) {}
  @Get('/all')
  test() {
    this.redisService.publish({ message: 'Hello Changed' });
    return 'Redis';
  }
  @Get('/single')
  testSingle() {
    this.redisService.publish({ message: 'Hello Changed', tenantId: '10000' });
    return 'Redis';
  }
}
