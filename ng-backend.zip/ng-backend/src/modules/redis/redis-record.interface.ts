export interface RedisRecord {
  tenantId?: string;
  userId?: string;
  message: string;
}
