import { FetcherService } from './services/fetcher.service';
import { Module } from '@nestjs/common';
import { CommonService } from './common.service';
import { AppConfigModule } from '../../config/app.config';

@Module({
  imports: [AppConfigModule],
  controllers: [],
  providers: [FetcherService, CommonService],
  exports: [FetcherService, CommonService],
})
export class CommonModule {}
