import { Test, TestingModule } from '@nestjs/testing';
import { CommonService } from './common.service';
import { FetcherService } from './services/fetcher.service';

describe('CommonService', () => {
  let service: CommonService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CommonService,
        {
          provide: FetcherService,
          useValue: {}, // Mock FetcherService if needed
        },
      ],
    }).compile();

    service = await module.resolve<CommonService>(CommonService);
  });

  describe('getApiResponseLevel', () => {
    it('should return "normal" for duration less than 2000ms', () => {
      expect(true).toBeTruthy();
    });
    it('should return "normal" for duration less than 2000ms', () => {
      const result = service.getApiResponseLevel(1500);
      expect(result).toBe('normal');
    });

    it('should return "slower" for duration between 2000ms and 5000ms', () => {
      const result = service.getApiResponseLevel(3000);
      expect(result).toBe('slower');
    });

    it('should return "slowest" for duration between 5000ms and 10000ms', () => {
      const result = service.getApiResponseLevel(7000);
      expect(result).toBe('slowest');
    });

    it('should return "timeout" for duration greater than or equal to 10000ms', () => {
      const result = service.getApiResponseLevel(15000);
      expect(result).toBe('timeout');
    });

    it('should return an empty string for negative duration', () => {
      const result = service.getApiResponseLevel(-1);
      expect(result).toBe('');
    });
  });
});
