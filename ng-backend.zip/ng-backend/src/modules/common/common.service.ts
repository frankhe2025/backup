import { Injectable, Scope } from '@nestjs/common';
import { FetcherService } from './services/fetcher.service';
import { SERVICE_NAME } from './enums/service-name.enum';

@Injectable({ scope: Scope.REQUEST })
export class CommonService {
  constructor(private fetcherService: FetcherService) {}

  async getTenantDetails(tenantId: string, columns: string[], req: Request): Promise<any> {
    const response = await this.fetcherService.request(
      SERVICE_NAME.CONNECTOR_SERVER,
      `/v1/tenants/${tenantId}`,
      'GET',
      null,
      req.headers
    );
    let result = {};

    columns.forEach((col) => {
      result = {
        ...result,
        [col]: response.data?.[0]?.[col],
      };
    });
    return result;
  }

  // This method is to give api response level based on the time taken
  getApiResponseLevel(duration: number) {
    if (duration < 0) return '';
    const bucket = [2000, 5000, 10000];
    const bucketName = ['normal', 'slower', 'slowest', 'timeout'];
    for (let i = 0; i < bucketName.length; i++) {
      if (duration < bucket[i]) {
        return bucketName[i];
      }
    }
    return bucketName[bucketName.length - 1];
  }
}
