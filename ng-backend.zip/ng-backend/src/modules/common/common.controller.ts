import { Controller, Get, Param } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { FetcherService } from './services/fetcher.service';
import { SERVICE_NAME } from './enums/service-name.enum';

@Controller('/common')
@ApiTags('Common')
export class CommonController {
  constructor(private readonly fetcherService: FetcherService) {}

  @Get('bots/:tenantId')
  async getBots(@Param('tenantId') tenantId: string) {
    const response = await this.fetcherService.request(
      SERVICE_NAME.TENANT_SERVER,
      `/v1/tenants/${tenantId}/bots`,
      'GET',
      null
    );
    return response.data;
  }
}
