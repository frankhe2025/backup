import getCacheManager from './cache_manager.util';

describe('getCacheManager()', () => {
  it('check cache', () => {
    getCacheManager().set('a', 'abc');
    getCacheManager().set('b', 1);
    getCacheManager().set({ a: 123 }, 2);
    expect(getCacheManager().get('a')).toBe('abc');
    expect(getCacheManager().get('b')).toBe(1);
    expect(getCacheManager().get({ a: 123 })).toBe(2);
  });

  it('passed in config', () => {
    getCacheManager().cache.setMax(1);
    getCacheManager().set('a', 1);
    expect(getCacheManager().get('a')).toBe(1);
    getCacheManager().set('b', 2);
    expect(getCacheManager().get('b')).toBe(2);
    expect(getCacheManager().get('a')).toBeFalsy();
  });
});
