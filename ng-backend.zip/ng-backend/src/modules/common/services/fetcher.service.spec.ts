import { Test, TestingModule } from '@nestjs/testing';
import { FetcherService } from './fetcher.service';
import { HttpService } from '@nestjs/axios';
import { of, throwError } from 'rxjs';
import { AxiosResponse, AxiosHeaders } from 'axios';
import { ConfigService } from '@nestjs/config';

describe('FetcherService', () => {
  let service: FetcherService;
  let httpService: HttpService;

  const mockHttpService = {
    request: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [FetcherService, { provide: HttpService, useValue: mockHttpService }, ConfigService],
    }).compile();

    service = module.get<FetcherService>(FetcherService);
    httpService = module.get<HttpService>(HttpService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('request', () => {
    it('should make an HTTP request and return the response', async () => {
      const mockResponse: AxiosResponse = {
        data: { success: true },
        status: 200,
        statusText: 'OK',
        headers: new AxiosHeaders(), // Use a valid AxiosHeaders instance
        config: {
          headers: new AxiosHeaders(), // Use a valid AxiosHeaders instance
        },
      };

      const mockRequestConfig = {
        method: 'GET',
        url: 'https://example.com', // Ensure the URL is valid
        serviceName: 'TENANT_SERVER',
        body: '',
      };

      // Mock the HttpService.request method
      mockHttpService.request.mockReturnValue(of(mockResponse));

      const result = await service.request(
        mockRequestConfig.serviceName,
        mockRequestConfig.url,
        mockRequestConfig.method as any,
        mockRequestConfig.body
      );
      expect(result != null).toBeTruthy();
    });

    it('should handle errors from the HTTP request', async () => {
      const mockError = new Error('Request failed');
      const mockRequestConfig = {
        method: 'POST',
        url: 'https://example.com', // Ensure the URL is valid
        serviceName: 'TENANT_SERVER',
        body: { key: 'value' },
      };

      // Mock the HttpService.request method to throw an error
      mockHttpService.request.mockReturnValue(throwError(() => mockError));

      const resp = await expect(
        service.request(
          mockRequestConfig.serviceName,
          mockRequestConfig.url,
          mockRequestConfig.method as any,
          mockRequestConfig.body
        )
      );

      expect(resp != null).toBeTruthy();
    });
  });
});
