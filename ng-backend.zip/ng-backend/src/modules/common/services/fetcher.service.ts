import { Injectable } from '@nestjs/common';
import axios from 'axios';
import { SERVICE_NAME } from '../enums/service-name.enum';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class FetcherService {
  constructor(private readonly configService: ConfigService) {}

  async request(
    serviceName: SERVICE_NAME | string,
    url: string,
    method: 'GET' | 'POST' | 'PUT' | 'DELETE',

    body?: any,
    headers?: any
  ) {
    const serverName = this.getServerName(serviceName as SERVICE_NAME);
    const response = await axios
      .request({
        method,
        url: `${serverName}${url}`,
        headers: {
          ...headers,
        },
        data: {
          ...body,
        },
      })
      .catch((e) => {
        //this.loggerService.error('Error returned from backend: ' + JSON.stringify(e));
        return e;
      });

    return response;
  }

  getServerName(serviceName: SERVICE_NAME) {
    return this.configService.get(serviceName);
  }
}
