export enum SERVICE_NAME {
  CONNECTOR_SERVER = 'connector_server_uri',
  TENANT_SERVER = 'tenant_server_uri',
  ACCESS_CONTROL = 'access_control_service_uri',
}
