import { forwardRef, Inject, Injectable, Logger, Scope } from '@nestjs/common';
import { TypeOrmModuleOptions, TypeOrmOptionsFactory } from '@nestjs/typeorm';
import { Cacheable } from 'nestjs-cacheable';
import { AppConfig } from './config/app.config';
import { AuthService } from './modules/auth/auth.service';

@Injectable({ scope: Scope.REQUEST })
export class TenantDbOptionFactory implements TypeOrmOptionsFactory {
  private readonly logger = new Logger(TenantDbOptionFactory.name);

  constructor(@Inject(forwardRef(() => AuthService)) private authService: AuthService) {}

  createTypeOrmOptions(connectionName?: string): Promise<TypeOrmModuleOptions> | TypeOrmModuleOptions {
    return new Promise(async (resolve) => {
      let tenantId = '';
      try {
        if (AuthService._authUser && AuthService._authUser.tenantId) {
          tenantId = AuthService._authUser.tenantId;
          AuthService._authUser.tenantId = ''; // we need to clear the _authUser to avoid any potential issue
        } else {
          console.log('No TenantId Available');
          return;
        }
      } catch (error) {
        this.logger.warn('Could not get tenant ID from auth service', error);
        return;
      }
      resolve(await this.getOptions(tenantId));
    });
  }

  @Cacheable({ key: (tenantId: string) => `tenant-db-name-${tenantId}`, ttl: 6000 })
  async getOptions(tenantId: string | number) {
    return {
      type: AppConfig.DB_TYPE,
      host: AppConfig.aisera_datastores_sql_host,
      port: AppConfig.aisera_datastores_sql_port,
      username: AppConfig.aisera_sql_user,
      password: AppConfig.aisera_sql_password,
      database: 'aisera_' + tenantId,
      synchronize: false,
      logging: true,
      autoLoadEntities: true,
    };
  }
}
