import { Test, TestingModule } from '@nestjs/testing';
import { TenantDbOptionFactory } from './tenant-db-option.factory';
import { AuthService } from './modules/auth/auth.service';
import { Logger } from '@nestjs/common';
import { AppConfig } from './config/app.config';

jest.mock('./modules/auth/auth.service');

describe('TenantDbOptionFactory', () => {
  let tenantDbOptionFactory: TenantDbOptionFactory;
  let authService: AuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TenantDbOptionFactory,
        {
          provide: AuthService,
          useValue: {
            _authUser: { tenantId: 'test-tenant-id' },
          },
        },
      ],
    }).compile();

    // Use resolve() for scoped providers
    tenantDbOptionFactory = await module.resolve<TenantDbOptionFactory>(TenantDbOptionFactory);
    authService = module.get<AuthService>(AuthService);
  });

  it('should be defined', () => {
    expect(tenantDbOptionFactory).toBeDefined();
  });
});
