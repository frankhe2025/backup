export const TENANT_DB_CONNECTION = 'TENANT_DB_CONNECTION';

export const DbSchema = {
  TENANT_STORE: 'tenant_store',
  CONFIG_DB: 'aisera_9000',
} as const;
