import { MiddlewareConsumer, Module, NestModule, RequestMethod } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TypeOrmCoreModule } from '@nestjs/typeorm/dist/typeorm-core.module';

import { AuthMiddleware } from './middleware/auth.middleware';
import { BackendHttpProxyMiddleware } from './middleware/backend-http-proxy.middleware';
import { AppConfig, AppConfigModule } from './config/app.config';
import { TENANT_DB_CONNECTION, DbSchema } from './common/constants';
import { TenantDbOptionFactory } from './tenant-db-option.factory';
import { AuthModule } from './modules/auth/auth.module';
import { CommonModule } from './modules/common/common.module';
import { EntityFilterModule } from './modules/entity-filter/entity-filter.module';
import { LoggerModule } from './modules/logger/logger.module';
import { TenantUserModule } from './modules/tenant-user/tenant-user.module';
import { HealthModule } from './modules/health/health.module';
import { PrometheusModule } from './modules/prometheus/prometheus.module';
import { RbacMiddleware } from './middleware/rbac.middleware';

import { RedisModule } from './modules/redis/redis.module';
import { NotificationModule } from './modules/notification/notification.module';
import { ConfigModule } from './modules/config/config.module';
@Module({
  imports: [
    PrometheusModule,
    AppConfigModule,
    TypeOrmModule.forRoot({
      type: AppConfig.DB_TYPE,
      host: AppConfig.aisera_datastores_sql_host,
      port: AppConfig.aisera_datastores_sql_port,
      username: AppConfig.aisera_sql_user,
      password: AppConfig.aisera_sql_password,
      database: DbSchema.TENANT_STORE,
      synchronize: false,
      autoLoadEntities: true,
      logging: true,
    }),
    TypeOrmCoreModule.forRootAsync({
      name: TENANT_DB_CONNECTION,
      useClass: TenantDbOptionFactory,
      imports: [AuthModule],
    }),
    EntityFilterModule,
    TenantUserModule,
    AuthModule,
    CommonModule,
    LoggerModule,
    HealthModule,
    RedisModule,
    NotificationModule,
    ConfigModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer): any {
    consumer
      .apply(AuthMiddleware, RbacMiddleware)
      .exclude(
        {
          path: 'auth/login',
          method: RequestMethod.POST,
        },
        {
          path: 'auth/sso/login',
          method: RequestMethod.GET,
        },
        {
          path: 'auth/sso/authenticate',
          method: RequestMethod.GET,
        },
        {
          path: 'auth/sso/callback',
          method: RequestMethod.POST,
        },
        {
          path: 'ng-backend/v1/health-check',
          method: RequestMethod.GET,
        },
        {
          path: 'metrics',
          method: RequestMethod.GET,
        },
        {
          path: 'metrics/test_counter',
          method: RequestMethod.GET,
        },
        {
          path: 'metrics/test_gauge',
          method: RequestMethod.GET,
        },
        {
          path: 'redis/all',
          method: RequestMethod.GET,
        },
        {
          path: 'redis/single',
          method: RequestMethod.GET,
        },
        {
          path: 'socket.io',
          method: RequestMethod.GET,
        },
        {
          path: 'config',
          method: RequestMethod.GET,
        }
      )
      .forRoutes('*');

    // This is to proxy all the requests to backend serverdirectly
    const backendServicesToBeProxied = AppConfig.BACKEND_PROXIES.split(',');
    backendServicesToBeProxied.forEach((bkName: string) => {
      consumer.apply(BackendHttpProxyMiddleware).forRoutes({ path: bkName + '/*', method: RequestMethod.ALL });
    });
  }
}
