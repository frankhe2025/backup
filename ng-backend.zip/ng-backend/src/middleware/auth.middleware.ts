import { Injectable, NestMiddleware, UnauthorizedException } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { AuthService } from '../modules/auth/auth.service';
import { LoggerService } from '../modules/logger/logger.service';

@Injectable()
export class AuthMiddleware implements NestMiddleware {
  constructor(
    private readonly authService: AuthService,
    private readonly loggerService: LoggerService
  ) {}

  async use(req: Request, res: Response, next: NextFunction) {
    this.loggerService.debug('Start Checking authentication');
    try {
      const isAuthenticated = await this.authService.authenticated(req);
      if (isAuthenticated) {
        next();
      } else {
        this.loggerService.error('Authentication failed.');
        throw new UnauthorizedException('Unauthenticated');
      }
    } catch (error) {
      this.loggerService.error('Authentication failed with error: ' + error.toString() + ', msg:' + error.message);
      throw new UnauthorizedException('Unauthenticated');
    }
  }
}
