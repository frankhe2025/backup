import { Injectable, NestMiddleware } from '@nestjs/common';
import { createProxyMiddleware } from 'http-proxy-middleware';
import * as process from 'process';
import { ConfigService } from '@nestjs/config';
import { LoggerService } from '../modules/logger/logger.service';
import { PrometheusService } from '../modules/prometheus/prometheus.service';
import { CommonService } from '../modules/common/common.service';
import { PrometheusMetricName } from '../modules/prometheus/prometheus.metric_name.enum';

@Injectable()
export class BackendHttpProxyMiddleware implements NestMiddleware {
  constructor(
    private readonly configService: ConfigService,
    private readonly logService: LoggerService,
    private readonly prometheusService: PrometheusService,
    private readonly commonService: CommonService
  ) {}
  private getProxy = (req: any, res: any, next: any) => {
    const target = this.generateTarget(req);

    return createProxyMiddleware({
      target: target,
      pathRewrite: (path, req) => {
        return path.replace('/' + this.getServiceName(req), '');
      },
      secure: false,
      on: {
        proxyReq: (proxyReq, req, res) => {
          // Mark the start time
          (req as any)._startTime = Date.now();
          const proxyString = `[MiddleWare]: Proxying ${req.method} request made to '${target}' - '${req.url}'`;
          let proxyDetails = `Request Headers: ${JSON.stringify(req.headers)}, Method: ${req.method}`;
          if (req['body']) {
            const bodyString = JSON.stringify(req['body']);
            proxyDetails += `, Body: ${bodyString}`;
            proxyReq.write(bodyString);
          }
          this.logService.log(proxyString);
          this.logService.debug(`[ServiceName]: ${this.getServiceName(req)}, [RequestDetails]: ` + proxyDetails);
        },
        proxyRes: (proxyRes, req, res) => {
          res.on('finish', () => {
            const duration = Date.now() - (req as any)._startTime;
            const timeLogString = `[MiddleWare]: ${req.method} ${req.url} -> Took ${duration}ms`;
            // now adding counter for the api response time
            this.trackingApiResponses(req, duration);
            this.logService.log(timeLogString);
          });
        },
        error: (err, req, res) => {
          const errorString = `[MiddleWare]: Error occurred while proxying request to '${req.url}': ${err.message}`;
          this.logService.error(errorString);
        },
      },
    });
  };

  trackingApiResponses(req, timeTaken: number) {
    const responseLevel = this.commonService.getApiResponseLevel(timeTaken);
    const { svcName, apiPath } = this.getMetricServiceInfo(req.url);
    if (svcName && apiPath) {
      this.prometheusService.count(
        PrometheusMetricName.BACKEND_API_RESPONSE_LEVEL,
        {
          SERVICE_NAME: svcName,
          RESPONSE_LEVEL: responseLevel,
          API_PATH: apiPath,
        },
        1
      );
    }
  }

  private generateTarget(req) {
    const urlName = this.getServiceName(req).replace(/-/g, '_') + '_uri';
    const url = this.configService.get(urlName);
    this.logService.log('[MiddleWare]: Target URL: ' + url);
    return url;
  }

  private getMetricServiceInfo(url: string) {
    // input pattern is /v1/tenants/10000/users/xxxx
    const urlParts = url.split('/');
    if (urlParts.length > 4) {
      const svcName = urlParts[2];
      const apiPath = urlParts.slice(1, 5).join('/');
      return {
        svcName,
        apiPath,
      };
    } else {
      return null;
    }
  }

  private getServiceName(req): string {
    let url = req.url;
    if (url.startsWith('/')) {
      url = url.substring(1);
    }
    const urlParts = url.split('/');
    const svName = urlParts[0]; // .replace(/-/g, '_');

    return svName;
  }

  use(req: any, res: any, next: any) {
    this.getProxy(req, res, next)(req, res, next);
  }
}
