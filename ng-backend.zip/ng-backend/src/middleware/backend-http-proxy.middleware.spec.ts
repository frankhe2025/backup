import { Test, TestingModule } from '@nestjs/testing';
import { BackendHttpProxyMiddleware } from './backend-http-proxy.middleware';
import { ConfigService } from '@nestjs/config';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { LoggerService } from '../modules/logger/logger.service';
import { PrometheusService } from '../modules/prometheus/prometheus.service';
import { CommonService } from '../modules/common/common.service';

jest.mock('http-proxy-middleware');

interface RequestWithStartTime {
  url: string;
  method: string;
  _startTime?: number;
}

describe('BackendHttpProxyMiddleware', () => {
  let middleware: BackendHttpProxyMiddleware;
  let configService: ConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BackendHttpProxyMiddleware,
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn(),
          },
        },
        {
          provide: LoggerService,
          useValue: {
            get: jest.fn(),
            log: jest.fn(),
            debug: jest.fn(),
          },
        },
        {
          provide: PrometheusService,
          useValue: {
            get: jest.fn(),
          },
        },
        {
          provide: CommonService,
          useValue: {
            get: jest.fn(),
          },
        },
      ],
    }).compile();

    middleware = module.get<BackendHttpProxyMiddleware>(BackendHttpProxyMiddleware);
    configService = module.get<ConfigService>(ConfigService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('use', () => {
    it('should call getProxy with request, response and next', () => {
      const req = { url: '/service-name/path' };
      const res = {};
      const next = jest.fn();
      const mockProxy = jest.fn();

      jest.spyOn(middleware as any, 'getProxy').mockReturnValue(mockProxy);

      middleware.use(req, res, next);

      expect(mockProxy).toHaveBeenCalledWith(req, res, next);
    });
  });

  describe('getServiceName', () => {
    it('should extract service name from URL', () => {
      const req = { url: '/service-name/path' };
      const serviceName = (middleware as any).getServiceName(req);
      expect(serviceName).toBe('service-name');
    });

    it('should handle URLs without leading slash', () => {
      const req = { url: 'service-name/path' };
      const serviceName = (middleware as any).getServiceName(req);
      expect(serviceName).toBe('service-name');
    });
  });

  describe('generateTarget', () => {
    it('should get target URL from config service', () => {
      const req = { url: '/service-name/path' };
      const expectedUrl = 'http://service-url';
      (configService.get as jest.Mock).mockReturnValue(expectedUrl);

      const target = (middleware as any).generateTarget(req);
      expect(target).toBe(expectedUrl);
      expect(configService.get).toHaveBeenCalledWith('service_name_uri');
    });
  });

  describe('getMetricServiceInfo', () => {
    it('should return service name and API path for a valid URL', () => {
      const url = '/v1/tenants/10000/users/xxxx';
      const result = (middleware as any).getMetricServiceInfo(url);

      expect(result).toEqual({
        svcName: 'tenants',
        apiPath: 'v1/tenants/10000/users',
      });
    });

    it('should return null for an invalid URL', () => {
      const url = '/v1/tenants';
      const result = (middleware as any).getMetricServiceInfo(url);

      expect(result).toBeNull();
    });
  });
});
