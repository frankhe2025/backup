import { Test, TestingModule } from '@nestjs/testing';
import { AuthMiddleware } from './auth.middleware';
import { AuthService } from '../modules/auth/auth.service';
import { UnauthorizedException } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { LoggerService } from '../modules/logger/logger.service';

describe('AuthMiddleware', () => {
  let middleware: AuthMiddleware;
  let authService: AuthService;
  let mockRequest: Partial<Request>;
  let mockResponse: Partial<Response>;
  let nextFunction: NextFunction;

  const mockAuthService = {
    authenticated: jest.fn(),
  };

  const mockLoggerService = {
    log: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    debug: jest.fn(),
    verbose: jest.fn(),
    fatal: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthMiddleware,
        {
          provide: AuthService,
          useValue: mockAuthService,
        },
        {
          provide: LoggerService,
          useValue: mockLoggerService,
        },
      ],
    }).compile();

    middleware = module.get<AuthMiddleware>(AuthMiddleware);
    authService = module.get<AuthService>(AuthService);

    // Reset mocks
    jest.clearAllMocks();

    // Setup mock request, response and next function
    mockRequest = {};
    mockResponse = {};
    nextFunction = jest.fn();
  });

  it('should be defined', () => {
    expect(middleware).toBeDefined();
  });

  describe('use', () => {
    it('should call next() when authentication is successful', async () => {
      // Arrange
      mockAuthService.authenticated.mockResolvedValue(true);

      // Act
      await middleware.use(mockRequest as Request, mockResponse as Response, nextFunction);

      // Assert
      expect(mockAuthService.authenticated).toHaveBeenCalledWith(mockRequest);
      expect(nextFunction).toHaveBeenCalled();
    });

    it('should throw UnauthorizedException when authentication fails', async () => {
      // Arrange
      mockAuthService.authenticated.mockResolvedValue(false);

      // Act & Assert
      await expect(middleware.use(mockRequest as Request, mockResponse as Response, nextFunction)).rejects.toThrow(
        UnauthorizedException
      );

      expect(mockAuthService.authenticated).toHaveBeenCalledWith(mockRequest);
      expect(nextFunction).not.toHaveBeenCalled();
    });

    it('should throw UnauthorizedException when authentication throws an error', async () => {
      // Arrange
      mockAuthService.authenticated.mockRejectedValue(new Error('Authentication error'));

      // Act & Assert
      await expect(middleware.use(mockRequest as Request, mockResponse as Response, nextFunction)).rejects.toThrow(
        UnauthorizedException
      );

      expect(mockAuthService.authenticated).toHaveBeenCalledWith(mockRequest);
      expect(nextFunction).not.toHaveBeenCalled();
    });
  });
});
