import { Injectable, NestMiddleware, UnauthorizedException } from '@nestjs/common';
import { RbacService } from '../modules/auth/rbac.service';
import { NextFunction, Request, Response } from 'express';
import { LoggerService } from '../modules/logger/logger.service';

@Injectable()
export class RbacMiddleware implements NestMiddleware {
  constructor(
    private readonly rbacService: RbacService,
    private readonly loggerService: LoggerService
  ) {}
  async use(req: Request, res: Response, next: NextFunction) {
    this.loggerService.debug('Start checking Rbac');
    try {
      const isAuthorized = await this.rbacService.authorized(req);
      if (isAuthorized) {
        next();
      } else {
        this.loggerService.debug('User is not authorized to visit this URL');
        throw new UnauthorizedException('Unauthorized');
      }
    } catch (error) {
      this.loggerService.error('Error retrieving Rbac: ' + error + ', msg: ' + error.message);
      throw new UnauthorizedException('Unauthorized');
    }
  }
}
