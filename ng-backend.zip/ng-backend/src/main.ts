import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Logger } from 'nestjs-pino';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import rateLimit from 'express-rate-limit';
import { ValidationPipe } from '@nestjs/common';

import { json, urlencoded } from 'express';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { bufferLogs: true, bodyParser: false });

  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true })); // Enables automatic DTO validation and transformation
  app.use(json()); // Explicitly add JSON body parser
  app.use(urlencoded({ extended: false }));

  app.useLogger(app.get(Logger));
  app.enableCors({ origin: '*' });

  // Rate limiting middleware
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
  });
  // app.use(limiter);

  const config = new DocumentBuilder()
    .setTitle('NG Backend')
    .setDescription('Next Gen Backend Service')
    .setVersion('1.0')
    .addTag('ng-backend')
    .build();
  const document = SwaggerModule.createDocument(app, config);

  SwaggerModule.setup('api-doc', app, document);

  await app.listen(process.env.PORT);
}
bootstrap();
