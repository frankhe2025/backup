import { ConfigModule } from '@nestjs/config';
import { z } from 'zod';

const envFilePath = process.env['NODE_ENV'] === 'test' ? '.env.test' : '.env';

export const AppConfigModule = ConfigModule.forRoot({
  envFilePath,
  isGlobal: true,
});

const envSchema = z.object({
  NODE_ENV: z.enum(['production', 'development', 'test']).default('production'),

  PORT: z
    .string()
    .default('3000')
    .transform((val) => parseInt(val, 10)),

  BACKEND_PROXIES: z.string().nonempty(),
  conversation_server_uri: z.string().nonempty(),
  tenant_server_uri: z.string().nonempty(),
  access_control_service_uri: z.string().nonempty(),
  llm_gateway_uri: z.string().nonempty(),
  connector_server_uri: z.string().nonempty(),

  aisera_datastores_sql_host: z.string().nonempty(),
  aisera_datastores_sql_port: z
    .string()
    .default('3306')
    .transform((val) => parseInt(val, 10)),
  aisera_sql_user: z.string().nonempty(),
  aisera_sql_password: z.string().nonempty(),

  aisera_clickhousedb_host: z.string().nonempty(),
  aisera_clickhousedb_user: z.string().nonempty(),
  aisera_clickhousedb_password: z.string().nonempty(),

  aisera_jwt_key: z.string().default(''),
  aiseraJwtIssuer: z.string().default(''),
  aiseraJwtSubject: z.string().default(''),
  JWT_DURATION: z
    .string()
    .default('0')
    .transform((val) => parseInt(val, 10)),

  aisera_sso_issuer: z.string(),
  SAML_CALLBACK_URL: z.string(),
  aisera_sso_login_url: z.string(),
  aisera_sso_x509_certificate: z.string(),

  EZLOGIN_DEV_ENABLED: z.string().optional(),
  EZLOGIN_DEV_ID: z.string().optional(),
  EZLOGIN_DEV_USERNAME: z.string().optional(),
  EZLOGIN_DEV_TENANT_ID: z.string().optional(),
  aisera_memstore_host: z.string().optional(),
  aisera_memstore_port: z.string().optional(),
  aisera_memstore_username: z.string().optional(),
  aisera_memstore_password: z.string().optional(),
  ng_notification_channel_name: z.string().optional(),
});
const e = process.env;
const envVars = envSchema.parse(process.env);
export const AppConfig = {
  ...envVars,
  DB_TYPE: envVars.NODE_ENV === 'test' ? 'sqlite' : 'mariadb',
  IS_DEV_ENV: envVars.NODE_ENV === 'development',
  IS_TEST_ENV: envVars.NODE_ENV === 'test',
  CACHE_TTL: 6000,
} as const;

export const getJWTKey = () => {
  return envVars.aisera_jwt_key;
};
