import { LoggerModuleAsyncParams } from 'nestjs-pino';
import { maskSensitiveData } from '../modules/logger/logger.entity';

export const loggerConfig: LoggerModuleAsyncParams = {
  useFactory: () => ({
    pinoHttp: {
      level: 'debug',
      serializers: {
        req(req) {
          return {
            method: req.method,
            url: req.url,
            headers: maskSensitiveData(req.headers),
            query: maskSensitiveData(req.query),
            body: maskSensitiveData(req.body),
          };
        },
        // Optionally sanitize response or err as well
        res(res) {
          return {
            statusCode: res.statusCode,
          };
        },
      },
    },
  }),
};
