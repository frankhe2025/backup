docker stop prometheus
docker stop grafana
docker rm prometheus
docker rm grafana
docker run -d --name prometheus -p 9090:9090 -v $(pwd)/prometheus.yml:/etc/prometheus/prometheus.yml prom/prometheus
docker run -d --name grafana -p 3003:3000 grafana/grafana
