import {render} from "@testing-library/react";

import TableControllerComponent from "../src/table-controller.component";
import getFilterConfigMock from "../../commons/components/general-filter/src/mock/entities/filter_config.mock";
import FilterConfig from "../../commons/components/general-filter/src/entities/filter_config";

describe("TableControllerComponent", () => {
  it("Should render correctly", () => {
    const tableControllerCfg = {
      filterConfig: new FilterConfig(getFilterConfigMock()),
      columns: [],
      defaultColumns: ["key1"],
      onSearch: () => {},
      onColumnChange: () => {},
      saveable: false,
    };
    const wrapper = render(<TableControllerComponent {...tableControllerCfg} />);

    expect(() => wrapper.unmount()).not.toThrow();
  });
});
