import {SavedTableConfig} from "../../src/entities/saved-table-config";
import {SavedFilter} from "../../../commons/components/general-filter/src/entities/saved-filter";

describe("SavedTableConfig", () => {
  it("create empty object", () => {
    const savedCfg = new SavedTableConfig();

    expect(savedCfg.columns.length).toEqual(0);
    expect(savedCfg.savedFilter).toBeNull();
  });
  it("set up non empty object", () => {
    const savedFilterData = {
      name: "name1",
      scope: "Public",
      finalFilters: [],
    };
    const savedCfg = new SavedTableConfig({savedFilter: savedFilterData});

    expect(savedCfg.savedFilter?.name).toEqual("name1");
    expect(savedCfg.savedFilter?.finalFilters?.finalFilters.length).toEqual(0);
    expect(savedCfg.columns.length).toEqual(0);
  });
  it("set up non empty object with SavedFilter Object", () => {
    const savedFilterData = {
      name: "name1",
      scope: "Public",
      finalFilters: [],
    };
    const savedCfg = new SavedTableConfig({savedFilter: new SavedFilter(savedFilterData)});

    expect(savedCfg.savedFilter?.name).toEqual("name1");
    expect(savedCfg.savedFilter?.finalFilters?.finalFilters.length).toEqual(0);
    expect(savedCfg.columns.length).toEqual(0);
  });
  it("Test sortBy and Asc", () => {
    const savedCfg = new SavedTableConfig();

    expect(savedCfg.sortBy).toEqual("");
    expect(savedCfg.asc).toBeTruthy();
  });
  it("set default value of sorter of table config", () => {
    let savedCfg = new SavedTableConfig({sortBy: "col1", asc: false});

    expect(savedCfg.sortBy).toEqual("col1");
    expect(savedCfg.asc).toBeFalsy();

    savedCfg = new SavedTableConfig({sortBy: "col1", asc: true});
    expect(savedCfg.sortBy).toEqual("col1");
    expect(savedCfg.asc).toBeTruthy();
  });

  it("auto assign id of savedFilter to be same as tableconfig Id", () => {
    let savedCfg = new SavedTableConfig({
      sortBy: "col1",
      asc: false,
      id: "id1",
      savedFilter: {name: "name1"},
    });

    expect(savedCfg.savedFilter?.id).toEqual("id1");
    savedCfg = new SavedTableConfig({
      sortBy: "col1",
      asc: false,
      id: "id1",
      savedFilter: {id: "id2"},
    });
    expect(savedCfg.savedFilter?.id).toEqual("id2");
  });

  it("Auto Generate ID if missing", () => {
    let savedCfg = new SavedTableConfig({
      sortBy: "col1",
      asc: false,
      savedFilter: {name: "name1"},
    });

    expect(savedCfg.id.length > 0).toBeTruthy();
    expect(savedCfg.savedFilter?.id).toEqual(savedCfg.id);
  });

  it("removeId", () => {
    let savedCfg = new SavedTableConfig({
      id: 123,
      columns: [],
      savedFilter: {
        id: 123,
        name: "name",
      },
    });

    expect(savedCfg.id).toEqual(123);
    expect(savedCfg.savedFilter?.id).toEqual(123);
    let tmp = savedCfg.removeId();

    expect(tmp.hasOwnProperty("id")).toBeFalsy();
    expect(tmp.savedFilter?.hasOwnProperty("id")).toBeFalsy();

    savedCfg = new SavedTableConfig({
      id: 123,
      columns: [],
      savedFilter: {
        name: "name",
      },
    });
    tmp = savedCfg.removeId();
    expect(tmp.hasOwnProperty("id")).toBeFalsy();
    expect(tmp.savedFilter?.hasOwnProperty("id")).toBeFalsy();
  });

  it("userId passed to savedFilter", () => {
    let savedCfg = new SavedTableConfig({
      id: 123,
      columns: [],
      savedFilter: {
        id: 123,
        name: "name",
      },
    });

    expect(savedCfg.savedFilter?.userId).toEqual(null);

    savedCfg = new SavedTableConfig({
      id: 123,
      columns: [],
      savedFilter: {
        id: 123,
        name: "name",
      },
      userId: "abc",
    });
    expect(savedCfg.savedFilter?.userId).toEqual("abc");
  });
});
