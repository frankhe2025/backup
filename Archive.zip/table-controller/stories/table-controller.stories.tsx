import TableControllerComponent from "../src/table-controller.component";
import getFilterConfigMock from "../../general-filter/src/mock/entities/filter_config.mock";
import {SavedTableConfig} from "../src/entities/saved-table-config";

const meta = {
  title: "ui/TableController",
  component: TableControllerComponent,
  tags: ["autodocs"],
};

export default meta;

const columns = [
  {key: "key1", title: "title1"},
  {key: "key2", title: "title2 Check"},
  {key: "key3", title: "title3"},
  {key: "key4", title: "title4"},
  {key: "key5", title: "title5"},
  {key: "key6", title: "title6"},
];

// @ts-ignore
const tableControllerConfig = {
  filterConfig: getFilterConfigMock(),
  columns: columns,
  defaultColumns: ["key1", "key2", "key3"],
  onSearch: (_cfg) => {
    // eslint-disable-next-line no-console
    console.log(_cfg);
  },
  onColumnChange: (_columns) => {
    // eslint-disable-next-line no-console
    console.log(_columns);
  },
  onSaveNewTableConfig: (_savedTableConfig: SavedTableConfig) => {
    // eslint-disable-next-line no-console
    console.log("save new config: ", _savedTableConfig);
  },
  onSavedTableConfigUpdated: (_cfg) => {
    // eslint-disable-next-line no-console
    console.log("Save table config updates: ", _cfg);
  },
  saveable: true,
  selfSaveable: true,
};

export const Primary = {
  args: tableControllerConfig,
};
