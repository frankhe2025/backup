# @aisera-ui/table-controller

A Quick description of the component

## Installation

```sh
yarn add @aisera-ui/table-controller
# or
npm i @aisera-ui/table-controller
# or
pnpm add @aisera-ui/table-controller
```