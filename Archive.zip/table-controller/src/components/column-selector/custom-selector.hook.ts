import {useState} from "react";

export function useCustomSelectorHook(defaultColumns: string[] = []) {
  const [selectedColumns, setSelectedColumns] = useState<string[]>(defaultColumns);
  const handler = {
    toggleColumn: (columnKey: string) => {
      setSelectedColumns((pre) =>
        pre.includes(columnKey) ? pre.filter((i) => i !== columnKey) : [...pre, columnKey],
      );
    },
  };

  return {selectedColumns, handler};
}
