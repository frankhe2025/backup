import {SavedFilter} from "../../../general-filter/src/entities/saved-filter";

interface SavedTableConfigData {
  id?: any;
  savedFilter?: any;
  columns?: string[];
  sortBy?: string;
  asc?: boolean;
  columnOrder?: string[];
  sortOrder?: {
    column: string;
    direction: "asc" | "desc" | "none";
  }[];
  userId?: string;
}

// This config meets UI requirements, but not in DB, DB is using entity_filter table
// but we need to reuse it to save table config
// so before calling API, we must pull out scope/name into first layer, and then save it
export class SavedTableConfig {
  id: any;
  savedFilter: SavedFilter | null;
  columns: string[];
  sortBy: string; // column to be sorted
  asc: boolean; //ascend or descend
  columnOrder: string[]; // order of columns
  sortOrder: {
    column: string;
    direction: "asc" | "desc" | "none";
  }[];
  userId?: string;

  constructor(data: SavedTableConfigData | null = null) {
    this.savedFilter = data?.savedFilter ? new SavedFilter(data.savedFilter, data.userId) : null;
    this.columns = data?.columns ? data.columns : [];
    this.sortBy = data?.sortBy ? data.sortBy : "";
    this.id = data?.id ?? "";
    this.columnOrder = data?.columnOrder ? data.columnOrder : [];
    this.userId = data?.userId ? data.userId : "";

    if (data?.sortOrder && data.sortOrder.length > 0) {
      this.sortOrder = data.sortOrder.map((item) => ({
        column: item.column,
        direction: item.direction,
      }));
    } else {
      this.sortOrder = [];
    }

    if (this.id && this.savedFilter && !this.savedFilter?.id) {
      // here, we need to pass the id to fitlerId so that we can match
      this.savedFilter.id = this.id;
    } else if (!this.id && this.savedFilter && !this.savedFilter?.id) {
      this.id = "" + Math.floor(Math.random() * 10000);
      this.savedFilter.id = this.id;
    }

    if (data && data.hasOwnProperty("asc")) {
      this.asc = data.asc as boolean;
    } else {
      this.asc = true;
    }

    if (this.sortBy && !this.sortOrder.length) {
      this.sortOrder = [
        {
          column: this.sortBy,
          direction: this.asc ? "asc" : "desc",
        },
      ];
    }
  }

  // Id is added for local dev only, and needs to be removed so as to avoid confusion on the DB
  removeId() {
    const tmp = new SavedTableConfig(this);

    delete tmp.id;
    tmp.savedFilter?.id && delete tmp.savedFilter?.id;

    return tmp;
  }
}
