import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { DemoModule } from './demo/demo.module';
import { EventsModule } from './events/events.module';

@Module({
    imports: [DemoModule, EventsModule],
    controllers: [AppController],
    providers: [AppService],
})
export class AppModule {}
