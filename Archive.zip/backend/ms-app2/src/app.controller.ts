import { Controller, Get, Post } from '@nestjs/common';
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get('route1')
  route1Get(): string {
    return 'route1 from app2 - Get';
  }

  @Post('route1')
  route1Post(): string {
    return 'route1 from app2 - Post';
  }

  @Get('route2')
  route2Get(): string {
    return 'route2 from app2 - Get';
  }

  @Post('route2')
  route2Post(): string {
    return 'route2 from app2 - Post';
  }
}
