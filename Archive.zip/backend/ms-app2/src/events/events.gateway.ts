import { MessageBody, SubscribeMessage, WebSocketGateway, WebSocketServer, WsResponse } from '@nestjs/websockets';
import { Server } from 'socket.io';
import { from, map, Observable } from 'rxjs';

@WebSocketGateway({
    cors: {
        origin: '*',
    },
})
export class EventsGateway {
    @WebSocketServer()
    server: Server;

    @SubscribeMessage('eventlist')
    findAll(@MessageBody() data: any): Observable<WsResponse<number>>{
        return from([1, 2, 3]).pipe(map(item => ({ event: 'eventlist', data: item })));
    }

    @SubscribeMessage('identity')
    findIdentity(@MessageBody() data: any): Observable<WsResponse<number>>{
        // return from([1, 2, 3]).pipe(map(item => ({ event: 'events', data: item })));
        return from([1, 2, 3]).pipe(map(item => ({ event: 'identity', data: item })));

    }
}
