import { Injectable } from '@nestjs/common';
import { DemoEntity } from './demo.entity';

@Injectable()
export class DemoService {
    getAll() {
        const entities: DemoEntity[] = [];
        for (let id = 0; id < 10; id++) {
            const firstName = 'firstName' + id;
            const lastName = 'lastName' + id;
            const userName = 'userName' + id;
            const createAt = new Date();
            entities.push(new DemoEntity({ id, firstName, lastName, userName, createAt }));
        }
        return entities;
    }
}
