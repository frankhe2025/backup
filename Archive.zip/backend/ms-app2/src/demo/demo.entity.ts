export class DemoEntity {
    id: number;
    firstName: string;
    lastName: string;
    userName: string;
    createdAt: Date;
    constructor(data) {
        this.id = data.id;
        this.firstName = data.firstName;
        this.lastName = data.lastName;
        this.userName = data.userName;
        this.createdAt = data.createdAt;
    }
}
