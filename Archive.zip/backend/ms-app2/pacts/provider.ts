import { NestFactory } from '@nestjs/core';
import { AppModule } from '../src/app.module';

const getPactServer = async () => {
    const app = await NestFactory.create(AppModule);
    return app;
};
export default getPactServer;
