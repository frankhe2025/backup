import * as path from 'path';
import { LogLevel } from '@nestjs/common';
import { Verifier } from '@pact-foundation/pact';
let port;
let opts;
const LOG_LEVEL = process.env.LOG_LEVEL || 'TRACE';
describe('Demo Test for Pact', () => {
    port = 3001;
    beforeAll(() => {
        opts = {
            provider: 'MF-App2 Provider',
            providerBaseUrl: 'http://localhost:8001',
            pactUrls: [path.resolve(process.cwd(), 'pacts/files/')],
            logLevel: LOG_LEVEL as LogLevel,
            // pactBrokerUrl: "",
            // pactBrokerUsername: "",
            // pactBrokerPassword: "",
            // publishVerificationResult: false,
            // providerVersionBranch: process.env.GIT_BRANCH ?? "master",
            // providerVersion: process.env.GIT_COMMIT ?? "1.0." + process.env.HOSTNAME,
            // consumerVersionSelectors: [
            //     { mainBranch: true },
            //     { deployedOrReleased: true }
            // ]
        };
    });

    it('should validate the expectations of all Demo APIS', () => {
        return new Verifier(opts)
            .verifyProvider()
            .then((output) => {
                console.log('Pact Verification Complete!');
                console.log(output);
            })
            .catch((e) => {
                console.error('Pact verification failed :(', e);
            });
    });
});
