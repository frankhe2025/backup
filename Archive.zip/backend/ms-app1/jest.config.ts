import type { Config } from 'jest';

const config: Config = {
    moduleFileExtensions: ['js', 'json', 'ts'],
    rootDir: '.',
    testEnvironment: 'node',
    testRegex: ['.e2e-spec.ts$', '.*\\.spec\\.ts$'],
    transform: {
        '^.+\\.(t|j)sx?$': 'ts-jest',
    },
    moduleNameMapper: {
        '^~/(.*)$': '<rootDir>/src/$1',
    },
    collectCoverageFrom: [
        '<rootDir>/src/**/*.{js,jsx,ts,tsx}',
        '!**/*.spec.{js,ts}',
        '!**/*.test.{js,ts}',
        '!<rootDir>/src/main.ts',
        '!<rootDir>/src/test-utils/**/*',
        '!<rootDir>/src/**/*.module.ts',
        '!<rootDir>/src/**/*.entity.ts',
        '!<rootDir>/src/common/schema/**/*',
    ],
    coverageDirectory: '<rootDir>/coverage',
    coverageReporters: ['clover', 'json', 'lcov', 'text-summary'],
    coverageThreshold: {
        global: {
            statements: 80,
            functions: 75,
            lines: 80,
        },
    },
};

export default config;
