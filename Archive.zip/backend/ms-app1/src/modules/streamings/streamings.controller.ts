import { Controller } from '@nestjs/common';
import { GrpcMethod, GrpcStreamMethod, GrpcStreamCall } from '@nestjs/microservices';
import { Observable, Subject } from 'rxjs';
import { Metadata, ServerDuplexStream } from '@grpc/grpc-js';
@Controller('streamings')
export class StreamingsController {
    @GrpcStreamMethod('StreamingService', 'getAnswer')
    getAnswer(messages: Observable<any>, metadata: Metadata, call: ServerDuplexStream<any, any>) {
        const subject = new Subject();
        const onNext = (message) => {
            console.log(message);
            subject.next({
                reply: 'your question is : ' + message.question,
            });
            // setTimeout(() => {
            //     onNext({ question: 'rande asdaf' });
            // }, 1000);

            sendResponse(10).subscribe((data) => {
                subject.next(data);
            });
        };
        const onComplete = () => {
            subject.next({
                reply: 'done',
            });
            subject.complete();
        };
        messages.subscribe({
            next: onNext,
            complete: onComplete,
        });
        return subject.asObservable();
    }
}

const sendResponse = (times: number) => {
    return new Observable((observer) => {
        let count = 0;
        const send = () => {
            setTimeout(() => {
                observer.next({
                    reply: 'Sreamed Reply is: Answer ' + count,
                });
                count++;
                if (count < times) {
                    send();
                } else {
                    observer.next({ reply: 'done' });
                }
            }, 1000);
        };
        send();
    });
};
