import { Module } from '@nestjs/common';
import { StreamingsController } from './streamings.controller';

@Module({
    controllers: [StreamingsController],
})
export class StreamingsModule {}
