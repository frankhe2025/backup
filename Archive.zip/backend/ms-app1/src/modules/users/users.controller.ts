import { Controller } from '@nestjs/common';
import {
  GrpcMethod,
  GrpcStreamMethod,
  GrpcStreamCall,
} from '@nestjs/microservices';
import { Observable, Subject } from 'rxjs';
import { Metadata, ServerDuplexStream } from '@grpc/grpc-js';
@Controller('users')
export class UsersController {
  @GrpcMethod('UserService', 'getUsers')
  getUsers() {
    console.log('reached ');

    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          users: [
            {
              id: 1,
              name: 'John',
            },
            {
              id: 2,
              name: 'Roger',
            },
          ],
        });
      }, 1000);
    });
  }

  @GrpcStreamMethod('UserService', 'ListOfGreetings')
  listOfGreetings(
    messages: Observable<any>,
    metadata: Metadata,
    call: ServerDuplexStream<any, any>,
  ) {
    const subject = new Subject();
    const onNext = (message) => {
      console.log(message);
      subject.next({
        reply: 'Hello, world! ' + message.greeting,
      });
    };

    const onComplete = () => subject.complete();
    messages.subscribe({
      next: onNext,
      complete: onComplete,
    });

    return subject.asObservable();
  }

  @GrpcStreamMethod('UserService', 'BidiHello')
  bidiHello(
    messages: Observable<any>,
    metadata: Metadata,
    call: ServerDuplexStream<any, any>,
  ): Observable<any> {
    const subject = new Subject();

    const onNext = (message) => {
      console.log(message);
      subject.next({
        reply: 'Hello, world! ' + message.greeting,
      });
    };
    const onComplete = () => {
      subject.next({
        reply: 'done',
      });
      subject.complete();
    };
    messages.subscribe({
      next: onNext,
      complete: onComplete,
    });

    return subject.asObservable();
  }
}
