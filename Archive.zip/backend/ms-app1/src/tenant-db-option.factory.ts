import { Injectable, Logger, Scope } from '@nestjs/common';
import { TypeOrmModuleOptions, TypeOrmOptionsFactory } from '@nestjs/typeorm';
import { Cacheable } from 'nestjs-cacheable';

@Injectable({ scope: Scope.REQUEST })
export class TenantDbOptionFactory implements TypeOrmOptionsFactory {
    private readonly logger = new Logger(TenantDbOptionFactory.name);

    constructor() {}

    createTypeOrmOptions(connectionName?: string): Promise<TypeOrmModuleOptions> | TypeOrmModuleOptions {
        return new Promise(async (resolve) => {
            // resolve(await this.getOptions(await this.authService.getTenantId()));
            //  resolve(await this.getOptions(1));
        });
    }

    @Cacheable({ key: (tenantId: number) => `tenant-db-name-${tenantId}`, ttl: 6000 })
    async getOptions(tenantId: number) {
        return {
            type: 'mariadb',
            host: 'localhost',
            port: '3309',
            username: 'root',
            password: '1234',
            database: 'tenantDBName',
            synchronize: false,
            autoLoadEntities: true,
        };
    }
}
