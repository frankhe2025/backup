import { Observable } from 'rxjs';

export interface UserService {
    getUsers({}): Observable<User[]>;
    listOfGreetings(upstream: Observable<HelloRequest>): Observable<HelloResponse>;
    bidiHello(upstream: Observable<HelloRequest>): Observable<HelloResponse>;
}

export interface StreamingService {
    getAnswer(upstream: Observable<QRequest>): Observable<QResponse>;
}
interface QRequest {
    question: string;
}
interface QResponse {
    reply: string;
}

export interface User {
    id: number;
    name: string;
    createdAt?: string;
    updatedAt?: string;
}

interface HelloRequest {
    greeting: string;
}
class HelloResponse {
    reply: string;
}

export interface HeroesService {
    findOne(heroById: HeroById): Observable<Hero>;
}

export interface HeroById {
    id: number;
}
export interface Hero {
    id: number;
    name: string;
}
