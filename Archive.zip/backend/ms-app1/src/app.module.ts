import { Module } from '@nestjs/common';
import { UsersModule } from './modules/users/users.module';
import { HeroesModule } from './modules/heroes/heroes.module';
import { ConfigModule } from '@nestjs/config';
import { StreamingsModule } from './modules/streamings/streamings.module';

@Module({
    imports: [UsersModule, HeroesModule, ConfigModule, StreamingsModule],
    controllers: [],
    providers: [],
})
export class AppModule {}
