import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { join } from 'path';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import process from 'process';
async function bootstrap() {
    const app = await NestFactory.createMicroservice<MicroserviceOptions>(AppModule, {
        transport: Transport.GRPC,
        options: {
            package: 'userproto',
            protoPath: join(__dirname, '../proto/protobuf/user.proto'),
            url: `0.0.0.0:50053`,
        },
    });
    await app.listen();
}
bootstrap();
