import { getDataSourceName, handleRetry, TypeOrmDataSourceFactory, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { EntitiesMetadataStorage } from '@nestjs/typeorm/dist/entities-metadata.storage';
import { TypeOrmCoreModule } from '@nestjs/typeorm/dist/typeorm-core.module';
import { createConnection } from 'mysql2';
import { defer, lastValueFrom } from 'rxjs';
import { DataSource, DataSourceOptions } from 'typeorm';
import { Logger } from '@nestjs/common';

const TYPEORM_DATASOURCE_CACHE = new Map<string, DataSource>();
const logger = new Logger('ms-app1');
const getDataSource = (token, options) => {
    let dataSource: any = TYPEORM_DATASOURCE_CACHE.get(token);
    if (!dataSource) {
        logger.debug(' creating connection');
        dataSource = (options: any) => {
            return DataSource === undefined ? createConnection(options) : new DataSource(options);
        };
        TYPEORM_DATASOURCE_CACHE.set(token, dataSource);
    }
    return dataSource;
};

// Solution is to overwrite TypeOrmCoreModule/createDataSourceFactory method to save connection time
// https://github.com/nestjs/typeorm/blob/36ccf21bb0200c3b1376cef20f6192fad19accc6/lib/typeorm-core.module.ts#L202

(TypeOrmCoreModule as any).createDataSourceFactory = async (
    options: TypeOrmModuleOptions,
    dataSourceFactory?: TypeOrmDataSourceFactory
): Promise<DataSource | null> => {
    const dataSourceToken = getDataSourceName(options as DataSourceOptions);
    const createTypeormDataSource = dataSourceFactory ?? getDataSource(dataSourceToken, options);

    return await lastValueFrom(
        defer(async () => {
            if (!options.autoLoadEntities) {
                const dataSource: any = await createTypeormDataSource(options as DataSourceOptions);
                // TODO: remove "dataSource.initialize" condition (left for backward compatibility)
                return (dataSource as any).initialize && !dataSource.isInitialized
                    ? dataSource.initialize()
                    : dataSource;
            }

            let entities = options.entities;
            if (Array.isArray(entities)) {
                entities = entities.concat(EntitiesMetadataStorage.getEntitiesByDataSource(dataSourceToken));
            } else {
                entities = EntitiesMetadataStorage.getEntitiesByDataSource(dataSourceToken);
            }
            const dataSource: any = await createTypeormDataSource({
                ...options,
                entities,
            } as DataSourceOptions);

            // TODO: remove "dataSource.initialize" condition (left for backward compatibility)
            return (dataSource as any).initialize && !dataSource.isInitialized ? dataSource.initialize() : dataSource;
        }).pipe(
            handleRetry(
                options.retryAttempts,
                options.retryDelay,
                dataSourceToken,
                options.verboseRetryLog,
                options.toRetry
            )
        )
    );
};
