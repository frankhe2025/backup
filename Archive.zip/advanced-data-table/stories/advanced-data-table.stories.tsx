import React, {useState, useEffect} from "react";
import {Meta, StoryObj} from "@storybook/react";

import {DataTableWithControls, DataTableWithControlsProps} from "../src";
import {DataTableColumn, DataTableConfiguration} from "../src/types";
import {FilterItem, FilterType} from "@aisera-ui/general-filter";

const meta: Meta<typeof DataTableWithControls> = {
  title: "ui/AdvancedDataTable",
  component: DataTableWithControls,
  argTypes: {
    data: {control: {type: "object"}},
    configuration: {control: {type: "object"}},
    filterItems: {control: {type: "object"}},
    defaultVisibleColumns: {control: {type: "object"}},
  },
};

export default meta;
type Story = StoryObj<typeof DataTableWithControls>;

const mockData = [
  {
    id: "1",
    name: "Amar Patel",
    email: "amar.patel@cortex.dev",
    role: "Developer",
    status: "Active",
    createdAt: "2023-01-15T08:00:00.000Z",
  },
  {
    id: "2",
    name: "Keisha Williams",
    email: "keisha.w@cortex.dev",
    role: "Designer",
    status: "Inactive",
    createdAt: "2023-02-20T10:30:00.000Z",
  },
  {
    id: "3",
    name: "Tariq Hassan",
    email: "tariq.h@cortex.dev",
    role: "Manager",
    status: "Active",
    createdAt: "2023-03-10T14:15:00.000Z",
  },
  {
    id: "4",
    name: "Zoe Chen",
    email: "zoe.chen@cortex.dev",
    role: "Developer",
    status: "Active",
    createdAt: "2023-04-05T09:45:00.000Z",
  },
  {
    id: "5",
    name: "Mateo Rodriguez",
    email: "mateo.r@cortex.dev",
    role: "Designer",
    status: "Inactive",
    createdAt: "2023-05-12T16:20:00.000Z",
  },
];

const defaultColumns: DataTableColumn[] = [
  {key: "name", title: "Name", sortable: true},
  {key: "email", title: "Email", sortable: true},
  {key: "role", title: "Role", sortable: true},
  {key: "status", title: "Status", sortable: true},
  {key: "createdAt", title: "Created At", type: "date", sortable: true},
];

const defaultConfiguration: DataTableConfiguration = {
  columns: defaultColumns,
  selectionMode: "multiple",
  onSelectionChange: (selectedKeys) => console.log("Selected:", selectedKeys),
  actions: {
    edit: {
      handler: (id) => console.log(`Edit ${id}`),
      icon: <span>✏️</span>,
      label: "Edit",
    },
    delete: {
      handler: (id) => console.log(`Delete ${id}`),
      icon: <span>🗑️</span>,
      label: "Delete",
    },
  },
  classNames: {
    base: "border-collapse",
    thead: "bg-gray-50",
    th: "bg-default-100 text-default-900 border-b border-divider font-semibold text-xs uppercase",
    td: "px-4 py-3 border-b border-divider",
  },
};

const filterItems = [
  new FilterItem({
    key: "name", 
    label: "Name", 
    type: FilterType.TEXT
  }),
  new FilterItem({
    key: "email", 
    label: "Email", 
    type: FilterType.TEXT
  }),
  new FilterItem({
    key: "role", 
    label: "Role", 
    type: FilterType.TEXT
  }),
  new FilterItem({
    key: "status", 
    label: "Status", 
    type: FilterType.SINGLE_SELECT,
    options: [
      {value: "Active", label: "Active"},
      {value: "Inactive", label: "Inactive"}
    ]
  }),
];

const Template = (args: DataTableWithControlsProps) => <DataTableWithControls {...args} />;

export const Default: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: defaultConfiguration,
    filterItems: filterItems,
    defaultVisibleColumns: ["name", "email", "role", "status", "createdAt"],
  },
};

export const WithoutActions: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: {
      ...defaultConfiguration,
      actions: undefined,
    },
    filterItems: filterItems,
    defaultVisibleColumns: ["name", "email", "role", "status", "createdAt"],
  },
};

export const SingleSelection: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: {
      ...defaultConfiguration,
      selectionMode: "single",
    },
    filterItems: filterItems,
    defaultVisibleColumns: ["name", "email", "role", "status"],
  },
};

export const NoSelection: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: {
      ...defaultConfiguration,
      selectionMode: "none",
    },
    filterItems: filterItems,
    defaultVisibleColumns: ["name", "email", "role", "status"],
  },
};

export const WithLimitedFilters: Story = {
  render: Template,
  args: {
    data: mockData,
    configuration: defaultConfiguration,
    filterItems: [
      new FilterItem({
        key: "name", 
        label: "Name", 
        type: FilterType.TEXT
      }),
      new FilterItem({
        key: "role", 
        label: "Role", 
        type: FilterType.SINGLE_SELECT,
        options: [
          {value: "Developer", label: "Developer"},
          {value: "Designer", label: "Designer"},
          {value: "Manager", label: "Manager"}
        ]
      }),
    ],
    defaultVisibleColumns: ["name", "email", "role", "status"],
  },
};

const InteractiveTemplate = (args: DataTableWithControlsProps) => {
  const [sortState, setSortState] = useState<
    {
      column: string;
      direction: "asc" | "desc" | "none";
    }[]
  >([]);

  const [columnOrderState, setColumnOrderState] = useState<string[]>([]);

  const [tableConfig, setTableConfig] = useState<DataTableConfiguration>({
    ...args.configuration,
  });

  const inspectSavedFilters = () => {
    const key = "storybook-test-table_NG-TABLE-CONFIG";
    const savedConfig = localStorage.getItem(key);

    if (savedConfig) {
      try {
        const parsedConfig = JSON.parse(savedConfig);

        console.log("Saved configs in localStorage:", parsedConfig);

        if (parsedConfig.savedTableConfigs && parsedConfig.savedTableConfigs.length > 0) {
          console.log("First saved config details:", parsedConfig.savedTableConfigs[0]);
          console.log("Sort order in saved config:", parsedConfig.savedTableConfigs[0].sortOrder);
        }
      } catch (error) {
        console.error("Error parsing localStorage data:", error);
      }
    } else {
      console.log("No saved configs found in localStorage");
    }
  };

  useEffect(() => {
    inspectSavedFilters();

    if (sortState.length > 0) {
      console.log("Sort state changed:", sortState);
      setTableConfig((prev) => {
        const newConfig = {
          ...prev,
          sortColumn: sortState[0].column,
          sortDirection: sortState[0].direction,
        };

        console.log(
          "Updated tableConfig with sort info:",
          newConfig.sortColumn,
          newConfig.sortDirection,
        );

        return newConfig;
      });
    }
  }, [sortState]);

  const handleSortOrderChange = (
    newSortOrder: {column: string; direction: "asc" | "desc" | "none"}[],
  ) => {
    console.log("Sort order changed:", newSortOrder);
    setSortState(newSortOrder);
  };

  const handleColumnOrderChange = (newColumnOrder: string[]) => {
    console.log("Column order changed: stories**", newColumnOrder);
    setColumnOrderState(newColumnOrder);
  };

  return (
    <div className="flex flex-col gap-4">
      <DataTableWithControls
        {...args}
        configuration={tableConfig}
        selfSaveable={true}
        tableName="storybook-test-table"
        onColumnOrderChange={handleColumnOrderChange}
        onSortOrderChange={handleSortOrderChange}
      />
    </div>
  );
};

export const WithFilterSaving: Story = {
  render: InteractiveTemplate,
  args: {
    data: mockData,
    configuration: {
      ...defaultConfiguration,
      sortColumn: "email",
      sortDirection: "asc",
    },
    filterItems: filterItems,
    defaultVisibleColumns: ["name", "email", "role", "status", "createdAt"],
  },
};
