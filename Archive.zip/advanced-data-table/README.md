# @aisera-ui/advanced-data-table

A Quick description of the component

## Installation

```sh
yarn add @aisera-ui/advanced-data-table
# or
npm i @aisera-ui/advanced-data-table
# or
pnpm add @aisera-ui/advanced-data-table
```