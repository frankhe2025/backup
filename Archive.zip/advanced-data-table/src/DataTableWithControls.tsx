import {useCallback, useEffect, useMemo, useRef, useState} from "react";
import TableControllerComponent, {
  TableControllerConfig,
  TableColumnConfig,
  SavedTableConfigs,
} from "@aisera-ui/table-controller";
import FilterConfig from "@aisera-ui/general-filter";
import {DataTableV2, SortDirection} from "@aisera-ui/data-table-v2";

import {DataTableWithControlsProps, FilterData} from "./types";

export const DataTableWithControls: React.FC<DataTableWithControlsProps> = ({
  data,
  configuration,
  filterItems = [],
  defaultVisibleColumns,
  onFilterChange,
  onColumnOrderChange,
  onSortOrderChange,
  tableName = "",
  selfSaveable = false,
  savedTableConfigs = [],
  onSaveNewTableConfig = null,
  onSavedTableConfigUpdated = null,
  currentUserId = null,
}) => {
  const dataRef = useRef<any[]>([]);
  const initialRenderRef = useRef(true);

  const [filteredData, setFilteredData] = useState<any[]>([]);

  const [visibleColumns, setVisibleColumns] = useState<string[]>(
    defaultVisibleColumns || configuration.columns.map((col) => col.key),
  );

  const [columnOrder, setColumnOrder] = useState<string[]>(
    configuration.columnOrder || configuration.columns.map((col) => col.key),
  );

  const [sortOrder, setSortOrder] = useState<
    {column: string; direction: "asc" | "desc" | "none"}[]
  >(() => {
    if (configuration.sortColumn && configuration.sortDirection) {
      return [
        {
          column: configuration.sortColumn,
          direction: configuration.sortDirection as "asc" | "desc" | "none",
        },
      ];
    }

    return [];
  });

  useEffect(() => {
    if (configuration.columnOrder && configuration.columnOrder.length > 0) {
      setColumnOrder(configuration.columnOrder);
    }

    if (configuration.sortColumn && configuration.sortDirection) {
      setSortOrder([
        {
          column: configuration.sortColumn,
          direction: configuration.sortDirection as "asc" | "desc" | "none",
        },
      ]);
    }
  }, [configuration.columnOrder, configuration.sortColumn, configuration.sortDirection]);

  const applyFilters = useCallback((sourceData: any[], filters: any) => {
    if (!sourceData || sourceData.length === 0) {
      console.log("No source data to filter");

      return [];
    }

    let finalFilters: FilterData[] | null = null;

    console.log("Filters: ***", filters);
    if (Array.isArray(filters)) {
      console.log("Filter is direct array format");
      finalFilters = filters;
    } else if (filters && filters.finalFilters && filters.finalFilters.length) {
      console.log("Filter has finalFilters property");
      finalFilters = filters.finalFilters;
    } else {
      console.log("No valid filters to apply");

      return sourceData;
    }

    if (!finalFilters || finalFilters.length === 0) {
      console.log("No filters to apply");

      return sourceData;
    }

    console.log("Found", finalFilters.length, "filters to apply");

    return sourceData.filter((item) => {
      for (const filter of finalFilters) {
        const key = filter.key;
        const value = filter.value;
        const operand = filter.operand || "Like";

        console.log(`Checking filter: ${key}=${value} (${operand})`);
        if (key === "GLOBAL_SEARCH_KEY") {
          if (!value || value === "") {
            continue;
          }

          const searchValue = String(value).toLowerCase();

          const visibleColumnKeys = configuration.columns
            .filter((col) => col.key && visibleColumns.includes(col.key))
            .map((col) => col.key);

          let hasMatch = false;
          let matchField = "";

          for (const columnKey of visibleColumnKeys) {
            let itemValue;
            const column = configuration.columns.find((col) => col.key === columnKey);

            if (column && typeof (column as any).getValue === "function") {
              try {
                itemValue = (column as any).getValue(item);
              } catch (e) {
                itemValue = item[columnKey];
              }
            } else {
              itemValue = item[columnKey];
            }

            if (itemValue !== undefined && itemValue !== null) {
              const stringValue = String(itemValue).toLowerCase();

              if (stringValue.includes(searchValue)) {
                hasMatch = true;
                matchField = columnKey;
                console.log(
                  `Match found in item ${
                    item.id || "unknown"
                  }, field ${columnKey}: "${stringValue}"`,
                );
                break;
              }
            }
          }

          if (!hasMatch) {
            return false;
          }

          continue;
        }

        if (
          !key ||
          value === undefined ||
          value === null ||
          (Array.isArray(value) && value.length === 0) ||
          value === ""
        ) {
          console.log(`Skipping empty filter ${key}=${value}`);
          continue;
        }

        const itemValue = item[key];

        console.log(`Item has ${key}="${itemValue}"`);

        if (itemValue === undefined || itemValue === null) {
          console.log(`Item has no ${key}, filter fails`);

          return false;
        }

        switch (operand) {
          case "Like":
            if (typeof itemValue === "string" && typeof value === "string") {
              const match = itemValue.toLowerCase().includes(value.toLowerCase());

              console.log(`Like comparison: "${itemValue}" includes "${value}" = ${match}`);
              if (!match) return false;
            } else if (String(itemValue) !== String(value)) {
              return false;
            }
            break;

          case "Equal":
            if (typeof itemValue === "string" && typeof value === "string") {
              const match = itemValue.toLowerCase() === value.toLowerCase();

              console.log(`Equal comparison: "${itemValue}" === "${value}" = ${match}`);
              if (!match) return false;
            } else if (itemValue !== value) {
              return false;
            }
            break;

          case "Include":
            if (Array.isArray(value)) {
              const match = Array.isArray(itemValue)
                ? itemValue.some((v) => value.includes(v))
                : value.includes(itemValue);

              console.log(`Include comparison: ${itemValue} in [${value}] = ${match}`);
              if (!match) return false;
            }
            break;

          case "Exclude":
            if (Array.isArray(value)) {
              const match = Array.isArray(itemValue)
                ? itemValue.some((v) => value.includes(v))
                : value.includes(itemValue);

              console.log(`Exclude comparison: ${itemValue} not in [${value}] = ${!match}`);
              if (match) return false;
            }
            break;

          case "Between":
            if (Array.isArray(value) && value.length >= 2) {
              const min = value[0];
              const max = value[1];
              let itemToCompare = itemValue;

              if (itemValue instanceof Date) {
                itemToCompare = itemValue.getTime();
              } else if (typeof itemValue === "string" && !isNaN(Date.parse(itemValue))) {
                itemToCompare = new Date(itemValue).getTime();
              }

              const match = itemToCompare >= min && itemToCompare <= max;

              console.log(`Between comparison: ${min} <= ${itemToCompare} <= ${max} = ${match}`);
              if (!match) return false;
            }
            break;

          case "Within":
            if (typeof value === "number") {
              const now = new Date().getTime();
              let itemTime;

              if (itemValue instanceof Date) {
                itemTime = itemValue.getTime();
              } else if (typeof itemValue === "number") {
                itemTime = itemValue;
              } else if (typeof itemValue === "string" && !isNaN(Date.parse(itemValue))) {
                itemTime = new Date(itemValue).getTime();
              } else {
                return false;
              }

              const match = now - itemTime <= value;

              console.log(`Within comparison: ${now} - ${itemTime} <= ${value} = ${match}`);
              if (!match) return false;
            }
            break;

          default:
            console.log(`Unknown operand ${operand}, using string comparison`);
            if (String(itemValue) !== String(value)) {
              return false;
            }
        }
      }

      return true;
    });
  }, []);

  const handleFilterChange = useCallback(
    (filters: any) => {
      console.log("Filter change in DataTableWithControls:", filters);

      const newFilteredData = applyFilters(data, filters);

      console.log(
        `Filtering result: ${data?.length || 0} items → ${newFilteredData?.length || 0} items`,
      );

      setFilteredData(newFilteredData);

      if (onFilterChange) {
        onFilterChange({
          ...filters,
          filteredData: newFilteredData,
        });
      }
    },
    [data, onFilterChange, applyFilters],
  );

  const handleColumnChange = useCallback((newVisibleColumns: string[]) => {
    setVisibleColumns(newVisibleColumns);
  }, []);

  const handleColumnOrderChange = useCallback(
    (newColumnOrder: string[]) => {
      console.log("Column order changed:", newColumnOrder);
      setColumnOrder(newColumnOrder);

      if (onColumnOrderChange) {
        onColumnOrderChange(newColumnOrder);
      }
    },
    [onColumnOrderChange],
  );

  const handleSortOrderChange = useCallback(
    (newSortOrder: {column: string; direction: "asc" | "desc" | "none"}[]) => {
      console.log("Sort order changed:", newSortOrder);
      setSortOrder(newSortOrder);

      if (onSortOrderChange) {
        onSortOrderChange(newSortOrder);
      }
    },
    [onSortOrderChange],
  );

  const handleDataTableSort = useCallback(
    (column: string, direction: SortDirection) => {
      const newSortOrder = [{column, direction}];

      console.log("DataTable sort changed:", newSortOrder, "Direction is:", direction);

      setSortOrder(newSortOrder);

      if (onSortOrderChange) {
        onSortOrderChange(newSortOrder);
      }
    },
    [onSortOrderChange],
  );

  const handleSaveNewTableConfig = (data) => {
    // this will be triggered when user click save as new, we need to call API
    console.log("saving single config: ", data);
    // Please add more into data here before send back to parent app for saving purpose
    if (onSaveNewTableConfig) {
      onSaveNewTableConfig(data);
    }
  };

  const handleSaveTableConfigUpdated = (data) => {
    // this will be triggered when multiple config are updated in a batch
    console.log("saving multiple congis: ", data);
    if (onSavedTableConfigUpdated) {
      onSavedTableConfigUpdated(data);
    }
  };

  const tableControllerConfig: TableControllerConfig = useMemo(() => {
    const config: TableControllerConfig = {
      filterConfig: new FilterConfig(),
      columns: [],
      defaultColumns: [],
      onSearch: handleFilterChange,
      onColumnChange: handleColumnChange,
      onColumnOrderChange: handleColumnOrderChange,
      onSortOrderChange: handleSortOrderChange,
      selfSaveable,
      tableName,
      initialColumnOrder: columnOrder,
      initialSortOrder: sortOrder,
      onSaveNewTableConfig: handleSaveNewTableConfig,
      onSavedTableConfigUpdated: handleSaveTableConfigUpdated,
      savedTableConfigs: new SavedTableConfigs(savedTableConfigs),
      currentUserId: currentUserId,
    };

    const filterConfig = new FilterConfig();

    filterConfig.filterItems = filterItems;

    filterConfig.defaultFilters = filterItems.slice(0, 2).map((item) => item.key);

    config.filterConfig = filterConfig;
    filterConfig.globalSearchable = true;

    config.columns = configuration.columns.map(
      (col) =>
        ({
          key: col.key,
          title: col.title,
        } as TableColumnConfig),
    );

    config.defaultColumns = visibleColumns;

    return config;
  }, [
    configuration.columns,
    filterItems,
    visibleColumns,
    handleFilterChange,
    handleColumnChange,
    handleColumnOrderChange,
    handleSortOrderChange,
    selfSaveable,
    tableName,
    columnOrder,
    sortOrder,
  ]);

  useEffect(() => {
    if (initialRenderRef.current) {
      initialRenderRef.current = false;

      return;
    }

    const hasDataChanged = dataRef.current !== data;

    if (hasDataChanged) {
      dataRef.current = data;

      setFilteredData(data);
    } else if (filteredData.length === 0 && data.length > 0) {
      setFilteredData(data);
    }
  }, [data]);

  const filteredConfiguration = useMemo(() => {
    const visibleColumnsSet = new Set(visibleColumns);

    return {
      ...configuration,
      columns: configuration.columns.filter((col) => visibleColumnsSet.has(col.key)),
      sortColumn: sortOrder.length > 0 ? sortOrder[0].column : undefined,
      sortDirection: sortOrder.length > 0 ? (sortOrder[0].direction as SortDirection) : undefined,
      columnOrder: columnOrder,
      onSortChange: handleDataTableSort,
      onColumnOrderChange: handleColumnOrderChange,
      actions: configuration.actions,
    };
  }, [
    configuration,
    visibleColumns,
    sortOrder,
    columnOrder,
    handleDataTableSort,
    handleColumnOrderChange,
  ]);

  return (
    <div className="flex flex-col gap-2">
      {(filterItems.length > 0 || defaultVisibleColumns) && (
        <TableControllerComponent {...tableControllerConfig} />
      )}

      <DataTableV2 configuration={filteredConfiguration} data={filteredData} />
    </div>
  );
};
