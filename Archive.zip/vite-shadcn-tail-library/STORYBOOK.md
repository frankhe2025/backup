# Storybook Setup

This project has been configured with Storybook for component development and documentation.

## Getting Started

### Running Storybook

To start the Storybook development server:

```bash
pnpm storybook
```

This will start Storybook on `http://localhost:6006`

### Building Storybook

To build Storybook for production:

```bash
pnpm build-storybook
```

## Project Structure

- `.storybook/` - Storybook configuration files
  - `main.ts` - Main configuration file
  - `preview.ts` - Preview configuration with global styles
- `src/components/ui/**/*.stories.tsx` - Component stories

## Available Stories

### Button Component
- **Location**: `src/components/ui/button/Button.stories.tsx`
- **Variants**: Primary, Secondary, Outline
- **Sizes**: Small, Medium, Large
- **States**: Default, Disabled

### Input Component
- **Location**: `src/components/ui/input.stories.tsx`
- **Types**: Text, Email, Password, Number, Tel, URL
- **States**: Default, Disabled, With Value

## Creating New Stories

To create a story for a new component:

1. Create a `.stories.tsx` file next to your component
2. Import the component and necessary types
3. Define the meta object with component metadata
4. Create story objects for different variants/states

Example:

```tsx
import type { Meta, StoryObj } from '@storybook/react';
import { YourComponent } from './YourComponent';

const meta: Meta<typeof YourComponent> = {
  title: 'UI/YourComponent',
  component: YourComponent,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    // Define controls for your props
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    // Default props
  },
};
```

## Features

- **Auto-documentation**: Components with `tags: ['autodocs']` will automatically generate documentation
- **Interactive controls**: Use the Controls panel to modify component props in real-time
- **Responsive design**: Test components at different viewport sizes
- **Accessibility**: Built-in accessibility testing and guidelines
- **Tailwind CSS**: Full support for Tailwind CSS classes

## Tips

- Use the `layout: 'centered'` parameter for better component presentation
- Add `tags: ['autodocs']` to automatically generate documentation
- Use the `argTypes` to create interactive controls for your component props
- Test different states and variants of your components
- Use the Actions panel to test event handlers 