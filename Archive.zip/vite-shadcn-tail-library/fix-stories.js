import fs from 'fs';

const storyFiles = [
  'src/components/ui/calendar.stories.tsx',
  'src/components/ui/card.stories.tsx',
  'src/components/ui/input.stories.tsx',
  'src/components/ui/breadcrumb.stories.tsx',
  'src/components/ui/button.stories.tsx',
  'src/components/ui/separator.stories.tsx',
  'src/components/ui/switch.stories.tsx',
  'src/components/ui/alert.stories.tsx',
  'src/components/ui/aspect-ratio.stories.tsx',
  'src/components/ui/checkbox.stories.tsx',
  'src/components/ui/dialog.stories.tsx',
  'src/components/ui/avatar.stories.tsx',
  'src/components/ui/accordion.stories.tsx',
  'src/components/ui/select.stories.tsx',
  'src/components/ui/textarea.stories.tsx',
  'src/components/ui/tabs.stories.tsx',
  'src/components/ui/toggle.stories.tsx',
  'src/components/ui/label.stories.tsx',
  'src/components/ui/progress.stories.tsx',
  'src/components/ui/skeleton.stories.tsx',
  'src/components/ui/pagination.stories.tsx',
  'src/components/ui/table.stories.tsx',
  'src/components/ui/slider.stories.tsx',
  'src/components/ui/badge.stories.tsx',
  'src/components/ui/alert-dialog.stories.tsx'
];

function fixStoryFile(filePath) {
  if (!fs.existsSync(filePath)) {
    console.log(`File not found: ${filePath}`);
    return;
  }

  let content = fs.readFileSync(filePath, 'utf8');

  // Add a closing brace and semicolon before every 'export const' that is not already preceded by one
  let newContent = content.replace(/(?<![};\n])\n(?=export const )/g, '\n};\n');

  // Remove all 'as StoryObj;' and 'as StoryObj;;'
  newContent = newContent.replace(/\s*as StoryObj;{1,2}/g, '');

  // Fix JSX attributes with extra closing braces: value={25}} -> value={25}
  newContent = newContent.replace(/(\w+)=\{([^}]+)\}\}/g, '$1={$2}');

  // Fix JSX attributes with extra closing braces in arrays: [30]} -> [30]
  newContent = newContent.replace(/(\[[^\]]+\])\}/g, '$1');

  // Add missing type annotations: export const StoryName = { -> export const StoryName: Story = {
  newContent = newContent.replace(/export const (\w+) = \{/g, 'export const $1: Story = {');

  // Fix missing closing braces for objects that end with JSX
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix broken template literals in JSX: {value[0]% -> {value[0]}%
  newContent = newContent.replace(/\{([^}]+)%/g, '{$1}%');

  // Fix broken template literals in JSX: ${value[0] - ${value[1] -> ${value[0]} - ${value[1]}
  newContent = newContent.replace(/\$\{([^}]+) - \$\{([^}]+)/g, '${$1} - ${$2}');

  // Fix broken template literals in JSX: {value[0]°C -> {value[0]}°C
  newContent = newContent.replace(/\{([^}]+)°C/g, '{$1}°C');

  // Fix missing closing braces for useState type definitions
  newContent = newContent.replace(/useState<\{([^}]+)\}>\(\);/g, 'useState<{$1}>();');

  // Fix missing closing braces for objects that end with JSX and have no comma
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix broken JSX closing tags that have extra parentheses
  newContent = newContent.replace(/>\s*\)\s*,?\s*\n\s*\)\s*,?\s*\n\s*\}\s*$/gm, '>');

  // Fix broken object structures: }} else { -> } else {
  newContent = newContent.replace(/\}\}\s*else\s*\{/g, '} else {');

  // Fix broken object structures: }}, -> },
  newContent = newContent.replace(/\}\},/g, '},');

  // Fix broken object structures: }}; -> };
  newContent = newContent.replace(/\}\};/g, '};');

  // Remove any trailing semicolons after object literals
  newContent = newContent.replace(/};\s*\n/g, '}\n');

  // Fix missing closing braces for objects that end with JSX
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix missing closing braces for objects that end with JSX and have no comma
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix missing closing braces for story objects that end with JSX
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix missing closing braces for story objects that end with JSX and have no comma
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix missing closing braces for story objects that end with JSX and have no comma
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix missing closing braces for story objects that end with JSX and have no comma
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix missing closing braces for story objects that end with JSX and have no comma
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix missing closing braces for story objects that end with JSX and have no comma
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  // Fix missing closing braces for story objects that end with JSX and have no comma
  newContent = newContent.replace(/(\s*\/>\s*)\n(\s*export const)/g, '$1\n  },\n$2');

  if (newContent !== content) {
    fs.writeFileSync(filePath, newContent, 'utf8');
    console.log(`Fixed: ${filePath}`);
  } else {
    console.log(`No changes needed: ${filePath}`);
  }
}

console.log('Adding missing closing braces and semicolons to all story files...');
storyFiles.forEach(fixStoryFile);
console.log('Done!'); 