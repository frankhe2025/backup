import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import { Avatar, AvatarImage, AvatarFallback } from './avatar'

vi.mock('@/lib/utils', () => ({
  cn: (...classes: (string | undefined | null | false)[]) => classes.filter(Boolean).join(' ')
}))

describe('Avatar', () => {
  it('renders Avatar root with data-slot and class', () => {
    render(<Avatar data-testid="avatar" className="custom">A</Avatar>)
    const avatar = screen.getByTestId('avatar')
    expect(avatar).toBeInTheDocument()
    expect(avatar).toHaveAttribute('data-slot', 'avatar')
    expect(avatar).toHaveClass('custom')
    expect(avatar).toHaveTextContent('A')
  })

  it('renders AvatarImage with data-slot and class', () => {
    render(<AvatarImage data-testid="img" className="img-class" alt="avatar" />)
    const img = screen.getByTestId('img')
    expect(img).toBeInTheDocument()
    expect(img).toHaveAttribute('data-slot', 'avatar-image')
    expect(img).toHaveClass('img-class')
  })

  it('renders AvatarFallback with data-slot and class', () => {
    render(<AvatarFallback data-testid="fallback" className="fb-class">F</AvatarFallback>)
    const fallback = screen.getByTestId('fallback')
    expect(fallback).toBeInTheDocument()
    expect(fallback).toHaveAttribute('data-slot', 'avatar-fallback')
    expect(fallback).toHaveClass('fb-class')
    expect(fallback).toHaveTextContent('F')
  })
}) 