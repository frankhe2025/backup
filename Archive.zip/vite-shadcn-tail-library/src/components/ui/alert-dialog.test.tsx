import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import {
  AlertDialog,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
} from './alert-dialog'

vi.mock('@/lib/utils', () => ({
  cn: (...classes: (string | undefined | null | false)[]) => classes.filter(Boolean).join(' ')
}))
vi.mock('./button', () => ({
  buttonVariants: () => 'btn',
}))

describe('AlertDialog', () => {
  it('renders root with data-slot', () => {
    render(<AlertDialog data-testid="root">Dialog</AlertDialog>)
    const root = screen.getByTestId('root')
    expect(root).toBeInTheDocument()
    expect(root).toHaveAttribute('data-slot', 'alert-dialog')
  })

  it('renders trigger with data-slot', () => {
    render(<AlertDialogTrigger data-testid="trigger">Open</AlertDialogTrigger>)
    const trigger = screen.getByTestId('trigger')
    expect(trigger).toBeInTheDocument()
    expect(trigger).toHaveAttribute('data-slot', 'alert-dialog-trigger')
  })

  it('renders portal with data-slot', () => {
    render(<AlertDialogPortal data-testid="portal">Portal</AlertDialogPortal>)
    const portal = screen.getByTestId('portal')
    expect(portal).toBeInTheDocument()
    expect(portal).toHaveAttribute('data-slot', 'alert-dialog-portal')
  })

  it('renders overlay with correct class and data-slot', () => {
    render(<AlertDialogOverlay data-testid="overlay" className="custom" />)
    const overlay = screen.getByTestId('overlay')
    expect(overlay).toBeInTheDocument()
    expect(overlay).toHaveAttribute('data-slot', 'alert-dialog-overlay')
    expect(overlay).toHaveClass('custom')
  })

  it('renders content with correct class and data-slot', () => {
    render(<AlertDialogContent data-testid="content" className="custom">Content</AlertDialogContent>)
    const content = screen.getByTestId('content')
    expect(content).toBeInTheDocument()
    expect(content).toHaveAttribute('data-slot', 'alert-dialog-content')
    expect(content).toHaveClass('custom')
    expect(content).toHaveTextContent('Content')
  })

  it('renders header and footer with correct class and data-slot', () => {
    render(
      <>
        <AlertDialogHeader data-testid="header" className="header">Header</AlertDialogHeader>
        <AlertDialogFooter data-testid="footer" className="footer">Footer</AlertDialogFooter>
      </>
    )
    const header = screen.getByTestId('header')
    const footer = screen.getByTestId('footer')
    expect(header).toBeInTheDocument()
    expect(header).toHaveAttribute('data-slot', 'alert-dialog-header')
    expect(header).toHaveClass('header')
    expect(footer).toBeInTheDocument()
    expect(footer).toHaveAttribute('data-slot', 'alert-dialog-footer')
    expect(footer).toHaveClass('footer')
  })

  it('renders title and description with correct class and data-slot', () => {
    render(
      <>
        <AlertDialogTitle data-testid="title" className="title">Title</AlertDialogTitle>
        <AlertDialogDescription data-testid="desc" className="desc">Desc</AlertDialogDescription>
      </>
    )
    const title = screen.getByTestId('title')
    const desc = screen.getByTestId('desc')
    expect(title).toBeInTheDocument()
    expect(title).toHaveAttribute('data-slot', 'alert-dialog-title')
    expect(title).toHaveClass('title')
    expect(desc).toBeInTheDocument()
    expect(desc).toHaveAttribute('data-slot', 'alert-dialog-description')
    expect(desc).toHaveClass('desc')
  })

  it('renders action and cancel with button classes', () => {
    render(
      <>
        <AlertDialogAction data-testid="action" className="action">Action</AlertDialogAction>
        <AlertDialogCancel data-testid="cancel" className="cancel">Cancel</AlertDialogCancel>
      </>
    )
    const action = screen.getByTestId('action')
    const cancel = screen.getByTestId('cancel')
    expect(action).toBeInTheDocument()
    expect(action).toHaveClass('btn')
    expect(action).toHaveClass('action')
    expect(cancel).toBeInTheDocument()
    expect(cancel).toHaveClass('btn')
    expect(cancel).toHaveClass('cancel')
  })
}) 