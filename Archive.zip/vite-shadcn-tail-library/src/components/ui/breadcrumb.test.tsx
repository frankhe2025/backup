import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator,
  BreadcrumbEllipsis,
} from './breadcrumb'

vi.mock('@/lib/utils', () => ({
  cn: (...classes: (string | undefined | null | false)[]) => classes.filter(Boolean).join(' ')
}))

describe('Breadcrumb', () => {
  it('renders nav with data-slot', () => {
    render(<Breadcrumb data-testid="nav">Nav</Breadcrumb>)
    const nav = screen.getByTestId('nav')
    expect(nav).toBeInTheDocument()
    expect(nav).toHaveAttribute('data-slot', 'breadcrumb')
    expect(nav).toHaveAttribute('aria-label', 'breadcrumb')
    expect(nav).toHaveTextContent('Nav')
  })

  it('renders list with data-slot and class', () => {
    render(<BreadcrumbList data-testid="list" className="custom">List</BreadcrumbList>)
    const list = screen.getByTestId('list')
    expect(list).toBeInTheDocument()
    expect(list).toHaveAttribute('data-slot', 'breadcrumb-list')
    expect(list).toHaveClass('custom')
    expect(list).toHaveTextContent('List')
  })

  it('renders item with data-slot and class', () => {
    render(<BreadcrumbItem data-testid="item" className="custom">Item</BreadcrumbItem>)
    const item = screen.getByTestId('item')
    expect(item).toBeInTheDocument()
    expect(item).toHaveAttribute('data-slot', 'breadcrumb-item')
    expect(item).toHaveClass('custom')
    expect(item).toHaveTextContent('Item')
  })

  it('renders link with data-slot and class', () => {
    render(<BreadcrumbLink data-testid="link" className="custom">Link</BreadcrumbLink>)
    const link = screen.getByTestId('link')
    expect(link).toBeInTheDocument()
    expect(link).toHaveAttribute('data-slot', 'breadcrumb-link')
    expect(link).toHaveClass('custom')
    expect(link).toHaveTextContent('Link')
  })

  it('renders page with data-slot, role, and class', () => {
    render(<BreadcrumbPage data-testid="page" className="custom">Page</BreadcrumbPage>)
    const page = screen.getByTestId('page')
    expect(page).toBeInTheDocument()
    expect(page).toHaveAttribute('data-slot', 'breadcrumb-page')
    expect(page).toHaveAttribute('role', 'link')
    expect(page).toHaveAttribute('aria-disabled', 'true')
    expect(page).toHaveAttribute('aria-current', 'page')
    expect(page).toHaveClass('custom')
    expect(page).toHaveTextContent('Page')
  })

  it('renders separator with data-slot and custom children', () => {
    render(<BreadcrumbSeparator data-testid="sep">/</BreadcrumbSeparator>)
    const sep = screen.getByTestId('sep')
    expect(sep).toBeInTheDocument()
    expect(sep).toHaveAttribute('data-slot', 'breadcrumb-separator')
    expect(sep).toHaveAttribute('role', 'presentation')
    expect(sep).toHaveAttribute('aria-hidden', 'true')
    expect(sep).toHaveTextContent('/')
  })

  it('renders ellipsis with data-slot and icon', () => {
    render(<BreadcrumbEllipsis data-testid="ellipsis" className="custom" />)
    const ellipsis = screen.getByTestId('ellipsis')
    expect(ellipsis).toBeInTheDocument()
    expect(ellipsis).toHaveAttribute('data-slot', 'breadcrumb-ellipsis')
    expect(ellipsis).toHaveAttribute('role', 'presentation')
    expect(ellipsis).toHaveAttribute('aria-hidden', 'true')
    expect(ellipsis).toHaveClass('custom')
    expect(ellipsis.querySelector('svg')).toBeInTheDocument()
    expect(ellipsis).toHaveTextContent('More')
  })
}) 