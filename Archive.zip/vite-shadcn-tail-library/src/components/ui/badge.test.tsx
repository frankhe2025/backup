import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import { Badge } from './badge'

vi.mock('@/lib/utils', () => ({
  cn: (...classes: (string | undefined | null | false)[]) => classes.filter(Boolean).join(' ')
}))
vi.mock('class-variance-authority', () => ({
  cva: () => () => 'badge-base',
}))

describe('Badge', () => {
  it('renders with data-slot and class', () => {
    render(<Badge data-testid="badge" className="custom">Badge</Badge>)
    const badge = screen.getByTestId('badge')
    expect(badge).toBeInTheDocument()
    expect(badge).toHaveAttribute('data-slot', 'badge')
    expect(badge).toHaveClass('custom')
    expect(badge).toHaveClass('badge-base')
    expect(badge).toHaveTextContent('Badge')
  })

  it('renders asChild as anchor', () => {
    render(
      <Badge asChild data-testid="badge-link">
        <a href="#">Link</a>
      </Badge>
    )
    const badge = screen.getByTestId('badge-link')
    expect(badge.tagName).toBe('A')
    expect(badge).toHaveAttribute('data-slot', 'badge')
    expect(badge).toHaveTextContent('Link')
  })
}) 