import { render, screen } from '@testing-library/react'
import { describe, it, expect } from 'vitest'
import { AspectRatio } from './aspect-ratio'

describe('AspectRatio', () => {
  it('renders with data-slot', () => {
    render(<AspectRatio data-testid="aspect">Content</AspectRatio>)
    const aspect = screen.getByTestId('aspect')
    expect(aspect).toBeInTheDocument()
    expect(aspect).toHaveAttribute('data-slot', 'aspect-ratio')
    expect(aspect).toHaveTextContent('Content')
  })
}) 