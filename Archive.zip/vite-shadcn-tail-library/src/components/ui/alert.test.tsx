import { render, screen } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import { Alert, AlertTitle, AlertDescription } from './alert'

// Mock the utils function
vi.mock('@/lib/utils', () => ({
  cn: (...classes: (string | undefined | null | false)[]) => classes.filter(Boolean).join(' ')
}))

// Mock class-variance-authority
vi.mock('class-variance-authority', () => ({
  cva: (base: string, _opts: any) => {
    return ({ variant }: { variant?: string }) => {
      if (!variant || variant === 'default') return base + ' bg-card text-card-foreground'
      if (variant === 'destructive') return base + ' text-destructive bg-card'
      return base
    }
  }
}))

describe('Alert', () => {
  it('renders with default variant and role', () => {
    render(
      <Alert data-testid="alert">Hello</Alert>
    )
    const alert = screen.getByTestId('alert')
    expect(alert).toBeInTheDocument()
    expect(alert).toHaveAttribute('role', 'alert')
    expect(alert).toHaveAttribute('data-slot', 'alert')
    expect(alert).toHaveTextContent('Hello')
    expect(alert.className).toMatch(/bg-card/)
    expect(alert.className).toMatch(/text-card-foreground/)
  })

  it('renders with destructive variant', () => {
    render(
      <Alert data-testid="alert" variant="destructive">Danger</Alert>
    )
    const alert = screen.getByTestId('alert')
    expect(alert).toBeInTheDocument()
    expect(alert.className).toMatch(/text-destructive/)
    expect(alert.className).toMatch(/bg-card/)
  })

  it('applies custom className', () => {
    render(
      <Alert data-testid="alert" className="custom-class">Custom</Alert>
    )
    const alert = screen.getByTestId('alert')
    expect(alert).toHaveClass('custom-class')
  })

  it('renders AlertTitle with correct class and slot', () => {
    render(
      <Alert>
        <AlertTitle data-testid="alert-title">Title</AlertTitle>
      </Alert>
    )
    const title = screen.getByTestId('alert-title')
    expect(title).toBeInTheDocument()
    expect(title).toHaveAttribute('data-slot', 'alert-title')
    expect(title.className).toMatch(/font-medium/)
    expect(title).toHaveTextContent('Title')
  })

  it('renders AlertDescription with correct class and slot', () => {
    render(
      <Alert>
        <AlertDescription data-testid="alert-desc">Description</AlertDescription>
      </Alert>
    )
    const desc = screen.getByTestId('alert-desc')
    expect(desc).toBeInTheDocument()
    expect(desc).toHaveAttribute('data-slot', 'alert-description')
    expect(desc.className).toMatch(/text-muted-foreground/)
    expect(desc).toHaveTextContent('Description')
  })

  it('renders children and nested elements', () => {
    render(
      <Alert data-testid="alert">
        <AlertTitle>Title</AlertTitle>
        <AlertDescription>
          <p>Paragraph</p>
          <span>Extra</span>
        </AlertDescription>
      </Alert>
    )
    const alert = screen.getByTestId('alert')
    expect(alert).toHaveTextContent('Title')
    expect(alert).toHaveTextContent('Paragraph')
    expect(alert).toHaveTextContent('Extra')
  })
}) 