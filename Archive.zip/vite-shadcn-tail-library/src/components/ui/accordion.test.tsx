import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from './accordion'

// Simple mock for the utils function
vi.mock('@/lib/utils', () => ({
  cn: (...classes: (string | undefined | null | false)[]) => classes.filter(Boolean).join(' ')
}))

describe('Accordion', () => {
  it('renders accordion root with correct props', () => {
    render(
      <Accordion type="single" data-testid="accordion" className="custom-class">
        <AccordionItem value="item-1">
          <AccordionTrigger>Trigger 1</AccordionTrigger>
          <AccordionContent>Content 1</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const accordion = screen.getByTestId('accordion')
    expect(accordion).toBeInTheDocument()
    expect(accordion).toHaveAttribute('data-slot', 'accordion')
  })

  it('renders accordion item with correct styling', () => {
    render(
      <Accordion type="single">
        <AccordionItem value="item-1" data-testid="accordion-item" className="custom-item-class">
          <AccordionTrigger>Trigger 1</AccordionTrigger>
          <AccordionContent>Content 1</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const item = screen.getByTestId('accordion-item')
    expect(item).toBeInTheDocument()
    expect(item).toHaveAttribute('data-slot', 'accordion-item')
    expect(item).toHaveClass('border-b', 'last:border-b-0', 'custom-item-class')
  })

  it('renders accordion trigger with correct styling and icon', () => {
    render(
      <Accordion type="single">
        <AccordionItem value="item-1">
          <AccordionTrigger data-testid="accordion-trigger" className="custom-trigger-class">
            Test Trigger
          </AccordionTrigger>
          <AccordionContent>Content 1</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const trigger = screen.getByTestId('accordion-trigger')
    expect(trigger).toBeInTheDocument()
    expect(trigger).toHaveAttribute('data-slot', 'accordion-trigger')
    expect(trigger).toHaveClass('custom-trigger-class')
    expect(trigger).toHaveTextContent('Test Trigger')

    // Check for chevron icon
    const chevronIcon = trigger.querySelector('svg')
    expect(chevronIcon).toBeInTheDocument()
    expect(chevronIcon).toHaveClass('text-muted-foreground', 'pointer-events-none', 'size-4', 'shrink-0')
  })

  it('renders accordion content with correct styling', () => {
    render(
      <Accordion type="single" defaultValue="item-1">
        <AccordionItem value="item-1">
          <AccordionTrigger>Trigger 1</AccordionTrigger>
          <AccordionContent data-testid="accordion-content" className="custom-content-class">
            Test Content
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const content = screen.getByTestId('accordion-content')
    expect(content).toBeInTheDocument()
    expect(content).toHaveAttribute('data-slot', 'accordion-content')
    expect(content).toHaveClass('data-[state=closed]:animate-accordion-up', 'data-[state=open]:animate-accordion-down', 'overflow-hidden', 'text-sm')
    expect(content).toHaveTextContent('Test Content')
  })

  it('handles trigger click to expand/collapse content', () => {
    render(
      <Accordion type="single" collapsible>
        <AccordionItem value="item-1">
          <AccordionTrigger data-testid="accordion-trigger">Trigger 1</AccordionTrigger>
          <AccordionContent data-testid="accordion-content">Content 1</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const trigger = screen.getByTestId('accordion-trigger')
    const content = screen.getByTestId('accordion-content')

    // Initially content should be collapsed
    expect(content).toHaveAttribute('data-state', 'closed')

    // Click trigger to expand
    fireEvent.click(trigger)
    
    // Content should now be expanded
    expect(content).toHaveAttribute('data-state', 'open')
  })

  it('supports multiple accordion items', () => {
    render(
      <Accordion type="multiple">
        <AccordionItem value="item-1">
          <AccordionTrigger data-testid="trigger-1">Trigger 1</AccordionTrigger>
          <AccordionContent data-testid="content-1">Content 1</AccordionContent>
        </AccordionItem>
        <AccordionItem value="item-2">
          <AccordionTrigger data-testid="trigger-2">Trigger 2</AccordionTrigger>
          <AccordionContent data-testid="content-2">Content 2</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    expect(screen.getByTestId('trigger-1')).toBeInTheDocument()
    expect(screen.getByTestId('trigger-2')).toBeInTheDocument()
    expect(screen.getByTestId('content-1')).toBeInTheDocument()
    expect(screen.getByTestId('content-2')).toBeInTheDocument()
  })

  it('applies disabled state correctly', () => {
    render(
      <Accordion type="single">
        <AccordionItem value="item-1">
          <AccordionTrigger data-testid="accordion-trigger" disabled>
            Disabled Trigger
          </AccordionTrigger>
          <AccordionContent>Content 1</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const trigger = screen.getByTestId('accordion-trigger')
    expect(trigger).toBeDisabled()
    expect(trigger).toHaveClass('disabled:pointer-events-none', 'disabled:opacity-50')
  })

  it('handles keyboard interactions', () => {
    render(
      <Accordion type="single">
        <AccordionItem value="item-1">
          <AccordionTrigger data-testid="accordion-trigger">Trigger 1</AccordionTrigger>
          <AccordionContent data-testid="accordion-content">Content 1</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const trigger = screen.getByTestId('accordion-trigger')
    
    // Test Enter key
    fireEvent.keyDown(trigger, { key: 'Enter', code: 'Enter' })
    
    // Test Space key
    fireEvent.keyDown(trigger, { key: ' ', code: 'Space' })
  })

  it('applies focus styles correctly', () => {
    render(
      <Accordion type="single">
        <AccordionItem value="item-1">
          <AccordionTrigger data-testid="accordion-trigger">Trigger 1</AccordionTrigger>
          <AccordionContent>Content 1</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const trigger = screen.getByTestId('accordion-trigger')
    expect(trigger).toHaveClass('focus-visible:border-ring', 'focus-visible:ring-ring/50', 'focus-visible:ring-[3px]')
  })

  it('rotates chevron icon when accordion is open', () => {
    render(
      <Accordion type="single" collapsible defaultValue="item-1">
        <AccordionItem value="item-1">
          <AccordionTrigger data-testid="accordion-trigger">Trigger 1</AccordionTrigger>
          <AccordionContent>Content 1</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const trigger = screen.getByTestId('accordion-trigger')
    
    // When open, trigger should have rotation class for the chevron
    expect(trigger).toHaveClass('[&[data-state=open]>svg]:rotate-180')
  })

  it('passes through additional props to root component', () => {
    const onValueChange = vi.fn()
    
    render(
      <Accordion 
        type="single"
        data-testid="accordion" 
        onValueChange={onValueChange}
        defaultValue="item-1"
      >
        <AccordionItem value="item-1">
          <AccordionTrigger>Trigger 1</AccordionTrigger>
          <AccordionContent>Content 1</AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    const accordion = screen.getByTestId('accordion')
    expect(accordion).toBeInTheDocument()
  })

  it('handles complex content with nested elements', () => {
    render(
      <Accordion type="single" defaultValue="item-1">
        <AccordionItem value="item-1">
          <AccordionTrigger>Complex Trigger</AccordionTrigger>
          <AccordionContent>
            <div data-testid="nested-content">
              <h3>Nested Title</h3>
              <p>Nested paragraph</p>
              <ul>
                <li>List item 1</li>
                <li>List item 2</li>
              </ul>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    )

    expect(screen.getByTestId('nested-content')).toBeInTheDocument()
    expect(screen.getByText('Nested Title')).toBeInTheDocument()
    expect(screen.getByText('Nested paragraph')).toBeInTheDocument()
    expect(screen.getByText('List item 1')).toBeInTheDocument()
    expect(screen.getByText('List item 2')).toBeInTheDocument()
  })
}) 