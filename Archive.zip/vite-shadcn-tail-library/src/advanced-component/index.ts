import TestComp from './test-comp/test-comp.component';

export { TestComp };