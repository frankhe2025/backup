import { render, screen } from '@testing-library/react'
import { describe, it, expect } from 'vitest'
import TestComp from './test-comp.component'

describe('TestComp', () => {
  it('renders the component with correct text content', () => {
    render(<TestComp />)
    const testElement = screen.getByText('Test')
    expect(testElement).toBeInTheDocument()
  })

  it('renders with correct CSS classes', () => {
    render(<TestComp />)
    const testElement = screen.getByText('Test')
    expect(testElement).toHaveClass('text-2xl')
    expect(testElement).toHaveClass('accent-blue-700')
  })

  it('renders as a div element', () => {
    render(<TestComp />)
    const testElement = screen.getByText('Test')
    expect(testElement.tagName).toBe('DIV')
  })

  it('has the expected styling applied', () => {
    render(<TestComp />)
    const testElement = screen.getByText('Test')
    
    // Check that the element has the expected classes
    expect(testElement.className).toContain('text-2xl')
    expect(testElement.className).toContain('accent-blue-700')
  })

  it('renders consistently across multiple renders', () => {
    const { rerender } = render(<TestComp />)
    
    // First render
    expect(screen.getByText('Test')).toBeInTheDocument()
    
    // Re-render
    rerender(<TestComp />)
    expect(screen.getByText('Test')).toBeInTheDocument()
    
    // Verify the element still has the same classes
    const testElement = screen.getByText('Test')
    expect(testElement).toHaveClass('text-2xl')
    expect(testElement).toHaveClass('accent-blue-700')
  })

  it('can be rendered within other components', () => {
    render(
      <div data-testid="container">
        <TestComp />
        <span>Additional content</span>
      </div>
    )
    
    const container = screen.getByTestId('container')
    expect(container).toBeInTheDocument()
    expect(container).toHaveTextContent('Test')
    expect(container).toHaveTextContent('Additional content')
  })
}) 