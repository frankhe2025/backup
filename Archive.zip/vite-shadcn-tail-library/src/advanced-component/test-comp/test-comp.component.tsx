import {Button} from "@/components";
import './test-comp.component.scss'
const TestComp = () => {
    return <div className={'text-2xl accent-red-600 txtCls'}>
        Test
        <div className="smaller">Small</div>
        <Button>Hello</Button>
    </div>
}
export default TestComp;