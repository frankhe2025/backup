import type { Meta, StoryObj } from '@storybook/react';
import TestComp from './test-comp.component';

const meta: Meta<typeof TestComp> = {
  title: 'Advanced Components/TestComp',
  component: TestComp,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    // Since TestComp doesn't accept props currently, we'll document the component behavior
  },
};

export default meta;
type Story = StoryObj<typeof TestComp>;

export const Default: Story = {
  render: () => <TestComp />,
};

export const WithCustomStyling: Story = {
  render: () => (
    <div className="space-y-4">
      <TestComp />
      <div className="text-sm text-gray-600">
        This component displays "Test" with text-2xl styling and blue accent color
      </div>
    </div>
  ),
};

export const InContext: Story = {
  render: () => (
    <div className="p-8 bg-gray-100 rounded-lg">
      <h2 className="text-lg font-semibold mb-4">Component in Context</h2>
      <TestComp />
      <p className="mt-4 text-sm text-gray-600">
        The TestComp component is displayed above with its default styling
      </p>
    </div>
  ),
};

export const MultipleInstances: Story = {
  render: () => (
    <div className="space-y-4">
      <div className="flex gap-4 items-center">
        <TestComp />
        <TestComp />
        <TestComp />
      </div>
      <p className="text-sm text-gray-600">
        Multiple instances of TestComp component
      </p>
    </div>
  ),
}; 