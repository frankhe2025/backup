import './App.css'
import {Button} from "@/components/ui/button";
import {Input} from "@/components/ui/input";

function App() {

  return (
    <>
      <div className={'font-bold text-red-500'}>
          Hello World
          <Button>Hello</Button>
          <Input/>
      </div>
    </>
  )
}

export default App
