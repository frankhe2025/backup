import { Injectable, NestMiddleware } from '@nestjs/common';
import { createProxyMiddleware } from 'http-proxy-middleware';
import * as process from 'process';
import { ConfigService } from '@nestjs/config';
import { AuthService } from '../service/auth.service';

@Injectable()
export class HttpProxyMiddleware implements NestMiddleware {
    constructor(private configService: ConfigService, private authService: AuthService) {}
    private getProxy = (req: any, res: any, next: any) => {
        const target = this.generateTarget(req);
        return createProxyMiddleware({
            target: target,
            pathRewrite: (path, req) => {
                return path.replace('/' + this.getServiceName(req), '');
            },
            secure: false,
            on: {
                proxyReq: (proxyReq, req, res) => {
                    console.log(`[MiddleWare]: Proxying ${req.method} request made to '${target}' - '${req.url}'`);
                },
            },
        });
    };

    private generateTarget(req) {
        const url = this.configService.get(this.getServiceName(req).toUpperCase() + '_SVC_URL');
        const port = this.configService.get(this.getServiceName(req).toUpperCase() + '_SVC_PORT');
        return url + ':' + port;
    }

    private getServiceName(req): string {
        let url = req.url;
        if (url.startsWith('/')) {
            url = url.substring(1);
        }
        const urlParts = url.split('/');
        return urlParts[0];
    }

    use(req: any, res: any, next: any) {
        this.authService.verify(req);
        this.getProxy(req, res, next)(req, res, next);
    }
}
