import { Injectable, UnauthorizedException } from '@nestjs/common';

@Injectable()
export class AuthService {
    verify(req: Request) {
        const headers = req.headers;
        console.log(headers);

        //throw new UnauthorizedException('Error happened');
    }
}
