import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Logger } from 'nestjs-pino';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import rateLimit from 'express-rate-limit';

async function bootstrap() {
    const app = await NestFactory.create(AppModule, { bufferLogs: true, bodyParser: false });
    app.useLogger(app.get(Logger));
    app.enableCors({ origin: '*' });

    // Rate limiting middleware
    const limiter = rateLimit({
        windowMs: 15 * 60 * 1000, // 15 minutes
        max: 100, // limit each IP to 100 requests per windowMs
    });
    app.use(limiter);

    const config = new DocumentBuilder()
        .setTitle('API Gateway')
        .setDescription('API Gateway API description')
        .setVersion('1.0')
        .addTag('api-gateway')
        .build();
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('api', app, document);

    await app.listen(process.env.PORT);
}
bootstrap();
