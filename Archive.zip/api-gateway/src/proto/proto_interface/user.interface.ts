import { Observable } from 'rxjs';

export interface StreamingService {
    getAnswer(upstream: Observable<QRequest>): Observable<QResponse>;
}
export interface QRequest {
    question: string;
}
export interface QResponse {
    reply: string;
}

export interface UserService {
    getUsers({}): Observable<User[]>;
    bidiHello(upstream: Observable<HelloRequest>): Observable<HelloResponse>;
    listOfGreetings(upstream: Observable<HelloRequest>): Observable<HelloResponse>;
}
export interface User {
    id: number;
    name: string;
    createdAt?: string;
    updatedAt?: string;
}

export interface HelloRequest {
    greeting: string;
}
export class HelloResponse {
    reply: string;
}

export interface HeroesService {
    findOne(heroById: HeroById): Observable<Hero>;
}

export interface HeroById {
    id: number;
}
export interface Hero {
    id: number;
    name: string;
}
