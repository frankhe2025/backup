import { Body, Controller, Get, Inject, Next, OnModuleInit, Post, Req, Res, Sse, UseGuards } from '@nestjs/common';
import { ClientGrpc } from '@nestjs/microservices';
import {
    HelloRequest,
    HeroesService,
    QRequest,
    QResponse,
    StreamingService,
    UserService,
} from '../proto/proto_interface/user.interface';
import { ApiOperation, ApiQuery, ApiTags } from '@nestjs/swagger';
import { Observable, fromEvent, map, ReplaySubject } from 'rxjs';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { AuthGuard } from '../service/auth.guard';
@Controller('app1')
@ApiTags('APP1 Related')
export class App1Controller implements OnModuleInit {
    private userService: UserService;
    private heroService: HeroesService;
    private streamingService: StreamingService;
    constructor(@Inject('APP1_GRPC_PACKAGE') private client: ClientGrpc, private eventEmitter: EventEmitter2) {}
    onModuleInit(): any {
        this.userService = this.client.getService<UserService>('UserService');
        this.heroService = this.client.getService<HeroesService>('HeroesService');
        this.streamingService = this.client.getService<StreamingService>('StreamingService');
    }

    @Get('/all')
    @ApiOperation({ summary: 'Demo API', description: 'this is a demo for getting all users' })
    @ApiQuery({
        name: 'names',
        description: 'name for Route1',
        type: String,
        allowEmptyValue: true,
    })
    async getAllUsers() {
        const results = this.userService.getUsers({});
        results.subscribe((value) => {
            console.log('received: ', value);
        });
        return this.userService.getUsers({});
    }
    @Get('/heroes')
    getHeroes() {
        return this.heroService.findOne({ id: 1 });
    }
    @Get('/greetings')
    async greeting() {
        const helloRequest$ = new ReplaySubject<HelloRequest>();
        let rsp = await helloRequest$.next({ greeting: 'Hello (1)!' });

        setTimeout(async () => {
            rsp = await helloRequest$.next({ greeting: 'Hello (2)!' });
            console.log(rsp);
            helloRequest$.complete();
        }, 1000);

        return this.userService.listOfGreetings(helloRequest$);
    }

    @Get('/bidihello')
    async bidiHello() {
        const helloRequest$ = new ReplaySubject<HelloRequest>();

        helloRequest$.next({ greeting: 'Hello (1)!' });
        helloRequest$.next({ greeting: 'Hello (2)!' });
        helloRequest$.complete();
        //return this.userService.bidiHello(helloRequest$);
        this.userService.bidiHello(helloRequest$).subscribe((resp) => {
            console.log('resp is;', resp);
            if (resp.reply === 'done') {
                console.log('stope it');
            }
        });
    }

    // https://www.iliabedian.com/blog/server-side-events-on-nestjs-emitting-events-to-clients
    @Sse('/sse')
    @UseGuards(AuthGuard)
    async sse(): Promise<Observable<MessageEvent>> {
        this.getAnswer();
        // @ts-ignore
        return fromEvent(this.eventEmitter, 'sse.event').pipe(
            map((payload) => ({
                data: JSON.stringify(payload),
            }))
        );
    }

    getAnswer() {
        const questionRequest$ = new ReplaySubject<QRequest>();
        questionRequest$.next({ question: 'question one 1' });

        const responseOb = this.streamingService.getAnswer(questionRequest$);
        responseOb.subscribe((resp: QResponse) => {
            this.eventEmitter.emit('sse.event', {
                message: resp.reply,
            });
            if (resp.reply === 'done') {
                questionRequest$.complete();
            }
        });
    }
}
