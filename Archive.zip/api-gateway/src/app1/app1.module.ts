import { Module } from '@nestjs/common';
import { LoggerModule } from 'nestjs-pino';
import { App1Controller } from './app1.controller';
import { join } from 'path';
import { ClientsModule, Transport } from '@nestjs/microservices';
import * as process from 'process';
import { ConfigModule } from '@nestjs/config';
import { AuthGuard } from '../service/auth.guard';
import { AuthService } from '../service/auth.service';
@Module({
    imports: [
        ConfigModule.forRoot(), // must load this first, and then can access PORT below
        LoggerModule.forRoot({
            pinoHttp: {
                safe: true,
            },
        }),
        ClientsModule.register([
            {
                name: 'APP1_GRPC_PACKAGE',
                transport: Transport.GRPC,
                options: {
                    url: 'localhost:' + process.env.APP1_SVC_PORT,
                    package: 'userproto',
                    protoPath: join(__dirname, '../proto/protobuf/app1/user.proto'),
                },
            },
        ]),
    ],
    controllers: [App1Controller],
    providers: [AuthGuard, AuthService],
})
export class App1Module {}
