import { MiddlewareConsumer, Module, NestModule, RequestMethod } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { LoggerModule } from 'nestjs-pino';
import { App1Module } from './app1/app1.module';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { WebsocketProxyMiddleware } from './middleware/websocket-proxy.middleware';
import { HttpProxyMiddleware } from './middleware/http-proxy.middleware';
import { AuthService } from './service/auth.service';

@Module({
    imports: [
        ConfigModule.forRoot({ isGlobal: true }),
        LoggerModule.forRoot({ pinoHttp: { safe: true } }),
        EventEmitterModule.forRoot(),
        App1Module,
    ],
    controllers: [],
    providers: [AuthService, HttpProxyMiddleware, WebsocketProxyMiddleware],
    exports: [],
})
export class AppModule implements NestModule {
    constructor(private configService: ConfigService) {}

    configure(consumer: MiddlewareConsumer): any {
        const microServicesToBeProxied: string[] = this.configService.get('MS_PROXIES').split(',');
        microServicesToBeProxied.forEach((msName: string) => {
            consumer
                .apply(WebsocketProxyMiddleware)
                .forRoutes({ path: msName + '_websocket/*', method: RequestMethod.ALL });
            consumer.apply(HttpProxyMiddleware).forRoutes({ path: msName + '/*', method: RequestMethod.ALL });
        });
    }
}
