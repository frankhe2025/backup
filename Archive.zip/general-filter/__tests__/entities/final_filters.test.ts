import FinalFilters, {FilterOperand, FinalFilter} from "../../src/entities/final_filters";
import FilterItem, {FilterType} from "../../src/entities/filter_item";
import FilterConfig, {GLOBAL_SEARCH_KEY} from "../../src/entities/filter_config";

describe("FinalFilters", () => {
  let filters;

  beforeEach(() => {
    filters = new FinalFilters([
      {
        key: "key1",
        operand: FilterOperand.Equal,
        value: "a",
      },
      {
        key: "key2",
        operand: FilterOperand.Include,
        value: ["a", "b"],
      },
      {
        key: "key3",
        operand: FilterOperand.Within,
        value: "1d",
      },
      {
        key: "key4",
        operand: FilterOperand.Between,
        value: [1741046400000, 1741305600000],
      },
    ]);
  });

  it("construct with another same object", () => {
    const newFinalFilters = new FinalFilters(filters);

    expect(newFinalFilters.finalFilters.length).toEqual(filters.finalFilters.length);
  });

  it("getStandardOutput()", () => {
    const out = filters.getStandardOutput();

    expect(out.length).toEqual(4);
    expect(out[0].operand).toEqual("Equal");
    expect(out[1].operand).toEqual("Include");
    expect(out[1].value).toEqual(["a", "b"]);
    expect(typeof out[2].value).toEqual("number");

    expect(out[3].value.length).toEqual(2);
    expect(typeof out[3].value[0]).toEqual("number");
    expect(typeof out[3].value[1]).toEqual("number");
  });

  it("upsertFinalFilterOperandAndValue", () => {
    let filterItem = new FilterItem({
      key: "key1",
    });

    filters.upsertFinalFilterOperandAndValue(filterItem, FilterOperand.LIKE, "A1");
    expect(filters.finalFilters[0].operand).toEqual("Like");
    expect(filters.finalFilters[0].value).toEqual("A1");

    filterItem = new FilterItem({
      key: "key10",
    });
    filters.upsertFinalFilterOperandAndValue(filterItem, FilterOperand.Equal, "A10");
    expect(filters.finalFilters.length).toEqual(5);
    expect(filters.finalFilters[4].value).toEqual("A10");
  });

  it("upsertFinalFilterOperand", () => {
    let filterItem = new FilterItem({
      key: "key1",
    });

    filters.upsertFinalFilterOperand(filterItem, FilterOperand.LIKE);
    expect(filters.finalFilters[0].operand).toEqual("Like");

    filterItem = new FilterItem({
      key: "key10",
    });
    filters.upsertFinalFilterOperandAndValue(filterItem, FilterOperand.Equal, "A10");
    expect(filters.finalFilters[4].operand).toEqual("Equal");
  });

  it("upsertFinalFilterValue()", () => {
    let filterItem = new FilterItem({
      key: "key1",
    });

    filters.upsertFinalFilterValue(filterItem, "A10");
    expect(filters.finalFilters[0].value).toEqual("A10");

    filterItem = new FilterItem({
      key: "key3",
      type: FilterType.MULTI_SELECT,
    });
    filters.upsertFinalFilterValue(filterItem, "A10");
    expect(filters.finalFilters[2].value).toEqual(["A10"]);

    filterItem = new FilterItem({
      key: "key30",
      type: FilterType.MULTI_SELECT,
    });
    filters.upsertFinalFilterValue(filterItem, "A10");
    expect(filters.finalFilters[4].value).toEqual(["A10"]);
  });

  it("getFilterValue()", () => {
    let filterItem = new FilterItem({
      key: "key1",
    });

    expect(filters.getFilterValue(filterItem)).toEqual("a");
    filterItem = new FilterItem({
      key: "key10",
      type: FilterType.MULTI_SELECT,
    });
    expect(filters.getFilterValue(filterItem)).toEqual([]);
    filterItem = new FilterItem({
      key: "key100",
      type: FilterType.SINGLE_SELECT,
    });
    expect(filters.getFilterValue(filterItem)).toEqual("");
  });

  it("getFilterValueAsDateRange()", () => {
    let filterItem = new FilterItem({
      key: "key4",
    });

    const res = filters.getFilterValueAsDateRange(filterItem);

    expect(Object.keys(res).length).toBe(2);
  });

  it("updateFinalFiltersWithFilterConfig", () => {
    const cfg = new FilterConfig({defaultFilters: "['key1', 'key2', 'key3' ]"});

    filters.updateFinalFiltersWithFilterConfig(cfg);
    expect(filters.finalFilters.length).toEqual(3);
  });

  it("updateFinalFiltersWithFilterConfig-GLOBAL FIlters", () => {
    const cfg = new FilterConfig({defaultFilters: "['key1' ]"});

    filters.finalFilters.push(
      new FinalFilter({
        key: GLOBAL_SEARCH_KEY,
        operand: "LIKE",
      }),
    );
    filters.updateFinalFiltersWithFilterConfig(cfg);

    expect(filters.finalFilters.length).toEqual(2);
  });
});
