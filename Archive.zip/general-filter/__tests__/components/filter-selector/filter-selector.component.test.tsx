import {render, screen} from "@testing-library/react";

import getFilterConfigMock from "../../../src/mock/entities/filter_config.mock";
import FinalFilters from "../../../src/entities/final_filters";
import FilterSelectorComponent from "../../../src/components/filter-selector/filter-selector.component";
import FilterConfig from "../../../src/entities/filter_config";

const props: any = {
  filterConfig: new FilterConfig(getFilterConfigMock()),
  setFilterConfig: () => {},
  finalFilters: new FinalFilters(),
  setFinalFilters: () => {},
};

describe("FilterSelectorComponent", () => {
  it("should render", async () => {
    render(<FilterSelectorComponent {...props} />);
    const btn = await screen.findByRole("button");

    expect(btn).toBeInTheDocument();
    btn.click();
    const checkboxes = await screen.findAllByTestId("filter-selector-checkbox");

    expect(checkboxes.length).toEqual(4);
  });
});
