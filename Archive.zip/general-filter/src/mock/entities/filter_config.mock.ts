const getFilterConfigMock = () => {
  return {
    filterItems: [
      {
        key: "key1",
        label: "Label 1",
        type: "SINGLE_SELECT",
        options: [
          {value: "option1", label: "Option 1"},
          {value: "option2", label: "Option 2"},
          {value: "option3", label: "Option 3"},
          {value: "option4", label: "Option 4"},
        ],
      },
      {
        key: "key2",
        label: "Label 2",
        type: "MULTI_SELECT",
        options: [
          {value: "option1", label: "Option 1"},
          {value: "option2", label: "Option 2"},
          {value: "option3", label: "Option 3"},
          {value: "option4", label: "Option 4"},
        ],
      },
      {
        key: "key3",
        label: "Label 3",
        options: [
          {value: "24h", label: "Last 24 Hours"},
          {value: "48h", label: "Last 48 Hours"},
          {value: "72h", label: "Last 72 Hours"},
          {value: "7d", label: "Last 7 days"},
          {value: "30d", label: "Last 30 days"},
          {value: "3m", label: "Last 3 Months"},
          {value: "6m", label: "Last 6 Months"},
          {value: "12m", label: "Last 12 Months"},
        ],
        type: "DATE",
      },
      // {
      //   key: "key4",
      //   label: "Label 4",
      //   type: "DATETIME",
      // },
      {
        key: "key5",
        label: "Label 5",
        type: "TEXT",
      },
      // {
      //   key: "key6",
      //   label: "Label 6",
      //   type: "NUMERIC",
      // },
    ],
    defaultFilters: ["key2", "key5"],
    saveable: true,
  };
};

export default getFilterConfigMock;
