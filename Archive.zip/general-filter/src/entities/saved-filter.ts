import FinalFilters, {FinalFilter} from "./final_filters";
import FilterItem from "./filter_item";

export enum SavedFilterScope {
  public = "public",
  private = "private",
}
export class SavedFilter {
  id: any; // This id is used to map SavedTableConfig, as this is not saved separately, we need to have way to find it from table config
  name: string;
  scope: SavedFilterScope | string;
  finalFilters: FinalFilters | null;
  userId: any;
  constructor(data: any = null, userId: any = null) {
    this.id = data?.id ?? "";
    this.name = data?.name ?? "";
    this.scope = data?.scope ?? SavedFilterScope.private;
    this.finalFilters = data?.finalFilters ? new FinalFilters(data.finalFilters) : null;
    if (userId) {
      this.userId = userId;
    } else if (data?.userId) {
      this.userId = data.userId;
    } else {
      this.userId = null;
    }
  }

  // we only need to remove the items from saved filter,
  // no need to add back as we are now showing in UI, so user can not add back
  toggleFinalFiltersWithFilterItem(filterItem: FilterItem) {
    let bExist = false;

    if (!this.finalFilters?.finalFilters) return;
    for (let i: any = this.finalFilters?.finalFilters?.length - 1; i >= 0; i--) {
      if (this.finalFilters?.finalFilters[i].key == filterItem.key) {
        bExist = true;
        this.finalFilters.finalFilters.splice(i, 1);
      }
    }
    if (!bExist) {
      // new we add empty filter
      const newFinalFilter = new FinalFilter({
        key: filterItem.key,
      });

      this.finalFilters?.finalFilters.push(newFinalFilter);
    }
  }

  isFilterItemSelected(filterItem: FilterItem) {
    //to check if filterItem passed is already included in the filter or not
    return this.finalFilters?.isFilterItemIncluded(filterItem);
  }

  clone() {
    return new SavedFilter({
      id: this.id,
      name: this.name,
      scope: this.scope,
      finalFilters: this.finalFilters,
    });
  }
}
