import FilterItem, {FilterType} from "./filter_item";
import {SavedFilter} from "./saved-filter";

export const GLOBAL_SEARCH_KEY = "GLOBAL_SEARCH_KEY";
class FilterConfig {
  filterItems: FilterItem[];
  defaultFilters: string[];
  globalSearchable: boolean;

  constructor(config?) {
    this.filterItems = [];
    this.defaultFilters = config?.defaultFilters || [];
    this.globalSearchable = true;
    if (config?.filterItems) {
      config.filterItems.forEach((item) => {
        this.filterItems.push(new FilterItem(item));
      });
    }
    if (config?.hasOwnProperty("globalSearchable")) {
      this.globalSearchable = config.globalSearchable;
    }
  }

  get filterItemsInUse() {
    const shownFilters = this.filterItems.filter((item) => this.defaultFilters.includes(item.key));

    return this._enrichWithGlobalSearch(shownFilters);
  }

  _enrichWithGlobalSearch(filters) {
    //Special handling, if globalSearchable is enabled, we then add one automatically
    if (this.globalSearchable) {
      filters.unshift(
        new FilterItem({
          key: GLOBAL_SEARCH_KEY,
          label: "Global Search",
          type: FilterType.TEXT,
        }),
      );
    }

    return filters;
  }

  // Here if saved filter is not there, then we return default ones
  // otherwise, we return the items from savedFilters
  getAllFiltersInUseWithSaveFilterConfig(savedFilter: SavedFilter | null = null) {
    if (!savedFilter || savedFilter.finalFilters?.finalFilters.length === 0) {
      // we show default filteritems
      return this.filterItemsInUse;
    } else {
      const savedFilterItemKeys = savedFilter.finalFilters?.finalFilters.map(
        (filter) => filter.key,
      );

      if (savedFilterItemKeys) {
        const shownFilters = this.filterItems.filter((item) =>
          savedFilterItemKeys.includes(item.key),
        );

        return this._enrichWithGlobalSearch(shownFilters);
      } else {
        return this.filterItemsInUse;
      }
    }
  }

  get clone() {
    const inst = new FilterConfig();

    inst.filterItems = this.filterItems;
    inst.defaultFilters = this.defaultFilters;

    return inst;
  }

  isFilterItemInUse(filterItem: FilterItem) {
    return this.defaultFilters.includes(filterItem.key);
  }

  toggleDefaultFilters(filterItem: FilterItem) {
    if (this.isFilterItemInUse(filterItem)) {
      this.defaultFilters.splice(this.defaultFilters.indexOf(filterItem.key), 1);
    } else {
      this.defaultFilters.push(filterItem.key);
    }

    return this;
  }
}

export default FilterConfig;
