import {CalendarDate, DateFormatter, parseDate} from "@internationalized/date";

import FilterItem, {FilterType} from "./filter_item";
import FilterConfig, {GLOBAL_SEARCH_KEY} from "./filter_config";

export interface DateRangeValue {
  start: CalendarDate;
  end: CalendarDate;
}

export enum FilterOperand {
  Include = "Include",
  Exclude = "Exclude",
  Equal = "Equal",
  Between = "Between",
  Within = "Within",
  LIKE = "Like",
}

const convertToCalendarDateFromTimeStamp = (ts: number): CalendarDate => {
  const date = new Date(ts);

  return parseDate(date.toISOString().split("T")[0]); // Converts YYYY-MM-DD string to CalendarDate
};

export class FinalFilter {
  key: string;
  operand: FilterOperand | string;
  value: any;

  constructor(filter) {
    this.key = "";
    this.operand = FilterOperand.Equal;
    this.value = "";
    if (filter) {
      this.key = filter.key || "";
      this.operand = filter.operand || FilterOperand.Equal;
      this.value = filter.value || "";
    }
  }

  get isEmpty() {
    return (
      this.value === null ||
      this.value === "" ||
      (Array.isArray(this.value) && this.value.length === 0)
    );
  }

  filterBetweenDays() {
    return (
      this.operand === FilterOperand.Between && Array.isArray(this.value) && this.value.length > 0
    );
  }
  filterWithinDay() {
    return this.operand === FilterOperand.Within && this.value.toLocaleString().includes("d");
  }
  filterWithinMonth() {
    return this.operand === FilterOperand.Within && this.value.toLocaleString().includes("m");
  }
  filterWithinHour() {
    return this.operand === FilterOperand.Within && this.value.toLocaleString().includes("h");
  }
  // This is to show in select component, and using [] to show multiple values
  getDisplayedTitle() {
    if (this.operand == FilterOperand.Equal || this.operand === FilterOperand.LIKE) {
      return this.value;
    }

    if (this.filterBetweenDays()) {
      const formatter = new DateFormatter("en-US", {
        dateStyle: "short", // Options: "short", "medium", "long", "full"
      });
      const start = new Date(this.value[0]);
      const end = new Date(this.value[1]);

      return (
        FilterOperand.Between + " " + formatter.format(start) + " and " + formatter.format(end)
      );
    }

    let unit = "";
    let num = 1;

    if (this.filterWithinDay()) {
      num = Number(this.value.substring(0, this.value.toLowerCase().indexOf("d")));
      unit = num + (num > 1 ? " Days" : " Day");

      return FilterOperand.Within + " " + unit;
    }

    if (this.filterWithinMonth()) {
      num = Number(this.value.substring(0, this.value.toLowerCase().indexOf("m")));
      unit = num + (num > 1 ? " Months" : " Month");

      return FilterOperand.Within + " " + unit;
    }

    if (this.filterWithinHour()) {
      num = Number(this.value.substring(0, this.value.toLowerCase().indexOf("h")));
      unit = num + (num > 1 ? " Hours" : " Hour");

      return FilterOperand.Within + " " + unit;
    }

    if (Array.isArray(this.value)) {
      return this.operand + " [" + this.value.join(", ") + "]";
    } else {
      return this.operand + " " + this.value;
    }
  }

  // getFinalDisplayedTitle(savedFilter: SavedFilter|null = null) {
  //   if(!savedFilter){
  //     return this.getDisplayedTitle();
  //   }else{
  //
  //   }
  //
  // }

  updateArrayTypeValue(value) {
    if (this.isEmpty) {
      this.value = Array.isArray(value) ? value : [value];
    } else if (Array.isArray(this.value)) {
      // This is array update
      this.value = this.value.includes(value)
        ? this.value.filter((i) => i !== value)
        : [...this.value, value];
    } else {
      this.value = [value];
    }
  }

  updateValue(value) {
    this.value = value;
  }
}

export class FinalFilters {
  finalFilters: FinalFilter[];

  constructor(filters: any = null) {
    this.finalFilters = [];
    if (filters && Array.isArray(filters)) {
      filters.forEach((item) => {
        this.finalFilters.push(new FinalFilter(item));
      });
    } else if (filters?.hasOwnProperty("finalFilters")) {
      filters.finalFilters.forEach((item) => {
        this.finalFilters.push(new FinalFilter(item));
      });
    }
  }

  // This method is to convert internal final filter to standard output,
  // this standard output will be fixed and not impacted
  getStandardOutput() {
    const filters: FinalFilter[] = [];

    this.finalFilters.forEach((f) => {
      if (f.operand === FilterOperand.Within) {
        //for within, we have to convert it to timestamp

        let count: number = 0;
        let unit = 0;

        if (f.value.toLocaleString().includes("d")) {
          unit = 3600 * 24; // 1 day
          count = Number(f.value.substring(0, f.value.toLowerCase().indexOf("d")));
        } else if (f.value.toLocaleString().includes("m")) {
          unit = 3600 * 24 * 30; // 1 month
          count = Number(f.value.substring(0, f.value.toLowerCase().indexOf("m")));
        } else {
          unit = 3600; // 1 hour
          count = Number(f.value.substring(0, f.value.toLowerCase().indexOf("h")));
        }

        filters.push(
          new FinalFilter({
            key: f.key,
            operand: FilterOperand.Within,
            value: unit * count * 1000,
          }),
        );
      } else {
        filters.push(new FinalFilter(f));
      }
    });

    return filters;
  }

  upsertFinalFilterOperandAndValueForDateRangeValue(
    filterItem: FilterItem,
    dateRangeValue: DateRangeValue | null,
  ) {
    this.upsertFinalFilterOperandAndValue(filterItem, FilterOperand.Between, [
      dateRangeValue?.start.toDate("UTC").getTime(),
      dateRangeValue?.end.toDate("UTC").getTime(),
    ]);

    return this;
  }

  upsertFinalFilterOperandAndValue(filterItem: FilterItem, operand: any, value: any) {
    const finalFilterItem = this.findFilterItemByKey(filterItem.key);

    if (finalFilterItem) {
      finalFilterItem.operand = operand;
      finalFilterItem.value = value;
    } else {
      this.finalFilters.push(
        new FinalFilter({
          key: filterItem.key,
          operand: operand,
          value: value,
        }),
      );
    }

    return this;
  }

  upsertFinalFilterOperand(filterItem: FilterItem, operand: any) {
    const finalFilterItem = this.findFilterItemByKey(filterItem.key);

    if (finalFilterItem) {
      finalFilterItem.operand = operand;
    } else {
      this.finalFilters.push(
        new FinalFilter({
          key: filterItem.key,
          operand: operand,
        }),
      );
    }

    return this;
  }

  upsertFinalFilterValue(filterItem: FilterItem, value: any) {
    const finalFilterItem = this.findFilterItemByKey(filterItem.key);

    if (finalFilterItem) {
      filterItem.type === FilterType.MULTI_SELECT
        ? finalFilterItem.updateArrayTypeValue(value)
        : finalFilterItem.updateValue(value);
    } else {
      this.finalFilters.push(
        new FinalFilter({
          key: filterItem.key,
          operand:
            filterItem.type === FilterType.MULTI_SELECT
              ? FilterOperand.Include
              : FilterOperand.Equal,
          value: filterItem.type === FilterType.MULTI_SELECT ? [value] : value,
        }),
      );
    }

    return this;
  }

  findFilterItemByKey(key: string) {
    const finalFilter = this.finalFilters.find((item) => item.key === key);

    return finalFilter;
  }

  // This is used for multi/single select
  getFilterValue(filterItem: FilterItem) {
    const getEmptyValueFor = (filterItem: FilterItem) => {
      switch (filterItem.type) {
        case FilterType.MULTI_SELECT:
          return [];
        case FilterType.SINGLE_SELECT:
        case FilterType.TEXT:
          return "";
        default:
          return "";
      }
    };

    const finalFilterItem = this.findFilterItemByKey(filterItem.key);

    if (finalFilterItem) {
      if (finalFilterItem.isEmpty) {
        return getEmptyValueFor(filterItem);
      } else {
        return finalFilterItem.value;
      }
    } else {
      return getEmptyValueFor(filterItem);
    }
  }

  getFilterValueAsDateRange(filtertItem: FilterItem): DateRangeValue | null {
    const finalFilterItem = this.findFilterItemByKey(filtertItem.key);

    if (finalFilterItem && finalFilterItem.operand === FilterOperand.Between) {
      // this is between only, and we can convert here
      // saved is timestamp
      return {
        start: convertToCalendarDateFromTimeStamp(finalFilterItem.value[0]),
        end: convertToCalendarDateFromTimeStamp(finalFilterItem.value[1]),
      };
    } else {
      return null;
    }
  }

  get clone() {
    const inst = new FinalFilters();

    inst.finalFilters = this.finalFilters;

    return inst;
  }

  // Available filters are all saved in filterConfig -> defaultFilters
  // we need to use it to udptate
  updateFinalFiltersWithFilterConfig(cfg: FilterConfig) {
    for (let i = this.finalFilters.length - 1; i >= 0; i--) {
      // Not global Search Key (it is not removable, passed in defaultFilters not including this global search key )
      if (
        this.finalFilters[i].key !== GLOBAL_SEARCH_KEY &&
        !cfg.defaultFilters.includes(this.finalFilters[i].key)
      ) {
        this.finalFilters.splice(i, 1);
      }
    }

    return this;
  }

  isFilterItemIncluded(filterItem: FilterItem): boolean {
    return !!this.finalFilters.find((finalFilter: FinalFilter) => {
      return finalFilter.key == filterItem.key;
    });
  }
}

export default FinalFilters;
