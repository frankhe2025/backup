import FilterItem from "./filter_item";
import FinalFilters from "./final_filters";
import {SavedFilter} from "./saved-filter";

export default interface FilterComponentInputType {
  filterItem: FilterItem;
  finalFilters: FinalFilters;
  setFinalFilters;
  savedFilter?: SavedFilter;
}
