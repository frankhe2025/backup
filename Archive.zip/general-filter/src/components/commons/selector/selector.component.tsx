import {useEffect, useState} from "react";
import {Popover, PopoverContent, PopoverTrigger} from "@aisera-ui/popover";
import {Button} from "@aisera-ui/button";
import {Input} from "@aisera-ui/input";
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from "@aisera-ui/select";
import {Checkbox} from "@aisera-ui/checkbox";
import {RadioGroupItem, RadioGroup} from "@aisera-ui/radio-group";
import {Icon} from "@iconify-icon/react";

import FilterComponentInputType from "../../../entities/fiter-component-input-type";
import {FilterOperand} from "../../../entities/final_filters";
import {FilterType, OptionItem} from "../../../entities/filter_item";
const SelectorComponent = (props: FilterComponentInputType) => {
  const FilterOperandIncExc: FilterOperand[] = [FilterOperand.Exclude, FilterOperand.Include];
  const [searchTerm, setSearchTerm] = useState("");
  const [popOpen, setPopOpen] = useState<boolean>(false);
  const [label, setLabel] = useState<string>("");
  let filteredItems: OptionItem[] = [];

  useEffect(() => {
    //we need to set up label based on passed in savedFilter
    if (props.savedFilter) {
      const newLable: any = props.savedFilter.finalFilters
        ?.findFilterItemByKey(props.filterItem.key)
        ?.getDisplayedTitle();

      setLabel(newLable);
    }
  }, []);

  if (props.filterItem.options && Array.isArray(props.filterItem.options)) {
    filteredItems = props.filterItem.options.filter((item) =>
      item.label.toLowerCase().includes(searchTerm.toLowerCase()),
    );
  }

  const toggleSelection = (item) => {
    props.setFinalFilters(props.finalFilters.upsertFinalFilterValue(props.filterItem, item).clone);
    updateLabel();
  };

  const changeSelectedOperantValue = (event) => {
    props.setFinalFilters(
      props.finalFilters.upsertFinalFilterOperand(props.filterItem, event).clone,
    );
    updateLabel();
  };

  const updateLabel = () => {
    const newLabel: any = props.finalFilters
      ?.findFilterItemByKey(props.filterItem.key)
      ?.getDisplayedTitle();

    setLabel(newLabel);
  };

  if (props.filterItem.type === FilterType.MULTI_SELECT) {
    return (
      <div>
        <Popover onOpenChange={(prev) => setPopOpen(!prev)}>
          <PopoverTrigger>
            <Button>
              {props.filterItem.label}: {label}
              <Icon icon={popOpen ? "mdi-light:chevron-down" : "mdi-light:chevron-up"} />
            </Button>
          </PopoverTrigger>
          <PopoverContent className={"items-start"}>
            <Input
              className={"mb-2"}
              data-testid={"searchingInput"}
              placeholder={"Searching.."}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <div className="mb-2">
              <Select onValueChange={changeSelectedOperantValue}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="" />
                </SelectTrigger>
                <SelectContent>
                  {FilterOperandIncExc.map((item: any) => {
                    return (
                      <SelectItem key={item} value={item}>
                        {item}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            <div className="mb-2">
              <Select
                data-testid="operand-selector"
                defaultValue={
                  props.finalFilters.findFilterItemByKey(props.filterItem.key)?.operand ??
                  FilterOperand.Include
                }
                onValueChange={changeSelectedOperantValue}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select operand" />
                </SelectTrigger>
                <SelectContent>
                  {FilterOperandIncExc.map((item: any) => {
                    return (
                      <SelectItem key={item} value={item}>
                        {item}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            {filteredItems.map((option: OptionItem) => {
              return (
                <div key={option.value} className="flex flex-row gap-2 items-center">
                  <Checkbox
                    key={option.value}
                    data-testid="selector-option-item"
                    defaultChecked={props.finalFilters
                      .getFilterValue(props.filterItem)
                      .includes(option.value)}
                    id={option.label}
                    onChange={() => toggleSelection(option.value)}
                  >
                    {option.label}
                  </Checkbox>
                  <label htmlFor={option.label}>{option.label}</label>
                </div>
              );
            })}
          </PopoverContent>
        </Popover>
      </div>
    );
  }

  return (
    <div>
      <Popover>
        <PopoverTrigger>
          <Button>
            {props.filterItem.label}:
            {props.finalFilters?.findFilterItemByKey(props.filterItem.key)?.getDisplayedTitle()}
          </Button>
        </PopoverTrigger>
        <PopoverContent className={"items-start"}>
          <RadioGroup
            value={props.finalFilters.getFilterValue(props.filterItem)}
            // onChange={toggleSelection}
            onValueChange={toggleSelection}
          >
            {filteredItems.map((option: OptionItem) => {
              return (
                <div key={option.value} className="flex flex-row gap-2 items-center">
                  <RadioGroupItem
                    key={option.value}
                    data-testid="selector-option-item-single"
                    id={option.value}
                    value={option.value}
                  >
                    {option.label}
                  </RadioGroupItem>
                  <label htmlFor={option.value}>{option.value}</label>
                </div>
              );
            })}
          </RadioGroup>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default SelectorComponent;
