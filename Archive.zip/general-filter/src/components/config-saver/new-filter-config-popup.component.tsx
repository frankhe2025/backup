import {DialogFooter, DialogHeader} from "@aisera-ui/dialog";
import {Input} from "@aisera-ui/input";
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from "@aisera-ui/select";
import {Button} from "@aisera-ui/button";
import {useState} from "react";

const NewFilterConfigPopupComponent = ({onClose, onConfirm}) => {
  const [name, setName] = useState<string>("");
  const [scope, setScope] = useState<string>("private");
  const confirm = () => {
    onConfirm({name, scope});
    onClose();
  };

  return (
    <>
      <DialogHeader className="flex flex-col gap-1" data-testid={"new-filter-model-header"}>
        New Filter
      </DialogHeader>
      <div>
        <div className="w-full flex flex-col gap-y-2">
          <div>
            This will save the current values into a new filter. Please enter the filter name.
          </div>
          <div className={"grid grid-cols-3 gap-2"}>
            <div>Name</div>
            <div className="col-span-2">
              <Input
                className="max-w-xs w-full"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className={"flex items-center gap-2"}>Scope</div>
            <div className="col-span-2">
              <Select defaultValue={scope} onValueChange={(scope: any) => setScope(scope)}>
                <SelectTrigger className="max-w-xs w-full">
                  <SelectValue placeholder="Theme" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={"private"}>Private</SelectItem>
                  <SelectItem value={"public"}>Public</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>
      <DialogFooter>
        <Button variant="destructive" onClick={onClose}>
          Cancel
        </Button>
        <Button onClick={confirm}>Confirm</Button>
      </DialogFooter>
    </>
  );
};

export default NewFilterConfigPopupComponent;
