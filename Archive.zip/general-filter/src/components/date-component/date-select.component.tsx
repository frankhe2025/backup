import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from "@aisera-ui/select";
import {Dialog, DialogContent, DialogFooter, DialogHeader} from "@aisera-ui/dialog";
import {Button} from "@aisera-ui/button";
// import {DateRangePicker} from "@aisera-ui/date-picker";
import {useEffect, useState} from "react";
import {useDisclosure} from "@aisera-ui/use-disclosure";

import {OptionItem} from "../../entities/filter_item";
import FilterComponentInputType from "../../entities/fiter-component-input-type";
import {DateRangeValue, FilterOperand} from "../../entities/final_filters";

// Define the correct type manually

const DateSelectComponent = (props: FilterComponentInputType) => {
  const {isOpen, onOpen, onOpenChange, onClose} = useDisclosure();
  const [label, setLabel] = useState<string>("");
  const [dateRangeValue] = useState<DateRangeValue | null>(
    props.finalFilters.getFilterValueAsDateRange(props.filterItem),
  );

  useEffect(() => {
    //we need to set up label based on passed in savedFilter
    if (props.savedFilter) {
      const newLable: any = props.savedFilter.finalFilters
        ?.findFilterItemByKey(props.filterItem.key)
        ?.getDisplayedTitle();

      setLabel(newLable);
    }
  }, []);
  const updateLabel = () => {
    const newLabel: any = props.finalFilters
      ?.findFilterItemByKey(props.filterItem.key)
      ?.getDisplayedTitle();

    setLabel(newLabel);
  };

  const onConfirm = (cb) => {
    props.setFinalFilters(
      props.finalFilters.upsertFinalFilterOperandAndValueForDateRangeValue(
        props.filterItem,
        dateRangeValue,
      ).clone,
    );
    cb();
  };

  const selectionChanged = (e) => {
    if (e === "-1") {
      onOpen();
    } else {
      if (props.filterItem.options) {
        props.setFinalFilters(
          props.finalFilters.upsertFinalFilterOperandAndValue(
            props.filterItem,
            FilterOperand.Within,
            props.filterItem.options[Number(e)].value,
          ).clone,
        );
        updateLabel();
      }
    }
  };

  return (
    <div className={"flex w-[280px] flex-wrap md:flex-nowrap gap-4"}>
      <Select
        data-testid={"dateselector-trigger-btn"}
        // renderValue={renderValue}
        onValueChange={selectionChanged}
      >
        <SelectTrigger className="w-full">
          <SelectValue placeholder={props.filterItem.label + ": " + label} />
        </SelectTrigger>
        <SelectContent>
          {
            props.filterItem.options?.map((option: OptionItem, key: number) => {
              return (
                <SelectItem key={key} data-testid={"dateselector-option-item"} value={String(key)}>
                  {option.label}
                </SelectItem>
              );
            }) as any
          }

          <SelectItem
            className={"border-t-1"}
            data-testid={"dateselector-option-custom-item"}
            value={"-1"}
          >
            Custom Range
          </SelectItem>
        </SelectContent>
      </Select>
      <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent>
          <DialogHeader
            className="flex flex-col gap-1"
            data-testid={"dateselector-custom-model-header"}
          >
            Select custom range
          </DialogHeader>
          <div>
            <div className="w-full flex flex-col gap-y-2">
              {/* <DateRangePicker
                label="Date range (controlled)"
                value={dateRangeValue}
                onChange={(range: RangeValue<CalendarDate> | null) => {
                  setDateRangeValue(range);
                }}
              /> */}
            </div>
          </div>
          <DialogFooter>
            <Button variant="destructive" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={() => onConfirm(onClose)}>Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DateSelectComponent;
