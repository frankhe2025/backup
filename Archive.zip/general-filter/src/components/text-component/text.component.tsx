import {Input} from "@aisera-ui/input";
import {useEffect, useState} from "react";

import FilterComponentInputType from "../../entities/fiter-component-input-type";
import {FilterOperand} from "../../entities/final_filters";

const TextComponent = (props: FilterComponentInputType) => {
  const [label, setLabel] = useState<string>("");

  useEffect(() => {
    //we need to set up label based on passed in savedFilter
    if (props.savedFilter) {
      const newLable: any = props.savedFilter.finalFilters
        ?.findFilterItemByKey(props.filterItem.key)
        ?.getDisplayedTitle();

      setLabel(newLable);
    }
  }, []);
  const updateLabel = () => {
    const newLabel: any = props.finalFilters
      ?.findFilterItemByKey(props.filterItem.key)
      ?.getDisplayedTitle();

    setLabel(newLabel);
  };
  const updateSearch = (value) => {
    props.setFinalFilters(
      props.finalFilters.upsertFinalFilterOperandAndValue(
        props.filterItem,
        FilterOperand.LIKE,
        value,
      ).clone,
    );
    updateLabel();
  };

  return (
    <div className={"flex items-center gap-2 w-max"} style={{height: "38px"}}>
      <label className="flex-shrink-0" htmlFor={props.filterItem.label}>
        {props.filterItem.label}
      </label>
      <Input
        data-testid={"text-component-input"}
        id={props.filterItem.label}
        // endContent={<Icon icon="mdi-light:magnify" />}
        value={label}
        onChange={(e) => updateSearch(e.target.value)}
      />
    </div>
  );
};

export default TextComponent;
