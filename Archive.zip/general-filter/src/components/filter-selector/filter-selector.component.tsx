import {Popover, PopoverContent, PopoverTrigger} from "@aisera-ui/popover";
import {Button} from "@aisera-ui/button";
import {Checkbox} from "@aisera-ui/checkbox";

import FilterItem from "../../entities/filter_item";
import {SavedFilter} from "../../entities/saved-filter";
import FilterConfig from "../../entities/filter_config";
import FinalFilters from "../../entities/final_filters";

export interface FilterSelectorPropType {
  setFilterConfig: any; //Setter
  filterConfig: FilterConfig; // State
  finalFilters: FinalFilters; // State
  savedFilter: SavedFilter; // State
  setSavedFilter: any; // setter
  setFinalFilters: any; //setter
}

const FilterSelectorComponent = (props: FilterSelectorPropType) => {
  const toggleSelection = (filterItem: FilterItem) => {
    if (props.savedFilter) {
      // if this is from saved filter, we need to edit it
      props.setSavedFilter(() => {
        props.savedFilter.toggleFinalFiltersWithFilterItem(filterItem);

        return props.savedFilter.clone();
      });
    } else {
      props.setFilterConfig(() => {
        const cfg = props.filterConfig.toggleDefaultFilters(filterItem).clone;

        //Now we still need to update final filters
        props.finalFilters.updateFinalFiltersWithFilterConfig(cfg);

        return cfg;
      });
    }
  };

  return (
    <div>
      <Popover>
        <PopoverTrigger>
          <Button>Filters</Button>
        </PopoverTrigger>

        <PopoverContent className="flex flex-col items-start gap-2">
          {props.filterConfig.filterItems.map((filterItem: FilterItem) => {
            return (
              <div key={filterItem.key} className="flex flex-row gap-2 items-center">
                <Checkbox
                  key={filterItem.key}
                  data-testid={"filter-selector-checkbox"}
                  defaultChecked={
                    props.savedFilter
                      ? props.savedFilter.isFilterItemSelected(filterItem)
                      : props.filterConfig.isFilterItemInUse(filterItem)
                  }
                  id={filterItem.key}
                  onCheckedChange={() => {
                    toggleSelection(filterItem);
                  }}
                >
                  {filterItem.label}
                </Checkbox>
                <label htmlFor={filterItem.key}>{filterItem.label}</label>
              </div>
            );
          })}
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default FilterSelectorComponent;
