import FilterConfig from "./entities/filter_config";
export default FilterConfig;

export {FilterConfig};

export * from "./general-filter.component";
export * from "./entities/final_filters";
export * from "./entities/filter_item";
export * from "./entities/filter_config";
