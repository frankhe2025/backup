import {Icon} from "@iconify-icon/react";
import {useState} from "react";
import {wait} from "@aisera-ui/utils";

import FilterConfig, {GLOBAL_SEARCH_KEY} from "./entities/filter_config";
import FilterItem, {FilterType} from "./entities/filter_item";
import TextComponent from "./components/text-component/text.component";
import DateSelectComponent from "./components/date-component/date-select.component";
import DateTimeSelectComponent from "./components/datetime-component/datetime-select.component";
import NumericComponent from "./components/numeric-component/numeric.component";
import FinalFilters from "./entities/final_filters";
import SelectorComponent from "./components/commons/selector/selector.component";
import FilterSelectorComponent from "./components/filter-selector/filter-selector.component";
import ConfigSaverComponent from "./components/config-saver/config-saver.component";
import {SavedFilter} from "./entities/saved-filter";
import {SavedFilters} from "./entities/saved-filters";

export interface GeneralFilterAtt {
  filterConfig: FilterConfig; // State
  setFilterConfig: any; // setter
  finalFilters: FinalFilters; // State for
  setFinalFilters: any; // Setter
  saveable?: boolean;
  savedFilters?: SavedFilter[];
  onSaveNewFilter?: any;
  onSavedFilterUpdated?: any;
  onSavedfilterSelected?: any;
  currentUserId?: any;
}

const GeneralFilterComponent = ({
  filterConfig,
  setFilterConfig,
  finalFilters,
  setFinalFilters,
  saveable = true,
  savedFilters = [],
  onSaveNewFilter = null,
  onSavedFilterUpdated = null,
  onSavedfilterSelected = null,
  currentUserId = null,
}: GeneralFilterAtt) => {
  const [savedFilter, setSavedFilter] = useState<SavedFilter | null>(null);
  const [showingFilter, setShowingFilter] = useState<boolean>(true);

  const refresh = async () => {
    setShowingFilter(false);
    await wait(0);

    setShowingFilter(true);
  };
  const toggleSelection = async (filterItem: FilterItem) => {
    await refresh();
    if (!savedFilter) {
      setFilterConfig(() => {
        const cfg = filterConfig.toggleDefaultFilters(filterItem).clone;

        //Now we still need to update final filters, and update state
        setFinalFilters(finalFilters.updateFinalFiltersWithFilterConfig(cfg).clone);

        return cfg;
      });
    } else {
      //IF user already selected saved filter
      setSavedFilter((prevState: any) => {
        prevState.toggleFinalFiltersWithFilterItem(filterItem);

        //new we need to update final finals to trigger filter updates
        return prevState.clone();
      });
    }
  };

  const onNewFilterSaved = ({name, scope}) => {
    if (onSaveNewFilter) {
      onSaveNewFilter(new SavedFilter({name, scope, finalFilters}));
    }
  };

  const onFilterUpdated = async (savedFilters: SavedFilters) => {
    await refresh();
    if (onSavedFilterUpdated) {
      onSavedFilterUpdated(savedFilters.savedFilters);
    }
  };
  const onFilterSelected = async (savedFilter: SavedFilter) => {
    await refresh();
    setSavedFilter(savedFilter);
    if (onSavedfilterSelected) {
      onSavedfilterSelected(savedFilter);
    }
  };

  return (
    <>
      {saveable && (
        <ConfigSaverComponent
          currentUserId={currentUserId}
          savedFilters={savedFilters}
          onFilterSelected={onFilterSelected}
          onFilterUpdated={onFilterUpdated}
          onNewFilterSaved={onNewFilterSaved}
        />
      )}
      {showingFilter &&
        filterConfig.getAllFiltersInUseWithSaveFilterConfig(savedFilter).map((item: FilterItem) => {
          let CMP;

          switch (item.type) {
            case FilterType.SINGLE_SELECT:
            case FilterType.MULTI_SELECT:
              CMP = SelectorComponent;
              break;
            case FilterType.TEXT:
              CMP = TextComponent;
              break;
            case FilterType.DATE:
              CMP = DateSelectComponent;
              break;
            case FilterType.DATETIME:
              CMP = DateTimeSelectComponent;
              break;
            case FilterType.NUMERIC:
              CMP = NumericComponent;
              break;
          }

          return (
            <div key={item.key} className={"relative  cursor-pointer group"}>
              <CMP
                key={item.key}
                filterItem={item}
                finalFilters={finalFilters}
                savedFilter={savedFilter}
                setFinalFilters={setFinalFilters}
              />
              {item.key !== GLOBAL_SEARCH_KEY && (
                <div
                  className={
                    "absolute z-10 right-0 -top-2 translate-x-1/4 -translate-y-1/4 hidden group-hover:block "
                  }
                  data-testid={"general-filter-item-close"}
                  role="button"
                  tabIndex={0}
                  onClick={() => toggleSelection(item)}
                  onKeyDown={() => toggleSelection(item)}
                >
                  <Icon icon="line-md:close-circle" />
                </div>
              )}
            </div>
          );
        })}
      <FilterSelectorComponent
        filterConfig={filterConfig}
        finalFilters={finalFilters}
        savedFilter={savedFilter as SavedFilter}
        setFilterConfig={setFilterConfig}
        setFinalFilters={setFilterConfig}
        setSavedFilter={setSavedFilter}
      />
    </>
  );
};

export default GeneralFilterComponent;
