# @aisera-ui/general-filter

A Quick description of the component

## Installation

```sh
yarn add @aisera-ui/general-filter
# or
npm i @aisera-ui/general-filter
# or
pnpm add @aisera-ui/general-filter
```