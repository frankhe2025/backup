// ... existing code ...
  build: {
    lib: {
      entry: [
        path.resolve(__dirname, "src/index.ts"),
        path.resolve(__dirname, "src/index.css"),
      ],
      name: "@frankhe/shadcn-lib",
      fileName: (format, entryName) => {
        if (entryName === "index") {
          return `index.${format}.js`;
        }
        return `${entryName}.${format}.js`;
      },
    },
    rollupOptions: {
// ... existing code ...
