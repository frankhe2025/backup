import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import '@frankhe/shadcn-lib/styles'
import FlowDemoComponent from './flow-demo/flow-demo.component';
import App from "./App.tsx";

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    {/*<FlowDemoComponent />*/}
      <App/>
  </StrictMode>,
)
