import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite';
import tsconfigPaths from 'vite-tsconfig-paths'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tsconfigPaths(), tailwindcss(),],
  resolve: {
    alias: {
      "@/components": `${process.cwd()}/node_modules/@frankhe/shadcn-lib/dist/components`,
      "@/hooks": `${process.cwd()}/node_modules/@frankhe/shadcn-lib/dist/hooks`,
      "@/lib": `${process.cwd()}/node_modules/@frankhe/shadcn-lib/dist/lib`,
      "@": `${process.cwd()}/src`,
    },
  },
})
