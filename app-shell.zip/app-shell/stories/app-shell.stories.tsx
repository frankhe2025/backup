import React from "react";
import {Meta} from "@storybook/react";

import {AppShell, AppShellProps} from "../src";

import {DemoSidebar} from "./DemoSidebar";
import {DemoNavbar} from "./DemoNavbar";
import {DemoFooter} from "./DemoFooter";
import {DemoMain} from "./DemoMain";

export default {
  title: "Advanced Components/AppShell",
  component: AppShell,
  argTypes: {
    navbar: {control: false},
    sidebar: {control: false},
    aside: {control: false},
    footer: {control: false},
    children: {control: false},
    mainRef: {control: false},
  },
} as Meta<typeof AppShell>;

const defaultProps = {
  navbar: <DemoNavbar />,
  sidebar: <DemoSidebar />,
  aside: <DemoSidebar />,
  footer: <DemoFooter />,
  children: <DemoMain />,
  mainRef: React.createRef<HTMLDivElement>(),
};

const Template = (args: AppShellProps) => <AppShell {...args} />;

export const Default = {
  render: Template,
  args: {
    ...defaultProps,
  },
};

export const HeaderAndFooter = {
  render: Template,
  args: {
    ...defaultProps,
    sidebar: undefined,
    aside: undefined,
  },
};

export const SidebarOnly = {
  render: Template,
  args: {
    ...defaultProps,
    navbar: undefined,
    aside: undefined,
    footer: undefined,
  },
};

export const AsideOnly = {
  render: Template,
  args: {
    ...defaultProps,
    navbar: undefined,
    sidebar: undefined,
    footer: undefined,
  },
};

export const MainOnly = {
  render: Template,
  args: {
    ...defaultProps,
    navbar: undefined,
    sidebar: undefined,
    aside: undefined,
    footer: undefined,
  },
};
