import {Button} from "@aisera-ui/button";
import {Icon} from "@iconify/react";

import {useAppShellContext} from "../src/app-shell-context";

export const DemoMain = () => {
  const {toggleSidebar} = useAppShellContext();

  return (
    <>
      <div className="flex items-center gap-x-3">
        <Button isIconOnly className="sm:hidden" size="sm" variant="flat" onPress={toggleSidebar}>
          <Icon className="text-default-500" icon="solar:sidebar-minimalistic-linear" width={20} />
        </Button>
        <h1 className="text-3xl font-bold leading-9 text-default-foreground">Settings</h1>
      </div>
      <h2 className="mt-2 text-small text-default-500">
        Customize settings, email preferences, and web appearance.
      </h2>
    </>
  );
};
