import * as React from "react";
import {render, screen} from "@testing-library/react";

import {AppShell} from "../src";

describe("AppShell", () => {
  it("should render correctly", () => {
    const wrapper = render(<AppShell>Main Content</AppShell>);

    expect(() => wrapper.unmount()).not.toThrow();
  });

  it("ref should be forwarded", () => {
    const ref = React.createRef<HTMLDivElement>();

    render(<AppShell ref={ref}>Main Content</AppShell>);
    expect(ref.current).not.toBeNull();
  });

  it("passed component should render", () => {
    render(
      <AppShell
        aside={<div>Aside</div>}
        footer={<div>Footer</div>}
        navbar={<div>Navbar</div>}
        sidebar={<div>Sidebar</div>}
      >
        Main Content
      </AppShell>,
    );

    expect(screen.getByText("Navbar")).toBeInTheDocument();
    expect(screen.getByText("Sidebar")).toBeInTheDocument();
    expect(screen.getByText("Aside")).toBeInTheDocument();
    expect(screen.getByText("Footer")).toBeInTheDocument();
    expect(screen.getByText("Main Content")).toBeInTheDocument();
  });
});
